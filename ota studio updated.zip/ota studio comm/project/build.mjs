import { build } from 'esbuild';
import { cpSync, readFileSync, writeFileSync, mkdirSync, rmSync } from 'fs';
import { execSync } from 'child_process';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const distDir = resolve(__dirname, 'dist');

// Clean dist
rmSync(distDir, { recursive: true, force: true });
mkdirSync(distDir, { recursive: true });
mkdirSync(resolve(distDir, 'assets'), { recursive: true });

// 1. Build JS with esbuild (code-split)
console.log('Building JS with esbuild...');
await build({
  entryPoints: [resolve(__dirname, 'src/main.tsx')],
  bundle: true,
  minify: true,
  sourcemap: false,
  format: 'esm',
  target: ['es2020'],
  outdir: resolve(distDir, 'assets'),
  entryNames: 'index',
  splitting: true,
  chunkNames: 'chunks/[name]-[hash]',
  jsx: 'automatic',
  define: {
    'process.env.NODE_ENV': '"production"',
  },
  logLevel: 'info',
  plugins: [{
    name: 'ignore-css',
    setup(build) {
      build.onResolve({ filter: /\.css$/ }, args => ({ path: args.path, namespace: 'ignore' }));
      build.onLoad({ filter: /\.css$/, namespace: 'ignore' }, () => ({ contents: '' }));
    },
  }],
});

// 2. Build Tailwind CSS separately
console.log('Building CSS with Tailwind...');
execSync('npx tailwindcss -i ./src/index.css -o ./dist/assets/index.css --minify', {
  cwd: __dirname,
  stdio: 'inherit',
});

// 3. Copy public assets
console.log('Copying public assets...');
try {
  cpSync(resolve(__dirname, 'public'), distDir, { recursive: true, dereference: true });
} catch {
  // some files may already exist
}

// 4. Process index.html - find the generated JS entry and reference it
console.log('Processing index.html...');
let html = readFileSync(resolve(__dirname, 'index.html'), 'utf-8');
html = html.replace(
  '<script type="module" src="/src/main.tsx"></script>',
  '<link rel="stylesheet" href="/assets/index.css" />\n  <script type="module" src="/assets/index.js"></script>'
);
writeFileSync(resolve(distDir, 'index.html'), html);

// 5. SPA redirect for client-side routing
writeFileSync(resolve(distDir, '_redirects'), '/* /index.html 200\n');

console.log('Build complete!');
