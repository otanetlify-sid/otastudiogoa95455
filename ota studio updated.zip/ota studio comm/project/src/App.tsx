import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { useEffect, lazy, Suspense } from 'react';
import Header from './components/Header';
import HeroDualAudience from './components/HeroDualAudience';
import OtaDashboardHero from './components/OtaDashboardHero';
import SmoothScroll from './components/SmoothScroll';
import ScrollNetworkOverlay from './components/ScrollNetworkOverlay';
import Footer from './components/Footer';
import FloatingContact from './components/FloatingContact';
import OtaManagementGoa from './pages/OtaManagementGoa';
import OtaOnboardingGoa from './pages/OtaOnboardingGoa';
import HotelMarketingGoa from './pages/HotelMarketingGoa';
import AirbnbManagementGoa from './pages/AirbnbManagementGoa';
import HotelDistributionGoa from './pages/HotelDistributionGoa';
import HospitalityActivationGoa from './pages/HospitalityActivationGoa';
import HospitalityActivationsGoa from './pages/HospitalityActivationsGoa';
import CommunityActivationGoa from './pages/CommunityActivationGoa';
import CommunityEventsGoa from './pages/CommunityEventsGoa';
import RestaurantMarketingGoa from './pages/RestaurantMarketingGoa';
import CafeMarketingGoa from './pages/CafeMarketingGoa';
import BarNightlifeMarketingGoa from './pages/BarNightlifeMarketingGoa';
import BarMarketingGoa from './pages/BarMarketingGoa';
import WellnessActivationGoa from './pages/WellnessActivationGoa';
import WellnessEventsGoa from './pages/WellnessEventsGoa';
import VenueActivationsGoa from './pages/VenueActivationsGoa';
import PartnerNetworkPage from './pages/PartnerNetworkPage';
import TechnologyPartners from './pages/TechnologyPartners';
import ActivationPartners from './pages/ActivationPartners';
import VenuePartners from './pages/VenuePartners';
import BlogPage from './pages/BlogPage';
import PrivacyPolicy from './pages/PrivacyPolicy';
import TermsConditions from './pages/TermsConditions';
import BookingComManagementGoa from './pages/BookingComManagementGoa';
import MakeMyTripManagementGoa from './pages/MakeMyTripManagementGoa';
import GoibiboManagementGoa from './pages/GoibiboManagementGoa';
import ExpediaManagementGoa from './pages/ExpediaManagementGoa';
import AgodaManagementGoa from './pages/AgodaManagementGoa';
import HostelworldManagementGoa from './pages/HostelworldManagementGoa';
import PropertyManagementGoa from './pages/PropertyManagementGoa';
import Founders from './pages/Founders';
import VisionMission from './pages/VisionMission';
import OtaStrategyInsights from './pages/OtaStrategyInsights';
import HowToStartAirbnbInGoa from './pages/HowToStartAirbnbInGoa';
import HowToStartHotelInGoa from './pages/HowToStartHotelInGoa';
import HowToStartVillaInGoa from './pages/HowToStartVillaInGoa';
import HowToStartHostelInGoa from './pages/HowToStartHostelInGoa';
import HowToStartCafeInGoa from './pages/HowToStartCafeInGoa';
import HowToStartBarInGoa from './pages/HowToStartBarInGoa';
import HowToStartRestaurantInGoa from './pages/HowToStartRestaurantInGoa';
import HowToStartResortInGoa from './pages/HowToStartResortInGoa';
import HowToStartGuestHouseInGoa from './pages/HowToStartGuestHouseInGoa';
import HowToGetTourismLicenseInGoa from './pages/HowToGetTourismLicenseInGoa';
import HotelLicenseRequirementsGoa from './pages/HotelLicenseRequirementsGoa';
import AirbnbRulesInGoa from './pages/AirbnbRulesInGoa';
import BestBusinessIdeasInGoaTourism from './pages/BestBusinessIdeasInGoaTourism';
import CommunityManagementGoa from './pages/CommunityManagementGoa';
import CommunityGrowthForRestaurants from './pages/CommunityGrowthForRestaurants';
import CommunityGrowthForCafes from './pages/CommunityGrowthForCafes';
import BarGrowthGoa from './pages/BarGrowthGoa';
import NightlifeGrowthGoa from './pages/NightlifeGrowthGoa';
import LiveMusicEventsGoa from './pages/LiveMusicEventsGoa';
import YogaEventsGoa from './pages/YogaEventsGoa';
import SoundHealingGoa from './pages/SoundHealingGoa';
import ReikiEventsGoa from './pages/ReikiEventsGoa';
import CreativeWorkshopsGoa from './pages/CreativeWorkshopsGoa';
import CulturalExperiencesGoa from './pages/CulturalExperiencesGoa';
import HospitalityCommunityBuildingGoa from './pages/HospitalityCommunityBuildingGoa';
import CommunityManagersNetwork from './pages/CommunityManagersNetwork';
import EventOrganizersNetwork from './pages/EventOrganizersNetwork';
import VenueActivationGoa from './pages/VenueActivationGoa';
import HowToOrganizeEventsInGoa from './pages/HowToOrganizeEventsInGoa';
import HowToBuildACommunityInGoa from './pages/HowToBuildACommunityInGoa';
import HowToHostYogaRetreatsInGoa from './pages/HowToHostYogaRetreatsInGoa';
import HowToStartAYogaSchoolInGoa from './pages/HowToStartAYogaSchoolInGoa';
import HowToOrganizeWellnessEventsInGoa from './pages/HowToOrganizeWellnessEventsInGoa';
import HowToOrganizeLiveMusicEventsInGoa from './pages/HowToOrganizeLiveMusicEventsInGoa';
import HowToRunCommunityEventsForCafes from './pages/HowToRunCommunityEventsForCafes';
import HowToRunCommunityEventsForRestaurants from './pages/HowToRunCommunityEventsForRestaurants';
import GrowBookingsBuildCommunities from './components/GrowBookingsBuildCommunities';
import CommandCenter from './components/CommandCenter';
import OtaStudioEcosystem from './components/OtaStudioEcosystem';
import HospitalityTimeline from './components/HospitalityTimeline';

// Lazy-loaded below-fold homepage sections
const LazyOtaCommunitySplit = lazy(() => import('./components/OtaCommunitySplit'));
const LazyDecisionPathway = lazy(() => import('./components/DecisionPathway'));
const LazyHero = lazy(() => import('./components/Hero'));
const LazyServices = lazy(() => import('./components/Services'));
const LazyOTAsSupported = lazy(() => import('./components/OTAsSupported'));
const LazyPropertyTypes = lazy(() => import('./components/PropertyTypes'));
const LazyWhyChooseUs = lazy(() => import('./components/WhyChooseUs'));
const LazyFAQ = lazy(() => import('./components/FAQ'));
const LazyCTA = lazy(() => import('./components/CTA'));
const LazyContact = lazy(() => import('./components/Contact'));
const LazyBeyondOTA = lazy(() => import('./components/BeyondOTA'));
const LazyOtaEcosystem = lazy(() => import('./components/OtaEcosystem'));
const LazyBeyondOtaGrowth = lazy(() => import('./components/BeyondOtaGrowth'));
const LazyCommunityDashboard = lazy(() => import('./components/CommunityDashboard'));
const LazyHospitalityActivations = lazy(() => import('./components/HospitalityActivations'));
const LazyNeedMoreFootfall = lazy(() => import('./components/NeedMoreFootfall'));
const LazyOtaStudioNetwork = lazy(() => import('./components/OtaStudioNetwork'));
const LazyOtaStudioNetworkSection = lazy(() => import('./components/OtaStudioNetworkSection'));
const LazyPartnerBenefits = lazy(() => import('./components/PartnerBenefits'));
const LazyActivationHero = lazy(() => import('./components/ActivationHero'));
const LazyActivationSplit = lazy(() => import('./components/ActivationSplit'));
const LazyPartnerNetwork = lazy(() => import('./components/PartnerNetwork'));
const LazyRequestActivation = lazy(() => import('./components/RequestActivation'));
const LazyMarketPositioning = lazy(() => import('./components/MarketPositioning'));
import HowToRunCommunityEventsForBars from './pages/HowToRunCommunityEventsForBars';
import HowToCreateHospitalityExperiencesInGoa from './pages/HowToCreateHospitalityExperiencesInGoa';
import HowToStartHomestayInGoa from './pages/HowToStartHomestayInGoa';
import HowToStartBeachClubInGoa from './pages/HowToStartBeachClubInGoa';
import HowToStartWellnessRetreatInGoa from './pages/HowToStartWellnessRetreatInGoa';
import HowToStartCommunityEventsInGoa from './pages/HowToStartCommunityEventsInGoa';
import HowToStartLiveMusicEventsInGoa from './pages/HowToStartLiveMusicEventsInGoa';
import HowToStartAHospitalityBusinessInGoa from './pages/HowToStartAHospitalityBusinessInGoa';
import CommunityEventsForHotelsGoa from './pages/CommunityEventsForHotelsGoa';
import RestaurantEventIdeasGoa from './pages/RestaurantEventIdeasGoa';
import HospitalityNetworkingEventsGoa from './pages/HospitalityNetworkingEventsGoa';
import LiveMusicForHospitalityGoa from './pages/LiveMusicForHospitalityGoa';
import CafeCommunityBuildingGoa from './pages/CafeCommunityBuildingGoa';
import WellnessTourismGoa from './pages/WellnessTourismGoa';
import CookiePolicy from './pages/CookiePolicy';
import HospitalityGrowthGoa from './pages/HospitalityGrowthGoa';
import HotelOnboardingGoa from './pages/HotelOnboardingGoa';
import NotFound from './pages/NotFound';
import useSEO from './hooks/useSEO';
import pageConfig from './pageConfig';
import TrustSection from './components/TrustSection';
import CtaSystem from './components/CtaSystem';

function RouteSEO() {
  const location = useLocation();
  const seo = pageConfig[location.pathname];
  useSEO(seo ? {
    title: seo.title,
    description: seo.description,
    canonical: seo.canonical,
    schemaType: seo.schemaType,
    breadcrumbs: seo.breadcrumbs,
  } : {
    title: 'The OTA Studio | OTA Growth + Hospitality Activations',
    description: 'OTA Studio helps hospitality brands grow through OTA onboarding, distribution management, community experiences and hospitality activations across Goa.',
    canonical: 'https://otastudio.in' + location.pathname,
  });

  return null;
}

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  return null;
}

function HomePage() {
  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <ScrollNetworkOverlay />
      <main>
        {/* 1. Hero — left-aligned SaaS layout with dual audience cards */}
        <HeroDualAudience />

        {/* 2. OTA Studio Intelligence Dashboard — proof of expertise */}
        <OtaDashboardHero />

        {/* 3. Why OTA Studio — bridge section */}
        <GrowBookingsBuildCommunities />

        {/* 4. Hospitality Ecosystem — command center */}
        <CommandCenter />

        {/* 5. Ecosystem Framework */}
        <OtaStudioEcosystem />

        {/* 6. Growth Timeline */}
        <HospitalityTimeline />

        {/* 7. Trust & Credibility */}
        <TrustSection />

        {/* 8. CTA Hierarchy */}
        <CtaSystem />

        {/* Below-fold sections — lazy loaded */}
        <Suspense fallback={null}>
          <LazyServices />
          <LazyOTAsSupported />
          <LazyPropertyTypes />
          <LazyWhyChooseUs />
          <LazyBeyondOTA />
          <LazyHospitalityActivations />
          <LazyCommunityDashboard />
          <LazyBeyondOtaGrowth />
          <LazyOtaEcosystem />
          <LazyNeedMoreFootfall />
          <LazyOtaStudioNetworkSection />
          <LazyPartnerBenefits />
          <LazyActivationHero />
          <LazyActivationSplit />
          <LazyPartnerNetwork />
          <LazyRequestActivation />
          <LazyMarketPositioning />
          <LazyOtaCommunitySplit />
          <LazyDecisionPathway />
          <LazyOtaStudioNetwork />
          <LazyFAQ />
          <LazyCTA />
          <LazyContact />
          <LazyHero />
        </Suspense>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <SmoothScroll />
      <RouteSEO />
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/ota-management-goa" element={<OtaManagementGoa />} />
        <Route path="/ota-onboarding-goa" element={<OtaOnboardingGoa />} />
        <Route path="/hotel-marketing-goa" element={<HotelMarketingGoa />} />
        <Route path="/airbnb-management-goa" element={<AirbnbManagementGoa />} />
        <Route path="/hotel-distribution-goa" element={<HotelDistributionGoa />} />
        <Route path="/hospitality-activation-goa" element={<HospitalityActivationGoa />} />
        <Route path="/hospitality-activations-goa" element={<HospitalityActivationsGoa />} />
        <Route path="/community-activation-goa" element={<CommunityActivationGoa />} />
        <Route path="/community-events-goa" element={<CommunityEventsGoa />} />
        <Route path="/restaurant-marketing-goa" element={<RestaurantMarketingGoa />} />
        <Route path="/cafe-marketing-goa" element={<CafeMarketingGoa />} />
        <Route path="/bar-nightlife-marketing-goa" element={<BarNightlifeMarketingGoa />} />
        <Route path="/bar-marketing-goa" element={<BarMarketingGoa />} />
        <Route path="/wellness-activation-goa" element={<WellnessActivationGoa />} />
        <Route path="/wellness-events-goa" element={<WellnessEventsGoa />} />
        <Route path="/venue-activations-goa" element={<VenueActivationsGoa />} />
        <Route path="/partner-network" element={<PartnerNetworkPage />} />
        <Route path="/technology-partners" element={<TechnologyPartners />} />
        <Route path="/activation-partners" element={<ActivationPartners />} />
        <Route path="/venue-partners" element={<VenuePartners />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/privacy-policy" element={<PrivacyPolicy />} />
        <Route path="/terms-and-conditions" element={<TermsConditions />} />
        <Route path="/booking-com-management-goa" element={<BookingComManagementGoa />} />
        <Route path="/makemytrip-management-goa" element={<MakeMyTripManagementGoa />} />
        <Route path="/goibibo-management-goa" element={<GoibiboManagementGoa />} />
        <Route path="/expedia-management-goa" element={<ExpediaManagementGoa />} />
        <Route path="/agoda-management-goa" element={<AgodaManagementGoa />} />
        <Route path="/hostelworld-management-goa" element={<HostelworldManagementGoa />} />
        <Route path="/property-management-goa" element={<PropertyManagementGoa />} />
        <Route path="/founders" element={<Founders />} />
        <Route path="/vision-mission" element={<VisionMission />} />
        <Route path="/ota-strategy-insights" element={<OtaStrategyInsights />} />
        <Route path="/how-to-start-airbnb-in-goa" element={<HowToStartAirbnbInGoa />} />
        <Route path="/how-to-start-hotel-in-goa" element={<HowToStartHotelInGoa />} />
        <Route path="/how-to-start-villa-in-goa" element={<HowToStartVillaInGoa />} />
        <Route path="/how-to-start-hostel-in-goa" element={<HowToStartHostelInGoa />} />
        <Route path="/how-to-start-cafe-in-goa" element={<HowToStartCafeInGoa />} />
        <Route path="/how-to-start-bar-in-goa" element={<HowToStartBarInGoa />} />
        <Route path="/how-to-start-restaurant-in-goa" element={<HowToStartRestaurantInGoa />} />
        <Route path="/how-to-start-resort-in-goa" element={<HowToStartResortInGoa />} />
        <Route path="/how-to-start-guest-house-in-goa" element={<HowToStartGuestHouseInGoa />} />
        <Route path="/how-to-get-tourism-license-in-goa" element={<HowToGetTourismLicenseInGoa />} />
        <Route path="/hotel-license-requirements-goa" element={<HotelLicenseRequirementsGoa />} />
        <Route path="/airbnb-rules-in-goa" element={<AirbnbRulesInGoa />} />
        <Route path="/best-business-ideas-in-goa-tourism" element={<BestBusinessIdeasInGoaTourism />} />
        <Route path="/community-management-goa" element={<CommunityManagementGoa />} />
        <Route path="/community-growth-for-restaurants" element={<CommunityGrowthForRestaurants />} />
        <Route path="/community-growth-for-cafes" element={<CommunityGrowthForCafes />} />
        <Route path="/bar-growth-goa" element={<BarGrowthGoa />} />
        <Route path="/nightlife-growth-goa" element={<NightlifeGrowthGoa />} />
        <Route path="/live-music-events-goa" element={<LiveMusicEventsGoa />} />
        <Route path="/yoga-events-goa" element={<YogaEventsGoa />} />
        <Route path="/sound-healing-goa" element={<SoundHealingGoa />} />
        <Route path="/reiki-events-goa" element={<ReikiEventsGoa />} />
        <Route path="/creative-workshops-goa" element={<CreativeWorkshopsGoa />} />
        <Route path="/cultural-experiences-goa" element={<CulturalExperiencesGoa />} />
        <Route path="/hospitality-community-building-goa" element={<HospitalityCommunityBuildingGoa />} />
        <Route path="/community-managers-network" element={<CommunityManagersNetwork />} />
        <Route path="/event-organizers-network" element={<EventOrganizersNetwork />} />
        <Route path="/venue-activation-goa" element={<VenueActivationGoa />} />
        <Route path="/how-to-organize-events-in-goa" element={<HowToOrganizeEventsInGoa />} />
        <Route path="/how-to-build-a-community-in-goa" element={<HowToBuildACommunityInGoa />} />
        <Route path="/how-to-host-yoga-retreats-in-goa" element={<HowToHostYogaRetreatsInGoa />} />
        <Route path="/how-to-start-a-yoga-school-in-goa" element={<HowToStartAYogaSchoolInGoa />} />
        <Route path="/how-to-organize-wellness-events-in-goa" element={<HowToOrganizeWellnessEventsInGoa />} />
        <Route path="/how-to-organize-live-music-events-in-goa" element={<HowToOrganizeLiveMusicEventsInGoa />} />
        <Route path="/how-to-run-community-events-for-cafes" element={<HowToRunCommunityEventsForCafes />} />
        <Route path="/how-to-run-community-events-for-restaurants" element={<HowToRunCommunityEventsForRestaurants />} />
        <Route path="/how-to-run-community-events-for-bars" element={<HowToRunCommunityEventsForBars />} />
        <Route path="/how-to-create-hospitality-experiences-in-goa" element={<HowToCreateHospitalityExperiencesInGoa />} />
        <Route path="/how-to-start-homestay-in-goa" element={<HowToStartHomestayInGoa />} />
        <Route path="/how-to-start-beach-club-in-goa" element={<HowToStartBeachClubInGoa />} />
        <Route path="/how-to-start-wellness-retreat-in-goa" element={<HowToStartWellnessRetreatInGoa />} />
        <Route path="/how-to-start-community-events-in-goa" element={<HowToStartCommunityEventsInGoa />} />
        <Route path="/how-to-start-live-music-events-in-goa" element={<HowToStartLiveMusicEventsInGoa />} />
        <Route path="/how-to-start-a-hospitality-business-in-goa" element={<HowToStartAHospitalityBusinessInGoa />} />
        <Route path="/cookie-policy" element={<CookiePolicy />} />
        <Route path="/community-events-for-hotels-goa" element={<CommunityEventsForHotelsGoa />} />
        <Route path="/restaurant-event-ideas-goa" element={<RestaurantEventIdeasGoa />} />
        <Route path="/hospitality-networking-events-goa" element={<HospitalityNetworkingEventsGoa />} />
        <Route path="/live-music-for-hospitality-goa" element={<LiveMusicForHospitalityGoa />} />
        <Route path="/cafe-community-building-goa" element={<CafeCommunityBuildingGoa />} />
        <Route path="/wellness-tourism-goa" element={<WellnessTourismGoa />} />
        <Route path="/hospitality-growth-goa" element={<HospitalityGrowthGoa />} />
        <Route path="/hotel-onboarding-goa" element={<HotelOnboardingGoa />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
