import { CheckCircle, Eye, TrendingUp, DollarSign } from 'lucide-react';
import { useInView } from '../hooks/useInView';

export default function About() {
  const { ref, isInView } = useInView();

  return (
    <section ref={ref} id="about" className="py-20 sm:py-28 bg-neutral-50/50">
      <div className="section-max section-padding">
        <div
          className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 ${
            isInView ? 'animate-fade-up' : 'opacity-0'
          }`}
        >
          <span className="badge bg-accent/10 text-accent-700 mb-4">
            About OTA Studio
          </span>
          <h2 className="heading-lg !text-3xl sm:!text-4xl">
            Goa-Based OTA Onboarding & Optimization Studio
          </h2>
          <p className="body-lg mt-5">
            OTA Studio is a Goa-based OTA onboarding and optimization studio
            exclusively for hotel owners. We help properties that are either
            not yet listed on OTAs, or already listed but not getting
            visibility or bookings.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-5 sm:gap-6 mb-10">
          {[
            {
              icon: Eye,
              title: 'Increase Visibility',
              text: 'Get your property seen by more travelers on every OTA platform.',
            },
            {
              icon: TrendingUp,
              title: 'Fix OTA Performance',
              text: 'Resolve ranking issues, poor conversion, and underperforming listings.',
            },
            {
              icon: DollarSign,
              title: 'Increase Bookings & Revenue',
              text: 'Turn visibility into real bookings with smart optimization strategies.',
            },
          ].map((item, i) => (
            <div
              key={i}
              className={`card-accent group text-center opacity-0 ${
                isInView ? `animate-fade-up delay-${(i + 1) * 100}` : ''
              }`}
            >
              <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-accent/20 transition-colors">
                <item.icon size={22} className="text-accent-600" />
              </div>
              <h3 className="heading-md !text-lg mb-2">{item.title}</h3>
              <p className="body-md">{item.text}</p>
            </div>
          ))}
        </div>

        <div
          className={`max-w-2xl mx-auto opacity-0 ${
            isInView ? 'animate-fade-up delay-400' : ''
          }`}
        >
          <div className="bg-white rounded-2xl border border-accent/20 p-6 sm:p-8 flex items-center gap-4 shadow-sm">
            <div className="w-12 h-12 rounded-lg bg-accent flex items-center justify-center shrink-0">
              <CheckCircle size={24} className="text-neutral-950" />
            </div>
            <div>
              <div className="font-display font-bold text-base sm:text-lg">
                Only for Hotel & Hostel Owners
              </div>
              <div className="text-sm text-neutral-500">
                No travelers. No tourism. 100% hotel-focused.
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
