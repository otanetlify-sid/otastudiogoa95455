import { Sparkles } from 'lucide-react';
import { useInView } from '../hooks/useInView';

export default function ActivationHero() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="activation-hero"
      aria-labelledby="activation-hero-heading"
      className="py-20 sm:py-28 bg-neutral-900 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-30" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-accent/5 rounded-full blur-3xl" />

      <div className="section-max section-padding relative">
        <div className={`max-w-4xl mx-auto text-center ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/20 mb-6">
            <Sparkles size={14} className="text-accent" aria-hidden="true" />
            <span className="text-xs font-medium text-accent">Hospitality Activation</span>
          </div>

          <h2 id="activation-hero-heading" className="heading-xl text-white mb-6">
            Goa's First <span className="text-accent">Hospitality Activation Company</span>
          </h2>

          <p className="body-lg text-lg sm:text-xl text-white/70 mb-6 max-w-3xl mx-auto">
            We grow hospitality brands through OTA optimization, revenue systems,
            and curated real-world activations across partner venues in Goa.
          </p>

          <p className="font-display font-bold text-base sm:text-lg text-white/50 italic">
            We don't replace what exists. We amplify it.
          </p>
        </div>
      </div>
    </section>
  );
}
