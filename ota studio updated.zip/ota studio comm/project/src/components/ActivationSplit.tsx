import {
  Rocket, TrendingUp, BarChart3, ShieldCheck,
  Music, Mic2, Laugh, Gamepad2, PartyPopper,
  Leaf, HeartPulse, Dumbbell, Flower2, Ear,
  Palette, Brush, Camera, Shirt, Store,
  Coffee, Umbrella, UtensilsCrossed, Grape, Users,
} from 'lucide-react';
import { useInView } from '../hooks/useInView';

const otaGrowth = [
  { icon: Rocket, title: 'OTA Optimization', desc: 'Airbnb, Booking.com, Agoda — listing optimization, ranking improvement, and conversion growth.' },
  { icon: TrendingUp, title: 'Revenue Management', desc: 'Dynamic pricing, demand analysis, and revenue systems to maximize ADR and RevPAR.' },
  { icon: BarChart3, title: 'Occupancy Growth', desc: 'Data-driven strategies to fill rooms consistently across peak and off-peak seasons.' },
  { icon: ShieldCheck, title: 'PMS & Channel Integrations', desc: 'Channel manager setup, inventory sync, and multi-platform distribution.' },
];

const activationCategories = [
  {
    icon: Music,
    title: 'Nightlife & Entertainment',
    items: [
      { icon: Music, label: 'Live music curation' },
      { icon: Mic2, label: 'Karaoke nights' },
      { icon: Laugh, label: 'Stand-up comedy nights' },
      { icon: Gamepad2, label: 'Trivia & game nights' },
      { icon: PartyPopper, label: 'Themed party nights' },
    ],
  },
  {
    icon: Leaf,
    title: 'Wellness & Retreat',
    items: [
      { icon: Leaf, label: 'Yoga sessions at partner properties' },
      { icon: HeartPulse, label: 'Meditation & breathwork' },
      { icon: Dumbbell, label: 'Fitness bootcamps' },
      { icon: Flower2, label: 'Wellness retreats coordination' },
      { icon: Ear, label: 'Sound healing experiences' },
    ],
  },
  {
    icon: Palette,
    title: 'Creative & Cultural',
    items: [
      { icon: Palette, label: 'Art exhibitions & pop-ups' },
      { icon: Brush, label: 'Pottery workshops' },
      { icon: Camera, label: 'Photography walks' },
      { icon: Shirt, label: 'Fashion & craft pop-ups' },
      { icon: Store, label: 'Painting sessions at cafes' },
    ],
  },
  {
    icon: Coffee,
    title: 'Hospitality Experience',
    items: [
      { icon: Coffee, label: 'Cafe takeovers' },
      { icon: Umbrella, label: 'Beach club activations' },
      { icon: UtensilsCrossed, label: 'Food + music pairing events' },
      { icon: Grape, label: 'Cultural Goa nights' },
      { icon: Users, label: 'Community engagement events' },
    ],
  },
];

export default function ActivationSplit() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="activation-split"
      aria-labelledby="activation-split-heading"
      className="py-20 sm:py-28 bg-neutral-950 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-40" />

      <div className="section-max section-padding relative">
        <div className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Two Engines, One Company</span>
          <h2 id="activation-split-heading" className="heading-lg text-white mb-4">
            Digital Growth + Real-World <span className="text-accent">Activations</span>
          </h2>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
          {/* LEFT — OTA Growth Studio */}
          <div className={`space-y-5 ${isInView ? 'animate-fade-up delay-100' : 'opacity-0'}`}>
            <div className="p-6 sm:p-8 rounded-2xl border border-accent/20 bg-accent/5">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-lg bg-accent/15 flex items-center justify-center">
                  <Rocket size={20} className="text-accent" />
                </div>
                <h3 className="font-display font-bold text-xl text-white">OTA Growth Studio</h3>
              </div>
              <p className="text-sm text-white/50 leading-relaxed">
                OTA optimization, revenue management, and distribution for hotels, villas, and resorts across Goa.
              </p>
            </div>

            <div className="space-y-4">
              {otaGrowth.map((item, i) => (
                <div
                  key={i}
                  className="group p-5 rounded-2xl border border-white/8 bg-white/4 hover:bg-white/8 hover:border-accent/20 transition-all duration-300"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center shrink-0 group-hover:bg-accent/20 transition-colors">
                      <item.icon size={18} className="text-accent" aria-hidden="true" />
                    </div>
                    <div>
                      <h4 className="font-display font-bold text-sm text-white mb-1">{item.title}</h4>
                      <p className="text-xs text-white/45 leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* RIGHT — Community Activation Studio */}
          <div className={`space-y-5 ${isInView ? 'animate-fade-up delay-300' : 'opacity-0'}`}>
            <div className="p-6 sm:p-8 rounded-2xl border border-white/15 bg-white/4">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center">
                  <Music size={20} className="text-white" />
                </div>
                <h3 className="font-display font-bold text-xl text-white">Community Activation Studio</h3>
              </div>
              <p className="text-sm text-white/50 leading-relaxed">
                Curated real-world activations at partner venues across Goa. We are not a physical space — all activations happen at your venue.
              </p>
            </div>

            <div className="space-y-4">
              {activationCategories.map((cat, i) => (
                <div
                  key={i}
                  className="group p-5 rounded-2xl border border-white/8 bg-white/4 hover:bg-white/8 hover:border-white/20 transition-all duration-300"
                >
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-8 h-8 rounded-lg bg-white/8 flex items-center justify-center group-hover:bg-white/15 transition-colors">
                      <cat.icon size={16} className="text-white/80" aria-hidden="true" />
                    </div>
                    <h4 className="font-display font-bold text-sm text-white">{cat.title}</h4>
                  </div>
                  <div className="flex flex-wrap gap-2 ml-11">
                    {cat.items.map((item, j) => (
                      <span
                        key={j}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/4 border border-white/6 text-xs text-white/55"
                      >
                        <item.icon size={11} className="text-white/40 shrink-0" aria-hidden="true" />
                        {item.label}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
