import { useState, useEffect } from 'react';
import { Building2, TrendingUp, Globe, Music, Zap } from 'lucide-react';

const activities = [
  { icon: Building2, text: 'Villa in North Goa improved OTA score +18', time: '2m ago', color: 'text-accent' },
  { icon: Globe, text: 'New property onboarded on Booking.com', time: '5m ago', color: 'text-accent' },
  { icon: TrendingUp, text: 'Revenue optimization completed for 3 properties', time: '12m ago', color: 'text-green-400' },
  { icon: Music, text: 'Live music event confirmed at beach club', time: '18m ago', color: 'text-accent' },
  { icon: Zap, text: 'Cafe added to community network', time: '25m ago', color: 'text-white/60' },
  { icon: Building2, text: 'Resort distribution expanded to 10 platforms', time: '32m ago', color: 'text-accent' },
  { icon: TrendingUp, text: 'Hotel occupancy reached 85% this week', time: '45m ago', color: 'text-green-400' },
  { icon: Globe, text: 'Airbnb ranking improved for homestay cluster', time: '1h ago', color: 'text-accent' },
];

export default function ActivityFeed() {
  const [currentIdx, setCurrentIdx] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIdx(prev => (prev + 1) % activities.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const visible = [
    activities[currentIdx],
    activities[(currentIdx + 1) % activities.length],
    activities[(currentIdx + 2) % activities.length],
  ];

  return (
    <div className="rounded-lg sm:rounded-xl border border-white/8 bg-white/[0.02] p-2.5 sm:p-3 overflow-hidden">
      <div className="flex items-center gap-2 mb-2">
        <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
        <span className="text-[8px] sm:text-[10px] font-medium text-white/30 uppercase tracking-wider">Live Activity</span>
      </div>
      <div className="space-y-1.5">
        {visible.map((activity, i) => {
          const Icon = activity.icon;
          return (
            <div
              key={`${currentIdx}-${i}`}
              className="flex items-start gap-2 py-1.5 transition-opacity duration-500"
              style={{ opacity: 1 - i * 0.1 }}
            >
              <Icon size={10} className={`${activity.color} shrink-0 mt-0.5`} />
              <div className="min-w-0">
                <span className="text-[8px] sm:text-[10px] text-white/70 leading-tight block truncate">{activity.text}</span>
                <span className="text-[7px] sm:text-[9px] text-white/50">{activity.time}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
