import { ArrowRight } from 'lucide-react';
import { useInView } from '../hooks/useInView';

export default function BeyondOTA() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="beyond-ota"
      aria-labelledby="beyond-ota-heading"
      className="py-20 sm:py-28 bg-neutral-900 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-30" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-accent/5 rounded-full blur-3xl" />

      <div className="section-max section-padding relative">
        <div className={`max-w-4xl mx-auto text-center ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Beyond OTA Growth</span>

          <h2 id="beyond-ota-heading" className="heading-xl text-white mb-6">
            Beyond <span className="text-accent">OTA Growth</span>
          </h2>

          <p className="body-lg text-lg sm:text-xl text-white/70 mb-6 max-w-3xl mx-auto">
            While OTA Studio helps accommodation businesses grow through OTA onboarding, OTA management and distribution,
            we also help hospitality venues create experiences that increase engagement, repeat visits and footfall.
          </p>

          <p className="font-display font-bold text-base sm:text-lg text-accent/80 italic mb-8">
            Digital Visibility. Real-World Activation. Hospitality Growth.
          </p>

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <a
              href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20learn%20about%20hospitality%20activations"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary group"
            >
              Explore Activations
              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </a>
            <a href="#ota-ecosystem" className="btn-secondary">
              View Ecosystem
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
