import { TrendingUp, Users, Handshake } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const pillars = [
  {
    icon: TrendingUp,
    title: 'OTA Growth & Revenue',
    description:
      'Professional onboarding across multiple OTA platforms, continuous optimization, and revenue management systems to maximize your direct and OTA bookings.',
  },
  {
    icon: Users,
    title: 'Community Experiences',
    description:
      'Curated live music, wellness activities, creative workshops, and cultural events that enhance guest experiences and drive repeat bookings.',
  },
  {
    icon: Handshake,
    title: 'Hospitality Partnerships',
    description:
      'Strategic partnerships with property operators, technology providers, and activation specialists to create comprehensive growth ecosystems.',
  },
];

export default function BeyondOtaGrowth() {
  const { ref, isInView } = useInView(0.15);

  return (
    <section
      ref={ref}
      className="relative py-20 sm:py-32 bg-neutral-950 text-white overflow-hidden"
    >
      {/* Background elements */}
      <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-accent/8 rounded-full blur-3xl opacity-40" />
      <div className="absolute top-1/3 left-1/4 w-[300px] h-[300px] bg-accent/5 rounded-full blur-3xl opacity-30" />
      <div className="absolute inset-0 section-grid opacity-20" />

      <div className="section-max section-padding relative">
        {/* Header */}
        <div className={`text-center max-w-3xl mx-auto mb-14 sm:mb-20 ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/20 text-accent mb-4">Beyond OTA</span>
          <h2 className="heading-lg text-white mb-4">Beyond OTA Growth</h2>
          <p className="body-lg text-white/70 mb-6">
            OTA Studio is a Hospitality Growth Platform that connects OTA visibility with community experiences and strategic partnerships.
          </p>
          <p className="text-sm sm:text-base text-accent font-display font-bold">
            Digital Visibility. Community Engagement. Hospitality Growth.
          </p>
        </div>

        {/* Pillars Grid */}
        <div className="grid sm:grid-cols-3 gap-6 sm:gap-5">
          {pillars.map((pillar, i) => {
            const Icon = pillar.icon;

            return (
              <div
                key={i}
                className={`group p-6 sm:p-7 rounded-xl border border-white/10 bg-white/[0.03] backdrop-blur-sm hover:border-accent/30 hover:bg-white/[0.06] transition-all duration-300 hover:-translate-y-1 ${
                  isInView ? `animate-fade-up opacity-100` : 'opacity-0'
                }`}
                style={{
                  animationDelay: isInView ? `${i * 100}ms` : undefined,
                }}
              >
                {/* Glow on hover */}
                <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-accent/10 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                <div className="relative">
                  {/* Icon */}
                  <div className="w-12 h-12 rounded-lg bg-accent/15 flex items-center justify-center mb-4 group-hover:bg-accent/25 transition-colors">
                    <Icon size={24} className="text-accent" />
                  </div>

                  {/* Title */}
                  <h3 className="font-display font-bold text-lg sm:text-xl mb-3 text-white">
                    {pillar.title}
                  </h3>

                  {/* Description */}
                  <p className="text-sm sm:text-base text-white/60 leading-relaxed group-hover:text-white/70 transition-colors">
                    {pillar.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* CTA */}
        <div
          className={`mt-12 sm:mt-16 text-center ${
            isInView ? 'animate-fade-up opacity-100' : 'opacity-0'
          }`}
          style={{
            animationDelay: isInView ? '300ms' : undefined,
          }}
        >
          <a
            href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20learn%20more%20about%20OTA%20Studio"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary"
            onClick={() => {
              if (typeof window !== 'undefined' && (window as any).dataLayer) {
                (window as any).dataLayer.push({ event: 'cta_click', cta_name: 'beyond_ota_growth' });
              }
            }}
          >
            Explore Our Hospitality Growth Platform
          </a>
        </div>
      </div>
    </section>
  );
}
