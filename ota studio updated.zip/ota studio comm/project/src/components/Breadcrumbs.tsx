import { ChevronRight, Home } from 'lucide-react';

interface Crumb {
  label: string;
  href?: string;
}

interface BreadcrumbsProps {
  crumbs: Crumb[];
}

export default function Breadcrumbs({ crumbs }: BreadcrumbsProps) {
  return (
    <nav aria-label="Breadcrumb" className="py-3">
      <ol
        className="flex items-center gap-1.5 text-sm text-white/50 flex-wrap"
        itemScope
        itemType="https://schema.org/BreadcrumbList"
      >
        <li
          itemProp="itemListElement"
          itemScope
          itemType="https://schema.org/ListItem"
        >
          <a
            href="/"
            itemProp="item"
            className="flex items-center gap-1 hover:text-white transition-colors"
          >
            <Home size={13} />
            <span itemProp="name">Home</span>
          </a>
          <meta itemProp="position" content="1" />
        </li>
        {crumbs.map((crumb, i) => (
          <li
            key={i}
            className="flex items-center gap-1.5"
            itemProp="itemListElement"
            itemScope
            itemType="https://schema.org/ListItem"
          >
            <ChevronRight size={13} className="text-white/30" />
            {crumb.href ? (
              <a
                href={crumb.href}
                itemProp="item"
                className="hover:text-white transition-colors"
              >
                <span itemProp="name">{crumb.label}</span>
              </a>
            ) : (
              <span itemProp="name" className="text-white font-medium">
                {crumb.label}
              </span>
            )}
            <meta itemProp="position" content={String(i + 2)} />
          </li>
        ))}
      </ol>
    </nav>
  );
}
