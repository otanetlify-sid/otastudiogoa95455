import { ArrowRight, TrendingUp } from 'lucide-react';
import { useInView } from '../hooks/useInView';

export default function CTA() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="cta"
      aria-labelledby="cta-heading"
      className="py-20 sm:py-28 bg-neutral-950 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-40" />
      <div className="absolute inset-0 bg-gradient-to-br from-accent/5 to-transparent" />

      <div className="section-max section-padding relative">
        <div className={`max-w-3xl mx-auto text-center ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent text-neutral-950 mb-6">FREE OTA Audit</span>
          <h2 id="cta-heading" className="heading-lg text-white mb-4">
            Get a FREE OTA Visibility Audit
          </h2>
          <p className="body-lg text-lg mb-8">
            Discover what's holding back your OTA bookings. We'll review your current
            listings, identify issues, and provide actionable recommendations.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <a
              href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20a%20FREE%20OTA%20Visibility%20Audit%20for%20my%20property"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary group"
              onClick={() => {
                if (typeof window !== 'undefined' && (window as any).dataLayer) {
                  (window as any).dataLayer.push({ event: 'cta_click', cta_name: 'free_audit_cta' });
                }
              }}
            >
              <TrendingUp size={18} aria-hidden="true" />
              Get Your Free OTA Audit
              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </a>
            <a href="#contact" className="btn-secondary">
              Contact Us
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
