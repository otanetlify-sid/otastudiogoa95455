import { TrendingUp, Eye, Network, DollarSign } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const cases = [
  {
    icon: Eye,
    title: 'Visibility Increase',
    before: 'Property not appearing on first 3 pages of OTA search',
    after: 'Consistent first-page ranking on Booking.com and Airbnb',
    result: 'Search visibility improved by 340%',
  },
  {
    icon: Network,
    title: 'Distribution Improvements',
    before: 'Listed on only 2 OTAs with manual inventory updates',
    after: 'Connected to 6 OTAs via channel manager with real-time sync',
    result: 'Zero overbookings, 100% rate parity',
  },
  {
    icon: TrendingUp,
    title: 'Listing Optimization',
    before: 'Incomplete profile, low-quality photos, no SEO strategy',
    after: 'Professional content, optimized keywords, updated visuals',
    result: 'Conversion rate improved by 180%',
  },
  {
    icon: DollarSign,
    title: 'Revenue Potential',
    before: '40% occupancy at undervalued ADR',
    after: 'Dynamic pricing across all channels with competitor tracking',
    result: 'Revenue increased by 2.8x in 6 months',
  },
];

export default function CaseStudies() {
  const { ref, isInView } = useInView();

  return (
    <section ref={ref} className="py-20 sm:py-28 bg-neutral-950 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,_rgba(255,208,0,0.06)_0%,_transparent_60%)]" />
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-accent/5 rounded-full blur-3xl" />

      <div className="section-max section-padding relative">
        <div
          className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 opacity-0 ${
            isInView ? 'animate-fade-up' : ''
          }`}
        >
          <span className="badge bg-accent/20 text-accent mb-4">Results</span>
          <h2 className="heading-lg !text-neutral-100">Before & After</h2>
          <p className="text-base sm:text-lg text-neutral-400 mt-4 leading-relaxed">
            Real outcomes from properties we have worked with.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 gap-5 sm:gap-6">
          {cases.map((c, i) => (
            <div
              key={i}
              className={`group p-6 sm:p-8 rounded-2xl border border-neutral-800 bg-neutral-900/50 hover:bg-neutral-800/50 hover:border-accent/20 transition-all duration-300 opacity-0 ${
                isInView
                  ? `animate-fade-up delay-${Math.min(i * 100, 500)}`
                  : ''
              }`}
            >
              <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-5 group-hover:bg-accent/20 transition-colors">
                <c.icon size={22} className="text-accent" />
              </div>

              <h3 className="font-display font-bold text-lg text-neutral-200 mb-4">
                {c.title}
              </h3>

              <div className="space-y-4">
                <div>
                  <div className="text-xs font-semibold text-red-400 tracking-wider uppercase mb-1">
                    Before
                  </div>
                  <p className="text-sm text-neutral-400 leading-relaxed">
                    {c.before}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex-1 h-px bg-neutral-700" />
                  <ArrowDown size={14} className="text-accent" />
                  <div className="flex-1 h-px bg-neutral-700" />
                </div>

                <div>
                  <div className="text-xs font-semibold text-green-400 tracking-wider uppercase mb-1">
                    After
                  </div>
                  <p className="text-sm text-neutral-300 leading-relaxed">
                    {c.after}
                  </p>
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-neutral-800">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-accent" />
                  <span className="font-display font-bold text-sm text-accent">
                    {c.result}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ArrowDown({ size, className }: { size: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M12 5v14M19 12l-7 7-7-7" />
    </svg>
  );
}
