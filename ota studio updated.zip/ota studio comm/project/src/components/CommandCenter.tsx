import { useState, useEffect, useRef, useCallback } from 'react';
import { Music, Heart, Calendar, Users, Coffee, Utensils, Sparkles, Activity, TrendingUp, Radio, MapPin, Zap, Volume2 } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const goaLocations = [
  { name: 'Mandrem', status: 'Active', intensity: 92 },
  { name: 'Morjim', status: 'High Activity', intensity: 88 },
  { name: 'Ashwem', status: 'Growing', intensity: 75 },
  { name: 'Anjuna', status: 'Active', intensity: 85 },
  { name: 'Vagator', status: 'Expanding', intensity: 70 },
  { name: 'Assagao', status: 'Growing', intensity: 65 },
];

const activeExperiences = [
  { name: 'Live Music', icon: Music, status: 'active', count: 12 },
  { name: 'Yoga Sessions', icon: Heart, status: 'active', count: 8 },
  { name: 'Workshops', icon: Calendar, status: 'scheduled', count: 5 },
  { name: 'Wellness', icon: Sparkles, status: 'active', count: 7 },
  { name: 'Community Events', icon: Users, status: 'growing', count: 15 },
  { name: 'Venue Activations', icon: Coffee, status: 'active', count: 23 },
];

const activityFeedItems = [
  { text: 'New Yoga Session Scheduled at Mandrem', time: '2m ago', type: 'yoga' },
  { text: 'Workshop Registration Open for Assagao', time: '5m ago', type: 'workshop' },
  { text: 'Venue Activation Published - Vagator', time: '12m ago', type: 'venue' },
  { text: 'Live Music Experience Confirmed', time: '18m ago', type: 'music' },
  { text: 'New Hospitality Partner Added', time: '25m ago', type: 'partner' },
  { text: 'Wellness Session Updated - Morjim', time: '32m ago', type: 'wellness' },
];

const venueNetwork = [
  { name: 'Cafes', icon: Coffee, connections: 42, status: 'active' },
  { name: 'Restaurants', icon: Utensils, connections: 38, status: 'active' },
  { name: 'Yoga Studios', icon: Heart, connections: 15, status: 'growing' },
  { name: 'Wellness Centers', icon: Sparkles, connections: 12, status: 'active' },
  { name: 'Live Music Venues', icon: Music, connections: 28, status: 'high' },
  { name: 'Workshop Spaces', icon: Calendar, connections: 18, status: 'expanding' },
];

const communityMetrics = [
  { label: 'Venue Engagement', value: 87, trend: '+12%' },
  { label: 'Experience Participation', value: 78, trend: '+8%' },
  { label: 'Activation Readiness', value: 92, trend: '+15%' },
];

// Experience Mixer Channels with live values
const mixerChannels = [
  { id: 'live-music', name: 'Live Music', icon: Music },
  { id: 'yoga', name: 'Yoga', icon: Heart },
  { id: 'wellness', name: 'Wellness', icon: Sparkles },
  { id: 'workshops', name: 'Workshops', icon: Calendar },
  { id: 'cafe-events', name: 'Cafe Events', icon: Coffee },
  { id: 'activations', name: 'Activations', icon: Zap },
];

// Status bar metrics
const statusBarMetrics = [
  { label: 'Experience Energy', value: 92 },
  { label: 'Venue Activity', value: 88 },
  { label: 'Community Momentum', value: 91 },
  { label: 'Participation', value: 84 },
];

export default function CommandCenter() {
  const { ref, isInView } = useInView(0.1);
  const [currentActivity, setCurrentActivity] = useState(0);
  const [visibleActivities, setVisibleActivities] = useState(activityFeedItems.slice(0, 3));

  // Live mixer values with realistic fluctuations
  const [mixerValues, setMixerValues] = useState({
    'live-music': 84,
    'yoga': 79,
    'wellness': 89,
    'workshops': 74,
    'cafe-events': 81,
    'activations': 86,
  });

  // Status bar values
  const [statusValues, setStatusValues] = useState({
    'experience-energy': 92,
    'venue-activity': 88,
    'community-momentum': 91,
    'participation': 84,
  });

  // Hovered channel for glow effect
  const [hoveredChannel, setHoveredChannel] = useState<string | null>(null);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);

  // Realistic slow value changes for mixer
  const updateMixerValue = useCallback((current: number) => {
    const change = (Math.random() - 0.5) * 4; // -2 to +2
    const newValue = Math.max(60, Math.min(95, current + change));
    return Math.round(newValue);
  }, []);

  // Update mixer values slowly
  useEffect(() => {
    const interval = setInterval(() => {
      setMixerValues(prev => {
        const keys = Object.keys(prev) as (keyof typeof mixerValues)[];
        const keyToUpdate = keys[Math.floor(Math.random() * keys.length)];
        return {
          ...prev,
          [keyToUpdate]: updateMixerValue(prev[keyToUpdate]),
        };
      });
    }, 3000);
    return () => clearInterval(interval);
  }, [updateMixerValue]);

  // Update status values occasionally
  useEffect(() => {
    const interval = setInterval(() => {
      setStatusValues(prev => {
        const keys = Object.keys(prev) as (keyof typeof statusValues)[];
        const keyToUpdate = keys[Math.floor(Math.random() * keys.length)];
        const change = (Math.random() - 0.5) * 3;
        return {
          ...prev,
          [keyToUpdate]: Math.max(75, Math.min(98, Math.round(prev[keyToUpdate] + change))),
        };
      });
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  // Rotate activity feed
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentActivity(prev => (prev + 1) % activityFeedItems.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  // Update visible activities
  useEffect(() => {
    const items = [];
    for (let i = 0; i < 3; i++) {
      items.push(activityFeedItems[(currentActivity + i) % activityFeedItems.length]);
    }
    setVisibleActivities(items);
  }, [currentActivity]);

  // Network visualization
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      const rect = canvas.parentElement?.getBoundingClientRect();
      if (!rect) return;
      canvas.width = rect.width;
      canvas.height = rect.height;
    };
    resize();
    window.addEventListener('resize', resize);

    const nodes = [
      { x: 0.1, y: 0.2, vx: 0.0001, vy: 0.0001 },
      { x: 0.3, y: 0.15, vx: -0.00015, vy: 0.0001 },
      { x: 0.5, y: 0.3, vx: 0.0001, vy: -0.0001 },
      { x: 0.7, y: 0.2, vx: -0.0001, vy: 0.00015 },
      { x: 0.9, y: 0.25, vx: 0.0001, vy: -0.0001 },
      { x: 0.2, y: 0.5, vx: 0.00015, vy: 0.0001 },
      { x: 0.4, y: 0.6, vx: -0.0001, vy: -0.0001 },
      { x: 0.6, y: 0.55, vx: 0.0001, vy: 0.00015 },
      { x: 0.8, y: 0.5, vx: -0.00015, vy: 0.0001 },
      { x: 0.5, y: 0.8, vx: 0.0001, vy: -0.0001 },
    ];

    const draw = () => {
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      for (const node of nodes) {
        node.x += node.vx;
        node.y += node.vy;
        if (node.x < 0.05 || node.x > 0.95) node.vx *= -1;
        if (node.y < 0.05 || node.y > 0.95) node.vy *= -1;
      }

      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = (nodes[i].x - nodes[j].x) * w;
          const dy = (nodes[i].y - nodes[j].y) * h;
          const dist = Math.sqrt(dx * dx + dy * dy);
          const maxDist = Math.min(w, h) * 0.3;
          if (dist < maxDist) {
            const alpha = (1 - dist / maxDist) * 0.12;
            ctx.beginPath();
            ctx.moveTo(nodes[i].x * w, nodes[i].y * h);
            ctx.lineTo(nodes[j].x * w, nodes[j].y * h);
            ctx.strokeStyle = `rgba(34, 211, 238, ${alpha})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }

      for (const node of nodes) {
        ctx.beginPath();
        ctx.arc(node.x * w, node.y * h, 2, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(34, 211, 238, 0.35)';
        ctx.fill();
      }

      rafRef.current = requestAnimationFrame(draw);
    };

    rafRef.current = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener('resize', resize);
    };
  }, []);

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'yoga': return 'text-accent';
      case 'workshop': return 'text-accent';
      case 'venue': return 'text-accent';
      case 'music': return 'text-accent';
      case 'partner': return 'text-accent';
      case 'wellness': return 'text-accent';
      default: return 'text-accent';
    }
  };

  return (
    <section ref={ref} className="relative py-20 sm:py-28 bg-neutral-950 overflow-hidden">
      {/* Network Background */}
      <div className="absolute inset-0 pointer-events-none">
        <canvas ref={canvasRef} className="w-full h-full opacity-50" />
      </div>

      <div className="section-max section-padding relative">
        {/* Header */}
        <div className={`text-center mb-12 sm:mb-16 transition-all duration-1000 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-accent/10 border border-accent/30">
              <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
              <span className="text-xs font-semibold text-accent uppercase tracking-wider">Live Network</span>
            </div>
          </div>
          <h2 className="heading-lg text-white mb-4">
            Community & Activations <span className="text-accent">Command Center</span>
          </h2>
          <p className="body-lg max-w-2xl mx-auto">
            Real-time hospitality activations, community growth, wellness experiences, live music, workshops, cafés, restaurants and venue engagement.
          </p>
        </div>

        {/* Main Grid */}
        <div className="grid lg:grid-cols-3 gap-4 sm:gap-6">
          {/* Left Column */}
          <div className="space-y-4 sm:space-y-6">
            {/* Active Experiences */}
            <div className={`p-4 sm:p-6 rounded-xl sm:rounded-2xl border border-white/8 bg-neutral-900/40 transition-all duration-1000 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
              <h3 className="text-sm font-semibold text-accent mb-4 flex items-center gap-2">
                <Activity size={14} />
                Active Experiences
              </h3>
              <div className="grid grid-cols-2 gap-2">
                {activeExperiences.map((exp, i) => {
                  const Icon = exp.icon;
                  return (
                    <div
                      key={exp.name}
                      className="flex items-center gap-2 px-3 py-2.5 rounded-lg bg-white/[0.02] border border-white/5 transition-colors hover:border-accent/20"
                      style={{ transitionDelay: `${i * 50}ms` }}
                    >
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                        exp.status === 'active' ? 'bg-accent/10 text-accent' :
                        exp.status === 'high' ? 'bg-accent/10 text-accent' :
                        'bg-accent/5 text-accent/70'
                      }`}>
                        <Icon size={14} />
                      </div>
                      <div className="min-w-0">
                        <span className="block text-xs font-medium text-white truncate">{exp.name}</span>
                        <span className={`block text-[10px] ${
                          exp.status === 'active' ? 'text-accent/70' :
                          exp.status === 'high' ? 'text-accent/70' :
                          'text-white/40'
                        }`}>{exp.count} active</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Event Energy Index */}
            <div className={`p-4 sm:p-6 rounded-xl sm:rounded-2xl border border-white/8 bg-neutral-900/40 transition-all duration-1000 delay-200 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
              <h3 className="text-sm font-semibold text-accent mb-4 flex items-center gap-2">
                <Radio size={14} />
                Event Energy
              </h3>
              <div className="flex items-end gap-1 h-20 mb-3">
                {[85, 92, 78, 95, 82, 88].map((h, i) => (
                  <div
                    key={i}
                    className="flex-1 rounded-t bg-gradient-to-t from-accent/20 via-accent/40 to-accent/60 transition-all duration-700"
                    style={{ height: `${h}%`, transitionDelay: `${i * 100}ms` }}
                  />
                ))}
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-white/50">Energy Index</span>
                <span className="text-lg font-display font-bold text-accent">92%</span>
              </div>
            </div>
          </div>

          {/* Center Column */}
          <div className="space-y-4 sm:space-y-6">
            {/* Community Momentum */}
            <div className={`p-4 sm:p-6 rounded-xl sm:rounded-2xl border border-white/8 bg-neutral-900/40 transition-all duration-1000 delay-100 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
              <h3 className="text-sm font-semibold text-accent mb-4 flex items-center gap-2">
                <TrendingUp size={14} />
                Community Momentum
              </h3>
              <div className="space-y-4">
                {communityMetrics.map((metric, i) => (
                  <div key={metric.label}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs text-white/60">{metric.label}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-white">{metric.value}%</span>
                        <span className="text-[10px] text-accent">{metric.trend}</span>
                      </div>
                    </div>
                    <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-accent/50 via-accent/60 to-accent/80 transition-all duration-1000"
                        style={{ width: isInView ? `${metric.value}%` : '0%', transitionDelay: `${i * 100 + 200}ms` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Venue Network */}
            <div className={`p-4 sm:p-6 rounded-xl sm:rounded-2xl border border-white/8 bg-neutral-900/40 transition-all duration-1000 delay-300 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
              <h3 className="text-sm font-semibold text-accent mb-4 flex items-center gap-2">
                <Users size={14} />
                Venue Network
              </h3>
              <div className="grid grid-cols-2 gap-2">
                {venueNetwork.map((venue) => {
                  const Icon = venue.icon;
                  return (
                    <div
                      key={venue.name}
                      className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/[0.02] border border-white/5 transition-all hover:border-accent/20"
                    >
                      <div className={`w-7 h-7 rounded-lg flex items-center justify-center bg-accent/10 text-accent`}>
                        <Icon size={12} />
                      </div>
                      <div className="min-w-0">
                        <span className="block text-[11px] font-medium text-white truncate">{venue.name}</span>
                        <span className="block text-[10px] text-accent/70">{venue.connections} connected</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-4 sm:space-y-6">
            {/* Live Activity Feed */}
            <div className={`p-4 sm:p-6 rounded-xl sm:rounded-2xl border border-white/8 bg-neutral-900/40 transition-all duration-1000 delay-200 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
              <h3 className="text-sm font-semibold text-accent mb-4 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
                Live Activity
              </h3>
              <div className="space-y-2">
                {visibleActivities.map((activity, i) => (
                  <div
                    key={`${currentActivity}-${i}`}
                    className="flex items-start gap-2 px-3 py-2 rounded-lg bg-white/[0.02] border border-white/8 transition-opacity duration-500"
                    style={{ opacity: 1 - i * 0.15 }}
                  >
                    <Zap size={12} className={`${getActivityColor(activity.type)} shrink-0 mt-0.5`} />
                    <div className="min-w-0">
                      <span className="block text-xs text-white/70 truncate">{activity.text}</span>
                      <span className="text-[10px] text-accent/60">{activity.time}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Goa Experience Network */}
            <div className={`p-4 sm:p-6 rounded-xl sm:rounded-2xl border border-white/8 bg-neutral-900/40 transition-all duration-1000 delay-400 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
              <h3 className="text-sm font-semibold text-accent mb-4 flex items-center gap-2">
                <MapPin size={14} />
                Goa Experience Network
              </h3>
              <div className="space-y-2">
                {goaLocations.map((loc, i) => (
                  <div
                    key={loc.name}
                    className="flex items-center justify-between px-3 py-2.5 rounded-lg bg-white/[0.02] border border-white/5 transition-all hover:border-accent/20"
                  >
                    <div className="flex items-center gap-2">
                      <MapPin size={12} className="text-accent" />
                      <span className="text-xs font-medium text-white">{loc.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="h-1 rounded-full bg-white/5 overflow-hidden w-12">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-accent/50 to-accent/80 transition-all duration-1000"
                          style={{ width: `${loc.intensity}%`, transitionDelay: `${i * 50}ms` }}
                        />
                      </div>
                      <span className="text-[10px] font-medium text-accent">{loc.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Experience Mixer Panel - DJ Console Style */}
        <div className={`mt-8 sm:mt-12 transition-all duration-1000 delay-500 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          {/* Status Bar */}
          <div className="mb-4 p-4 rounded-xl border border-accent/15 bg-gradient-to-r from-accent/4 via-transparent to-accent/4">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
                <span className="text-sm font-bold text-accent uppercase tracking-wider">Live Experience Energy</span>
              </div>
              <div className="flex items-center gap-4 sm:gap-6">
                {statusBarMetrics.map((metric) => (
                  <div key={metric.label} className="text-center">
                    <span className="block text-[10px] sm:text-xs text-white/50">{metric.label}</span>
                    <span className="text-sm sm:text-base font-display font-bold text-accent">
                      {statusValues[metric.label.toLowerCase().replace(/ /g, '-') as keyof typeof statusValues] || metric.value}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Mixer Console */}
          <div className="p-6 sm:p-8 rounded-2xl sm:rounded-3xl border border-white/8 bg-gradient-to-br from-neutral-900/90 via-neutral-950/95 to-neutral-900/90 backdrop-blur-xl shadow-2xl shadow-accent/5">
            {/* Console Header */}
            <div className="flex items-center justify-between mb-6 pb-4 border-b border-white/8">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center">
                  <Volume2 size={20} className="text-accent" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-display font-bold text-white">Experience Mixer</h3>
                  <p className="text-xs text-accent/70">Community Activity Control Deck</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
                <span className="text-xs text-accent uppercase tracking-wider">Live</span>
              </div>
            </div>

            {/* Mixer Channels */}
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-4 sm:gap-6">
              {mixerChannels.map((channel) => {
                const Icon = channel.icon;
                const value = mixerValues[channel.id as keyof typeof mixerValues];
                const isHovered = hoveredChannel === channel.id;

                return (
                  <div
                    key={channel.id}
                    className="relative group"
                    onMouseEnter={() => setHoveredChannel(channel.id)}
                    onMouseLeave={() => setHoveredChannel(null)}
                  >
                    {/* Channel Card */}
                    <div className={`relative p-4 rounded-xl border transition-all duration-300 ${
                      isHovered
                        ? 'border-accent/40 bg-accent/5 shadow-lg shadow-accent/10'
                        : 'border-white/8 bg-white/[0.01]'
                    }`}>
                      {/* Glow effect on hover */}
                      <div className={`absolute inset-0 rounded-xl transition-opacity duration-300 ${
                        isHovered ? 'opacity-100' : 'opacity-0'
                      }`}>
                        <div className="absolute inset-0 rounded-xl bg-gradient-to-b from-accent/5 to-transparent" />
                      </div>

                      {/* Icon */}
                      <div className={`relative w-10 h-10 mx-auto mb-4 rounded-lg flex items-center justify-center transition-colors duration-300 ${
                        isHovered ? 'bg-accent/20 text-accent' : 'bg-accent/10 text-accent/80'
                      }`}>
                        <Icon size={18} />
                      </div>

                      {/* Fader Track */}
                      <div className="relative h-32 sm:h-40 mb-4 mx-auto w-4 bg-gradient-to-b from-white/5 via-white/[0.02] to-white/5 rounded-full overflow-hidden border border-white/10">
                        {/* Fill */}
                        <div
                          className="absolute bottom-0 left-0 right-0 rounded-full transition-all duration-1000 ease-out"
                          style={{ height: `${value}%` }}
                        >
                          <div className="absolute inset-0 bg-gradient-to-t from-accent/60 via-accent/40 to-accent/20" />
                          <div className="absolute inset-0 bg-gradient-to-t from-accent to-accent/60 opacity-20" />
                        </div>

                        {/* Slider Handle */}
                        <div
                          className="absolute left-1/2 -translate-x-1/2 w-6 h-2 rounded-full transition-all duration-1000 ease-out shadow-lg"
                          style={{ bottom: `calc(${value}% - 4px)` }}
                        >
                          <div className={`absolute inset-0 rounded-full transition-colors duration-300 ${
                            isHovered
                              ? 'bg-gradient-to-r from-accent via-accent-300 to-accent shadow-accent/50'
                              : 'bg-gradient-to-r from-accent via-accent-400 to-accent'
                          }`}>
                            {/* Inner glow */}
                            <div className="absolute inset-0 rounded-full bg-gradient-to-r from-white/20 via-white/10 to-white/20" />
                          </div>
                          {/* Glow ring */}
                          <div className={`absolute -inset-1 rounded-full transition-opacity duration-300 ${
                            isHovered ? 'opacity-100 bg-accent/20 blur-sm' : 'opacity-0'
                          }`} />
                        </div>
                      </div>

                      {/* Label */}
                      <div className="text-center">
                        <span className={`block text-[10px] sm:text-xs font-medium transition-colors duration-300 ${
                          isHovered ? 'text-white' : 'text-white/70'
                        }`}>
                          {channel.name}
                        </span>
                        <span className={`block text-sm sm:text-lg font-display font-bold transition-colors duration-300 ${
                          isHovered ? 'text-accent' : 'text-accent/90'
                        }`}>
                          {value}<span className="text-xs">%</span>
                        </span>
                      </div>

                      {/* Reflection line */}
                      <div className={`absolute bottom-0 left-1/2 -translate-x-1/2 w-3/4 h-px transition-opacity duration-300 ${
                        isHovered ? 'opacity-60' : 'opacity-30'
                      }`}>
                        <div className="w-full h-full bg-gradient-to-r from-transparent via-accent/50 to-transparent" />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Console Footer */}
            <div className="mt-6 pt-4 border-t border-white/8 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                  <span className="text-xs text-white/50">All systems operational</span>
                </div>
              </div>
              <div className="text-xs text-accent/50">Real-time updates</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
