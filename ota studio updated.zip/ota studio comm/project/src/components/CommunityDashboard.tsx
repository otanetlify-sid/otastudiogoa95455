import { Music, Heart, Palette, Building2 } from 'lucide-react';
import { useInView } from '../hooks/useInView';
import GoaNetworkMap from './GoaNetworkMap';

const experiences = [
  {
    id: 'music',
    icon: Music,
    title: 'Music & Entertainment',
    items: ['Live Music', 'DJs', 'Karaoke', 'Trivia Nights', 'Stand-Up Comedy'],
  },
  {
    id: 'wellness',
    icon: Heart,
    title: 'Wellness Experiences',
    items: ['Yoga', 'Beach Yoga', 'Meditation', 'Breathwork', 'Reiki', 'Sound Healing', 'Wellness Retreats'],
  },
  {
    id: 'creative',
    icon: Palette,
    title: 'Creative Experiences',
    items: ['Art Exhibitions', 'Painting Workshops', 'Pottery Workshops', 'Photography Walks', 'Creative Pop-Ups'],
  },
  {
    id: 'venue',
    icon: Building2,
    title: 'Venue Activations',
    items: ['Cafe Activations', 'Restaurant Activations', 'Bar Activations', 'Beach Club Activations'],
  },
];

export default function CommunityDashboard() {
  const { ref, isInView } = useInView(0.15);

  return (
    <section
      ref={ref}
      className="relative py-16 sm:py-24 bg-neutral-950 text-white overflow-hidden"
    >
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-accent/8 rounded-full blur-3xl opacity-30" />
      <div className="absolute inset-0 section-grid opacity-15" />

      <div className="section-max section-padding relative">
        <div className={`text-center max-w-3xl mx-auto mb-10 sm:mb-14 ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/15 text-accent border border-accent/20 mb-4">Community Network</span>
          <h2 className="heading-lg text-white mb-4">Guest Experiences That Drive Loyalty</h2>
          <p className="body-lg text-white/70">
            Curated community experiences and venue activations that transform guest stays into memorable moments.
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-6 sm:gap-5">
          {/* Goa Network Map - left side on desktop */}
          <div className={`hidden lg:flex lg:col-span-1 items-center justify-center ${isInView ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: '200ms' }}>
            <GoaNetworkMap />
          </div>

          {/* Experience cards */}
          <div className="lg:col-span-4 grid sm:grid-cols-2 gap-4 sm:gap-5">
          {experiences.map((category, i) => {
            const Icon = category.icon;

            return (
              <div
                key={category.id}
                className={`group relative p-5 sm:p-6 rounded-xl border border-white/10 bg-white/[0.03] backdrop-blur-sm hover:border-accent/30 hover:bg-white/[0.06] transition-all duration-300 ${
                  isInView ? 'animate-fade-up opacity-100' : 'opacity-0'
                }`}
                style={{ animationDelay: isInView ? `${i * 80}ms` : undefined }}
              >
                <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-accent/10 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                <div className="relative">
                  <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-lg bg-accent/15 flex items-center justify-center mb-4 group-hover:bg-accent/25 transition-colors">
                    <Icon size={18} className="text-accent" />
                  </div>

                  <h3 className="font-display font-bold text-sm sm:text-base mb-3 text-white group-hover:text-accent transition-colors">
                    {category.title}
                  </h3>

                  <div className="space-y-1.5">
                    {category.items.map((item, itemIdx) => (
                      <div key={itemIdx} className="flex items-center gap-2">
                        <div className="w-1 h-1 rounded-full bg-accent/40 group-hover:bg-accent transition-colors" />
                        <span className="text-xs text-white/50 group-hover:text-white/70 transition-colors">
                          {item}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        </div>

        <div
          className={`mt-10 sm:mt-14 p-5 sm:p-7 rounded-xl border border-accent/20 bg-accent/5 text-center ${
            isInView ? 'animate-fade-up opacity-100' : 'opacity-0'
          }`}
          style={{ animationDelay: isInView ? '320ms' : undefined }}
        >
          <h3 className="heading-md text-white mb-3">Want to Activate Your Space?</h3>
          <p className="body-md text-white/70 mb-5 max-w-2xl mx-auto">
            Connect with our community activation network to bring live experiences to your property.
          </p>
          <a
            href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20activate%20my%20venue%20with%20community%20experiences"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary inline-block"
          >
            Activate Your Venue
          </a>
        </div>
      </div>
    </section>
  );
}
