import { Phone, Mail, MessageCircle, MapPin } from 'lucide-react';
import { useInView } from '../hooks/useInView';

export default function Contact() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="contact"
      aria-labelledby="contact-heading"
      className="py-20 sm:py-28 bg-neutral-900 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-30" />

      <div className="section-max section-padding relative">
        <div className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Contact</span>
          <h2 id="contact-heading" className="heading-lg text-white mb-4">
            Contact The OTA Studio
          </h2>
          <p className="body-lg">
            Ready to grow your hospitality business? Get in touch for a free growth assessment.
          </p>
        </div>

        <div className={`grid sm:grid-cols-2 lg:grid-cols-4 gap-5 ${isInView ? 'animate-fade-up delay-200' : 'opacity-0'}`}>
          <a
            href="tel:+919270598602"
            className="group p-6 rounded-2xl border border-white/8 bg-white/4 hover:bg-white/10 hover:border-accent/30 transition-all duration-300 text-center"
            onClick={() => {
              if (typeof window !== 'undefined' && (window as any).dataLayer) {
                (window as any).dataLayer.push({ event: 'phone_click', phone_number: '+919270598602' });
              }
            }}
          >
            <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-accent/20 transition-colors">
              <Phone size={22} className="text-accent" aria-hidden="true" />
            </div>
            <h3 className="font-display font-bold text-sm text-white mb-1">Call Us</h3>
            <p className="text-sm text-accent">+91 92705 98602</p>
          </a>

          <a
            href="tel:+918551952391"
            className="group p-6 rounded-2xl border border-white/8 bg-white/4 hover:bg-white/10 hover:border-accent/30 transition-all duration-300 text-center"
            onClick={() => {
              if (typeof window !== 'undefined' && (window as any).dataLayer) {
                (window as any).dataLayer.push({ event: 'phone_click', phone_number: '+918551952391' });
              }
            }}
          >
            <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-accent/20 transition-colors">
              <Phone size={22} className="text-accent" aria-hidden="true" />
            </div>
            <h3 className="font-display font-bold text-sm text-white mb-1">Alt Number</h3>
            <p className="text-sm text-accent">+91 85519 52391</p>
          </a>

          <a
            href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20discuss%20OTA%20services"
            target="_blank"
            rel="noopener noreferrer"
            className="group p-6 rounded-2xl border border-white/8 bg-white/4 hover:bg-white/10 hover:border-accent/30 transition-all duration-300 text-center"
            onClick={() => {
              if (typeof window !== 'undefined' && (window as any).dataLayer) {
                (window as any).dataLayer.push({ event: 'whatsapp_click', action: 'contact_section' });
              }
            }}
          >
            <div className="w-12 h-12 rounded-xl bg-green-500/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-green-500/20 transition-colors">
              <MessageCircle size={22} className="text-green-400" aria-hidden="true" />
            </div>
            <h3 className="font-display font-bold text-sm text-white mb-1">WhatsApp</h3>
            <p className="text-sm text-green-400">Message Us</p>
          </a>

          <a
            href="mailto:theotastudios@gmail.com"
            className="group p-6 rounded-2xl border border-white/8 bg-white/4 hover:bg-white/10 hover:border-accent/30 transition-all duration-300 text-center"
            onClick={() => {
              if (typeof window !== 'undefined' && (window as any).dataLayer) {
                (window as any).dataLayer.push({ event: 'email_click', email: 'theotastudios@gmail.com' });
              }
            }}
          >
            <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-accent/20 transition-colors">
              <Mail size={22} className="text-accent" aria-hidden="true" />
            </div>
            <h3 className="font-display font-bold text-sm text-white mb-1">Email</h3>
            <p className="text-sm text-accent">theotastudios@gmail.com</p>
          </a>
        </div>

        <div className={`mt-12 text-center ${isInView ? 'animate-fade-up delay-400' : 'opacity-0'}`}>
          <div className="flex items-center justify-center gap-2 text-white/40">
            <MapPin size={16} aria-hidden="true" />
            <span className="text-sm">Based in Goa, India – Serving hospitality businesses nationwide</span>
          </div>
        </div>
      </div>
    </section>
  );
}
