import { useInView } from '../hooks/useInView';
import { Phone, Search, Sparkles } from 'lucide-react';

interface CtaCardProps {
  icon: React.ReactNode;
  iconBgColor: string;
  title: string;
  description: string;
  buttonText: string;
  buttonHref: string;
  buttonStyle: 'primary' | 'secondary' | 'tertiary';
  delay: number;
  borderColor: string;
  bgColor: string;
}

const CtaCard = ({
  icon,
  iconBgColor,
  title,
  description,
  buttonText,
  buttonHref,
  buttonStyle,
  delay,
  borderColor,
  bgColor,
}: CtaCardProps) => {
  const { ref, isInView } = useInView();

  const buttonStyles = {
    primary: 'bg-accent text-black hover:bg-yellow-500',
    secondary: 'border border-accent text-accent hover:border-yellow-500 hover:text-yellow-500',
    tertiary: 'border border-accent text-accent hover:border-accent-300 hover:text-accent-300',
  };

  const glowStyles = {
    primary: 'group-hover:shadow-[0_0_30px_rgba(255,208,0,0.3)]',
    secondary: '',
    tertiary: 'group-hover:shadow-[0_0_30px_rgba(255,208,0,0.2)]',
  };

  return (
    <div
      ref={ref as React.Ref<HTMLDivElement>}
      className={`group relative rounded-2xl border p-8 transition-all duration-500 transform ${borderColor} ${bgColor} ${
        isInView
          ? 'opacity-100 translate-y-0'
          : 'opacity-0 translate-y-8'
      } ${glowStyles[buttonStyle]}`}
      style={{
        transitionDelay: isInView ? `${delay}ms` : '0ms',
      }}
    >
      {/* Icon Circle */}
      <div
        className={`w-16 h-16 rounded-full ${iconBgColor} flex items-center justify-center mb-6 transition-transform duration-300 group-hover:scale-110`}
      >
        {icon}
      </div>

      {/* Title */}
      <h3 className="text-xl sm:text-2xl font-bold text-white mb-3">
        {title}
      </h3>

      {/* Description */}
      <p className="text-white/70 text-sm sm:text-base mb-6 leading-relaxed">
        {description}
      </p>

      {/* Button */}
      <a
        href={buttonHref}
        target={buttonHref.startsWith('http') ? '_blank' : undefined}
        rel={buttonHref.startsWith('http') ? 'noopener noreferrer' : undefined}
        className={`inline-block px-6 py-3 rounded-lg font-semibold transition-all duration-300 transform group-hover:scale-105 ${buttonStyles[buttonStyle]}`}
      >
        {buttonText}
      </a>
    </div>
  );
};

export default function CtaSystem() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref as React.Ref<HTMLElement>}
      className="w-full bg-neutral-950 py-16 sm:py-24 overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div
          className={`mb-12 sm:mb-16 transition-all duration-700 transform ${
            isInView
              ? 'opacity-100 translate-y-0'
              : 'opacity-0 translate-y-8'
          }`}
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Ready to Transform Your OTA Strategy?
          </h2>
          <p className="text-white/60 text-lg max-w-2xl">
            Whether you're just starting or looking to optimize, we have the right solution for your property.
          </p>
        </div>

        {/* CTA Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          {/* Primary CTA */}
          <CtaCard
            icon={<Phone className="w-8 h-8 text-black" />}
            iconBgColor="bg-accent"
            title="Book Growth Assessment"
            description="Get a personalized OTA growth strategy for your property"
            buttonText="Get Assessment"
            buttonHref="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20discuss%20OTA%20services"
            buttonStyle="primary"
            delay={100}
            borderColor="border-accent/30"
            bgColor="bg-accent/5"
          />

          {/* Secondary CTA */}
          <CtaCard
            icon={<Search className="w-8 h-8 text-accent" />}
            iconBgColor="bg-accent/10"
            title="Get Free OTA Audit"
            description="Find out how your OTA listings score against competitors"
            buttonText="Request Audit"
            buttonHref="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20discuss%20OTA%20services"
            buttonStyle="secondary"
            delay={200}
            borderColor="border-white/15"
            bgColor="bg-white/[0.02]"
          />

          {/* Tertiary CTA */}
          <CtaCard
            icon={<Sparkles className="w-8 h-8 text-accent" />}
            iconBgColor="bg-accent/10"
            title="Explore Experiences"
            description="Discover community experiences, wellness events and activations"
            buttonText="Learn More"
            buttonHref="/hospitality-activations-goa"
            buttonStyle="tertiary"
            delay={300}
            borderColor="border-accent/20"
            bgColor="bg-accent/5"
          />
        </div>
      </div>
    </section>
  );
};

/**
 * Individual button components for reuse
 */

export const BookConsultationButton = ({
  className = '',
}: {
  className?: string;
}) => (
  <a
    href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20discuss%20OTA%20services"
    target="_blank"
    rel="noopener noreferrer"
    className={`inline-flex items-center gap-2 px-4 py-2 bg-accent text-black font-semibold rounded-lg hover:bg-yellow-500 transition-colors duration-300 ${className}`}
  >
    <Phone className="w-4 h-4" />
    Get Growth Assessment
  </a>
);

export const OtaAuditButton = ({
  className = '',
}: {
  className?: string;
}) => (
  <a
    href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20discuss%20OTA%20services"
    target="_blank"
    rel="noopener noreferrer"
    className={`inline-flex items-center gap-2 px-4 py-2 border border-accent text-accent font-semibold rounded-lg hover:border-yellow-500 hover:text-yellow-500 transition-colors duration-300 ${className}`}
  >
    <Search className="w-4 h-4" />
    Get Free OTA Audit
  </a>
);

export const ExploreExperiencesButton = ({
  className = '',
}: {
  className?: string;
}) => (
  <a
    href="/hospitality-activations-goa"
    className={`inline-flex items-center gap-2 px-4 py-2 border border-accent text-accent font-semibold rounded-lg hover:border-accent-300 hover:text-accent-300 transition-colors duration-300 ${className}`}
  >
    <Sparkles className="w-4 h-4" />
    Explore Experiences
  </a>
);
