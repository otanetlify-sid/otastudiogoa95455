import { Hotel, Home, Building2, Users, ArrowRight } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const pathways = [
  {
    icon: Hotel,
    label: 'Grow Hotel Bookings',
    desc: 'OTA optimization & distribution',
    target: '/ota-management-goa',
  },
  {
    icon: Home,
    label: 'Improve Airbnb Ranking',
    desc: 'Listing optimization & reviews',
    target: '/airbnb-management-goa',
  },
  {
    icon: Building2,
    label: 'Start Hospitality Business in Goa',
    desc: 'Licensing, setup & OTA launch',
    target: '/how-to-start-a-hospitality-business-in-goa',
  },
  {
    icon: Users,
    label: 'Build Community Experiences',
    desc: 'Events, activations & loyalty',
    target: '/hospitality-activations-goa',
  },
];

export default function DecisionPathway() {
  const { ref, isInView } = useInView(0.15);

  return (
    <section ref={ref} className="relative py-12 sm:py-16 bg-neutral-950 text-white overflow-hidden">
      <div className="section-max section-padding relative">
        <div className={`text-center mb-8 sm:mb-10 ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/15 text-accent border border-accent/20 mb-3">Quick Start</span>
          <h2 className="heading-md text-white">What are you here for?</h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 max-w-4xl mx-auto">
          {pathways.map((pathway, i) => {
            const Icon = pathway.icon;
            return (
              <a
                key={i}
                href={pathway.target}
                className={`group relative p-4 sm:p-5 rounded-xl border border-white/10 bg-white/[0.02] hover:border-accent/25 hover:bg-white/[0.04] transition-all duration-300 ${
                  isInView ? 'animate-fade-up' : 'opacity-0'
                }`}
                style={{ animationDelay: isInView ? `${i * 80}ms` : undefined }}
              >
                <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-accent/6 via-transparent to-accent/3 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="relative">
                  <div className="w-9 h-9 rounded-lg bg-accent/10 flex items-center justify-center mb-3 group-hover:bg-accent/20 transition-colors">
                    <Icon size={16} className="text-accent" />
                  </div>
                  <h3 className="font-display font-bold text-sm text-white/80 group-hover:text-white transition-colors mb-1">
                    {pathway.label}
                  </h3>
                  <p className="text-[10px] sm:text-xs text-white/30 mb-3">{pathway.desc}</p>
                  <div className="flex items-center gap-1 text-[10px] text-accent/50 group-hover:text-accent transition-colors">
                    <span>Explore</span>
                    <ArrowRight size={10} className="group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </a>
            );
          })}
        </div>
      </div>
    </section>
  );
}
