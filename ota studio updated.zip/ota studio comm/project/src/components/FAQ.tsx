import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const faqs = [
  {
    q: 'What is OTA onboarding?',
    a: 'OTA onboarding is the process of setting up your property on Online Travel Agency platforms like Booking.com, Airbnb, Agoda, Expedia, MakeMyTrip, and others. It includes account creation, verification, listing setup, content optimization, pricing configuration, and go-live testing.',
  },
  {
    q: 'What is OTA management?',
    a: 'OTA management is the ongoing service of maintaining and optimizing your property listings across all OTA platforms. This includes content updates, pricing adjustments, review responses, performance monitoring, ranking optimization, and distribution management.',
  },
  {
    q: 'Which OTAs do you support?',
    a: 'We support all major OTAs including Booking.com, Airbnb, Agoda, Expedia, Hostelworld, MakeMyTrip, Goibibo, and Trip.com. We also work with regional and niche platforms as needed.',
  },
  {
    q: 'Do you work with Airbnb properties?',
    a: 'Yes, we provide complete Airbnb management services including listing optimization, Superhost achievement support, pricing strategy, guest communication templates, and ongoing performance management.',
  },
  {
    q: 'Do you work with hotels and villas?',
    a: 'Yes, we work with all property types including hotels, resorts, hostels, villas, homestays, boutique hotels, vacation rentals, and guest houses across India.',
  },
  {
    q: 'How long does OTA onboarding take?',
    a: 'Most properties go live on major OTAs within 7 to 14 days. The timeline depends on the number of platforms, property complexity, photo readiness, and document availability.',
  },
  {
    q: 'Do you offer distribution management?',
    a: 'Yes, we provide complete distribution management including channel manager setup, inventory synchronization across all OTAs, rate parity management, and real-time availability updates.',
  },
  {
    q: 'Can you optimize existing OTA listings?',
    a: 'Absolutely. If your property is already listed but underperforming, we perform a complete audit and optimize content, photos, pricing, and visibility signals. Most properties see ranking improvements within 2-4 weeks.',
  },
  {
    q: 'What is channel management?',
    a: 'Channel management is the process of managing your property\'s availability and rates across multiple OTA platforms through a centralized system. It prevents overbookings and ensures rate parity.',
  },
  {
    q: 'How can OTA optimization improve occupancy?',
    a: 'OTA optimization improves your property\'s search ranking, visibility, and conversion rate on booking platforms. Higher visibility leads to more bookings, better occupancy, and increased revenue.',
  },
];

export default function FAQ() {
  const { ref, isInView } = useInView();
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  return (
    <section
      ref={ref}
      id="faq"
      aria-labelledby="faq-heading"
      className="py-20 sm:py-28 bg-neutral-900 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-30" />

      <div className="section-max section-padding relative">
        <div className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">FAQ</span>
          <h2 id="faq-heading" className="heading-lg text-white mb-4">
            Frequently Asked <span className="text-accent">Questions</span>
          </h2>
          <p className="body-lg">
            Everything you need to know about OTA onboarding, management, and distribution services.
          </p>
        </div>

        <div className="max-w-3xl mx-auto space-y-3" role="list" itemScope itemType="https://schema.org/FAQPage">
          {faqs.map((faq, i) => (
            <div
              key={i}
              role="listitem"
              itemScope
              itemProp="mainEntity"
              itemType="https://schema.org/Question"
              className={`rounded-2xl border border-white/8 bg-white/4 overflow-hidden transition-all duration-300 ${isInView ? `animate-fade-up delay-${Math.min(i * 50, 500)}` : 'opacity-0'} ${openIdx === i ? 'border-accent/20 bg-white/6' : 'hover:border-white/12'}`}
            >
              <button
                onClick={() => setOpenIdx(openIdx === i ? null : i)}
                className="w-full flex items-center justify-between p-5 sm:p-6 text-left"
                aria-expanded={openIdx === i}
                aria-controls={`faq-answer-${i}`}
              >
                <span className="font-display font-bold text-sm sm:text-base text-white pr-4" itemProp="name">
                  {faq.q}
                </span>
                <ChevronDown
                  size={18}
                  aria-hidden="true"
                  className={`shrink-0 text-white/30 transition-transform duration-300 ${openIdx === i ? 'rotate-180 text-accent' : ''}`}
                />
              </button>
              <div
                id={`faq-answer-${i}`}
                className={`overflow-hidden transition-all duration-300 ${openIdx === i ? 'max-h-96' : 'max-h-0'}`}
                itemScope
                itemProp="acceptedAnswer"
                itemType="https://schema.org/Answer"
              >
                <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-sm text-white/50 leading-relaxed" itemProp="text">
                  {faq.a}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className={`mt-12 text-center ${isInView ? 'animate-fade-up delay-600' : 'opacity-0'}`}>
          <p className="text-sm text-white/40 mb-4">Have a question not answered here?</p>
          <a
            href="https://wa.me/919270598602?text=Hi%2C%20I%20have%20a%20question%20about%20OTA%20services"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-secondary"
          >
            Ask on WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}
