import { Phone, MessageCircle, X, TrendingUp } from 'lucide-react';
import { useState, useEffect } from 'react';

export default function FloatingContact() {
  const [open, setOpen] = useState(false);
  const [nearForm, setNearForm] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const formVisible = entries.some((entry) => entry.isIntersecting);
        setNearForm(formVisible);
      },
      { threshold: 0.3 }
    );

    const forms = document.querySelectorAll('form');
    forms.forEach((form) => observer.observe(form));

    return () => observer.disconnect();
  }, []);

  return (
    <>
      <div className={`fixed right-6 z-50 flex flex-col items-end gap-3 transition-all duration-300 ${nearForm ? 'bottom-24 sm:bottom-8' : 'bottom-24 sm:bottom-8'}`}>
        {open && (
          <div className="flex flex-col gap-2 animate-fade-up">
            <a
              href="tel:+919270598602"
              className="flex items-center gap-2.5 px-4 py-3 bg-neutral-900/95 backdrop-blur-xl text-white rounded-xl shadow-xl border border-white/12 text-sm font-medium hover:bg-neutral-800 hover:border-white/20 transition-all"
              aria-label="Call The OTA Studio"
            >
              <Phone size={15} aria-hidden="true" />
              +91 92705 98602
            </a>
            <a
              href="tel:+918551952391"
              className="flex items-center gap-2.5 px-4 py-3 bg-neutral-900/95 backdrop-blur-xl text-white/80 rounded-xl shadow-xl border border-white/12 text-sm font-medium hover:bg-neutral-800 hover:border-white/20 transition-all"
              aria-label="Call The OTA Studio alternate"
            >
              <Phone size={15} aria-hidden="true" />
              +91 85519 52391
            </a>
            <a
              href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20discuss%20OTA%20services"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2.5 px-4 py-3 bg-green-500 text-white rounded-xl shadow-xl text-sm font-bold hover:bg-green-600 transition-all"
              aria-label="WhatsApp The OTA Studio"
            >
              <MessageCircle size={15} aria-hidden="true" />
              WhatsApp Us
            </a>
          </div>
        )}
        <button
          onClick={() => setOpen(!open)}
          className={`w-14 h-14 rounded-full bg-accent text-neutral-950 shadow-lg shadow-accent/25 flex items-center justify-center hover:bg-accent-300 active:scale-95 transition-all ${nearForm ? 'sm:hidden' : ''}`}
          aria-label={open ? 'Close contact options' : 'Open contact options'}
          aria-expanded={open}
        >
          {open ? <X size={22} aria-hidden="true" /> : <MessageCircle size={22} aria-hidden="true" />}
        </button>
      </div>

      <div
        className={`fixed bottom-0 left-0 right-0 z-40 bg-neutral-950/95 backdrop-blur-xl border-t border-white/8 px-4 py-3 sm:hidden flex items-center gap-2 transition-transform duration-300 ${nearForm && !open ? '-translate-y-14' : ''}`}
        role="complementary"
        aria-label="Quick contact"
      >
        <a
          href="tel:+919270598602"
          className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-white/8 border border-white/12 text-white text-xs font-display font-bold"
          aria-label="Call The OTA Studio"
        >
          <Phone size={14} aria-hidden="true" />
          Call
        </a>
        <a
          href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20discuss%20OTA%20services"
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-green-500 text-white text-xs font-display font-bold"
          aria-label="WhatsApp The OTA Studio"
        >
          <MessageCircle size={14} aria-hidden="true" />
          WhatsApp
        </a>
        <a
          href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20a%20FREE%20OTA%20Audit"
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-accent text-neutral-950 text-xs font-display font-bold"
          aria-label="Get Free OTA Audit"
        >
          <TrendingUp size={14} aria-hidden="true" />
          Free Audit
        </a>
      </div>
    </>
  );
}
