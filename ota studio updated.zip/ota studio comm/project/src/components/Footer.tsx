import { Phone, Mail, MessageCircle, ArrowUpRight } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-neutral-950 border-t border-white/8 pt-16 pb-8 sm:pt-20 sm:pb-10" role="contentinfo">
      <div className="section-max section-padding">
        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-10 mb-14">
          <div className="sm:col-span-2 lg:col-span-1">
            <a href="/" className="group inline-flex items-baseline gap-0 mb-5">
              <span className="font-display font-extrabold text-base tracking-wider text-white/80 group-hover:text-white transition-colors">THE OT</span>
              <span className="font-display font-extrabold text-base tracking-wider text-accent">A</span>
              <span className="font-display font-extrabold text-base tracking-wider text-white/80 group-hover:text-white transition-colors"> STUDIO</span>
            </a>
            <p className="text-sm text-white/40 leading-relaxed max-w-xs mb-5">
              Hospitality Growth Platform. OTA onboarding, management, distribution, community activations, and partnerships across Goa.
            </p>
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              <span className="text-xs text-white/30">Based in Goa, India</span>
            </div>
          </div>

          <div>
            <h3 className="text-xs font-bold text-white/40 tracking-widest uppercase mb-5">OTA Services</h3>
            <ul className="space-y-2.5" role="list">
              {[
                { label: 'OTA Onboarding', href: '/ota-onboarding-goa' },
                { label: 'OTA Management', href: '/ota-management-goa' },
                { label: 'Airbnb Management', href: '/airbnb-management-goa' },
                { label: 'Hotel Marketing', href: '/hotel-marketing-goa' },
                { label: 'Hotel Distribution', href: '/hotel-distribution-goa' },
                { label: 'Property Management', href: '/property-management-goa' },
                { label: 'OTA Strategy Insights', href: '/ota-strategy-insights' },
              ].map((item) => (
                <li key={item.label}>
                  <a href={item.href} className="text-xs text-white/40 hover:text-white/80 transition-colors">{item.label}</a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-xs font-bold text-white/40 tracking-widest uppercase mb-5">OTA Platforms</h3>
            <ul className="space-y-2.5" role="list">
              {[
                { label: 'Booking.com', href: '/booking-com-management-goa' },
                { label: 'MakeMyTrip', href: '/makemytrip-management-goa' },
                { label: 'Goibibo', href: '/goibibo-management-goa' },
                { label: 'Expedia', href: '/expedia-management-goa' },
                { label: 'Agoda', href: '/agoda-management-goa' },
                { label: 'Hostelworld', href: '/hostelworld-management-goa' },
              ].map((item) => (
                <li key={item.label}>
                  <a href={item.href} className="text-xs text-white/40 hover:text-white/80 transition-colors">{item.label}</a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-xs font-bold text-white/40 tracking-widest uppercase mb-5">Community & Activations</h3>
            <ul className="space-y-2.5" role="list">
              {[
                { label: 'Hospitality Activations', href: '/hospitality-activations-goa' },
                { label: 'Community Events', href: '/community-events-goa' },
                { label: 'Venue Activations', href: '/venue-activations-goa' },
                { label: 'Wellness Events', href: '/wellness-events-goa' },
                { label: 'Live Music Events', href: '/live-music-events-goa' },
                { label: 'Yoga Events', href: '/yoga-events-goa' },
                { label: 'Sound Healing', href: '/sound-healing-goa' },
                { label: 'Creative Workshops', href: '/creative-workshops-goa' },
                { label: 'Bar Growth', href: '/bar-growth-goa' },
                { label: 'Nightlife Growth', href: '/nightlife-growth-goa' },
                { label: 'Restaurant Community', href: '/community-growth-for-restaurants' },
                { label: 'Cafe Community', href: '/community-growth-for-cafes' },
              ].map((item) => (
                <li key={item.label}>
                  <a href={item.href} className="text-xs text-white/40 hover:text-white/80 transition-colors">{item.label}</a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-xs font-bold text-white/40 tracking-widest uppercase mb-5">How-To Guides</h3>
            <ul className="space-y-2.5" role="list">
              {[
                { label: 'Start a Hotel', href: '/how-to-start-hotel-in-goa' },
                { label: 'Start a Hostel', href: '/how-to-start-hostel-in-goa' },
                { label: 'Start a Villa', href: '/how-to-start-villa-in-goa' },
                { label: 'Start a Resort', href: '/how-to-start-resort-in-goa' },
                { label: 'Start a Cafe', href: '/how-to-start-cafe-in-goa' },
                { label: 'Start a Restaurant', href: '/how-to-start-restaurant-in-goa' },
                { label: 'Start a Bar', href: '/how-to-start-bar-in-goa' },
                { label: 'Start a Homestay', href: '/how-to-start-homestay-in-goa' },
                { label: 'Start a Beach Club', href: '/how-to-start-beach-club-in-goa' },
                { label: 'Tourism License', href: '/how-to-get-tourism-license-in-goa' },
              ].map((item) => (
                <li key={item.label}>
                  <a href={item.href} className="text-xs text-white/40 hover:text-white/80 transition-colors">{item.label}</a>
                </li>
              ))}
            </ul>

            <h3 className="text-xs font-bold text-white/40 tracking-widest uppercase mt-6 mb-5">Network</h3>
            <ul className="space-y-2.5" role="list">
              {[
                { label: 'Partner Network', href: '/partner-network' },
                { label: 'Technology Partners', href: '/technology-partners' },
                { label: 'Activation Partners', href: '/activation-partners' },
                { label: 'Venue Partners', href: '/venue-partners' },
                { label: 'Founders', href: '/founders' },
                { label: 'Vision & Mission', href: '/vision-mission' },
              ].map((item) => (
                <li key={item.label}>
                  <a href={item.href} className="text-xs text-white/40 hover:text-white/80 transition-colors">{item.label}</a>
                </li>
              ))}
            </ul>

            <h3 className="text-xs font-bold text-white/40 tracking-widest uppercase mt-6 mb-5">Contact</h3>
            <address className="not-italic">
              <ul className="space-y-2.5" role="list">
                <li>
                  <a href="tel:+919270598602" className="flex items-center gap-2 text-xs text-white/40 hover:text-white/80 transition-colors">
                    <Phone size={12} aria-hidden="true" />
                    +91 92705 98602
                  </a>
                </li>
                <li>
                  <a href="tel:+918551952391" className="flex items-center gap-2 text-xs text-white/40 hover:text-white/80 transition-colors">
                    <Phone size={12} aria-hidden="true" />
                    +91 85519 52391
                  </a>
                </li>
                <li>
                  <a href="https://wa.me/919270598602" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-xs text-white/40 hover:text-white/80 transition-colors">
                    <MessageCircle size={12} aria-hidden="true" />
                    WhatsApp
                  </a>
                </li>
                <li>
                  <a href="mailto:theotastudios@gmail.com" className="flex items-center gap-2 text-xs text-white/40 hover:text-white/80 transition-colors">
                    <Mail size={12} aria-hidden="true" />
                    theotastudios@gmail.com
                  </a>
                </li>
                <li>
                  <span className="flex items-center gap-2 text-xs text-white/40">
                    <ArrowUpRight size={12} aria-hidden="true" />
                    otastudio.in
                  </span>
                </li>
              </ul>
            </address>
          </div>
        </div>

        <div className="pt-8 border-t border-white/8">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-xs text-white/25">&copy; {currentYear} The OTA Studio. All rights reserved. Goa, India.</p>
            <nav aria-label="Legal navigation">
              <ul className="flex flex-wrap gap-5" role="list">
                {[
                  { label: 'Privacy Policy', href: '/privacy-policy' },
                  { label: 'Terms & Conditions', href: '/terms-and-conditions' },
                ].map((item) => (
                  <li key={item.label}>
                    <a href={item.href} className="text-xs text-white/25 hover:text-white/50 transition-colors">{item.label}</a>
                  </li>
                ))}
              </ul>
            </nav>
          </div>
          <p className="text-[10px] text-white/15 mt-3 text-center sm:text-left">
            Hospitality Growth Platform — OTA Growth + Community Activations
          </p>
        </div>
      </div>
    </footer>
  );
}
