import { useState } from 'react';

interface FormFieldProps {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
  placeholder?: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  className?: string;
  rows?: number;
  error?: string;
}

export default function FormField({
  label,
  name,
  type = 'text',
  required = false,
  placeholder = '',
  value,
  onChange,
  className = '',
  rows,
  error,
}: FormFieldProps) {
  const [touched, setTouched] = useState(false);
  const showError = touched && error;
  const isTextarea = rows !== undefined;

  const sharedClasses = `w-full px-4 py-3 rounded-xl bg-white border border-neutral-200 text-sm text-neutral-950 placeholder:text-[#666666] focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent/30 transition-colors ${showError ? 'border-red-400 focus:border-red-400 focus:ring-red-400/30' : ''} ${className}`;

  return (
    <div className="space-y-1.5">
      <label htmlFor={name} className="block text-sm font-semibold text-white">
        {label}{required && <span className="text-accent ml-0.5">*</span>}
      </label>
      {isTextarea ? (
        <textarea
          id={name}
          name={name}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          onBlur={() => setTouched(true)}
          required={required}
          rows={rows}
          className={`${sharedClasses} resize-none`}
          aria-invalid={showError ? 'true' : undefined}
          aria-describedby={showError ? `${name}-error` : undefined}
        />
      ) : (
        <input
          id={name}
          name={name}
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          onBlur={() => setTouched(true)}
          required={required}
          className={sharedClasses}
          aria-invalid={showError ? 'true' : undefined}
          aria-describedby={showError ? `${name}-error` : undefined}
        />
      )}
      {showError && (
        <p id={`${name}-error`} className="text-xs text-red-400 mt-1" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

interface FormSelectProps {
  label: string;
  name: string;
  required?: boolean;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  children: React.ReactNode;
  className?: string;
}

export function FormSelect({
  label,
  name,
  required = false,
  value,
  onChange,
  children,
  className = '',
}: FormSelectProps) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={name} className="block text-sm font-semibold text-white">
        {label}{required && <span className="text-accent ml-0.5">*</span>}
      </label>
      <select
        id={name}
        name={name}
        required={required}
        value={value}
        onChange={onChange}
        className={`w-full px-4 py-3 rounded-xl bg-white border border-neutral-200 text-sm text-neutral-950 focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent/30 transition-colors appearance-none ${className}`}
      >
        {children}
      </select>
    </div>
  );
}
