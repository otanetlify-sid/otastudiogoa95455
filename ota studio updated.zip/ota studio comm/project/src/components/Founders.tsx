import { Users, Award, Clock } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const founders = [
  {
    name: 'Siddharth',
    role: 'Co-Founder, OTA Studio',
    initials: 'S',
    highlights: [
      '10+ years in Goa hospitality',
      'OTA systems & property performance',
      'Visibility & bookings optimization',
    ],
    bio: 'Siddharth has over 10 years of experience in Goa\'s hospitality industry, working closely with hotels, hostels, and tourism businesses. His expertise includes OTA systems, property performance optimization, and improving visibility and bookings for hospitality businesses.',
  },
  {
    name: 'Suchit',
    role: 'Co-Founder, OTA Studio',
    initials: 'Su',
    highlights: [
      '10+ years in Goa ecosystem',
      'Business development & operations',
      'OTA growth strategies',
    ],
    bio: 'Suchit brings over 10 years of experience in Goa\'s hospitality ecosystem, specializing in hospitality business development, operations, and OTA growth strategies. He focuses on scaling hotel and hostel performance through structured onboarding, optimization, and hospitality network expansion.',
  },
  {
    name: 'Bhavana Rana',
    role: 'Founding Builder – Community Experiences & Partnerships',
    initials: 'BR',
    highlights: [
      'Community building & experiences',
      'Creator collaborations & partnerships',
      'Hospitality ecosystem development',
    ],
    bio: 'Bhavana Rana is a hospitality-focused creator, partnership builder and community strategist passionate about bringing people, brands and experiences together across Goa. Her interests include community building, hospitality experiences, creator collaborations, partnerships, networking and ecosystem development.',
  },
];

export default function Founders() {
  const { ref, isInView } = useInView();

  return (
    <section ref={ref} id="founders" className="py-20 sm:py-28 bg-neutral-50/50">
      <div className="section-max section-padding">
        {/* Header */}
        <div
          className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 ${
            isInView ? 'animate-fade-up' : 'opacity-0'
          }`}
        >
          <span className="badge bg-accent/10 text-accent-700 mb-4">
            <Users size={12} />
            The Founders
          </span>
          <h2 className="heading-lg">Meet the Founders</h2>
          <p className="body-lg mt-4">
            Built by hospitality professionals with 10+ years of experience in
            Goa's hotel, hostel, and tourism ecosystem.
          </p>
        </div>

        {/* Founder Cards */}
        <div className="grid md:grid-cols-3 gap-6 sm:gap-8 max-w-5xl mx-auto">
          {founders.map((founder, i) => (
            <div
              key={i}
              className={`group relative bg-white rounded-2xl border border-neutral-100 hover:shadow-xl hover:shadow-neutral-200/40 transition-all duration-300 hover:-translate-y-1 overflow-hidden opacity-0 ${
                isInView
                  ? `animate-fade-up delay-${(i + 1) * 100}`
                  : ''
              }`}
            >
              {/* Top accent bar */}
              <div className="h-1.5 bg-gradient-to-r from-accent to-accent-300" />

              <div className="p-6 sm:p-8">
                <div className="flex items-center gap-4 mb-5">
                  <div className="w-14 h-14 rounded-xl bg-neutral-950 flex items-center justify-center shrink-0">
                    <span className="font-display font-extrabold text-lg text-accent">
                      {founder.initials}
                    </span>
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-xl">
                      {founder.name}
                    </h3>
                    <p className="text-sm text-neutral-500">{founder.role}</p>
                  </div>
                </div>

                <p className="text-sm text-neutral-600 leading-relaxed mb-5">
                  {founder.bio}
                </p>

                <div className="space-y-2.5 pt-5 border-t border-neutral-100">
                  {founder.highlights.map((h, j) => (
                    <div key={j} className="flex items-center gap-2.5 text-sm text-neutral-700">
                      <span className="w-1.5 h-1.5 rounded-full bg-accent shrink-0" />
                      {h}
                    </div>
                  ))}
                </div>

                <div className="flex items-center gap-2 mt-5">
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-accent/10 text-xs font-semibold text-accent-700">
                    <Clock size={12} />
                    10+ Years
                  </div>
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-accent/10 text-xs font-semibold text-accent-700">
                    <Award size={12} />
                    Goa Expert
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Trust Statement */}
        <div
          className={`mt-12 sm:mt-16 max-w-3xl mx-auto opacity-0 ${
            isInView ? 'animate-fade-up delay-300' : ''
          }`}
        >
          <div className="relative bg-white rounded-2xl p-8 sm:p-10 border border-neutral-100 text-center shadow-sm">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2">
              <div className="w-6 h-6 rounded-full bg-accent flex items-center justify-center">
                <span className="text-xs font-bold text-neutral-950">+</span>
              </div>
            </div>
            <p className="text-base sm:text-lg text-neutral-700 leading-relaxed font-medium">
              Together, Siddharth and Suchit have built strong roots in Goa's
              hospitality ecosystem, working closely with property owners,
              investors, and tourism businesses to unlock growth opportunities.
            </p>
            <div className="flex items-center justify-center gap-2 mt-5">
              <div className="w-8 h-px bg-accent" />
              <span className="text-xs font-semibold text-accent-600 tracking-wider uppercase">
                10+ Years Combined Expertise
              </span>
              <div className="w-8 h-px bg-accent" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
