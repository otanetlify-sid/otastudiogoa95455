import { useEffect, useRef } from 'react';

const ARC_CITIES = [
  { name: 'Goa', lat: 15.3, lng: 74.1, hub: true, flow: 100, type: 'hub' },
  { name: 'Mumbai', lat: 19.1, lng: 72.9, flow: 35, type: 'domestic' },
  { name: 'Delhi', lat: 28.6, lng: 77.2, flow: 25, type: 'domestic' },
  { name: 'Bangalore', lat: 12.97, lng: 77.6, flow: 20, type: 'domestic' },
  { name: 'Dubai', lat: 25.2, lng: 55.3, flow: 15, type: 'international' },
  { name: 'London', lat: 51.5, lng: -0.1, flow: 12, type: 'international' },
  { name: 'Pune', lat: 18.5, lng: 73.9, flow: 18, type: 'domestic' },
  { name: 'Hyderabad', lat: 17.4, lng: 78.5, flow: 12, type: 'domestic' },
  { name: 'Moscow', lat: 55.8, lng: 37.6, flow: 8, type: 'international' },
  { name: 'Berlin', lat: 52.5, lng: 13.4, flow: 6, type: 'international' },
];

function project(lat: number, lng: number, cx: number, cy: number, r: number, rot: number) {
  const phi = (lat * Math.PI) / 180;
  const lambda = ((lng - rot) * Math.PI) / 180;
  const x = cx + r * Math.cos(phi) * Math.sin(lambda);
  const y = cy - r * Math.sin(phi);
  const vis = Math.cos(phi) * Math.cos(lambda) > 0;
  return { x, y, vis };
}

export default function GlobeVisual() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);
  const rotRef = useRef(74);
  const mouseRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      const rect = canvas.parentElement?.getBoundingClientRect();
      if (!rect) return;
      const dpr = window.devicePixelRatio || 1;
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      canvas.style.width = rect.width + 'px';
      canvas.style.height = rect.height + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener('resize', resize);

    const onMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    };
    canvas.addEventListener('mousemove', onMove);

    const draw = () => {
      const w = canvas.width / (window.devicePixelRatio || 1);
      const h = canvas.height / (window.devicePixelRatio || 1);
      ctx.clearRect(0, 0, w, h);

      const cx = w * 0.5;
      const cy = h * 0.5;
      const r = Math.min(w, h) * 0.35;

      rotRef.current += 0.03;
      const rot = rotRef.current;
      const mx = (mouseRef.current.x - cx) / w;
      const tilt = mx * 5;

      // Globe outline
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255, 208, 0, 0.06)';
      ctx.lineWidth = 1;
      ctx.stroke();

      // Latitude lines
      for (let lat = -60; lat <= 60; lat += 30) {
        ctx.beginPath();
        for (let lng = 0; lng <= 360; lng += 3) {
          const p = project(lat, lng + tilt, cx, cy, r, rot);
          if (p.vis) {
            if (lng === 0) ctx.moveTo(p.x, p.y);
            else ctx.lineTo(p.x, p.y);
          }
        }
        ctx.strokeStyle = 'rgba(255, 208, 0, 0.03)';
        ctx.lineWidth = 0.5;
        ctx.stroke();
      }

      // Longitude lines
      for (let lng = 0; lng < 360; lng += 30) {
        ctx.beginPath();
        for (let lat = -90; lat <= 90; lat += 3) {
          const p = project(lat, lng + tilt, cx, cy, r, rot);
          if (p.vis) {
            if (lat === -90) ctx.moveTo(p.x, p.y);
            else ctx.lineTo(p.x, p.y);
          }
        }
        ctx.strokeStyle = 'rgba(255, 208, 0, 0.03)';
        ctx.lineWidth = 0.5;
        ctx.stroke();
      }

      // Tourist flow arcs and city dots
      const goa = project(ARC_CITIES[0].lat, ARC_CITIES[0].lng + tilt, cx, cy, r, rot);
      if (goa.vis) {
        // Goa hub - larger glow based on flow intensity
        ctx.beginPath();
        ctx.arc(goa.x, goa.y, 8, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 208, 0, 0.1)';
        ctx.fill();
        ctx.beginPath();
        ctx.arc(goa.x, goa.y, 4, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 208, 0, 0.15)';
        ctx.fill();
        ctx.beginPath();
        ctx.arc(goa.x, goa.y, 2.5, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 208, 0, 0.6)';
        ctx.fill();
      }

      for (let i = 1; i < ARC_CITIES.length; i++) {
        const city = project(ARC_CITIES[i].lat, ARC_CITIES[i].lng + tilt, cx, cy, r, rot);
        if (city.vis && goa.vis) {
          const isInternational = ARC_CITIES[i].type === 'international';
          const flowIntensity = ARC_CITIES[i].flow / 100;

          // Flow arc - thicker and brighter for higher flow
          ctx.beginPath();
          ctx.moveTo(goa.x, goa.y);
          const midX = (goa.x + city.x) / 2;
          const midY = (goa.y + city.y) / 2 - 20 - flowIntensity * 10;
          ctx.quadraticCurveTo(midX, midY, city.x, city.y);
          ctx.strokeStyle = isInternational
            ? `rgba(255, 255, 255, ${0.04 + flowIntensity * 0.06})`
            : `rgba(255, 208, 0, ${0.06 + flowIntensity * 0.08})`;
          ctx.lineWidth = 0.5 + flowIntensity;
          ctx.stroke();

          // City dot - size based on flow
          const dotR = 1 + flowIntensity * 1.5;
          ctx.beginPath();
          ctx.arc(city.x, city.y, dotR, 0, Math.PI * 2);
          ctx.fillStyle = isInternational
            ? `rgba(255, 255, 255, ${0.2 + flowIntensity * 0.3})`
            : `rgba(255, 208, 0, ${0.25 + flowIntensity * 0.35})`;
          ctx.fill();

          // Glow ring for bigger feeder cities
          if (flowIntensity > 0.15) {
            ctx.beginPath();
            ctx.arc(city.x, city.y, dotR + 2, 0, Math.PI * 2);
            ctx.strokeStyle = isInternational
              ? `rgba(255, 255, 255, ${0.06 + flowIntensity * 0.04})`
              : `rgba(255, 208, 0, ${0.08 + flowIntensity * 0.06})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }

      rafRef.current = requestAnimationFrame(draw);
    };

    rafRef.current = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener('resize', resize);
      canvas.removeEventListener('mousemove', onMove);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none"
      style={{ opacity: 0.5 }}
    />
  );
}
