import { useEffect, useRef, useState } from 'react';

interface NetworkNode {
  id: string;
  cx: number;
  cy: number;
  label: string;
}

const nodes: NetworkNode[] = [
  { id: 'hotels', cx: 52, cy: 35, label: 'Hotels' },
  { id: 'hostels', cx: 38, cy: 28, label: 'Hostels' },
  { id: 'villas', cx: 65, cy: 42, label: 'Villas' },
  { id: 'cafes', cx: 45, cy: 55, label: 'Cafes' },
  { id: 'restaurants', cx: 58, cy: 62, label: 'Restaurants' },
  { id: 'bars', cx: 70, cy: 55, label: 'Bars' },
  { id: 'yoga', cx: 32, cy: 48, label: 'Yoga' },
  { id: 'wellness', cx: 40, cy: 42, label: 'Wellness' },
  { id: 'events', cx: 55, cy: 48, label: 'Events' },
  { id: 'activations', cx: 48, cy: 38, label: 'Activations' },
];

const connections = [
  ['activations', 'hotels'], ['activations', 'hostels'], ['activations', 'villas'],
  ['activations', 'cafes'], ['activations', 'restaurants'], ['activations', 'bars'],
  ['events', 'cafes'], ['events', 'restaurants'], ['events', 'bars'],
  ['wellness', 'yoga'], ['wellness', 'hotels'], ['wellness', 'villas'],
  ['yoga', 'cafes'], ['yoga', 'activations'],
];

export default function GoaNetworkMap() {
  const ref = useRef<HTMLDivElement>(null);
  const [isInView, setIsInView] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setIsInView(true); obs.unobserve(el); } }, { threshold: 0.1 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  return (
    <div ref={ref} className="relative w-full max-w-md mx-auto aspect-square">
      <svg viewBox="0 0 100 80" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
        {/* Goa outline - simplified */}
        <path
          d="M15,20 Q20,12 30,10 Q40,8 50,12 Q60,10 70,15 Q78,20 80,30 Q82,40 78,50 Q75,58 68,65 Q58,72 45,70 Q32,68 22,60 Q14,52 12,42 Q10,32 15,20 Z"
          fill="none"
          stroke="rgba(255,208,0,0.08)"
          strokeWidth="0.5"
        />

        {/* Connection lines */}
        {connections.map(([from, to], i) => {
          const a = nodes.find(n => n.id === from);
          const b = nodes.find(n => n.id === to);
          if (!a || !b) return null;
          return (
            <line
              key={i}
              x1={a.cx} y1={a.cy} x2={b.cx} y2={b.cy}
              stroke="rgba(255,208,0,0.08)"
              strokeWidth="0.3"
              className={isInView ? 'animate-draw-line' : ''}
              style={{ animationDelay: `${i * 50}ms` }}
            />
          );
        })}

        {/* Nodes */}
        {nodes.map((node, i) => (
          <g key={node.id}>
            {/* Pulse ring */}
            <circle
              cx={node.cx} cy={node.cy} r="3"
              fill="none" stroke="rgba(255,208,0,0.12)"
              strokeWidth="0.2"
              className={isInView ? 'animate-node-pulse' : ''}
              style={{ animationDelay: `${i * 200}ms` }}
            />
            {/* Core dot */}
            <circle
              cx={node.cx} cy={node.cy} r="1.2"
              fill="rgba(255,208,0,0.4)"
              className={isInView ? 'animate-node-glow' : ''}
              style={{ animationDelay: `${i * 200}ms` }}
            />
            {/* Label */}
            <text
              x={node.cx} y={node.cy + 4}
              textAnchor="middle"
              fill="rgba(255,255,255,0.25)"
              fontSize="2.2"
              fontFamily="Inter, sans-serif"
              fontWeight="500"
            >
              {node.label}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}
