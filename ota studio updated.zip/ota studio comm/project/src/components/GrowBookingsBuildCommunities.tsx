import { Building2, Users, TrendingUp, Sparkles, Globe, Calendar, Music, Heart, ArrowRight } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const hospitalityItems = [
  { label: 'OTA Onboarding', icon: Globe, href: '/ota-onboarding-goa' },
  { label: 'OTA Management', icon: Building2, href: '/ota-management-goa' },
  { label: 'Distribution', icon: TrendingUp, href: '/hotel-distribution-goa' },
  { label: 'Visibility', icon: Sparkles, href: '/hotel-marketing-goa' },
  { label: 'Revenue Optimization', icon: TrendingUp, href: '/ota-strategy-insights' },
];

const communityItems = [
  { label: 'Activations', icon: Sparkles, href: '/hospitality-activations-goa' },
  { label: 'Live Music', icon: Music, href: '/live-music-events-goa' },
  { label: 'Yoga', icon: Heart, href: '/yoga-events-goa' },
  { label: 'Wellness', icon: Users, href: '/wellness-events-goa' },
  { label: 'Workshops', icon: Calendar, href: '/creative-workshops-goa' },
  { label: 'Events', icon: Users, href: '/community-events-goa' },
];

export default function GrowBookingsBuildCommunities() {
  const { ref, isInView } = useInView(0.2);

  return (
    <section ref={ref} className="relative py-20 sm:py-28 bg-neutral-950 overflow-hidden">
      {/* Background network lines */}
      <div className="absolute inset-0 pointer-events-none">
        <svg className="w-full h-full opacity-20" viewBox="0 0 1200 600" preserveAspectRatio="none">
          <defs>
            <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#FFD000" stopOpacity="0" />
              <stop offset="50%" stopColor="#FFD000" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#FFD000" stopOpacity="0" />
            </linearGradient>
          </defs>
          <line x1="100" y1="300" x2="1100" y2="300" stroke="url(#lineGradient)" strokeWidth="1" />
          <line x1="100" y1="280" x2="1100" y2="320" stroke="url(#lineGradient)" strokeWidth="0.5" />
          <line x1="100" y1="320" x2="1100" y2="280" stroke="url(#lineGradient)" strokeWidth="0.5" />
        </svg>
      </div>

      <div className="section-max section-padding relative">
        {/* Headlines */}
        <div className={`text-center mb-12 sm:mb-16 transition-all duration-1000 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <h2 className="heading-xl text-white mb-3">
            <span className="text-accent">GROW BOOKINGS.</span>
            <br />
            <span className="text-white">BUILD COMMUNITIES.</span>
          </h2>
          <p className="body-lg max-w-2xl mx-auto">
            OTA Studio powers hospitality growth through two connected pillars: OTA distribution and community experiences.
          </p>
        </div>

        {/* Two Pillars */}
        <div className="grid md:grid-cols-2 gap-6 sm:gap-8 lg:gap-12 max-w-5xl mx-auto">
          {/* Hospitality Growth - Yellow */}
          <div className={`transition-all duration-1000 delay-200 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <div className="relative p-6 sm:p-8 rounded-2xl sm:rounded-3xl border border-accent/20 bg-gradient-to-br from-accent/5 via-transparent to-transparent overflow-hidden group hover:border-accent/40 transition-colors">
              {/* Glow effect */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-32 bg-accent/20 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity" />

              <div className="relative">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center">
                    <Building2 size={24} className="text-accent" />
                  </div>
                  <div>
                    <h3 className="text-lg sm:text-xl font-display font-bold text-accent">Hospitality Growth</h3>
                    <p className="text-sm text-white/50">OTA Distribution & Visibility</p>
                  </div>
                </div>

                <div className="space-y-2">
                  {hospitalityItems.map((item, i) => {
                    const Icon = item.icon;
                    return (
                      <a
                        key={item.label}
                        href={item.href}
                        className="flex items-center gap-3 px-4 py-3 rounded-lg bg-white/[0.02] border border-white/5 text-white/70 text-sm font-medium transition-all hover:bg-accent/5 hover:border-accent/20 hover:text-accent group/item"
                        style={{ transitionDelay: `${i * 50}ms` }}
                      >
                        <Icon size={16} className="text-accent/60 group-hover/item:text-accent transition-colors" />
                        <span>{item.label}</span>
                        <ArrowRight size={14} className="ml-auto opacity-0 group-hover/item:opacity-100 text-accent transition-opacity" />
                      </a>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Community Growth - Electric Cyan */}
          <div className={`transition-all duration-1000 delay-400 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <div className="relative p-6 sm:p-8 rounded-2xl sm:rounded-3xl border border-white/10 bg-gradient-to-br from-white/3 via-transparent to-transparent overflow-hidden group hover:border-accent/30 transition-colors">
              {/* Glow effect */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-32 bg-accent/10 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity" />

              <div className="relative">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-white/8 flex items-center justify-center">
                    <Users size={24} className="text-white/70" />
                  </div>
                  <div>
                    <h3 className="text-lg sm:text-xl font-display font-bold text-white">Community Growth</h3>
                    <p className="text-sm text-white/50">Activations & Experiences</p>
                  </div>
                </div>

                <div className="space-y-2">
                  {communityItems.map((item, i) => {
                    const Icon = item.icon;
                    return (
                      <a
                        key={item.label}
                        href={item.href}
                        className="flex items-center gap-3 px-4 py-3 rounded-lg bg-white/[0.02] border border-white/5 text-white/70 text-sm font-medium transition-all hover:bg-accent/5 hover:border-accent/20 hover:text-accent group/item"
                        style={{ transitionDelay: `${i * 50}ms` }}
                      >
                        <Icon size={16} className="text-white/30 group-hover/item:text-accent transition-colors" />
                        <span>{item.label}</span>
                        <ArrowRight size={14} className="ml-auto opacity-0 group-hover/item:opacity-100 text-accent transition-opacity" />
                      </a>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Center Connection */}
        <div className={`flex justify-center mt-8 sm:mt-12 transition-all duration-1000 delay-600 ${isInView ? 'opacity-100' : 'opacity-0'}`}>
          <div className="flex items-center gap-4">
            <div className="w-20 h-px bg-gradient-to-r from-transparent via-accent/50 to-transparent" />
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10">
              <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
              <div className="w-2 h-2 rounded-full bg-white/40 animate-pulse" style={{ animationDelay: '0.5s' }} />
            </div>
            <div className="w-20 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
          </div>
        </div>
      </div>
    </section>
  );
}
