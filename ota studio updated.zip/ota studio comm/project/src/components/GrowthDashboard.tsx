import { useEffect, useState, useRef } from 'react';
import { TrendingUp, BarChart3, ArrowUpRight, Target, Wallet, Gauge } from 'lucide-react';

interface Kpi {
  label: string;
  target: number;
  suffix: string;
  icon: React.ElementType;
}

const defaultKpis: Kpi[] = [
  { label: 'Occupancy Rate', target: 76, suffix: '%', icon: BarChart3 },
  { label: 'Revenue Growth', target: 23, suffix: '%', icon: TrendingUp },
  { label: 'Booking Increase', target: 34, suffix: '%', icon: ArrowUpRight },
  { label: 'OTA Ranking Score', target: 87, suffix: '/100', icon: Target },
  { label: 'Direct Booking Growth', target: 18, suffix: '%', icon: Wallet },
];

function AnimatedNumber({ target, suffix, trigger }: { target: number; suffix: string; trigger: boolean }) {
  const [value, setValue] = useState(0);

  useEffect(() => {
    if (!trigger) return;
    let start = 0;
    const duration = 1800;
    const startTime = performance.now();

    function tick(now: number) {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = Math.round(eased * target);
      if (current !== start) {
        start = current;
        setValue(current);
      }
      if (progress < 1) requestAnimationFrame(tick);
    }

    requestAnimationFrame(tick);
  }, [trigger, target]);

  return (
    <span className="font-display font-extrabold text-2xl sm:text-3xl text-accent tabular-nums">
      {value}{suffix}
    </span>
  );
}

interface GrowthDashboardProps {
  kpis?: Kpi[];
}

export default function GrowthDashboard({ kpis = defaultKpis }: GrowthDashboardProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          obs.unobserve(el);
        }
      },
      { threshold: 0.2 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  return (
    <section ref={ref} className="py-12 sm:py-16 bg-neutral-950 relative overflow-hidden">
      <div className="absolute inset-0 section-grid opacity-20" />
      <div className="section-max section-padding relative">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent/10 border border-accent/20 text-accent text-xs font-semibold tracking-wide uppercase mb-4">
            <Gauge size={12} />
            Live Insights
          </div>
          <h2 className="heading-lg text-white mb-2">OTA Studio Performance Snapshot</h2>
          <p className="body-md max-w-xl mx-auto">Real-time optimization insights across hospitality systems in Goa</p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
          {kpis.map((kpi, i) => (
            <div
              key={i}
              className="relative group p-4 sm:p-5 rounded-2xl border border-white/10 bg-white/[0.03] backdrop-blur-sm hover:border-accent/30 hover:bg-white/[0.06] transition-all duration-300"
            >
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-accent/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="relative">
                <kpi.icon size={18} className="text-accent/60 mb-3" />
                <AnimatedNumber target={kpi.target} suffix={kpi.suffix} trigger={visible} />
                <p className="text-xs text-white/50 mt-1.5 leading-tight">{kpi.label}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
