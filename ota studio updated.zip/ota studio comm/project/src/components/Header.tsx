import { useState, useEffect, useRef, useCallback } from 'react';
import { X, Phone, ChevronDown, Home, Building2, Users, BookOpen, Network, Sparkles, ArrowRight } from 'lucide-react';

const navCategories = [
  {
    label: 'OTA Services',
    icon: Building2,
    color: 'accent',
    description: 'OTA onboarding, management, distribution',
    items: [
      { label: 'OTA Onboarding', href: '/ota-onboarding-goa' },
      { label: 'OTA Management', href: '/ota-management-goa' },
      { label: 'Airbnb Management', href: '/airbnb-management-goa' },
      { label: 'Hotel Marketing', href: '/hotel-marketing-goa' },
      { label: 'Hotel Distribution', href: '/hotel-distribution-goa' },
      { label: 'Property Management', href: '/property-management-goa' },
      { label: 'OTA Strategy', href: '/ota-strategy-insights' },
    ],
  },
  {
    label: 'OTA Platforms',
    icon: Network,
    color: 'accent',
    description: 'Channel management across platforms',
    items: [
      { label: 'Booking.com', href: '/booking-com-management-goa' },
      { label: 'MakeMyTrip', href: '/makemytrip-management-goa' },
      { label: 'Goibibo', href: '/goibibo-management-goa' },
      { label: 'Expedia', href: '/expedia-management-goa' },
      { label: 'Agoda', href: '/agoda-management-goa' },
      { label: 'Hostelworld', href: '/hostelworld-management-goa' },
    ],
  },
  {
    label: 'Community',
    icon: Users,
    color: 'emerald',
    description: 'Activations, events, experiences',
    items: [
      { label: 'Hospitality Activations', href: '/hospitality-activations-goa' },
      { label: 'Community Events', href: '/community-events-goa' },
      { label: 'Venue Activations', href: '/venue-activations-goa' },
      { label: 'Wellness Events', href: '/wellness-events-goa' },
      { label: 'Live Music Events', href: '/live-music-events-goa' },
      { label: 'Yoga Events', href: '/yoga-events-goa' },
      { label: 'Creative Workshops', href: '/creative-workshops-goa' },
    ],
  },
  {
    label: 'How-To Guides',
    icon: BookOpen,
    color: 'accent',
    description: 'Start hospitality businesses in Goa',
    items: [
      { label: 'Start a Hotel', href: '/how-to-start-hotel-in-goa' },
      { label: 'Start a Hostel', href: '/how-to-start-hostel-in-goa' },
      { label: 'Start a Villa', href: '/how-to-start-villa-in-goa' },
      { label: 'Start a Resort', href: '/how-to-start-resort-in-goa' },
      { label: 'Start a Cafe', href: '/how-to-start-cafe-in-goa' },
      { label: 'Start a Restaurant', href: '/how-to-start-restaurant-in-goa' },
      { label: 'Start a Bar', href: '/how-to-start-bar-in-goa' },
      { label: 'Start a Homestay', href: '/how-to-start-homestay-in-goa' },
      { label: 'Tourism License', href: '/how-to-get-tourism-license-in-goa' },
    ],
  },
  {
    label: 'Network',
    icon: Sparkles,
    color: 'emerald',
    description: 'Partners, founders, vision',
    items: [
      { label: 'Partner Network', href: '/partner-network' },
      { label: 'Technology Partners', href: '/technology-partners' },
      { label: 'Activation Partners', href: '/activation-partners' },
      { label: 'Venue Partners', href: '/venue-partners' },
      { label: 'Founders', href: '/founders' },
      { label: 'Vision & Mission', href: '/vision-mission' },
    ],
  },
];

const desktopDropdowns = navCategories.map(cat => ({
  label: cat.label,
  items: cat.items,
}));

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [expandedMobile, setExpandedMobile] = useState<string | null>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [mobileOpen]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    const onClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setOpenDropdown(null);
      }
    };
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setMobileOpen(false);
        setOpenDropdown(null);
        setExpandedMobile(null);
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);

  const closeMobile = useCallback(() => {
    setMobileOpen(false);
    setOpenDropdown(null);
    setExpandedMobile(null);
  }, []);

  const toggleMobileExpand = useCallback((label: string) => {
    setExpandedMobile(prev => prev === label ? null : label);
  }, []);

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled || mobileOpen ? 'bg-neutral-950/95 backdrop-blur-xl border-b border-white/10' : 'bg-neutral-950/80 backdrop-blur-md'
        }`}
        role="banner"
      >
        <div className="section-max section-padding">
          <nav className="flex items-center justify-between h-16 sm:h-20" aria-label="Main navigation">
            <a href="/" className="group flex items-baseline shrink-0" aria-label="The OTA Studio - Home">
              <span className="font-display font-extrabold text-base tracking-wider text-white group-hover:text-white/80 transition-colors">THE OT</span>
              <span className="font-display font-extrabold text-base tracking-wider text-accent">A</span>
              <span className="font-display font-extrabold text-base tracking-wider text-white group-hover:text-white/80 transition-colors"> STUDIO</span>
            </a>

            {/* Desktop nav */}
            <div className="hidden lg:flex items-center gap-1" ref={dropdownRef}>
              {desktopDropdowns.map((dropdown) => (
                <div key={dropdown.label} className="relative">
                  <button
                    onClick={() => setOpenDropdown(openDropdown === dropdown.label ? null : dropdown.label)}
                    onMouseEnter={() => setOpenDropdown(dropdown.label)}
                    className={`flex items-center gap-1 px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                      openDropdown === dropdown.label ? 'text-accent' : 'text-white/60 hover:text-white'
                    }`}
                  >
                    {dropdown.label}
                    <ChevronDown size={14} className={`transition-transform duration-200 ${openDropdown === dropdown.label ? 'rotate-180' : ''}`} />
                  </button>

                  {openDropdown === dropdown.label && (
                    <div
                      className="absolute top-full left-0 mt-1 py-2 min-w-[200px] bg-neutral-900/95 backdrop-blur-xl border border-white/10 rounded-xl shadow-xl shadow-black/40 z-50"
                      onMouseLeave={() => setOpenDropdown(null)}
                    >
                      {dropdown.items.map((item) => (
                        <a
                          key={item.href}
                          href={item.href}
                          className="block px-4 py-2 text-sm text-white/60 hover:text-white hover:bg-white/5 transition-colors"
                          onClick={() => setOpenDropdown(null)}
                        >
                          {item.label}
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="hidden lg:flex items-center gap-3">
              <a
                href="tel:+919270598602"
                className="flex items-center gap-2 text-sm text-white/60 hover:text-white transition-colors"
                aria-label="Call The OTA Studio"
              >
                <Phone size={16} aria-hidden="true" />
                +91 92705 98602
              </a>
              <a
                href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20discuss%20OTA%20services"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary text-sm py-2.5"
              >
                Book a Call
              </a>
            </div>

            {/* Mobile menu trigger */}
            <button
              onClick={() => setMobileOpen(true)}
              className="lg:hidden relative p-2 text-white hover:text-accent transition-colors group"
              aria-label="Open menu"
              aria-expanded={mobileOpen}
            >
              <div className="relative w-6 h-6 flex items-center justify-center">
                <div className={`absolute w-5 h-0.5 bg-white transition-all duration-300 ${mobileOpen ? 'rotate-45' : '-translate-y-1.5'}`} />
                <div className={`absolute w-5 h-0.5 bg-white transition-all duration-300 ${mobileOpen ? 'opacity-0' : 'opacity-100'}`} />
                <div className={`absolute w-5 h-0.5 bg-white transition-all duration-300 ${mobileOpen ? '-rotate-45' : 'translate-y-1.5'}`} />
              </div>
            </button>
          </nav>
        </div>
      </header>

      {/* Premium Mobile Navigation Overlay */}
      <div
        className={`lg:hidden fixed inset-0 z-[60] transition-opacity duration-300 ${
          mobileOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        {/* Backdrop */}
        <div
          className="absolute inset-0 bg-black/80 backdrop-blur-xl"
          onClick={closeMobile}
        />

        {/* Menu Panel - Slide from right */}
        <div
          className={`absolute top-0 right-0 bottom-0 w-full max-w-sm bg-gradient-to-br from-neutral-950 via-neutral-900 to-neutral-950 transform transition-transform duration-500 ease-out ${
            mobileOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-white/10">
            <div className="flex items-baseline">
              <span className="font-display font-extrabold text-sm tracking-wider text-white">THE OT</span>
              <span className="font-display font-extrabold text-sm tracking-wider text-accent">A</span>
              <span className="font-display font-extrabold text-sm tracking-wider text-white"> STUDIO</span>
            </div>
            <button
              onClick={closeMobile}
              className="p-2 text-white/60 hover:text-white transition-colors"
              aria-label="Close menu"
            >
              <X size={24} />
            </button>
          </div>

          {/* Home Link */}
          <div className="px-4 pt-4 pb-2">
            <a
              href="/"
              onClick={closeMobile}
              className="flex items-center gap-3 px-4 py-3.5 rounded-xl bg-gradient-to-r from-accent/10 to-transparent border border-accent/20 text-white font-medium transition-all hover:from-accent/20"
            >
              <Home size={18} className="text-accent" />
              <span>Home</span>
              <ArrowRight size={16} className="ml-auto text-accent/60" />
            </a>
          </div>

          {/* Navigation Categories */}
          <div className="px-4 py-2 space-y-2 overflow-y-auto max-h-[calc(100vh-280px)]">
            {navCategories.map((category) => {
              const Icon = category.icon;
              const isExpanded = expandedMobile === category.label;
              const isGreen = category.color === 'emerald';

              return (
                <div
                  key={category.label}
                  className={`rounded-xl border transition-all duration-300 ${
                    isExpanded
                      ? isGreen
                        ? 'bg-emerald-500/5 border-emerald-500/30'
                        : 'bg-accent/5 border-accent/30'
                      : 'bg-white/[0.02] border-white/8 hover:border-white/15'
                  }`}
                >
                  <button
                    onClick={() => toggleMobileExpand(category.label)}
                    className="w-full flex items-center gap-3 px-4 py-3.5 text-left"
                  >
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center transition-colors ${
                      isGreen
                        ? 'bg-emerald-500/10 text-emerald-400'
                        : 'bg-accent/10 text-accent'
                    }`}>
                      <Icon size={18} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="block text-sm font-semibold text-white">{category.label}</span>
                      <span className="block text-xs text-white/40 truncate">{category.description}</span>
                    </div>
                    <ChevronDown
                      size={18}
                      className={`transition-transform duration-300 ${
                        isExpanded ? 'rotate-180 text-accent' : 'text-white/40'
                      }`}
                    />
                  </button>

                  <div
                    className={`overflow-hidden transition-all duration-300 ${
                      isExpanded ? 'max-h-[400px] opacity-100' : 'max-h-0 opacity-0'
                    }`}
                  >
                    <div className="px-4 pb-3 space-y-1">
                      {category.items.map((item) => (
                        <a
                          key={item.href}
                          href={item.href}
                          onClick={closeMobile}
                          className={`flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                            isGreen
                              ? 'text-white/60 hover:text-emerald-400 hover:bg-emerald-500/5'
                              : 'text-white/60 hover:text-accent hover:bg-accent/5'
                          }`}
                        >
                          <div className={`w-1 h-1 rounded-full ${isGreen ? 'bg-emerald-500/40' : 'bg-accent/40'}`} />
                          {item.label}
                        </a>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Footer */}
          <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-neutral-950 via-neutral-950/95 to-transparent">
            <div className="flex flex-col gap-2">
              <a
                href="tel:+919270598602"
                className="flex items-center justify-center gap-2 py-3 rounded-xl bg-white/5 border border-white/10 text-white/80 text-sm font-medium transition-all hover:bg-white/10"
              >
                <Phone size={16} />
                +91 92705 98602
              </a>
              <a
                href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20discuss%20OTA%20services"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-3 rounded-xl bg-accent text-neutral-950 text-sm font-bold transition-all hover:bg-accent-300"
              >
                Book a Call
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
