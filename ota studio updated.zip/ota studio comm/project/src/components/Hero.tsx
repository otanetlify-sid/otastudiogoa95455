import { ArrowRight, TrendingUp } from 'lucide-react';
import { useInView } from '../hooks/useInView';

export default function Hero() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="hero"
      aria-labelledby="hero-heading"
      className="relative min-h-[90vh] flex items-center pt-16 pb-20 overflow-hidden bg-neutral-950"
    >
      <div className="absolute inset-0 section-grid opacity-40" />
      <div className="absolute top-1/4 left-1/4 w-[400px] h-[400px] bg-accent/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 right-1/4 w-[300px] h-[300px] bg-accent/3 rounded-full blur-3xl" />

      <div className="section-max section-padding relative">
        <div className={`max-w-4xl ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/20 mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
            <span className="text-xs font-medium text-accent">OTA Onboarding, Management & Distribution</span>
          </div>

          <h1 id="hero-heading" className="heading-xl text-white mb-6">
            The OTA Studio –{' '}
            <span className="text-accent">OTA Onboarding, Management & Distribution</span>{' '}
            for Hospitality Businesses
          </h1>

          <p className="body-lg text-lg sm:text-xl text-white/70 mb-8 max-w-2xl">
            We help hotels, hostels, villas, homestays, and resorts improve OTA visibility
            through professional onboarding, management, and distribution services.
            We don't sell advice. We execute.
          </p>

          <div className="flex flex-col sm:flex-row gap-3 mb-12">
            <a
              href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20a%20FREE%20OTA%20Visibility%20Audit"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary group"
              onClick={() => {
                if (typeof window !== 'undefined' && (window as any).dataLayer) {
                  (window as any).dataLayer.push({ event: 'cta_click', cta_name: 'free_ota_audit' });
                }
              }}
            >
              <TrendingUp size={18} aria-hidden="true" />
              Get a FREE OTA Audit
              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </a>
            <a href="#services" className="btn-secondary">
              View Services
            </a>
          </div>

          <div className="flex flex-wrap gap-6 text-sm text-white/50">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-400" />
              <span>100+ Properties Onboarded</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-400" />
              <span>8+ OTA Platforms</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-400" />
              <span>3x Average Booking Growth</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
