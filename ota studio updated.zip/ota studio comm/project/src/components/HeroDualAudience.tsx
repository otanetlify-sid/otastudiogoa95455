import { Building2, Globe, BarChart3, Link2, Server, Network, Users, Calendar, Handshake, Sparkles, UserPlus, ArrowRight, TrendingUp, MapPin } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const otaServices = [
  { label: 'OTA Onboarding', icon: Globe, href: '/ota-onboarding-goa' },
  { label: 'OTA Management', icon: BarChart3, href: '/ota-management-goa' },
  { label: 'Distribution', icon: Network, href: '/hotel-distribution-goa' },
  { label: 'Revenue Optimization', icon: TrendingUp, href: '/ota-strategy-insights' },
  { label: 'PMS Integration', icon: Server, href: '/technology-partners' },
  { label: 'Channel Management', icon: Link2, href: '/property-management-goa' },
];

const communityServices = [
  { label: 'Community Experiences', icon: Sparkles, href: '/hospitality-activations-goa' },
  { label: 'Hospitality Activations', icon: Calendar, href: '/hospitality-activations-goa' },
  { label: 'Audience Building', icon: Users, href: '/hospitality-community-building-goa' },
  { label: 'Venue Partnerships', icon: Handshake, href: '/venue-partners' },
  { label: 'Networking Events', icon: Network, href: '/hospitality-networking-events-goa' },
  { label: 'Guest Engagement', icon: UserPlus, href: '/community-management-goa' },
];

const propertyTypes = [
  'Hotels', 'Resorts', 'Villas', 'Homestays', 'Hostels',
  'Cafes', 'Restaurants', 'Bars', 'Beach Clubs', 'Wellness Brands',
];

const stats = [
  { value: '100+', label: 'Properties Onboarded' },
  { value: '8+', label: 'OTA Platforms' },
  { value: '3x', label: 'Avg Booking Growth' },
];

export default function HeroDualAudience() {
  const { ref, isInView } = useInView(0.05);

  return (
    <section
      ref={ref}
      id="hero"
      aria-labelledby="hero-heading"
      className="relative min-h-[100svh] flex items-center bg-neutral-950 overflow-hidden pt-20 pb-16"
    >
      {/* Subtle grid */}
      <div className="absolute inset-0 section-grid opacity-20 pointer-events-none" />

      {/* Ambient glows — GPU only via transform/opacity */}
      <div
        className="absolute top-0 left-0 w-[600px] h-[600px] rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(255,208,0,0.07) 0%, transparent 70%)', transform: 'translate(-20%, -20%)' }}
      />
      <div
        className="absolute bottom-0 right-0 w-[500px] h-[500px] rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(255,208,0,0.04) 0%, transparent 70%)', transform: 'translate(20%, 20%)' }}
      />

      <div className="section-max section-padding relative z-10 w-full">
        <div className="grid lg:grid-cols-[60fr_40fr] gap-12 xl:gap-16 items-center">

          {/* ── LEFT: Content (60%) ── */}
          <div className={`transition-all duration-1000 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>

            {/* Location badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 mb-6">
              <MapPin size={12} className="text-accent" />
              <span className="text-xs text-white/60 font-medium">Hospitality Growth Partner · Goa</span>
              <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
            </div>

            {/* Subheadline / service tags */}
            <p className="text-sm sm:text-base font-medium text-accent/80 mb-4 tracking-wide">
              OTA Growth&nbsp;&nbsp;•&nbsp;&nbsp;Distribution&nbsp;&nbsp;•&nbsp;&nbsp;Community Experiences&nbsp;&nbsp;•&nbsp;&nbsp;Hospitality Activations
            </p>

            {/* Main heading */}
            <h1
              id="hero-heading"
              className="font-display text-3xl sm:text-4xl md:text-5xl xl:text-6xl font-extrabold tracking-tight leading-[1.05] text-white mb-6"
            >
              Your Hospitality Business in Goa{' '}
              <span className="text-accent">Deserves More</span>{' '}
              Than Just a Listing
            </h1>

            {/* Description */}
            <p className="text-base sm:text-lg text-white/60 leading-relaxed mb-4 max-w-2xl">
              OTA Studio helps hotels, resorts, villas, homestays, cafes, restaurants, bars, beach clubs and hospitality brands grow through OTA onboarding, OTA management, hospitality distribution and curated community experiences across Goa.
            </p>

            {/* Supporting statement */}
            <p className="text-sm sm:text-base font-semibold text-accent mb-8 font-display">
              We don't sell advice.&nbsp;&nbsp;We execute hospitality growth.
            </p>

            {/* CTA buttons — left aligned */}
            <div className="flex flex-col sm:flex-row gap-3 mb-10">
              <a
                href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20a%20FREE%20OTA%20Audit"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary group"
                onClick={() => {
                  if (typeof window !== 'undefined' && (window as any).dataLayer) {
                    (window as any).dataLayer.push({ event: 'cta_click', cta_name: 'free_ota_audit_hero' });
                  }
                }}
              >
                <TrendingUp size={16} aria-hidden="true" />
                Get Free OTA Audit
                <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform duration-200" />
              </a>
              <a
                href="/hospitality-activations-goa"
                className="btn-secondary group"
              >
                <Sparkles size={16} aria-hidden="true" />
                Explore Community Experiences
              </a>
              <a
                href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20a%20free%20property%20review"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-6 py-3 sm:px-7 sm:py-3.5 text-white/70 font-display font-bold text-sm sm:text-base rounded-xl border border-white/10 hover:border-white/25 hover:text-white transition-all duration-200 active:scale-[0.98]"
              >
                Request Property Review
              </a>
            </div>

            {/* Stats row */}
            <div className="flex flex-wrap gap-6 mb-10">
              {stats.map((s) => (
                <div key={s.label} className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-accent" />
                  <span className="text-sm text-white/50"><strong className="text-white/80">{s.value}</strong> {s.label}</span>
                </div>
              ))}
            </div>

            {/* Property types served */}
            <div>
              <p className="text-xs text-white/30 mb-3 uppercase tracking-widest">Serving across Goa</p>
              <div className="flex flex-wrap gap-2">
                {propertyTypes.map((type) => (
                  <span
                    key={type}
                    className="px-3 py-1 text-xs text-white/50 bg-white/5 border border-white/8 rounded-full"
                  >
                    {type}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* ── RIGHT: Dual Audience Visual (40%) ── */}
          <div
            className={`transition-all duration-1000 delay-300 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'} hidden lg:block`}
          >
            <div className="space-y-4">

              {/* FOR PROPERTIES */}
              <div className="relative group rounded-2xl border border-accent/20 bg-neutral-900/60 backdrop-blur-sm p-6 overflow-hidden hover:border-accent/40 transition-all duration-300">
                <div className="absolute inset-0 bg-gradient-to-br from-accent/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="relative">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-xl bg-accent/15 flex items-center justify-center">
                      <Building2 size={18} className="text-accent" />
                    </div>
                    <div>
                      <div className="text-xs text-accent font-semibold uppercase tracking-widest mb-0.5">For Properties</div>
                      <div className="text-[11px] text-white/40">Hotels · Resorts · Villas · Homestays · Hostels</div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {otaServices.map((service) => {
                      const Icon = service.icon;
                      return (
                        <a
                          key={service.label}
                          href={service.href}
                          className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/4 border border-white/8 hover:border-accent/30 hover:bg-accent/8 transition-all duration-200 group/item"
                        >
                          <Icon size={12} className="text-accent/50 group-hover/item:text-accent transition-colors shrink-0" />
                          <span className="text-[11px] text-white/55 group-hover/item:text-white transition-colors leading-tight">{service.label}</span>
                        </a>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* FOR HOSPITALITY EXPERIENCES */}
              <div className="relative group rounded-2xl border border-white/10 bg-neutral-900/60 backdrop-blur-sm p-6 overflow-hidden hover:border-accent/30 transition-all duration-300">
                <div className="absolute inset-0 bg-gradient-to-br from-white/2 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="relative">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-xl bg-white/8 flex items-center justify-center">
                      <Users size={18} className="text-white/70" />
                    </div>
                    <div>
                      <div className="text-xs text-white font-semibold uppercase tracking-widest mb-0.5">For Hospitality Experiences</div>
                      <div className="text-[11px] text-white/40">Restaurants · Cafes · Bars · Beach Clubs · Wellness</div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {communityServices.map((service) => {
                      const Icon = service.icon;
                      return (
                        <a
                          key={service.label}
                          href={service.href}
                          className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/4 border border-white/8 hover:border-accent/25 hover:bg-accent/5 transition-all duration-200 group/item"
                        >
                          <Icon size={12} className="text-white/30 group-hover/item:text-accent transition-colors shrink-0" />
                          <span className="text-[11px] text-white/50 group-hover/item:text-white transition-colors leading-tight">{service.label}</span>
                        </a>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Live indicator */}
              <div className="flex items-center justify-between px-4 py-3 rounded-xl border border-white/8 bg-white/2">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-accent animate-pulse" />
                  <span className="text-xs text-white/40">OTA Studio is actively managing properties in Goa</span>
                </div>
                <span className="text-[10px] text-accent/60 font-display font-bold">LIVE</span>
              </div>
            </div>
          </div>

        </div>

        {/* Mobile: dual cards shown below content */}
        <div className={`lg:hidden mt-10 space-y-4 transition-all duration-1000 delay-300 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          {/* FOR PROPERTIES */}
          <div className="rounded-2xl border border-accent/20 bg-neutral-900/60 p-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-xl bg-accent/15 flex items-center justify-center">
                <Building2 size={16} className="text-accent" />
              </div>
              <div>
                <div className="text-xs text-accent font-semibold uppercase tracking-widest mb-0.5">For Properties</div>
                <div className="text-[11px] text-white/40">Hotels · Resorts · Villas · Homestays · Hostels</div>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {otaServices.map((s) => (
                <a key={s.label} href={s.href} className="px-3 py-1.5 text-[11px] text-white/55 bg-white/5 border border-white/8 rounded-lg hover:border-accent/30 hover:text-accent transition-all">
                  {s.label}
                </a>
              ))}
            </div>
          </div>
          {/* FOR EXPERIENCES */}
          <div className="rounded-2xl border border-white/10 bg-neutral-900/60 p-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-xl bg-white/8 flex items-center justify-center">
                <Users size={16} className="text-white/70" />
              </div>
              <div>
                <div className="text-xs text-white font-semibold uppercase tracking-widest mb-0.5">For Hospitality Experiences</div>
                <div className="text-[11px] text-white/40">Restaurants · Cafes · Bars · Wellness</div>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {communityServices.map((s) => (
                <a key={s.label} href={s.href} className="px-3 py-1.5 text-[11px] text-white/50 bg-white/5 border border-white/8 rounded-lg hover:border-accent/25 hover:text-white transition-all">
                  {s.label}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
