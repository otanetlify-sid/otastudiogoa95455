import {
  Music, Mic2, Headphones, Laugh, Gamepad2,
  Leaf, Sun, Flower2, Wind, HeartPulse, Ear,
  Palette, Brush, Camera, Store, ShoppingCart,
  Coffee, UtensilsCrossed, Umbrella, Users, Grape, Sparkles,
} from 'lucide-react';
import { useInView } from '../hooks/useInView';

const serviceCards = [
  {
    icon: Music,
    title: 'Music & Entertainment',
    accent: true,
    items: [
      { icon: Music, label: 'Live Music' },
      { icon: Headphones, label: 'DJs' },
      { icon: Mic2, label: 'Acoustic Nights' },
      { icon: Mic2, label: 'Karaoke Nights' },
      { icon: Gamepad2, label: 'Trivia Nights' },
      { icon: Laugh, label: 'Stand-Up Comedy' },
    ],
  },
  {
    icon: Leaf,
    title: 'Wellness Experiences',
    accent: false,
    items: [
      { icon: Leaf, label: 'Yoga Sessions' },
      { icon: Sun, label: 'Beach Yoga' },
      { icon: Flower2, label: 'Meditation' },
      { icon: Wind, label: 'Breathwork' },
      { icon: HeartPulse, label: 'Wellness Retreats' },
      { icon: Ear, label: 'Sound Healing' },
    ],
  },
  {
    icon: Palette,
    title: 'Creative Experiences',
    accent: false,
    items: [
      { icon: Palette, label: 'Art Exhibitions' },
      { icon: Brush, label: 'Pottery Workshops' },
      { icon: Camera, label: 'Painting Sessions' },
      { icon: Camera, label: 'Photography Walks' },
      { icon: ShoppingCart, label: 'Creative Pop-Ups' },
    ],
  },
  {
    icon: Sparkles,
    title: 'Venue Activations',
    accent: true,
    items: [
      { icon: Coffee, label: 'Cafe Activations' },
      { icon: UtensilsCrossed, label: 'Restaurant Activations' },
      { icon: Umbrella, label: 'Beach Club Activations' },
      { icon: Users, label: 'Community Events' },
      { icon: Grape, label: 'Food & Music Experiences' },
      { icon: Store, label: 'Cultural Goa Experiences' },
    ],
  },
];

export default function HospitalityActivations() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="hospitality-activations"
      aria-labelledby="hospitality-activations-heading"
      className="py-20 sm:py-28 bg-neutral-900 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-30" />
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-accent/5 rounded-full blur-3xl" />

      <div className="section-max section-padding relative">
        <div className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Hospitality Activations</span>
          <h2 id="hospitality-activations-heading" className="heading-lg text-white mb-4">
            Curated <span className="text-accent">Experiences</span> for Hospitality Venues
          </h2>
          <p className="body-lg">
            From live music to wellness retreats, we create experiences that drive footfall,
            engagement, and repeat visits at your venue.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
          {serviceCards.map((card, i) => (
            <div
              key={i}
              className={`group p-6 sm:p-8 rounded-2xl border ${
                card.accent ? 'border-accent/20 bg-accent/5' : 'border-white/10 bg-white/3'
              } ${isInView ? `animate-fade-up delay-${(i + 1) * 100}` : 'opacity-0'}`}
            >
              <div className="flex items-center gap-3 mb-5">
                <div className={`w-10 h-10 rounded-lg ${card.accent ? 'bg-accent/15' : 'bg-white/10'} flex items-center justify-center`}>
                  <card.icon size={20} className={card.accent ? 'text-accent' : 'text-white/80'} />
                </div>
                <h3 className="font-display font-bold text-lg text-white">{card.title}</h3>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {card.items.map((item, j) => (
                  <div
                    key={j}
                    className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/4 border border-white/6"
                  >
                    <item.icon size={12} className={card.accent ? 'text-accent/70' : 'text-white/50'} />
                    <span className="text-xs text-white/60 font-medium">{item.label}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className={`text-center mt-10 ${isInView ? 'animate-fade-up delay-500' : 'opacity-0'}`}>
          <a
            href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20request%20an%20activation%20for%20my%20venue%20in%20Goa"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary group"
          >
            Request an Activation
          </a>
        </div>
      </div>
    </section>
  );
}
