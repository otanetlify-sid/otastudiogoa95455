import {
  Building2,
  BedDouble,
  Coffee,
  Wine,
  Home,
  ArrowRight,
  MessageCircle,
  Compass,
  ClipboardList,
  Users,
  Link2,
  Shield,
  Clock,
  Network,
  Handshake,
} from 'lucide-react';
import { useInView } from '../hooks/useInView';

const categories = [
  {
    icon: Building2,
    title: 'Hotels',
    items: [
      'Hotels available for lease in Goa',
      'Hotel sale opportunities',
      'Operational hotel takeover options',
    ],
  },
  {
    icon: BedDouble,
    title: 'Hostels',
    items: [
      'Hostel takeover opportunities',
      'Running hostel partnerships',
      'Pre-built hostel business setups',
    ],
  },
  {
    icon: Coffee,
    title: 'Cafes',
    items: [
      'Cafe spaces for lease',
      'Ready-to-run cafe setups',
      'High tourism location cafes',
    ],
  },
  {
    icon: Wine,
    title: 'Bars & Nightlife Spaces',
    items: [
      'Bar leasing opportunities',
      'Lounge & nightlife venues',
      'High-footfall hospitality spaces',
    ],
  },
  {
    icon: Home,
    title: 'Boutique Stays & Guesthouses',
    items: [
      'Boutique property investments',
      'Guesthouse partnerships',
      'Short-term rental setups',
    ],
  },
];

const steps = [
  {
    number: '01',
    title: 'Share Your Interest',
    description: 'Tell us what you seek — buy, lease, invest, or partner.',
    icon: ClipboardList,
  },
  {
    number: '02',
    title: 'We Understand Your Requirement',
    description: 'Budget, location preference, and business type across Goa.',
    icon: Compass,
  },
  {
    number: '03',
    title: 'We Connect You With Opportunities',
    description: 'Matched hospitality properties curated for your needs.',
    icon: Link2,
  },
  {
    number: '04',
    title: 'Direct Engagement With Owners',
    description: 'Straight to the decision-maker — no middlemen, no delays.',
    icon: Users,
  },
];

const reasons = [
  {
    icon: Shield,
    title: 'Focused Only on Hospitality',
    description: 'No residential, land-only, or commercial office listings.',
  },
  {
    icon: Network,
    title: 'Verified & Curated Opportunities',
    description: 'Every opportunity is vetted before it reaches you.',
  },
  {
    icon: Handshake,
    title: 'Strong Hospitality Network',
    description: 'Deep connections across Goa\'s hotel and hostel ecosystem.',
  },
  {
    icon: Clock,
    title: 'Saves Time for Investors & Operators',
    description: 'Skip the search — we bring the right options to you.',
  },
  {
    icon: ArrowRight,
    title: 'Direct Decision-Maker Connections',
    description: 'Engage directly with property owners, not brokers.',
  },
];

export default function HospitalityRealEstate() {
  const { ref, isInView } = useInView();

  return (
    <section ref={ref} id="real-estate" className="py-20 sm:py-28 bg-neutral-50/50">
      <div className="section-max section-padding">
        {/* Header */}
        <div
          className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 ${
            isInView ? 'animate-fade-up' : 'opacity-0'
          }`}
        >
          <span className="badge bg-accent/10 text-accent-700 mb-4">
            <Building2 size={12} />
            Hospitality Real Estate
          </span>
          <h2 className="heading-lg">
            Hospitality Real Estate Opportunities in Goa
          </h2>
          <p className="body-lg mt-4">
            Curated hotel, hostel, cafe & bar opportunities available for lease,
            sale, and partnership across Goa's hospitality market.
          </p>
        </div>

        {/* Intro */}
        <div
          className={`max-w-3xl mx-auto text-center mb-14 sm:mb-16 ${
            isInView ? 'animate-fade-up delay-100' : 'opacity-0'
          }`}
        >
          <p className="body-md">
            OTA Studio connects verified hospitality business opportunities
            across Goa including hotels, hostels, cafes, bars, and boutique
            stays available for lease, sale, takeover, or partnership. This
            helps entrepreneurs, investors, and operators find the right
            hospitality space while ensuring property owners get serious and
            qualified interest.
          </p>
        </div>

        {/* Opportunity Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6 mb-16 sm:mb-20">
          {categories.map((cat, i) => (
            <div
              key={i}
              className={`card-accent group opacity-0 ${
                isInView
                  ? `animate-fade-up delay-${Math.min((i + 1) * 100, 600)}`
                  : ''
              }`}
            >
              <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-5 group-hover:bg-accent/20 transition-colors">
                <cat.icon
                  size={22}
                  className="text-accent-600 group-hover:text-accent-700 transition-colors"
                />
              </div>
              <h3 className="heading-md !text-lg mb-4">{cat.title}</h3>
              <ul className="space-y-2.5">
                {cat.items.map((item, j) => (
                  <li
                    key={j}
                    className="flex items-start gap-2 text-sm text-neutral-600"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-accent shrink-0 mt-1.5" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* How It Works */}
        <div
          className={`mb-16 sm:mb-20 ${
            isInView ? 'animate-fade-up delay-300' : 'opacity-0'
          }`}
        >
          <h3 className="heading-md text-center mb-8 sm:mb-10">
            How It Works
          </h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {steps.map((step, i) => (
              <div
                key={i}
                className="relative p-5 rounded-xl bg-white border border-neutral-100 text-center group hover:shadow-lg hover:shadow-neutral-200/40 hover:-translate-y-1 transition-all duration-300"
              >
                <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-accent/20 transition-colors">
                  <step.icon
                    size={18}
                    className="text-accent-600 group-hover:text-accent-700 transition-colors"
                  />
                </div>
                <div className="text-xs font-semibold text-accent-600 tracking-wider uppercase mb-1">
                  Step {step.number}
                </div>
                <h4 className="font-display font-bold text-sm sm:text-base mb-2">
                  {step.title}
                </h4>
                <p className="text-xs sm:text-sm text-neutral-500 leading-relaxed">
                  {step.description}
                </p>
                {i < steps.length - 1 && (
                  <ArrowRight
                    size={16}
                    className="hidden lg:block absolute -right-3 top-1/2 -translate-y-1/2 text-neutral-300"
                  />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Why This Section Exists */}
        <div
          className={`mb-14 sm:mb-16 ${
            isInView ? 'animate-fade-up delay-400' : 'opacity-0'
          }`}
        >
          <h3 className="heading-md text-center mb-8 sm:mb-10">
            Why This Section Exists
          </h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {reasons.map((reason, i) => (
              <div
                key={i}
                className="flex flex-col items-center text-center p-5 rounded-xl bg-white border border-neutral-100 hover:border-accent/20 hover:shadow-md hover:shadow-accent/5 transition-all duration-300 group"
              >
                <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center mb-3 group-hover:bg-accent/20 transition-colors">
                  <reason.icon
                    size={18}
                    className="text-accent-600 group-hover:text-accent-700 transition-colors"
                  />
                </div>
                <h4 className="font-display font-bold text-sm mb-1.5">
                  {reason.title}
                </h4>
                <p className="text-xs text-neutral-500 leading-relaxed">
                  {reason.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div
          className={`text-center opacity-0 ${
            isInView ? 'animate-fade-up delay-500' : ''
          }`}
        >
          <div className="bg-white rounded-2xl border border-accent/20 p-8 sm:p-12 max-w-2xl mx-auto">
            <h3 className="heading-md !text-xl sm:!text-2xl mb-3">
              Looking for a Hospitality Business in Goa?
            </h3>
            <p className="body-md mb-6">
              We connect you with curated, verified hospitality opportunities
              across Goa.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <a
                href="https://wa.me/918010939523?text=Hi%2C%20I%20am%20looking%20for%20hospitality%20real%20estate%20opportunities%20in%20Goa"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
              >
                <MessageCircle size={18} />
                WhatsApp Now
              </a>
              <a
                href="https://wa.me/918010939523?text=Hi%2C%20I%20want%20to%20explore%20hospitality%20opportunities%20in%20Goa"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-outline"
              >
                <Compass size={18} />
                Explore Opportunities
              </a>
            </div>
          </div>
        </div>

        {/* Rule Disclaimer */}
        <p
          className={`text-center text-xs text-neutral-400 mt-6 opacity-0 ${
            isInView ? 'animate-fade-in delay-600' : ''
          }`}
        >
          Strictly limited to hospitality-related real estate in Goa only. No
          residential, land-only, or commercial office listings.
        </p>
      </div>
    </section>
  );
}
