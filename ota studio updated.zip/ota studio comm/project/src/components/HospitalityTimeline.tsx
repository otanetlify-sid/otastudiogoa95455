import { Globe, Eye, Users, TrendingUp, Check } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const timelineStages = [
  { day: 1, label: 'OTA Setup', description: 'Platform registration & onboarding', icon: Globe, color: 'accent' },
  { day: 15, label: 'Distribution Active', description: 'Multi-channel presence established', icon: Globe, color: 'accent' },
  { day: 30, label: 'Visibility Growth', description: 'Search ranking improvement', icon: Eye, color: 'accent' },
  { day: 60, label: 'Community Activation', description: 'Local network connections', icon: Users, color: 'accent' },
  { day: 90, label: 'Revenue Expansion', description: 'Sustainable growth trajectory', icon: TrendingUp, color: 'accent' },
];

export default function HospitalityTimeline() {
  const { ref, isInView } = useInView(0.2);

  return (
    <section ref={ref} className="relative py-20 sm:py-28 bg-neutral-950 overflow-hidden">
      <div className="section-max section-padding relative">
        {/* Header */}
        <div className={`text-center mb-12 sm:mb-16 transition-all duration-1000 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <h2 className="heading-lg text-white mb-4">
            Hospitality Growth <span className="text-accent">Timeline</span>
          </h2>
          <p className="body-lg max-w-2xl mx-auto">
            A structured 90-day journey from property onboarding to revenue expansion.
          </p>
        </div>

        {/* Timeline */}
        <div className="max-w-4xl mx-auto">
          <div className="relative">
            {/* Progress Line */}
            <div className="absolute top-8 left-0 right-0 h-0.5 bg-white/10">
              <div
                className="absolute top-0 left-0 h-full bg-gradient-to-r from-accent via-accent to-accent transition-all duration-1000"
                style={{ width: isInView ? '100%' : '0%' }}
              />
            </div>

            {/* Timeline Nodes */}
            <div className="flex justify-between relative">
              {timelineStages.map((stage, i) => {
                const Icon = stage.icon;
                const isAccent = stage.color === 'accent';

                return (
                  <div
                    key={stage.day}
                    className={`flex-1 transition-all duration-1000 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
                    style={{ transitionDelay: `${i * 150}ms` }}
                  >
                    <div className="text-center">
                      {/* Day badge */}
                      <div className="flex justify-center mb-2">
                        <div className={`px-2 py-1 rounded text-[10px] sm:text-xs font-semibold ${
                          isAccent
                            ? 'bg-accent/10 text-accent border border-accent/20'
                            : 'bg-white/5 text-white/60 border border-white/10'
                        }`}>
                          Day {stage.day}
                        </div>
                      </div>

                      {/* Icon node */}
                      <div className="flex justify-center mb-3">
                        <div className={`w-16 h-16 rounded-xl flex items-center justify-center transition-all ${
                          isAccent
                            ? 'bg-accent/10 border-2 border-accent/30'
                            : 'bg-white/5 border-2 border-white/15'
                        }`}>
                          <Icon size={24} className={isAccent ? 'text-accent' : 'text-white/70'} />
                        </div>
                      </div>

                      {/* Label */}
                      <h3 className={`text-xs sm:text-sm font-display font-bold ${
                        isAccent ? 'text-accent' : 'text-white/70'
                      }`}>
                        {stage.label}
                      </h3>
                      <p className="text-[10px] sm:text-xs text-white/50 mt-1 max-w-[100px] mx-auto hidden sm:block">
                        {stage.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Mobile Labels */}
          <div className="sm:hidden mt-6 grid grid-cols-2 gap-x-4 gap-y-3">
            {timelineStages.map((stage, i) => {
              const isAccent = stage.color === 'accent';
              return (
                <div
                  key={stage.day}
                  className={`flex items-start gap-2 transition-all duration-1000 ${isInView ? 'opacity-100' : 'opacity-0'}`}
                  style={{ transitionDelay: `${(i + 5) * 100}ms` }}
                >
                  <div className={`w-5 h-5 rounded flex items-center justify-center shrink-0 ${
                    isAccent ? 'bg-accent/10 text-accent' : 'bg-white/5 text-white/60'
                  }`}>
                    <Check size={12} />
                  </div>
                  <div>
                    <span className={`text-xs font-semibold ${isAccent ? 'text-accent' : 'text-white/70'}`}>
                      {stage.day}d:
                    </span>
                    <span className="text-xs text-white/70 ml-1">{stage.label}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* CTA */}
        <div className={`mt-12 sm:mt-16 text-center transition-all duration-1000 delay-700 ${isInView ? 'opacity-100' : 'opacity-0'}`}>
          <a
            href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20discuss%20OTA%20services"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary inline-flex"
          >
            Start Your Growth Journey
          </a>
        </div>
      </div>
    </section>
  );
}
