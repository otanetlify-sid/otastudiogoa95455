import { ClipboardCheck, Building2, Rocket, Network, TrendingUp, BarChart3, ShieldCheck } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const steps = [
  { icon: ClipboardCheck, number: '01', title: 'Free OTA Audit', description: 'We analyze your current OTA presence and identify gaps, ranking issues, and revenue opportunities.' },
  { icon: Building2, number: '02', title: 'Property Assessment', description: 'Deep dive into your property profile, photos, pricing, policies, and competitive positioning.' },
  { icon: Rocket, number: '03', title: 'OTA Setup', description: 'Complete onboarding on Booking.com, Airbnb, Agoda, Expedia, and other relevant platforms.' },
  { icon: Network, number: '04', title: 'Distribution Setup', description: 'Channel manager integration, inventory sync, and rate parity across all connected OTAs.' },
  { icon: TrendingUp, number: '05', title: 'Optimization', description: 'Continuous listing improvement, pricing adjustments, and visibility enhancement.' },
  { icon: BarChart3, number: '06', title: 'Launch', description: 'Go live with optimized profiles, synced inventory, and a revenue-ready setup.' },
  { icon: ShieldCheck, number: '07', title: 'Ongoing Management', description: 'Monthly performance reviews, content updates, and strategic adjustments.' },
];

export default function HowItWorks() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="how-it-works"
      aria-labelledby="how-it-works-heading"
      className="py-20 sm:py-28 bg-neutral-950 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-50" />

      <div className="section-max section-padding relative">
        <div
          className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 opacity-0 ${
            isInView ? 'animate-fade-up' : ''
          }`}
        >
          <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">
            How It Works
          </span>
          <h2 id="how-it-works-heading" className="heading-lg text-white mb-4">
            From Invisible to{' '}
            <span className="text-accent">Fully Booked</span>
          </h2>
          <p className="body-lg">
            A simple, execution-driven process designed to get your property
            performing on OTAs fast.
          </p>
        </div>

        <div className="max-w-3xl mx-auto relative">
          {/* Vertical line */}
          <div className="absolute left-[22px] sm:left-[27px] top-8 bottom-8 w-px bg-gradient-to-b from-accent/20 via-white/8 to-transparent" />

          <div className="space-y-4">
            {steps.map((step, i) => (
              <div
                key={i}
                className={`group flex items-start gap-5 sm:gap-6 opacity-0 ${
                  isInView ? `animate-fade-up delay-${Math.min(i * 80, 600)}` : ''
                }`}
              >
                {/* Step indicator */}
                <div className="relative shrink-0 mt-4">
                  <div className="w-11 h-11 sm:w-[54px] sm:h-[54px] rounded-full bg-neutral-900 border border-white/10 group-hover:border-accent/30 flex items-center justify-center transition-colors z-10 relative">
                    <span className="font-display font-extrabold text-xs text-accent/60 group-hover:text-accent transition-colors">
                      {step.number}
                    </span>
                  </div>
                </div>

                {/* Card */}
                <div className="flex-1 p-5 sm:p-6 rounded-2xl bg-white/4 border border-white/8 group-hover:bg-white/7 group-hover:border-accent/20 group-hover:shadow-[0_0_30px_rgba(255,208,0,0.05)] transition-all duration-300">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-xl bg-accent/8 flex items-center justify-center shrink-0 group-hover:bg-accent/15 transition-colors mt-0.5">
                      <step.icon size={18} className="text-accent/70 group-hover:text-accent transition-colors" aria-hidden="true" />
                    </div>
                    <div>
                      <h3 className="font-display font-bold text-base sm:text-lg text-white mb-1.5">
                        {step.title}
                      </h3>
                      <p className="text-sm text-white/45 leading-relaxed">
                        {step.description}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
