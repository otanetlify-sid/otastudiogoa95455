import { BarChart3, Users, TrendingUp } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const pillars = [
  {
    icon: BarChart3,
    label: 'OTA Optimization System',
    desc: 'Multi-platform distribution, revenue intelligence, and ranking optimization for hotels, villas, and homestays across Goa.',
  },
  {
    icon: Users,
    label: 'Community Experience Network',
    desc: 'Curated hospitality activations, live events, wellness programs, and creative experiences that drive footfall and loyalty.',
  },
  {
    icon: TrendingUp,
    label: 'Revenue Intelligence Layer',
    desc: 'Real-time performance monitoring, benchmarking, and actionable insights that turn data into booking growth.',
  },
];

export default function MarketPositioning() {
  const { ref, isInView } = useInView(0.15);

  return (
    <section ref={ref} className="relative py-12 sm:py-16 bg-neutral-950 text-white overflow-hidden border-t border-white/5">
      <div className="section-max section-padding relative">
        <div className={`text-center mb-8 sm:mb-10 ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/15 text-accent border border-accent/20 mb-3">Intelligence Layer</span>
          <h2 className="heading-lg text-white mb-3">Hospitality Intelligence Layer for Goa</h2>
          <p className="body-md text-white/50 max-w-2xl mx-auto">
            Category-defining SaaS platform combining OTA optimization, community experiences, and revenue intelligence into one unified system.
          </p>
        </div>

        <div className="grid sm:grid-cols-3 gap-4 sm:gap-5 max-w-4xl mx-auto">
          {pillars.map((pillar, i) => {
            const Icon = pillar.icon;
            return (
              <div
                key={i}
                className={`group relative p-5 sm:p-6 rounded-xl border border-white/8 bg-white/[0.02] hover:border-accent/20 transition-all duration-500 ${
                  isInView ? 'animate-fade-up' : 'opacity-0'
                }`}
                style={{ animationDelay: isInView ? `${i * 100}ms` : undefined }}
              >
                <div className="absolute inset-0 rounded-xl bg-gradient-to-b from-accent/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                <div className="relative">
                  <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                    <Icon size={18} className="text-accent" />
                  </div>
                  <h3 className="font-display font-bold text-sm sm:text-base text-white mb-2">
                    {pillar.label}
                  </h3>
                  <p className="text-xs sm:text-sm text-white/40 leading-relaxed">
                    {pillar.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        <div className={`mt-8 sm:mt-10 text-center ${isInView ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: isInView ? '300ms' : undefined }}>
          <a
            href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20learn%20about%20OTA%20Studio%27s%20hospitality%20intelligence%20platform."
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary"
          >
            Get Started with OTA Studio
          </a>
        </div>
      </div>
    </section>
  );
}
