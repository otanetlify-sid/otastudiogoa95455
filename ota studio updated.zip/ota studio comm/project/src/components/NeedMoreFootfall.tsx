import { ArrowRight, Footprints } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const venueTypes = [
  'Cafes', 'Restaurants', 'Bars', 'Beach Clubs', 'Hotels', 'Resorts', 'Villas',
];

export default function NeedMoreFootfall() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="need-more-footfall"
      aria-labelledby="need-more-footfall-heading"
      className="py-20 sm:py-28 bg-neutral-950 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-40" />
      <div className="absolute inset-0 bg-gradient-to-tl from-accent/5 to-transparent" />

      <div className="section-max section-padding relative">
        <div className={`max-w-3xl mx-auto text-center ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/20 mb-6">
            <Footprints size={14} className="text-accent" aria-hidden="true" />
            <span className="text-xs font-medium text-accent">Lead Generation</span>
          </div>

          <h2 id="need-more-footfall-heading" className="heading-xl text-white mb-4">
            Need More <span className="text-accent">Footfall?</span>
          </h2>

          <p className="body-lg text-lg mb-8 max-w-2xl mx-auto">
            From live music and wellness experiences to community-led events, OTA Studio
            helps hospitality venues create reasons for people to return.
          </p>

          <div className="flex flex-wrap justify-center gap-3 mb-10">
            {venueTypes.map((type, i) => (
              <span
                key={i}
                className="px-4 py-2 rounded-xl bg-white/6 border border-white/10 text-sm font-medium text-white/60"
              >
                {type}
              </span>
            ))}
          </div>

          <a
            href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20request%20an%20activation%20for%20my%20venue%20in%20Goa"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary group"
            onClick={() => {
              if (typeof window !== 'undefined' && (window as any).dataLayer) {
                (window as any).dataLayer.push({ event: 'cta_click', cta_name: 'request_activation' });
              }
            }}
          >
            Request an Activation
            <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </a>
        </div>
      </div>
    </section>
  );
}
