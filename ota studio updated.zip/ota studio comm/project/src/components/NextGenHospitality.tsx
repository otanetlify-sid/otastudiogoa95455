import {
  Hotel,
  Trees,
  BedDouble,
  Home,
  Building2,
  Coffee,
  UtensilsCrossed,
  Beer,
  Rocket,
  Globe,
  BarChart3,
  Settings,
  Users,
  TrendingUp,
  Search,
  Zap,
} from 'lucide-react';
import { useInView } from '../hooks/useInView';

const businessTypes = [
  { icon: Hotel, label: 'Hotel' },
  { icon: Trees, label: 'Resort' },
  { icon: BedDouble, label: 'Hostel' },
  { icon: Home, label: 'Villa' },
  { icon: Building2, label: 'Airbnb' },
  { icon: Hotel, label: 'Boutique Property' },
  { icon: Coffee, label: 'Cafe' },
  { icon: UtensilsCrossed, label: 'Restaurant' },
  { icon: Beer, label: 'Bar' },
];

const services = [
  { icon: Rocket, label: 'OTA Onboarding' },
  { icon: Search, label: 'Listing Optimization' },
  { icon: Globe, label: 'Distribution Setup' },
  { icon: Settings, label: 'Property Launch Support' },
  { icon: Home, label: 'Airbnb Setup' },
  { icon: BarChart3, label: 'Hospitality Growth Systems' },
  { icon: TrendingUp, label: 'Visibility Optimization' },
  { icon: Zap, label: 'Revenue Growth Support' },
  { icon: Globe, label: 'Digital Presence Optimization' },
  { icon: Users, label: 'Hospitality Business Support' },
];

const whoWeWorkWith = [
  { title: 'Founders', desc: 'Hospitality entrepreneurs building their first or next concept in Goa.' },
  { title: 'Operators', desc: 'Professionals running day-to-day hospitality operations who need growth support.' },
  { title: 'Investors', desc: 'Property owners and investors seeking to maximize returns from hospitality assets.' },
  { title: 'Property Owners', desc: 'Owners looking to enter OTAs, grow bookings, or improve their existing performance.' },
];

export default function NextGenHospitality() {
  const { ref: ref1, isInView: inView1 } = useInView();
  const { ref: ref2, isInView: inView2 } = useInView();
  const { ref: ref3, isInView: inView3 } = useInView();

  return (
    <>
      {/* Section 1 — Hero positioning */}
      <section
        ref={ref1}
        id="next-gen-hospitality"
        aria-labelledby="nextgen-heading"
        className="py-20 sm:py-28 bg-neutral-950 relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,_rgba(255,208,0,0.07)_0%,_transparent_60%)]" />
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-accent/5 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />

        <div className="section-max section-padding relative">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <div
              className={`opacity-0 ${inView1 ? 'animate-fade-up' : ''}`}
            >
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">
                The Next Generation of Hospitality
              </span>
              <h2
                id="nextgen-heading"
                className="font-display font-extrabold text-3xl sm:text-4xl md:text-5xl tracking-tight leading-[1.1] text-white mb-6"
              >
                Building The Next Generation Of{' '}
                <span className="text-accent">Hospitality Businesses</span>
              </h2>
              <p className="text-base sm:text-lg text-white/70 leading-relaxed mb-8">
                The OTA Studio helps hospitality entrepreneurs launch, optimize, and grow
                modern hospitality brands across Goa. From onboarding and setup to
                optimization and expansion, we support businesses through every stage
                of growth.
              </p>

              <p className="text-sm text-white/50 mb-5 font-medium uppercase tracking-wider">
                Whether you're opening a:
              </p>
              <div className="grid grid-cols-3 gap-2.5 mb-10">
                {businessTypes.map((biz, i) => (
                  <div
                    key={i}
                    className={`flex items-center gap-2.5 p-3 rounded-xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-accent/5 transition-all duration-200 opacity-0 ${
                      inView1 ? `animate-fade-up delay-${Math.min(100 + i * 60, 600)}` : ''
                    }`}
                  >
                    <biz.icon size={15} className="text-accent shrink-0" aria-hidden="true" />
                    <span className="text-xs font-medium text-white/80">{biz.label}</span>
                  </div>
                ))}
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href="https://wa.me/919270598602?text=Hi%2C%20I%27d%20like%20to%20launch%20or%20grow%20my%20hospitality%20business%20in%20Goa"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary"
                >
                  Start Growing Your Bookings
                </a>
                <a
                  href="https://wa.me/919270598602?text=Hi%2C%20I%27d%20like%20a%20Property%20Growth%20Audit"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-secondary"
                >
                  Get A Property Growth Audit
                </a>
              </div>
            </div>

            <div
              className={`opacity-0 ${inView1 ? 'animate-fade-up delay-300' : ''}`}
            >
              <div className="p-8 rounded-3xl border border-white/8 bg-white/4">
                <h3 className="font-display font-bold text-xl text-white mb-2">
                  We help create the systems needed for long-term growth
                </h3>
                <p className="text-sm text-white/50 mb-8 leading-relaxed">
                  Visibility · Distribution · Digital Foundation · Platform Presence · Revenue Growth
                </p>

                <div className="space-y-3">
                  {[
                    { label: 'OTA Visibility', pct: 92 },
                    { label: 'Booking Performance', pct: 87 },
                    { label: 'Distribution Reach', pct: 95 },
                    { label: 'Revenue Growth', pct: 78 },
                  ].map((bar, i) => (
                    <div key={i}>
                      <div className="flex justify-between items-center mb-1.5">
                        <span className="text-xs font-medium text-white/70">{bar.label}</span>
                        <span className="text-xs font-bold text-accent">{bar.pct}%</span>
                      </div>
                      <div className="h-1.5 bg-white/8 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-accent rounded-full transition-all duration-1000"
                          style={{ width: inView1 ? `${bar.pct}%` : '0%' }}
                        />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-8 pt-6 border-t border-white/8 grid grid-cols-3 gap-4 text-center">
                  {[
                    { num: '100+', label: 'Businesses Served' },
                    { num: '3x', label: 'Avg Growth' },
                    { num: 'Goa', label: 'Our Market' },
                  ].map((stat, i) => (
                    <div key={i}>
                      <div className="font-display font-extrabold text-xl sm:text-2xl text-accent">
                        {stat.num}
                      </div>
                      <div className="text-xs text-white/40 mt-0.5">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 2 — For New & Existing Businesses */}
      <section
        ref={ref2}
        id="new-existing-hospitality"
        aria-labelledby="new-existing-heading"
        className="py-20 sm:py-28 bg-neutral-900 relative overflow-hidden"
      >
        <div className="absolute inset-0 section-grid opacity-30" />

        <div className="section-max section-padding relative">
          <div
            className={`text-center max-w-3xl mx-auto mb-14 sm:mb-16 opacity-0 ${
              inView2 ? 'animate-fade-up' : ''
            }`}
          >
            <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">
              New &amp; Existing Businesses
            </span>
            <h2
              id="new-existing-heading"
              className="heading-lg text-white"
            >
              For New &amp; Existing{' '}
              <span className="text-accent">Hospitality Businesses</span>
            </h2>
            <p className="body-lg mt-4">
              Whether you're launching a new hospitality concept or improving an existing
              business, The OTA Studio helps create stronger online visibility, better platform
              performance, and sustainable growth.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-14">
            {whoWeWorkWith.map((who, i) => (
              <article
                key={i}
                className={`p-6 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/7 hover:shadow-[0_0_20px_rgba(255,208,0,0.05)] hover:-translate-y-1 transition-all duration-300 opacity-0 ${
                  inView2 ? `animate-fade-up delay-${Math.min(100 + i * 100, 600)}` : ''
                }`}
              >
                <div className="w-2 h-2 rounded-full bg-accent mb-4" />
                <h3 className="font-display font-bold text-base sm:text-lg text-white mb-2">{who.title}</h3>
                <p className="text-sm text-white/50 leading-relaxed">{who.desc}</p>
              </article>
            ))}
          </div>

          <div
            className={`rounded-3xl bg-neutral-950 border border-accent/20 p-8 sm:p-12 opacity-0 ${
              inView2 ? 'animate-fade-up delay-500' : ''
            }`}
          >
            <div className="grid lg:grid-cols-2 gap-10 items-center">
              <div>
                <h3 className="font-display font-bold text-2xl sm:text-3xl text-white mb-4">
                  We work with those who want to build hospitality businesses{' '}
                  <span className="text-accent">ready for the modern travel market</span>
                </h3>
                <p className="text-white/50 leading-relaxed mb-6">
                  The travel market has fundamentally changed. Guests discover and book through
                  platforms. Visibility is earned through optimization. Revenue is grown through
                  strategy. The OTA Studio gives you the team, tools, and expertise to compete
                  and win — in Goa and beyond.
                </p>
                <a
                  href="https://wa.me/919270598602?text=Hi%2C%20I%27d%20like%20to%20discuss%20growing%20my%20hospitality%20business"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary"
                >
                  Start Growing Your Bookings
                </a>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { title: 'Launch Support', desc: 'Get new properties online and optimized from day one.' },
                  { title: 'Growth Systems', desc: 'Build the digital infrastructure for long-term success.' },
                  { title: 'Platform Presence', desc: 'Maximize visibility across all relevant OTAs.' },
                  { title: 'Revenue Strategy', desc: 'Pricing, distribution, and campaigns that grow revenue.' },
                ].map((card, i) => (
                  <div
                    key={i}
                    className="p-5 rounded-2xl border border-white/8 bg-white/4"
                  >
                    <h4 className="font-display font-bold text-sm text-accent mb-2">
                      {card.title}
                    </h4>
                    <p className="text-xs text-white/50 leading-relaxed">{card.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 3 — Hospitality Setup & Growth Support */}
      <section
        ref={ref3}
        id="hospitality-setup-growth"
        aria-labelledby="setup-growth-heading"
        className="py-20 sm:py-28 bg-neutral-950 relative overflow-hidden"
      >
        <div className="absolute inset-0 section-grid opacity-40" />

        <div className="section-max section-padding relative">
          <div
            className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 opacity-0 ${
              inView3 ? 'animate-fade-up' : ''
            }`}
          >
            <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">
              Setup &amp; Growth Support
            </span>
            <h2
              id="setup-growth-heading"
              className="heading-lg text-white"
            >
              Hospitality Setup &amp;{' '}
              <span className="text-accent">Growth Support</span>
            </h2>
            <p className="body-lg mt-4">
              Every service The OTA Studio offers is designed to build a stronger, more
              visible, and more profitable hospitality business — from first listing to
              full-scale growth.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-12">
            {services.map((service, i) => (
              <div
                key={i}
                className={`group flex flex-col items-center gap-3 p-5 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-accent/5 hover:-translate-y-1 hover:shadow-[0_0_20px_rgba(255,208,0,0.05)] transition-all duration-300 text-center opacity-0 ${
                  inView3 ? `animate-fade-up delay-${Math.min(i * 60, 600)}` : ''
                }`}
              >
                <div className="w-10 h-10 rounded-xl bg-accent/10 group-hover:bg-accent/20 flex items-center justify-center transition-colors">
                  <service.icon size={18} className="text-accent" aria-hidden="true" />
                </div>
                <span className="text-xs sm:text-sm font-display font-bold text-white/80 group-hover:text-white transition-colors leading-tight">
                  {service.label}
                </span>
              </div>
            ))}
          </div>

          <div
            className={`text-center opacity-0 ${inView3 ? 'animate-fade-up delay-600' : ''}`}
          >
            <p className="text-sm text-white/50 mb-5">
              All services are available for hospitality businesses across Goa —
              hotels, resorts, villas, cafes, restaurants, and more.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <a
                href="https://wa.me/919270598602?text=Hi%2C%20I%27d%20like%20to%20set%20up%20and%20grow%20my%20hospitality%20business%20in%20Goa"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
              >
                Start Growing Your Bookings
              </a>
              <a
                href="https://wa.me/919270598602?text=Hi%2C%20I%27d%20like%20a%20Property%20Growth%20Audit"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-secondary"
              >
                Get A Property Growth Audit
              </a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
