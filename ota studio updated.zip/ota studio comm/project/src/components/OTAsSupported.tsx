import { useInView } from '../hooks/useInView';

const platforms = [
  'Booking.com',
  'Airbnb',
  'Agoda',
  'Expedia',
  'Hostelworld',
  'MakeMyTrip',
  'Goibibo',
  'Trip.com',
];

export default function OTAsSupported() {
  const { ref, isInView } = useInView();
  const doubled = [...platforms, ...platforms];

  return (
    <section
      ref={ref}
      id="otas"
      aria-labelledby="otas-heading"
      className="py-16 sm:py-20 bg-neutral-950 overflow-hidden"
    >
      <div className="section-max section-padding mb-8 sm:mb-10">
        <div className={`text-center ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/10 text-accent border border-accent/20 mb-3">Supported Platforms</span>
          <h2 id="otas-heading" className="heading-md text-xl sm:text-2xl text-white">
            We Work With All Major <span className="text-accent">OTAs</span>
          </h2>
        </div>
      </div>

      <div className={`relative ${isInView ? 'animate-fade-in delay-200' : 'opacity-0'}`}>
        <div className="absolute left-0 top-0 bottom-0 w-16 sm:w-24 bg-gradient-to-r from-neutral-950 to-transparent z-10 pointer-events-none" />
        <div className="absolute right-0 top-0 bottom-0 w-16 sm:w-24 bg-gradient-to-l from-neutral-950 to-transparent z-10 pointer-events-none" />

        <div className="overflow-hidden">
          <div className="flex gap-5 sm:gap-8 marquee-track">
            {doubled.map((name, i) => (
              <div
                key={i}
                className="flex items-center justify-center px-6 sm:px-8 py-4 sm:py-5 rounded-xl bg-neutral-900 border border-white/8 hover:border-accent/30 transition-all duration-300 shrink-0"
              >
                <span className="font-display font-bold text-sm sm:text-base text-white whitespace-nowrap">{name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
