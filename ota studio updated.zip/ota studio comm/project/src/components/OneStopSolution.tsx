import { Hotel, Trees, Home, Building2, BedDouble, Coffee, UtensilsCrossed, Beer, Lightbulb } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const businessTypes = [
  { icon: Hotel, title: 'Hotels', desc: 'Boutique to chain hotels in Goa' },
  { icon: Trees, title: 'Resorts', desc: 'Beach and hillside resorts' },
  { icon: BedDouble, title: 'Hostels', desc: 'Budget-friendly social stays' },
  { icon: Home, title: 'Villas', desc: 'Luxury private villa rentals' },
  { icon: Building2, title: 'Airbnb Hosts', desc: 'Short-term rental properties' },
  { icon: Hotel, title: 'Boutique Properties', desc: 'Design-led unique stays' },
  { icon: Coffee, title: 'Cafes', desc: 'Specialty and beachside cafes' },
  { icon: UtensilsCrossed, title: 'Restaurants', desc: 'Dining establishments in Goa' },
  { icon: Beer, title: 'Bars', desc: 'Beachfront and nightlife bars' },
];

const services = [
  'OTA Onboarding & Setup',
  'Listing Content Optimization',
  'Photo Strategy & Sequencing',
  'Dynamic Pricing Management',
  'Channel Manager Integration',
  'Multi-Platform Distribution',
  'Review & Reputation Management',
  'Revenue Strategy & Reporting',
  'Google Business Profile',
  'Seasonal Campaign Management',
  'Hospitality Growth Planning',
  'Platform Dispute Resolution',
];

export default function OneStopSolution() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="one-stop-solution"
      aria-labelledby="one-stop-heading"
      className="py-20 sm:py-28 bg-neutral-950 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-40" />

      <div className="section-max section-padding relative">
        <div
          className={`text-center max-w-3xl mx-auto mb-14 sm:mb-16 opacity-0 ${
            isInView ? 'animate-fade-up' : ''
          }`}
        >
          <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">One Stop Solution</span>
          <h2
            id="one-stop-heading"
            className="heading-lg text-white"
          >
            One Stop Solution For All <br className="hidden sm:block" />
            <span className="text-accent">Hospitality Needs in Goa</span>
          </h2>
          <p className="body-lg mt-4">
            Whether you run a hotel, a hostel, a villa, an Airbnb, a cafe, or a restaurant —
            The OTA Studio is your single partner for all hospitality growth needs in Goa.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className={`opacity-0 ${isInView ? 'animate-fade-up delay-200' : ''}`}>
            <h3 className="font-display font-bold text-xl sm:text-2xl text-white mb-6">
              We Serve Every Type of Hospitality Business
            </h3>
            <div className="grid grid-cols-3 gap-3">
              {businessTypes.map((biz, i) => (
                <div
                  key={i}
                  className="group p-3 sm:p-4 rounded-xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-accent/5 transition-all duration-200 text-center"
                >
                  <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center mx-auto mb-2 group-hover:bg-accent/20 transition-colors">
                    <biz.icon size={18} className="text-accent" />
                  </div>
                  <div className="font-display font-bold text-xs sm:text-sm text-white">
                    {biz.title}
                  </div>
                  <div className="text-xs text-white/40 mt-0.5 hidden sm:block">{biz.desc}</div>
                </div>
              ))}
            </div>
          </div>

          <div className={`opacity-0 ${isInView ? 'animate-fade-up delay-400' : ''}`}>
            <h3 className="font-display font-bold text-xl sm:text-2xl text-white mb-6">
              Everything Your Property Needs — In One Place
            </h3>
            <div className="grid grid-cols-2 gap-2.5">
              {services.map((service, i) => (
                <div
                  key={i}
                  className="flex items-center gap-2 p-3 rounded-xl bg-white/4 border border-white/8"
                >
                  <div className="w-5 h-5 rounded-full bg-accent/20 flex items-center justify-center shrink-0">
                    <div className="w-1.5 h-1.5 rounded-full bg-accent" />
                  </div>
                  <span className="text-xs sm:text-sm font-medium text-white/70">{service}</span>
                </div>
              ))}
            </div>

            <div className="mt-8 p-6 rounded-2xl bg-white/4 border border-accent/20">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-accent/15 flex items-center justify-center shrink-0">
                  <Lightbulb size={18} className="text-accent" />
                </div>
                <div>
                  <h4 className="font-display font-bold text-base text-white mb-1">
                    Stop Managing Multiple Vendors
                  </h4>
                  <p className="text-sm text-white/50 leading-relaxed">
                    One team, one point of contact, complete accountability. The OTA Studio
                    handles everything so you can focus on your guests and your business.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
