import { useState } from 'react';
import { X, BarChart3, Eye, TrendingUp, Building2, MapPin, Globe } from 'lucide-react';

export default function OtaAuditModal() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({ propertyType: '', location: '', otaPresence: '' });
  const [result, setResult] = useState<{ score: number; visibility: string; growth: string } | null>(null);

  const handleSubmit = () => {
    const baseScore = form.otaPresence === 'none' ? 25 : form.otaPresence === '1-2' ? 45 : form.otaPresence === '3-5' ? 62 : 78;
    setResult({
      score: baseScore + Math.floor(Math.random() * 10),
      visibility: baseScore < 40 ? 'Low' : baseScore < 60 ? 'Medium' : 'Good',
      growth: baseScore < 40 ? '+35-50%' : baseScore < 60 ? '+20-35%' : '+10-20%',
    });
    setStep(3);
  };

  const reset = () => {
    setOpen(false);
    setStep(1);
    setForm({ propertyType: '', location: '', otaPresence: '' });
    setResult(null);
  };

  return (
    <>
      {/* CTA Buttons */}
      <div className="flex flex-wrap gap-2 sm:gap-3 mt-3 sm:mt-4">
        {[
          { label: 'Get Free OTA Audit', icon: BarChart3 },
          { label: 'Check Property Score', icon: Eye },
          { label: 'Estimate Revenue Growth', icon: TrendingUp },
        ].map((cta, i) => (
          <button
            key={i}
            onClick={() => { setOpen(true); setStep(1); }}
            className="group flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-lg bg-accent/10 border border-accent/20 text-[9px] sm:text-xs font-medium text-accent hover:bg-accent/20 hover:border-accent/40 transition-all duration-300"
          >
            <cta.icon size={12} className="text-accent/70 group-hover:text-accent transition-colors" />
            {cta.label}
          </button>
        ))}
      </div>

      {/* Modal */}
      {open && (
        <>
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60]" onClick={reset} />
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
            <div className="w-full max-w-md bg-neutral-900 border border-white/10 rounded-2xl overflow-hidden shadow-2xl shadow-black/40">
              {/* Header */}
              <div className="flex items-center justify-between px-5 py-4 border-b border-white/8">
                <div>
                  <h3 className="font-display font-bold text-white text-sm sm:text-base">Free OTA Audit</h3>
                  <p className="text-[10px] sm:text-xs text-white/40">Get your property score in 30 seconds</p>
                </div>
                <button onClick={reset} className="p-1.5 rounded-lg hover:bg-white/10 transition-colors">
                  <X size={16} className="text-white/50" />
                </button>
              </div>

              <div className="p-5">
                {step === 1 && (
                  <div className="space-y-4">
                    <div>
                      <label className="text-xs text-white/50 mb-2 block">Property Type</label>
                      <div className="grid grid-cols-3 gap-2">
                        {['Hotel', 'Villa', 'Homestay', 'Hostel', 'Resort', 'Cafe/Restaurant'].map((type) => (
                          <button
                            key={type}
                            onClick={() => setForm({ ...form, propertyType: type })}
                            className={`p-2.5 rounded-lg text-[10px] sm:text-xs font-medium border transition-all ${
                              form.propertyType === type ? 'border-accent/40 bg-accent/10 text-accent' : 'border-white/10 text-white/40 hover:border-white/20'
                            }`}
                          >
                            {type}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <label className="text-xs text-white/50 mb-2 block">Location in Goa</label>
                      <div className="flex items-center gap-2 px-3 py-2.5 rounded-lg border border-white/10 bg-white/[0.02]">
                        <MapPin size={14} className="text-white/30" />
                        <input
                          type="text"
                          placeholder="e.g. North Goa, Panjim..."
                          value={form.location}
                          onChange={(e) => setForm({ ...form, location: e.target.value })}
                          className="flex-1 bg-transparent text-xs text-white/70 placeholder:text-white/20 outline-none"
                        />
                      </div>
                    </div>
                    <button
                      onClick={() => form.propertyType ? setStep(2) : null}
                      disabled={!form.propertyType}
                      className={`w-full py-3 rounded-xl font-display font-bold text-sm transition-all ${
                        form.propertyType ? 'btn-primary' : 'bg-white/5 text-white/20 cursor-not-allowed'
                      }`}
                    >
                      Continue
                    </button>
                  </div>
                )}

                {step === 2 && (
                  <div className="space-y-4">
                    <div>
                      <label className="text-xs text-white/50 mb-2 block">Current OTA Presence</label>
                      <div className="space-y-2">
                        {[
                          { val: 'none', label: 'Not on any OTAs yet', icon: Building2 },
                          { val: '1-2', label: 'Listed on 1-2 platforms', icon: Globe },
                          { val: '3-5', label: 'Active on 3-5 platforms', icon: BarChart3 },
                          { val: '6+', label: 'Present on 6+ platforms', icon: TrendingUp },
                        ].map((opt) => (
                          <button
                            key={opt.val}
                            onClick={() => setForm({ ...form, otaPresence: opt.val })}
                            className={`w-full flex items-center gap-3 p-3 rounded-lg border text-left transition-all ${
                              form.otaPresence === opt.val ? 'border-accent/40 bg-accent/10' : 'border-white/10 hover:border-white/20'
                            }`}
                          >
                            <opt.icon size={16} className={form.otaPresence === opt.val ? 'text-accent' : 'text-white/30'} />
                            <span className={`text-xs ${form.otaPresence === opt.val ? 'text-accent' : 'text-white/50'}`}>
                              {opt.label}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button onClick={() => setStep(1)} className="px-4 py-3 rounded-xl text-xs font-medium text-white/40 border border-white/10 hover:border-white/20 transition-colors">
                        Back
                      </button>
                      <button
                        onClick={form.otaPresence ? handleSubmit : undefined}
                        disabled={!form.otaPresence}
                        className={`flex-1 py-3 rounded-xl font-display font-bold text-sm transition-all ${
                          form.otaPresence ? 'btn-primary' : 'bg-white/5 text-white/20 cursor-not-allowed'
                        }`}
                      >
                        Get My Score
                      </button>
                    </div>
                  </div>
                )}

                {step === 3 && result && (
                  <div className="space-y-4 text-center">
                    <div className="py-4">
                      <div className="text-4xl sm:text-5xl font-display font-bold text-accent mb-1">{result.score}<span className="text-lg text-accent/50">/100</span></div>
                      <span className="text-xs text-white/40">OTA Score</span>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 rounded-lg border border-white/8 bg-white/[0.02]">
                        <Eye size={14} className="text-accent/60 mx-auto mb-1" />
                        <div className="text-sm font-display font-bold text-white">{result.visibility}</div>
                        <div className="text-[9px] text-white/30">Visibility Rating</div>
                      </div>
                      <div className="p-3 rounded-lg border border-white/8 bg-white/[0.02]">
                        <TrendingUp size={14} className="text-accent/60 mx-auto mb-1" />
                        <div className="text-sm font-display font-bold text-accent">{result.growth}</div>
                        <div className="text-[9px] text-white/30">Revenue Potential</div>
                      </div>
                    </div>
                    <a
                      href="https://wa.me/919270598602?text=Hi%2C%20I%20just%20completed%20the%20OTA%20audit%20and%20got%20a%20score%20of%20{result.score}%2F100.%20I%27d%20like%20to%20discuss%20improving%20my%20OTA%20performance."
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn-primary w-full inline-flex items-center justify-center"
                    >
                      Discuss My Audit Results
                    </a>
                    <button onClick={reset} className="text-[10px] text-white/30 hover:text-white/50 transition-colors">
                      Close
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
}
