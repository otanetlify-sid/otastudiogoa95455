import { TrendingUp, Radio, BarChart3, Globe, Eye, Layers, Music, Heart, Palette, Building2, Coffee, Utensils, Users } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const otaItems = [
  { icon: Layers, label: 'OTA Onboarding', desc: 'Complete setup across all platforms' },
  { icon: BarChart3, label: 'OTA Management', desc: 'Ongoing optimization and monitoring' },
  { icon: Globe, label: 'OTA Distribution', desc: 'Multi-platform channel management' },
  { icon: TrendingUp, label: 'Revenue Optimization', desc: 'Pricing strategy and yield management' },
  { icon: Eye, label: 'Visibility Improvement', desc: 'Ranking and listing optimization' },
  { icon: Radio, label: 'Channel Management', desc: 'Unified inventory and rate control' },
];

const communityItems = [
  { icon: Building2, label: 'Hospitality Activations', desc: 'Live experiences at your venue' },
  { icon: Users, label: 'Community Events', desc: 'Curated events that build loyalty' },
  { icon: Music, label: 'Live Music Experiences', desc: 'DJs, bands, and performances' },
  { icon: Heart, label: 'Wellness Programs', desc: 'Yoga, sound healing, retreats' },
  { icon: Palette, label: 'Creative Workshops', desc: 'Art, pottery, photography walks' },
  { icon: Coffee, label: 'Cafe & Restaurant Growth', desc: 'Community-driven footfall increase' },
  { icon: Utensils, label: 'Bar & Nightlife Growth', desc: 'Events that fill your venue' },
];

export default function OtaCommunitySplit() {
  const { ref, isInView } = useInView(0.1);

  return (
    <section ref={ref} className="relative py-16 sm:py-24 bg-neutral-950 text-white overflow-hidden">
      <div className="absolute inset-0 section-grid opacity-8" />

      <div className="section-max section-padding relative">
        <div className={`text-center mb-10 sm:mb-14 ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/15 text-accent border border-accent/20 mb-4">Dual Growth System</span>
          <h2 className="heading-lg text-white mb-3">OTA Growth Meets Community Power</h2>
          <p className="body-md text-white/60 max-w-2xl mx-auto">
            Two interconnected growth engines that drive both digital visibility and real-world engagement for your hospitality brand.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6 sm:gap-8">
          {/* OTA Growth Column */}
          <div className={`group/column rounded-2xl border border-white/10 bg-white/[0.02] p-5 sm:p-7 hover:border-accent/20 transition-all duration-500 ${isInView ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: isInView ? '100ms' : undefined }}>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-accent/15 flex items-center justify-center">
                <TrendingUp size={18} className="text-accent" />
              </div>
              <div>
                <h3 className="font-display font-bold text-white text-base sm:text-lg">OTA Growth</h3>
                <p className="text-xs text-white/40">Digital visibility & revenue engine</p>
              </div>
            </div>

            <div className="space-y-3">
              {otaItems.map((item, i) => {
                const Icon = item.icon;
                return (
                  <a
                    key={i}
                    href={i === 0 ? '/ota-onboarding-goa' : i === 1 ? '/ota-management-goa' : i === 2 ? '/hotel-distribution-goa' : i === 3 ? '/ota-strategy-insights' : i === 4 ? '/hotel-marketing-goa' : '/property-management-goa'}
                    className="group flex items-center gap-3 p-3 rounded-lg border border-white/5 bg-white/[0.01] hover:border-accent/20 hover:bg-white/[0.04] transition-all duration-300"
                  >
                    <div className="w-8 h-8 rounded bg-accent/10 flex items-center justify-center group-hover:bg-accent/20 transition-colors shrink-0">
                      <Icon size={14} className="text-accent" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-white/70 group-hover:text-white transition-colors">{item.label}</div>
                      <div className="text-xs text-white/30">{item.desc}</div>
                    </div>
                  </a>
                );
              })}
            </div>
          </div>

          {/* Community Experiences Column */}
          <div className={`group/column rounded-2xl border border-white/10 bg-white/[0.02] p-5 sm:p-7 hover:border-accent/20 transition-all duration-500 ${isInView ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: isInView ? '200ms' : undefined }}>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-accent/15 flex items-center justify-center">
                <Users size={18} className="text-accent" />
              </div>
              <div>
                <h3 className="font-display font-bold text-white text-base sm:text-lg">Community Experiences</h3>
                <p className="text-xs text-white/40">Real-world engagement & loyalty engine</p>
              </div>
            </div>

            <div className="space-y-3">
              {communityItems.map((item, i) => {
                const Icon = item.icon;
                return (
                  <a
                    key={i}
                    href={i === 0 ? '/hospitality-activations-goa' : i === 1 ? '/community-events-goa' : i === 2 ? '/live-music-events-goa' : i === 3 ? '/wellness-events-goa' : i === 4 ? '/creative-workshops-goa' : i === 5 ? '/community-growth-for-cafes' : '/bar-growth-goa'}
                    className="group flex items-center gap-3 p-3 rounded-lg border border-white/5 bg-white/[0.01] hover:border-accent/20 hover:bg-white/[0.04] transition-all duration-300"
                  >
                    <div className="w-8 h-8 rounded bg-accent/10 flex items-center justify-center group-hover:bg-accent/20 transition-colors shrink-0">
                      <Icon size={14} className="text-accent" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-white/70 group-hover:text-white transition-colors">{item.label}</div>
                      <div className="text-xs text-white/30">{item.desc}</div>
                    </div>
                  </a>
                );
              })}
            </div>
          </div>
        </div>

        {/* Connecting bridge visual */}
        <div className={`mt-6 sm:mt-8 text-center ${isInView ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: isInView ? '300ms' : undefined }}>
          <div className="inline-flex items-center gap-3 px-5 py-2.5 rounded-full border border-accent/15 bg-accent/5">
            <span className="text-xs font-medium text-accent">OTA Growth</span>
            <div className="flex items-center gap-1">
              <div className="w-1.5 h-1.5 rounded-full bg-accent/40 animate-pulse" />
              <div className="w-8 h-px bg-gradient-to-r from-accent/40 to-accent/20" />
              <div className="w-1.5 h-1.5 rounded-full bg-accent/40 animate-pulse" style={{ animationDelay: '0.5s' }} />
              <div className="w-8 h-px bg-gradient-to-r from-accent/20 to-accent/40" />
              <div className="w-1.5 h-1.5 rounded-full bg-accent/40 animate-pulse" style={{ animationDelay: '1s' }} />
            </div>
            <span className="text-xs font-medium text-accent">Community Power</span>
          </div>
        </div>
      </div>
    </section>
  );
}
