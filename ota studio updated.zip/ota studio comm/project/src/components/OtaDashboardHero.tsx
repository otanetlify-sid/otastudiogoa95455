import { useState, useCallback } from 'react';
import { BarChart3, TrendingUp, Calendar, Target, Globe, AlertTriangle, ArrowUpRight, ChevronDown, ChevronUp, Zap } from 'lucide-react';
import { useInView } from '../hooks/useInView';
import NetworkBackground from './NetworkBackground';
import GlobeVisual from './GlobeVisual';
import OtaNetworkVisualization from './OtaNetworkVisualization';
import PropertyJourney from './PropertyJourney';
import VisibleCanvas from './VisibleCanvas';
import OtaAuditModal from './OtaAuditModal';
import ActivityFeed from './ActivityFeed';

const kpis = [
  {
    label: 'Occupancy', value: '76%', icon: BarChart3, bar: 76,
    insight: 'Above Goa average of 62%',
    impact: '+18 bookings/month potential',
    risk: 'low' as const,
    action: 'Maintain pricing strategy',
    benchmark: { property: 76, avg: 62, top10: 89 },
  },
  {
    label: 'Revenue Growth', value: '+23%', icon: TrendingUp, bar: 85,
    insight: 'Driven by OTA distribution expansion',
    impact: '+INR 1.2L monthly revenue gain',
    risk: 'low' as const,
    action: 'Scale to 10+ platforms',
    benchmark: { property: 23, avg: 11, top10: 35 },
  },
  {
    label: 'Bookings', value: '342/mo', icon: Calendar, bar: 68,
    insight: 'Booking.com leads at 32% share',
    impact: 'Direct bookings at 8% — room to grow',
    risk: 'medium' as const,
    action: 'Improve direct booking channel',
    benchmark: { property: 342, avg: 210, top10: 480 },
  },
  {
    label: 'OTA Score', value: '87/100', icon: Target, bar: 87,
    insight: 'Top 15% among Goa properties',
    impact: 'Higher ranking = more visibility',
    risk: 'low' as const,
    action: 'Push to 90+ for premium placement',
    benchmark: { property: 87, avg: 64, top10: 94 },
  },
  {
    label: 'Distribution', value: '8 Platforms', icon: Globe, bar: 92,
    insight: '3 more platforms available for onboarding',
    impact: 'Each new platform = +5-12% reach',
    risk: 'medium' as const,
    action: 'Activate Hostelworld + TripAdvisor',
    benchmark: { property: 8, avg: 4, top10: 11 },
  },
];

const riskColors = { low: 'text-green-400', medium: 'text-yellow-400', high: 'text-red-400' };

export default function OtaDashboardHero() {
  const { ref, isInView } = useInView(0.1);
  const [compareMode, setCompareMode] = useState(false);
  const [expandedKpi, setExpandedKpi] = useState<number | null>(null);

  const handleTilt = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const card = e.currentTarget;
    const rect = card.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    card.style.transform = `perspective(1200px) rotateY(${x * 2}deg) rotateX(${-y * 2}deg)`;
  }, []);

  const resetTilt = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    e.currentTarget.style.transform = '';
  }, []);

  return (
    <section ref={ref} className="relative py-16 sm:py-24 bg-neutral-950 text-white overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-accent/5 rounded-full blur-3xl animate-glow-pulse" />
      <div className="absolute inset-0 section-grid opacity-10" />
      <VisibleCanvas className="absolute inset-0">
        <OtaNetworkVisualization />
      </VisibleCanvas>
      <VisibleCanvas className="absolute inset-0">
        <NetworkBackground />
      </VisibleCanvas>
      <VisibleCanvas className="absolute inset-0">
        <GlobeVisual />
      </VisibleCanvas>

      <div className="section-max section-padding relative">
        <div className={`text-center mb-8 sm:mb-12 ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/15 text-accent border border-accent/20 mb-4">OTA Intelligence</span>
          <h2 className="heading-lg text-white mb-3">OTA Studio Intelligence Dashboard</h2>
          <p className="body-md text-white/60 max-w-2xl mx-auto">
            Real-time OTA performance, revenue analytics, and distribution insights across all platforms
          </p>
        </div>

        <div className={`relative max-w-5xl mx-auto transition-all duration-1000 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="relative rounded-2xl sm:rounded-3xl border border-white/10 bg-neutral-900/80 backdrop-blur-sm overflow-hidden shadow-2xl shadow-accent/5 transition-transform duration-300 ease-out"
               onMouseMove={handleTilt}
               onMouseLeave={resetTilt}>

            {/* Top bar */}
            <div className="flex items-center justify-between px-4 sm:px-6 py-2.5 sm:py-3 border-b border-white/8 bg-white/[0.02]">
              <div className="flex items-center gap-2 sm:gap-3">
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-400/60" />
                  <div className="w-2.5 h-2.5 rounded-full bg-yellow-400/60" />
                  <div className="w-2.5 h-2.5 rounded-full bg-green-400/60" />
                </div>
                <span className="text-[10px] sm:text-xs font-medium text-white/40 font-display">OTA Studio Dashboard</span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setCompareMode(!compareMode)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[10px] sm:text-xs font-medium transition-all ${
                    compareMode ? 'bg-accent/15 text-accent border border-accent/20' : 'text-white/30 hover:text-white/50 border border-transparent'
                  }`}
                >
                  <Zap size={10} />
                  <span className="hidden sm:inline">Compare</span>
                </button>
                <div className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                  <span className="text-[10px] sm:text-xs text-white/30">Live</span>
                </div>
              </div>
            </div>

            <div className="p-3 sm:p-5 lg:p-6">
              {/* Property Journey (Phase 5) */}
              <div className="mb-3 sm:mb-4 px-1">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[8px] sm:text-[10px] text-white/50 font-medium uppercase tracking-widest">Property Journey</span>
                  <span className="text-[8px] sm:text-[10px] text-accent">Stage 3 of 5</span>
                </div>
                <PropertyJourney />
              </div>

              {/* KPI Row */}
              <div className="grid grid-cols-5 gap-2 sm:gap-3 mb-3 sm:mb-4">
                {kpis.map((kpi, i) => {
                  const Icon = kpi.icon;
                  const isExpanded = expandedKpi === i;
                  return (
                    <div key={i}>
                      <div
                        className={`group relative rounded-lg sm:rounded-xl border bg-white/[0.02] p-2 sm:p-3 lg:p-4 transition-all duration-500 overflow-hidden cursor-pointer ${
                          isExpanded ? 'border-accent/30' : 'border-white/8 hover:border-accent/25'
                        } ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}
                        style={{ transitionDelay: isInView ? `${i * 80 + 200}ms` : undefined }}
                        onClick={() => setExpandedKpi(isExpanded ? null : i)}
                      >
                        <div className="absolute inset-0 rounded-lg sm:rounded-xl bg-gradient-to-br from-accent/8 via-transparent to-accent/4 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-6 sm:w-10 h-px bg-gradient-to-r from-transparent via-accent/40 to-transparent group-hover:via-accent/70 transition-colors duration-500" />

                        <div className="relative">
                          <div className="flex items-center gap-1.5 sm:gap-2 mb-1.5 sm:mb-2">
                            <div className="w-5 h-5 sm:w-7 sm:h-7 lg:w-8 lg:h-8 rounded bg-accent/10 flex items-center justify-center group-hover:bg-accent/20 transition-colors duration-300">
                              <Icon size={10} className="text-accent sm:hidden" />
                              <Icon size={12} className="text-accent hidden sm:block lg:hidden" />
                              <Icon size={14} className="text-accent hidden lg:block" />
                            </div>
                            <span className="text-[8px] sm:text-[10px] lg:text-xs font-medium text-white/60 group-hover:text-white/80 transition-colors leading-tight truncate">
                              {kpi.label}
                            </span>
                          </div>
                          <div className="text-sm sm:text-lg lg:text-2xl font-display font-bold text-accent group-hover:text-accent-300 transition-colors">
                            {kpi.value}
                          </div>

                          {/* Benchmark comparison (Phase 3) */}
                          {compareMode && (
                            <div className="mt-1.5 space-y-1">
                              <div className="flex items-center justify-between">
                                <span className="text-[7px] sm:text-[9px] text-white/25">You</span>
                                <span className="text-[7px] sm:text-[9px] text-accent/70 font-bold">{kpi.benchmark.property}</span>
                              </div>
                              <div className="h-1 rounded-full bg-white/5 overflow-hidden">
                                <div className="h-full rounded-full bg-accent/50" style={{ width: `${Math.min((kpi.benchmark.property / kpi.benchmark.top10) * 100, 100)}%` }} />
                              </div>
                              <div className="flex items-center justify-between">
                                <span className="text-[7px] sm:text-[9px] text-white/25">Goa Avg</span>
                                <span className="text-[7px] sm:text-[9px] text-white/40">{kpi.benchmark.avg}</span>
                              </div>
                              <div className="h-1 rounded-full bg-white/5 overflow-hidden">
                                <div className="h-full rounded-full bg-white/20" style={{ width: `${Math.min((kpi.benchmark.avg / kpi.benchmark.top10) * 100, 100)}%` }} />
                              </div>
                              <div className="flex items-center justify-between">
                                <span className="text-[7px] sm:text-[9px] text-white/25">Top 10%</span>
                                <span className="text-[7px] sm:text-[9px] text-white/40">{kpi.benchmark.top10}</span>
                              </div>
                              <div className="h-1 rounded-full bg-white/5 overflow-hidden">
                                <div className="h-full rounded-full bg-white/10" style={{ width: '100%' }} />
                              </div>
                            </div>
                          )}

                          {!compareMode && (
                            <div className="mt-1.5 sm:mt-2 h-0.5 sm:h-1 rounded-full bg-white/5 overflow-hidden">
                              <div
                                className="h-full rounded-full bg-gradient-to-r from-accent/60 to-accent/30 animate-bar-fill"
                                style={{ width: isInView ? `${kpi.bar}%` : '0%', transitionDelay: `${i * 100 + 600}ms` }}
                              />
                            </div>
                          )}

                          {/* Expand indicator */}
                          <div className="flex items-center justify-center mt-1">
                            {isExpanded ? <ChevronUp size={10} className="text-white/20" /> : <ChevronDown size={10} className="text-white/20 opacity-0 group-hover:opacity-100 transition-opacity" />}
                          </div>
                        </div>
                      </div>

                      {/* Intelligence insights panel (Phase 2) */}
                      {isExpanded && (
                        <div className="mt-1 p-2 sm:p-3 rounded-lg border border-accent/15 bg-accent/5 space-y-1.5 sm:space-y-2">
                          <div className="flex items-start gap-1.5">
                            <ArrowUpRight size={9} className="text-accent/60 shrink-0 mt-0.5" />
                            <div>
                              <span className="text-[8px] sm:text-[10px] text-white/25 block">What this means</span>
                              <span className="text-[9px] sm:text-[11px] text-white/50">{kpi.insight}</span>
                            </div>
                          </div>
                          <div className="flex items-start gap-1.5">
                            <TrendingUp size={9} className="text-accent/60 shrink-0 mt-0.5" />
                            <div>
                              <span className="text-[8px] sm:text-[10px] text-white/25 block">Impact on bookings</span>
                              <span className="text-[9px] sm:text-[11px] text-white/50">{kpi.impact}</span>
                            </div>
                          </div>
                          <div className="flex items-start gap-1.5">
                            <AlertTriangle size={9} className={`${riskColors[kpi.risk]} shrink-0 mt-0.5`} />
                            <div>
                              <span className="text-[8px] sm:text-[10px] text-white/25 block">Risk level</span>
                              <span className={`text-[9px] sm:text-[11px] capitalize ${riskColors[kpi.risk]}`}>{kpi.risk}</span>
                            </div>
                          </div>
                          <div className="flex items-start gap-1.5">
                            <Zap size={9} className="text-accent/60 shrink-0 mt-0.5" />
                            <div>
                              <span className="text-[8px] sm:text-[10px] text-white/25 block">Recommended action</span>
                              <span className="text-[9px] sm:text-[11px] text-white/50">{kpi.action}</span>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Charts Area */}
              <div className="grid grid-cols-3 gap-2 sm:gap-3 lg:gap-4">
                {/* Revenue Chart */}
                <div className="col-span-2 rounded-lg sm:rounded-xl border border-white/8 bg-white/[0.02] p-3 sm:p-4 lg:p-5 overflow-hidden relative">
                  <div className="flex items-center justify-between mb-3 sm:mb-4">
                    <span className="text-[10px] sm:text-xs font-medium text-white/60">Revenue Performance</span>
                    <span className="text-[10px] sm:text-xs text-accent/60 font-display font-bold">+23% MoM</span>
                  </div>
                  <div className="flex items-end gap-1 sm:gap-1.5 lg:gap-2 h-20 sm:h-28 lg:h-36">
                    {[45, 62, 38, 71, 55, 80, 48, 67, 73, 59, 85, 76].map((h, i) => (
                      <div key={i} className="flex-1 rounded-t-sm sm:rounded-t relative overflow-hidden" style={{ height: isInView ? `${h}%` : '0%', transition: `height 0.8s cubic-bezier(0.16, 1, 0.3, 1) ${i * 60 + 400}ms` }}>
                        <div className="absolute inset-0 bg-gradient-to-t from-accent/30 to-accent/10" />
                        <div className="absolute inset-0 bg-gradient-to-t from-accent/20 to-accent/5 animate-shimmer-bar" style={{ animationDelay: `${i * 150}ms` }} />
                      </div>
                    ))}
                  </div>
                  <div className="flex justify-between mt-1.5 sm:mt-2">
                    {['Jan', 'Mar', 'May', 'Jul', 'Sep', 'Nov'].map((m) => (
                      <span key={m} className="text-[8px] sm:text-[10px] text-white/20">{m}</span>
                    ))}
                  </div>
                </div>

                {/* Side panels */}
                <div className="flex flex-col gap-2 sm:gap-3 lg:gap-4">
                  {/* OTA Distribution */}
                  <div className="flex-1 rounded-lg sm:rounded-xl border border-white/8 bg-white/[0.02] p-3 sm:p-4 overflow-hidden relative">
                    <span className="text-[10px] sm:text-xs font-medium text-white/60 mb-2 sm:mb-3 block">OTA Distribution</span>
                    <div className="space-y-1.5 sm:space-y-2">
                      {[
                        { name: 'Booking.com', pct: 32, color: 'bg-accent/40' },
                        { name: 'MakeMyTrip', pct: 24, color: 'bg-accent/30' },
                        { name: 'Airbnb', pct: 20, color: 'bg-accent/25' },
                        { name: 'Goibibo', pct: 14, color: 'bg-accent/20' },
                        { name: 'Others', pct: 10, color: 'bg-accent/15' },
                      ].map((ota, i) => (
                        <div key={i}>
                          <div className="flex items-center justify-between mb-0.5 sm:mb-1">
                            <span className="text-[8px] sm:text-[10px] text-white/40">{ota.name}</span>
                            <span className="text-[8px] sm:text-[10px] text-white/30">{ota.pct}%</span>
                          </div>
                          <div className="h-1 sm:h-1.5 rounded-full bg-white/5 overflow-hidden">
                            <div className={`h-full rounded-full ${ota.color} animate-bar-fill`} style={{ width: isInView ? `${ota.pct}%` : '0%', transitionDelay: `${i * 80 + 600}ms` }} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Occupancy Ring */}
                  <div className="flex-1 rounded-lg sm:rounded-xl border border-white/8 bg-white/[0.02] p-3 sm:p-4 flex flex-col items-center justify-center relative overflow-hidden">
                    <span className="text-[10px] sm:text-xs font-medium text-white/60 mb-2 block">Occupancy</span>
                    <div className="relative w-14 h-14 sm:w-20 sm:h-20">
                      <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                        <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="6" />
                        <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(255,208,0,0.4)" strokeWidth="6" strokeDasharray={`${76 * 2.64} ${100 * 2.64}`} strokeLinecap="round" className="animate-ring-fill" style={{ strokeDasharray: isInView ? `${76 * 2.64} ${100 * 2.64}` : '0 999' }} />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-sm sm:text-xl font-display font-bold text-accent">76%</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Activity Feed (Phase 8) */}
              <div className="mt-2 sm:mt-3">
                <ActivityFeed />
              </div>

              {/* Revenue Impact Analysis - Growth Opportunity View */}
              <div className="mt-3 sm:mt-4 grid grid-cols-3 gap-2 sm:gap-3">
                {[
                  { label: 'Revenue Growth Opportunity', value: '+INR 2.4L', icon: TrendingUp, color: 'text-green-400', bg: 'bg-green-400/8', border: 'border-green-400/15' },
                  { label: 'Potential Occupancy Increase', value: '+13%', icon: ArrowUpRight, color: 'text-accent', bg: 'bg-accent/8', border: 'border-accent/15' },
                  { label: 'Visibility Improvement', value: '+22%', icon: TrendingUp, color: 'text-green-400', bg: 'bg-green-400/8', border: 'border-green-400/15' },
                ].map((item, i) => {
                  const Icon = item.icon;
                  return (
                    <div key={i} className={`rounded-lg sm:rounded-xl border ${item.border} ${item.bg} p-2.5 sm:p-3 lg:p-4 ${isInView ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: `${i * 100 + 800}ms` }}>
                      <div className="flex items-center gap-1.5 mb-1.5">
                        <Icon size={10} className={item.color} />
                        <span className="text-[8px] sm:text-[10px] font-medium text-white/30">{item.label}</span>
                      </div>
                      <div className={`text-sm sm:text-lg lg:text-xl font-display font-bold ${item.color}`}>{item.value}</div>
                    </div>
                  );
                })}
              </div>

              {/* OTA Audit CTA + Modal (Phase 6) */}
              <OtaAuditModal />
            </div>

            {/* Bottom status bar */}
            <div className="flex items-center justify-between px-4 sm:px-6 py-1.5 sm:py-2 border-t border-white/8 bg-white/[0.02]">
              <div className="flex items-center gap-3 sm:gap-4">
                <span className="text-[8px] sm:text-[10px] text-white/50">8 Platforms Active</span>
                <span className="text-[8px] sm:text-[10px] text-white/50">Last sync: 2m ago</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-1 h-1 rounded-full bg-green-400/60 animate-pulse" />
                <span className="text-[8px] sm:text-[10px] text-white/50">All systems operational</span>
              </div>
            </div>
          </div>

          <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-3/4 h-8 bg-accent/10 rounded-full blur-xl animate-glow-pulse" />
          <div className="absolute -top-3 left-1/4 w-px h-3 bg-gradient-to-t from-accent/30 to-transparent animate-connector-pulse" />
          <div className="absolute -top-3 right-1/4 w-px h-3 bg-gradient-to-t from-accent/30 to-transparent animate-connector-pulse" style={{ animationDelay: '0.5s' }} />
          <div className="absolute -bottom-3 left-1/3 w-px h-3 bg-gradient-to-b from-accent/30 to-transparent animate-connector-pulse" style={{ animationDelay: '1s' }} />
          <div className="absolute -bottom-3 right-1/3 w-px h-3 bg-gradient-to-b from-accent/30 to-transparent animate-connector-pulse" style={{ animationDelay: '1.5s' }} />
        </div>
      </div>

      <style>{`
        @keyframes glow-pulse {
          0%, 100% { opacity: 0.4; transform: scale(1); }
          50% { opacity: 0.7; transform: scale(1.05); }
        }
        .animate-glow-pulse { animation: glow-pulse 4s ease-in-out infinite; }
        @keyframes shimmer-bar {
          0% { opacity: 0; transform: translateY(100%); }
          30% { opacity: 0.5; }
          100% { opacity: 0; transform: translateY(-100%); }
        }
        .animate-shimmer-bar { animation: shimmer-bar 3s ease-in-out infinite; }
        @keyframes connector-pulse {
          0%, 100% { opacity: 0.2; height: 12px; }
          50% { opacity: 0.6; height: 18px; }
        }
        .animate-connector-pulse { animation: connector-pulse 3s ease-in-out infinite; }
        .animate-bar-fill { transition: width 1s cubic-bezier(0.16, 1, 0.3, 1); }
        .animate-ring-fill { transition: stroke-dasharray 1.2s cubic-bezier(0.16, 1, 0.3, 1); }
      `}</style>
    </section>
  );
}
