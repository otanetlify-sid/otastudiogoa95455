import {
  Rocket, TrendingUp, ChartBar as BarChart3, ShieldCheck, Network, Eye,
  Music, Leaf, Users, Umbrella, Palette, Grape,
} from 'lucide-react';
import { useInView } from '../hooks/useInView';

const otaGrowthItems = [
  { icon: Rocket, label: 'OTA Onboarding' },
  { icon: TrendingUp, label: 'OTA Management' },
  { icon: Network, label: 'Distribution Management' },
  { icon: BarChart3, label: 'Revenue Optimization' },
  { icon: ShieldCheck, label: 'Channel Management' },
  { icon: Eye, label: 'Property Visibility' },
];

const activationItems = [
  { icon: Music, label: 'Music Experiences' },
  { icon: Leaf, label: 'Wellness Experiences' },
  { icon: Users, label: 'Community Events' },
  { icon: Umbrella, label: 'Venue Activations' },
  { icon: Palette, label: 'Creative Workshops' },
  { icon: Grape, label: 'Cultural Experiences' },
];

export default function OtaEcosystem() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="ota-ecosystem"
      aria-labelledby="ota-ecosystem-heading"
      className="py-20 sm:py-28 bg-neutral-950 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-40" />

      <div className="section-max section-padding relative">
        <div className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">OTA Studio Ecosystem</span>
          <h2 id="ota-ecosystem-heading" className="heading-lg text-white mb-4">
            One Company, <span className="text-accent">Two Engines</span>
          </h2>
          <p className="body-lg">
            OTA Studio operates as a unified hospitality growth ecosystem — digital visibility through OTA Growth,
            real-world engagement through Hospitality Activations.
          </p>
        </div>

        <div className={`max-w-4xl mx-auto ${isInView ? 'animate-fade-up delay-100' : 'opacity-0'}`}>
          {/* Root */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-3 px-6 py-4 rounded-2xl bg-accent/10 border-2 border-accent/30">
              <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center">
                <Rocket size={20} className="text-accent" />
              </div>
              <span className="font-display font-extrabold text-xl text-white">OTA Studio</span>
            </div>
          </div>

          {/* Connector line */}
          <div className="flex justify-center mb-2">
            <div className="w-px h-8 bg-white/15" />
          </div>

          {/* Branch connector */}
          <div className="flex justify-center mb-2">
            <div className="w-3/5 h-px bg-white/15 relative">
              <div className="absolute left-0 top-0 w-px h-4 bg-white/15 -translate-y-4" />
              <div className="absolute right-0 top-0 w-px h-4 bg-white/15 -translate-y-4" />
            </div>
          </div>

          {/* Two branches */}
          <div className="grid md:grid-cols-2 gap-6 lg:gap-10">
            {/* OTA Growth */}
            <div className="p-6 sm:p-8 rounded-2xl border border-accent/20 bg-accent/5">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-lg bg-accent/15 flex items-center justify-center">
                  <TrendingUp size={20} className="text-accent" />
                </div>
                <h3 className="font-display font-bold text-lg text-white">OTA Growth</h3>
              </div>
              <div className="space-y-3">
                {otaGrowthItems.map((item, i) => (
                  <div key={i} className="flex items-center gap-3 group">
                    <div className="w-8 h-8 rounded-lg bg-accent/10 flex items-center justify-center group-hover:bg-accent/20 transition-colors">
                      <item.icon size={14} className="text-accent" />
                    </div>
                    <span className="text-sm text-white/70 font-medium">{item.label}</span>
                  </div>
                ))}
              </div>
              <div className="mt-6 pt-4 border-t border-accent/15">
                <a href="/ota-management-goa" className="text-xs text-accent font-medium hover:text-accent-300 transition-colors">
                  Explore OTA Services &rarr;
                </a>
              </div>
            </div>

            {/* Hospitality Activations */}
            <div className="p-6 sm:p-8 rounded-2xl border border-white/15 bg-white/4">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center">
                  <Music size={20} className="text-white" />
                </div>
                <h3 className="font-display font-bold text-lg text-white">Hospitality Activations</h3>
              </div>
              <div className="space-y-3">
                {activationItems.map((item, i) => (
                  <div key={i} className="flex items-center gap-3 group">
                    <div className="w-8 h-8 rounded-lg bg-white/8 flex items-center justify-center group-hover:bg-white/15 transition-colors">
                      <item.icon size={14} className="text-white/80" />
                    </div>
                    <span className="text-sm text-white/70 font-medium">{item.label}</span>
                  </div>
                ))}
              </div>
              <div className="mt-6 pt-4 border-t border-white/10">
                <a href="/hospitality-activations-goa" className="text-xs text-white/60 font-medium hover:text-white transition-colors">
                  Explore Activations &rarr;
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
