import { useInView } from '../hooks/useInView';

const otas = [
  { name: 'Booking.com', angle: 0 },
  { name: 'Airbnb', angle: 51.4 },
  { name: 'Agoda', angle: 102.8 },
  { name: 'Expedia', angle: 154.3 },
  { name: 'Hostelworld', angle: 205.7 },
  { name: 'MakeMyTrip', angle: 257.1 },
  { name: 'Goibibo', angle: 308.5 },
];

function polarToXY(angle: number, r: number, cx: number, cy: number) {
  const rad = ((angle - 90) * Math.PI) / 180;
  return {
    x: cx + r * Math.cos(rad),
    y: cy + r * Math.sin(rad),
  };
}

export default function OtaNetwork() {
  const { ref, isInView } = useInView();
  const cx = 260;
  const cy = 260;
  const r = 180;

  return (
    <section
      ref={ref}
      id="ota-network"
      aria-labelledby="ota-network-heading"
      className="py-20 sm:py-28 bg-neutral-950 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-60" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-accent/5 rounded-full blur-3xl" />

      <div className="section-max section-padding relative">
        <div
          className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 opacity-0 ${
            isInView ? 'animate-fade-up' : ''
          }`}
        >
          <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">
            Distribution Network
          </span>
          <h2
            id="ota-network-heading"
            className="heading-lg text-white mb-4"
          >
            One Property.{' '}
            <span className="text-accent">Multiple Channels.</span>
          </h2>
          <p className="body-lg">
            We connect your property to every major OTA simultaneously — so you reach
            the right guests, everywhere they search.
          </p>
        </div>

        <div className="flex justify-center">
          <div
            className={`relative w-[520px] h-[520px] max-w-full opacity-0 ${
              isInView ? 'animate-fade-in delay-300' : ''
            }`}
            style={{ maxWidth: 'min(520px, 100%)' }}
            aria-label="OTA distribution network diagram"
          >
            <svg
              viewBox="0 0 520 520"
              className="w-full h-full"
              fill="none"
              aria-hidden="true"
            >
              {/* Outer ring */}
              <circle
                cx={cx}
                cy={cy}
                r={r + 20}
                stroke="rgba(255,255,255,0.04)"
                strokeWidth="1"
                strokeDasharray="4 6"
              />
              {/* Mid ring */}
              <circle
                cx={cx}
                cy={cy}
                r={r}
                stroke="rgba(255,255,255,0.04)"
                strokeWidth="1"
              />
              {/* Inner ring */}
              <circle
                cx={cx}
                cy={cy}
                r={60}
                stroke="rgba(255,208,0,0.15)"
                strokeWidth="1"
              />

              {/* Lines from center to OTA nodes */}
              {otas.map((ota, i) => {
                const pos = polarToXY(ota.angle, r, cx, cy);
                return (
                  <g key={i}>
                    <line
                      x1={cx}
                      y1={cy}
                      x2={pos.x}
                      y2={pos.y}
                      stroke="rgba(255,208,0,0.12)"
                      strokeWidth="1"
                    />
                    <line
                      x1={cx}
                      y1={cy}
                      x2={pos.x}
                      y2={pos.y}
                      stroke="rgba(255,208,0,0.35)"
                      strokeWidth="1.5"
                      strokeDasharray="8 6"
                      className="network-line"
                      style={{ animationDelay: `${i * 0.42}s` }}
                    />
                  </g>
                );
              })}

              {/* Center glow */}
              <circle cx={cx} cy={cy} r={58} fill="rgba(255,208,0,0.06)" />
              <circle cx={cx} cy={cy} r={48} fill="rgba(255,208,0,0.08)" />
              <circle
                cx={cx}
                cy={cy}
                r={38}
                fill="rgba(255,208,0,0.12)"
                stroke="rgba(255,208,0,0.4)"
                strokeWidth="1.5"
              />

              {/* OTA node dots */}
              {otas.map((ota, i) => {
                const pos = polarToXY(ota.angle, r, cx, cy);
                return (
                  <g key={i}>
                    <circle
                      cx={pos.x}
                      cy={pos.y}
                      r={28}
                      fill="rgba(255,255,255,0.04)"
                      stroke="rgba(255,255,255,0.12)"
                      strokeWidth="1"
                    />
                    <circle
                      cx={pos.x}
                      cy={pos.y}
                      r={4}
                      fill="rgba(255,208,0,0.8)"
                    />
                  </g>
                );
              })}
            </svg>

            {/* Center label */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="text-center">
                <p className="font-display font-extrabold text-sm text-accent leading-none">
                  YOUR
                </p>
                <p className="font-display font-extrabold text-xs text-white/70 mt-0.5">
                  PROPERTY
                </p>
              </div>
            </div>

            {/* OTA labels */}
            {otas.map((ota, i) => {
              const pos = polarToXY(ota.angle, r, cx, cy);
              const pct = 520;
              const lx = (pos.x / pct) * 100;
              const ly = (pos.y / pct) * 100;
              return (
                <div
                  key={i}
                  className="absolute pointer-events-none"
                  style={{
                    left: `${lx}%`,
                    top: `${ly}%`,
                    transform: 'translate(-50%, -50%)',
                  }}
                >
                  <span className="text-[9px] sm:text-[11px] font-display font-bold text-white/60 whitespace-nowrap">
                    {ota.name}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom stats */}
        <div
          className={`mt-12 grid grid-cols-3 gap-5 max-w-2xl mx-auto opacity-0 ${
            isInView ? 'animate-fade-up delay-500' : ''
          }`}
        >
          {[
            { num: '8+', label: 'OTA Platforms' },
            { num: '100%', label: 'Sync Rate' },
            { num: '24/7', label: 'Monitoring' },
          ].map((s, i) => (
            <div
              key={i}
              className="text-center p-5 rounded-2xl bg-white/4 border border-white/8"
            >
              <p className="font-display font-extrabold text-2xl sm:text-3xl text-accent mb-1">
                {s.num}
              </p>
              <p className="text-xs text-white/40 font-medium">{s.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
