import { useEffect, useRef } from 'react';

interface Node {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  opacity: number;
  label?: string;
  isHub?: boolean;
}

const OTA_HUBS = [
  { label: 'Booking.com', x: 0.2, y: 0.3 },
  { label: 'MMT', x: 0.15, y: 0.5 },
  { label: 'Agoda', x: 0.75, y: 0.35 },
  { label: 'Expedia', x: 0.85, y: 0.55 },
];

export default function OtaNetworkVisualization() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);
  const nodesRef = useRef<Node[]>([]);
  const hubNodesRef = useRef<Node[]>([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      const rect = canvas.parentElement?.getBoundingClientRect();
      if (!rect) return;
      canvas.width = rect.width;
      canvas.height = rect.height;
    };
    resize();
    window.addEventListener('resize', resize);

    // Initialize floating nodes
    if (nodesRef.current.length === 0) {
      for (let i = 0; i < 15; i++) {
        nodesRef.current.push({
          x: Math.random(),
          y: Math.random(),
          vx: (Math.random() - 0.5) * 0.0002,
          vy: (Math.random() - 0.5) * 0.0002,
          r: Math.random() * 1.5 + 0.5,
          opacity: Math.random() * 0.3 + 0.1,
        });
      }
    }

    // Initialize hub nodes (OTA platforms)
    if (hubNodesRef.current.length === 0) {
      for (const hub of OTA_HUBS) {
        hubNodesRef.current.push({
          x: hub.x,
          y: hub.y,
          vx: 0,
          vy: 0,
          r: 4,
          opacity: 0.6,
          label: hub.label,
          isHub: true,
        });
      }
      // Center hub (Property)
      hubNodesRef.current.push({
        x: 0.5,
        y: 0.45,
        vx: 0,
        vy: 0,
        r: 6,
        opacity: 0.8,
        label: 'Property',
        isHub: true,
      });
    }

    const draw = () => {
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      const nodes = nodesRef.current;
      const hubs = hubNodesRef.current;

      // Update floating node positions
      for (const n of nodes) {
        n.x += n.vx;
        n.y += n.vy;
        if (n.x < 0 || n.x > 1) n.vx *= -1;
        if (n.y < 0 || n.y > 1) n.vy *= -1;
      }

      // Draw connections from center hub to OTA hubs (white lines + yellow pulses)
      const centerHub = hubs[hubs.length - 1];
      for (let i = 0; i < hubs.length - 1; i++) {
        const hub = hubs[i];

        // White connection line
        ctx.beginPath();
        ctx.moveTo(centerHub.x * w, centerHub.y * h);
        ctx.lineTo(hub.x * w, hub.y * h);
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.06)';
        ctx.lineWidth = 0.5;
        ctx.stroke();

        // Animated yellow pulse traveling along line
        const pulsePos = (Date.now() / 2000 + i * 0.2) % 1;
        const pulseX = hub.x + (centerHub.x - hub.x) * pulsePos;
        const pulseY = hub.y + (centerHub.y - hub.y) * pulsePos;
        // Pulse glow
        ctx.beginPath();
        ctx.arc(pulseX * w, pulseY * h, 4, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 208, 0, 0.15)';
        ctx.fill();
        // Pulse core
        ctx.beginPath();
        ctx.arc(pulseX * w, pulseY * h, 1.5, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 208, 0, 0.5)';
        ctx.fill();
      }

      // Draw connections between floating nodes (white lines)
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = (nodes[i].x - nodes[j].x) * w;
          const dy = (nodes[i].y - nodes[j].y) * h;
          const dist = Math.sqrt(dx * dx + dy * dy);
          const maxDist = Math.min(w, h) * 0.15;
          if (dist < maxDist) {
            const alpha = (1 - dist / maxDist) * 0.06;
            ctx.beginPath();
            ctx.moveTo(nodes[i].x * w, nodes[i].y * h);
            ctx.lineTo(nodes[j].x * w, nodes[j].y * h);
            ctx.strokeStyle = `rgba(255, 255, 255, ${alpha})`;
            ctx.lineWidth = 0.3;
            ctx.stroke();

            // Small yellow signal
            const sigPos = (Date.now() / 4000 + i * 0.4 + j * 0.3) % 1;
            const sigX = nodes[i].x + (nodes[j].x - nodes[i].x) * sigPos;
            const sigY = nodes[i].y + (nodes[j].y - nodes[i].y) * sigPos;
            ctx.beginPath();
            ctx.arc(sigX * w, sigY * h, 0.8, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(255, 208, 0, ${alpha * 3})`;
            ctx.fill();
          }
        }
      }

      // Draw floating nodes
      for (const n of nodes) {
        ctx.beginPath();
        ctx.arc(n.x * w, n.y * h, n.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 208, 0, ${n.opacity})`;
        ctx.fill();
      }

      // Draw hub nodes
      for (const hub of hubs) {
        // Glow
        ctx.beginPath();
        ctx.arc(hub.x * w, hub.y * h, hub.r * 2, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 208, 0, ${hub.opacity * 0.2})`;
        ctx.fill();

        // Main node
        ctx.beginPath();
        ctx.arc(hub.x * w, hub.y * h, hub.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 208, 0, ${hub.opacity})`;
        ctx.fill();
      }

      rafRef.current = requestAnimationFrame(draw);
    };

    rafRef.current = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none"
      style={{ opacity: 0.4 }}
    />
  );
}
