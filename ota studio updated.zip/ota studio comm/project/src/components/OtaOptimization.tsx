import { Search, FileText, DollarSign, Camera, BarChart3, Zap } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const optimizations = [
  {
    icon: Search,
    title: 'Search Ranking Visibility',
    description: 'Get your property to appear on the first page of OTA search results for Goa.',
  },
  {
    icon: FileText,
    title: 'Listing SEO',
    description: 'Optimize your title, description, and keywords to match what travelers search for.',
  },
  {
    icon: DollarSign,
    title: 'Pricing Strategy',
    description: 'Set the right price at the right time to maximize both occupancy and revenue.',
  },
  {
    icon: Camera,
    title: 'Photos & Conversion Rate',
    description: 'Professional photo guidance that turns searchers into bookers.',
  },
  {
    icon: BarChart3,
    title: 'Algorithm Performance Signals',
    description: 'Send the right signals to OTA algorithms so they promote your listing.',
  },
  {
    icon: Zap,
    title: 'Smart OTA Growth System',
    description: 'Demand-based pricing, algorithm ranking improvement, and conversion-driven content strategy.',
  },
];

export default function OtaOptimization() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      className="py-20 sm:py-28 bg-neutral-950 text-white relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_rgba(245,196,0,0.08)_0%,_transparent_60%)]" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />

      <div className="section-max section-padding relative">
        <div
          className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 ${
            isInView ? 'animate-fade-up' : 'opacity-0'
          }`}
        >
          <span className="badge bg-accent/20 text-accent mb-4">
            OTA Optimization
          </span>
          <h2 className="heading-lg !text-white">
            Already Listed But Not Getting Bookings?
          </h2>
          <p className="text-base sm:text-lg text-neutral-400 mt-4 leading-relaxed">
            If your hotel is already on OTAs but invisible to guests, we fix
            it. We optimize every signal that drives OTA ranking and
            conversions.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
          {optimizations.map((item, i) => (
            <div
              key={i}
              className={`group p-6 sm:p-7 rounded-xl border border-neutral-800 hover:border-accent/30 bg-neutral-900/50 backdrop-blur-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:shadow-accent/5 opacity-0 ${
                isInView ? `animate-fade-up delay-${Math.min(i * 100, 500)}` : ''
              }`}
            >
              <div className="w-11 h-11 rounded-lg bg-accent/10 flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                <item.icon
                  size={20}
                  className="text-accent group-hover:text-accent-300 transition-colors"
                />
              </div>
              <h3 className="font-display font-bold text-lg mb-2 text-white">
                {item.title}
              </h3>
              <p className="text-sm text-neutral-400 leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>

        <div
          className={`mt-12 sm:mt-16 text-center opacity-0 ${
            isInView ? 'animate-fade-up delay-600' : ''
          }`}
        >
          <a
            href="https://wa.me/918010939523?text=Hi%2C%20my%20hotel%20is%20listed%20on%20OTAs%20but%20not%20getting%20bookings"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary"
          >
            Fix My OTA Listing
          </a>
        </div>
      </div>
    </section>
  );
}
