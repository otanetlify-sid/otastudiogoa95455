import { Building2, Globe, Eye, Users, Sparkles, TrendingUp, ArrowDown } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const ecosystemStages = [
  { label: 'Property', icon: Building2, description: 'Hotels, Resorts, Villas, Cafes', color: 'white' },
  { label: 'OTA Onboarding', icon: Globe, description: 'Platform registration & setup', color: 'accent' },
  { label: 'Distribution', icon: Globe, description: 'Multi-channel presence', color: 'accent' },
  { label: 'Visibility', icon: Eye, description: 'Search ranking & discovery', color: 'accent' },
  { label: 'Community', icon: Users, description: 'Local network connections', color: 'accent' },
  { label: 'Experiences', icon: Sparkles, description: 'Activations & events', color: 'accent' },
  { label: 'Revenue Growth', icon: TrendingUp, description: 'Sustainable income expansion', color: 'accent' },
];

export default function OtaStudioEcosystem() {
  const { ref, isInView } = useInView(0.2);

  return (
    <section ref={ref} className="relative py-20 sm:py-28 bg-neutral-950 overflow-hidden">
      <div className="section-max section-padding relative">
        {/* Header */}
        <div className={`text-center mb-12 sm:mb-16 transition-all duration-1000 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <h2 className="heading-lg text-white mb-4">
            The OTA Studio <span className="text-accent">Ecosystem</span>
          </h2>
          <p className="body-lg max-w-2xl mx-auto">
            A complete hospitality growth framework that transforms properties into thriving destinations.
          </p>
        </div>

        {/* Ecosystem Flow */}
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col gap-3 sm:gap-4">
            {ecosystemStages.map((stage, i) => {
              const Icon = stage.icon;
              const isAccent = stage.color === 'accent';
              const isLast = i === ecosystemStages.length - 1;
              const isEven = i % 2 === 0;

              return (
                <div
                  key={stage.label}
                  className={`transition-all duration-1000 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
                  style={{ transitionDelay: `${i * 100}ms` }}
                >
                  <div className={`flex flex-col sm:flex-row items-center gap-3 ${isEven ? 'sm:justify-start' : 'sm:justify-end'}`}>
                    <div className={`flex items-center gap-4 px-5 py-4 rounded-xl sm:rounded-2xl border transition-all ${
                      isAccent
                        ? 'bg-accent/5 border-accent/20 hover:border-accent/40'
                        : 'bg-white/[0.02] border-white/10 hover:border-white/20'
                    } ${isEven ? '' : 'sm:flex-row-reverse'}`}>
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                        isAccent
                          ? 'bg-accent/10 text-accent'
                          : 'bg-white/5 text-white/70'
                      }`}>
                        <Icon size={20} />
                      </div>
                      <div className={`text-center ${isEven ? 'sm:text-left' : 'sm:text-right'}`}>
                        <h3 className={`font-display font-bold text-sm sm:text-base ${
                          isAccent ? 'text-accent' : 'text-white'
                        }`}>
                          {stage.label}
                        </h3>
                        <p className="text-xs text-white/50">{stage.description}</p>
                      </div>
                    </div>
                  </div>

                  {/* Connection Arrow */}
                  {!isLast && (
                    <div className={`flex justify-center py-1 ${isEven ? 'sm:pl-10' : 'sm:pr-10 sm:justify-end'}`}>
                      <div className={`flex items-center justify-center ${isEven ? '' : 'sm:flex-row-reverse'}`}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          'bg-accent/10 text-accent'
                        }`}>
                          <ArrowDown size={14} className="rotate-0 sm:rotate-[-90deg]" />
                        </div>
                        <div className={`h-px w-8 sm:w-16 ${
                          'bg-accent/30'
                        }`} />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom Summary */}
        <div className={`mt-12 sm:mt-16 text-center transition-all duration-1000 delay-700 ${isInView ? 'opacity-100' : 'opacity-0'}`}>
          <div className="inline-flex items-center gap-4 px-6 py-4 rounded-2xl bg-white/[0.02] border border-white/10">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-accent" />
              <span className="text-sm text-white/70">Hospitality Growth</span>
            </div>
            <div className="w-px h-4 bg-white/20" />
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-white/60" />
              <span className="text-sm text-white/70">Community Growth</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
