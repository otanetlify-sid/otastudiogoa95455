import { useState } from 'react';
import {
  Building2, Server, Sparkles, Send,
  Hotel, Home, Castle, Palmtree, Coffee, UtensilsCrossed, Wine, Umbrella,
  Monitor, Cable, DollarSign, Globe, Cpu, Users, Camera, Code,
  Music, Leaf, Palette, Calendar, HeartPulse, Camera as Video, PartyPopper,
} from 'lucide-react';
import { useInView } from '../hooks/useInView';
import FormField, { FormSelect } from './FormField';

const propertyTypes = [
  { icon: Hotel, label: 'Hotels' },
  { icon: Home, label: 'Hostels' },
  { icon: Castle, label: 'Villas' },
  { icon: Home, label: 'Homestays' },
  { icon: Palmtree, label: 'Resorts' },
  { icon: Coffee, label: 'Cafes' },
  { icon: UtensilsCrossed, label: 'Restaurants' },
  { icon: Wine, label: 'Bars' },
  { icon: Umbrella, label: 'Beach Clubs' },
];

const techTypes = [
  { icon: Monitor, label: 'PMS Providers' },
  { icon: Cable, label: 'Channel Manager Providers' },
  { icon: DollarSign, label: 'Revenue Management Platforms' },
  { icon: Globe, label: 'Booking Engine Providers' },
  { icon: Cpu, label: 'Hospitality SaaS Companies' },
  { icon: Users, label: 'Hospitality Growth Partners' },
  { icon: Camera, label: 'Hotel Photographers' },
  { icon: Code, label: 'Hospitality Website Developers' },
];

const activationTypes = [
  { icon: Users, label: 'Community Managers' },
  { icon: Calendar, label: 'Event Organizers' },
  { icon: Music, label: 'Musicians' },
  { icon: Sparkles, label: 'DJs' },
  { icon: Palette, label: 'Artists' },
  { icon: Leaf, label: 'Yoga Instructors' },
  { icon: HeartPulse, label: 'Wellness Facilitators' },
  { icon: PartyPopper, label: 'Workshop Hosts' },
  { icon: Palmtree, label: 'Retreat Leaders' },
  { icon: Camera, label: 'Photographers' },
  { icon: Video, label: 'Videographers' },
  { icon: Sparkles, label: 'Experience Hosts' },
];

function validateEmail(email: string) {
  if (!email) return 'Email is required';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return 'Enter a valid email address';
  return '';
}

function validatePhone(phone: string) {
  if (!phone) return 'WhatsApp number is required';
  if (!/^[+]?[\d\s-]{7,15}$/.test(phone)) return 'Enter a valid phone number';
  return '';
}

function validateRequired(value: string, field: string) {
  if (!value.trim()) return `${field} is required`;
  return '';
}

export default function OtaStudioNetwork() {
  const { ref, isInView } = useInView();
  const [techForm, setTechForm] = useState({
    company: '', contact: '', website: '', productType: '', whatsapp: '', email: '', proposal: '',
  });
  const [activationForm, setActivationForm] = useState({
    name: '', category: '', location: '', whatsapp: '', instagram: '', experience: '', portfolio: '',
  });
  const [techErrors, setTechErrors] = useState<Record<string, string>>({});
  const [activationErrors, setActivationErrors] = useState<Record<string, string>>({});

  const handleTechSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errors: Record<string, string> = {};
    errors.company = validateRequired(techForm.company, 'Company name');
    errors.contact = validateRequired(techForm.contact, 'Contact name');
    errors.website = validateRequired(techForm.website, 'Website');
    errors.productType = validateRequired(techForm.productType, 'Product type');
    errors.whatsapp = validatePhone(techForm.whatsapp);
    errors.email = validateEmail(techForm.email);
    setTechErrors(errors);

    if (Object.values(errors).some(e => e)) return;

    const text = `Hi, I'd like to become a Technology Partner.\n\nCompany: ${techForm.company}\nContact: ${techForm.contact}\nWebsite: ${techForm.website}\nProduct Type: ${techForm.productType}\nWhatsApp: ${techForm.whatsapp}\nEmail: ${techForm.email}\nProposal: ${techForm.proposal}`;
    window.open(`https://wa.me/919270598602?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleActivationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errors: Record<string, string> = {};
    errors.name = validateRequired(activationForm.name, 'Full name');
    errors.category = validateRequired(activationForm.category, 'Category');
    errors.location = validateRequired(activationForm.location, 'Location');
    errors.whatsapp = validatePhone(activationForm.whatsapp);
    errors.experience = validateRequired(activationForm.experience, 'Experience');
    setActivationErrors(errors);

    if (Object.values(errors).some(e => e)) return;

    const text = `Hi, I'd like to join the Activation Network.\n\nName: ${activationForm.name}\nCategory: ${activationForm.category}\nLocation: ${activationForm.location}\nWhatsApp: ${activationForm.whatsapp}\nInstagram: ${activationForm.instagram}\nExperience: ${activationForm.experience}\nPortfolio: ${activationForm.portfolio}`;
    window.open(`https://wa.me/919270598602?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <section
      ref={ref}
      id="ota-studio-network"
      aria-labelledby="ota-studio-network-heading"
      className="py-20 sm:py-28 bg-neutral-900 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-30" />
      <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-accent/5 rounded-full blur-3xl" />

      <div className="section-max section-padding relative">
        <div className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">OTA Studio Network</span>
          <h2 id="ota-studio-network-heading" className="heading-lg text-white mb-4">
            The Hospitality Growth <span className="text-accent">Network</span>
          </h2>
          <p className="body-lg">
            OTA Studio connects properties, hospitality technology providers, and activation partners
            into a single ecosystem for hospitality growth.
          </p>
        </div>

        <div className="space-y-8">
          {/* Property Partners */}
          <div className={`p-6 sm:p-8 rounded-2xl border border-accent/20 bg-accent/5 ${isInView ? 'animate-fade-up delay-100' : 'opacity-0'}`}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-accent/15 flex items-center justify-center">
                <Building2 size={20} className="text-accent" />
              </div>
              <h3 className="font-display font-bold text-xl text-white">Property Partners</h3>
            </div>
            <p className="text-sm text-white/50 mb-5 leading-relaxed">
              For hospitality businesses looking to grow through OTA optimization, distribution, and real-world activations.
            </p>
            <div className="flex flex-wrap gap-2 mb-6">
              {propertyTypes.map((tag, i) => (
                <span key={i} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-accent/10 border border-accent/15 text-xs font-medium text-accent">
                  <tag.icon size={11} className="text-accent/70" />
                  {tag.label}
                </span>
              ))}
            </div>
            <a
              href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20grow%20my%20property%20with%20OTA%20Studio"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary"
            >
              Grow My Property
            </a>
          </div>

          {/* OTA Technology Partners */}
          <div className={`p-6 sm:p-8 rounded-2xl border border-white/15 bg-white/4 ${isInView ? 'animate-fade-up delay-200' : 'opacity-0'}`}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center">
                <Server size={20} className="text-white" />
              </div>
              <h3 className="font-display font-bold text-xl text-white">OTA Technology Partners</h3>
            </div>
            <p className="text-sm text-white/50 mb-5 leading-relaxed">
              For PMS providers, channel managers, revenue platforms, and hospitality tech companies.
            </p>
            <div className="flex flex-wrap gap-2 mb-6">
              {techTypes.map((tag, i) => (
                <span key={i} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/6 border border-white/10 text-xs font-medium text-white/60">
                  <tag.icon size={11} className="text-white/40" />
                  {tag.label}
                </span>
              ))}
            </div>

            {/* Tech Partner Form */}
            <div className="p-6 rounded-2xl border border-white/8 bg-white/3 mt-2">
              <h4 className="font-display font-bold text-sm text-white mb-4">Apply as Technology Partner</h4>
              <form onSubmit={handleTechSubmit} noValidate className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <FormField label="Company Name" name="tech-company" required placeholder="Your company name" value={techForm.company} onChange={(e) => setTechForm({ ...techForm, company: e.target.value })} error={techErrors.company} />
                  <FormField label="Contact Name" name="tech-contact" required placeholder="Your full name" value={techForm.contact} onChange={(e) => setTechForm({ ...techForm, contact: e.target.value })} error={techErrors.contact} />
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <FormField label="Website" name="tech-website" type="url" required placeholder="https://yourcompany.com" value={techForm.website} onChange={(e) => setTechForm({ ...techForm, website: e.target.value })} error={techErrors.website} />
                  <FormSelect label="Product Type" name="tech-productType" required value={techForm.productType} onChange={(e) => setTechForm({ ...techForm, productType: e.target.value })}>
                    <option value="">Select product type</option>
                    <option value="PMS">PMS Provider</option>
                    <option value="Channel Manager">Channel Manager</option>
                    <option value="Revenue Management">Revenue Management Platform</option>
                    <option value="Booking Engine">Booking Engine Provider</option>
                    <option value="Hospitality SaaS">Hospitality SaaS</option>
                    <option value="Growth Partner">Hospitality Growth Partner</option>
                    <option value="Photographer">Hotel Photographer</option>
                    <option value="Developer">Website Developer</option>
                  </FormSelect>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <FormField label="WhatsApp Number" name="tech-whatsapp" type="tel" required placeholder="+91 XXXXXXXXXX" value={techForm.whatsapp} onChange={(e) => setTechForm({ ...techForm, whatsapp: e.target.value })} error={techErrors.whatsapp} />
                  <FormField label="Email Address" name="tech-email" type="email" required placeholder="you@company.com" value={techForm.email} onChange={(e) => setTechForm({ ...techForm, email: e.target.value })} error={techErrors.email} />
                </div>
                <FormField label="Partnership Proposal" name="tech-proposal" placeholder="Brief description of the partnership you're proposing..." value={techForm.proposal} onChange={(e) => setTechForm({ ...techForm, proposal: e.target.value })} rows={3} />
                <button type="submit" className="btn-primary w-full">
                  <Send size={16} />
                  Become a Technology Partner
                </button>
              </form>
            </div>
          </div>

          {/* Activation Partners */}
          <div className={`p-6 sm:p-8 rounded-2xl border border-white/15 bg-white/4 ${isInView ? 'animate-fade-up delay-300' : 'opacity-0'}`}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-accent/15 flex items-center justify-center">
                <Sparkles size={20} className="text-accent" />
              </div>
              <h3 className="font-display font-bold text-xl text-white">Activation Partners</h3>
            </div>
            <p className="text-sm text-white/50 mb-5 leading-relaxed">
              For musicians, DJs, yoga instructors, artists, wellness facilitators, photographers, and experience hosts.
            </p>
            <div className="flex flex-wrap gap-2 mb-6">
              {activationTypes.map((tag, i) => (
                <span key={i} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-accent/10 border border-accent/15 text-xs font-medium text-accent">
                  <tag.icon size={11} className="text-accent/70" />
                  {tag.label}
                </span>
              ))}
            </div>

            {/* Activation Partner Form */}
            <div className="p-6 rounded-2xl border border-white/8 bg-white/3 mt-2">
              <h4 className="font-display font-bold text-sm text-white mb-4">Join Activation Network</h4>
              <form onSubmit={handleActivationSubmit} noValidate className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <FormField label="Full Name" name="activation-name" required placeholder="Your full name" value={activationForm.name} onChange={(e) => setActivationForm({ ...activationForm, name: e.target.value })} error={activationErrors.name} />
                  <FormSelect label="Category" name="activation-category" required value={activationForm.category} onChange={(e) => setActivationForm({ ...activationForm, category: e.target.value })}>
                    <option value="">Select a category</option>
                    <option value="Community Manager">Community Manager</option>
                    <option value="Event Organizer">Event Organizer</option>
                    <option value="Musician">Musician</option>
                    <option value="DJ">DJ</option>
                    <option value="Artist">Artist</option>
                    <option value="Yoga Instructor">Yoga Instructor</option>
                    <option value="Wellness Facilitator">Wellness Facilitator</option>
                    <option value="Workshop Host">Workshop Host</option>
                    <option value="Retreat Leader">Retreat Leader</option>
                    <option value="Photographer">Photographer</option>
                    <option value="Videographer">Videographer</option>
                    <option value="Experience Host">Experience Host</option>
                  </FormSelect>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <FormField label="Location" name="activation-location" required placeholder="Your city or area" value={activationForm.location} onChange={(e) => setActivationForm({ ...activationForm, location: e.target.value })} error={activationErrors.location} />
                  <FormField label="WhatsApp Number" name="activation-whatsapp" type="tel" required placeholder="+91 XXXXXXXXXX" value={activationForm.whatsapp} onChange={(e) => setActivationForm({ ...activationForm, whatsapp: e.target.value })} error={activationErrors.whatsapp} />
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <FormField label="Instagram Profile" name="activation-instagram" type="url" placeholder="@yourinstagram" value={activationForm.instagram} onChange={(e) => setActivationForm({ ...activationForm, instagram: e.target.value })} />
                  <FormField label="Portfolio Link" name="activation-portfolio" type="url" placeholder="https://yourportfolio.com" value={activationForm.portfolio} onChange={(e) => setActivationForm({ ...activationForm, portfolio: e.target.value })} />
                </div>
                <FormField label="Experience" name="activation-experience" required placeholder="Describe your experience, expertise, and what you bring..." value={activationForm.experience} onChange={(e) => setActivationForm({ ...activationForm, experience: e.target.value })} rows={3} error={activationErrors.experience} />
                <button type="submit" className="btn-primary w-full">
                  <Send size={16} />
                  Join Activation Network
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
