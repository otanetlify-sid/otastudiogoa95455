import { useState } from 'react';
import { Hotel, Settings, Sparkles, X, Send, ExternalLink } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const WHATSAPP_URL = 'https://wa.me/919270598602';

const partnerIcons: Record<string, React.ElementType> = {
  property: Hotel,
  technology: Settings,
  activation: Sparkles,
};

const partners = [
  {
    id: 'property',
    title: 'Property Partners',
    description: 'Hotels, hostels, villas, homestays, and hospitality businesses',
    items: ['Hotels', 'Hostels', 'Villas', 'Homestays', 'Resorts', 'Cafes', 'Restaurants', 'Bars', 'Beach Clubs'],
    ctaText: 'Grow My Property',
    ctaLink: `${WHATSAPP_URL}?text=Hi%2C%20I%20want%20to%20grow%20my%20property%20with%20OTA%20Studio`,
    hasForm: false,
  },
  {
    id: 'technology',
    title: 'Technology Partners',
    description: 'Software and tech solutions integrated with OTA Studio',
    items: ['PMS Providers', 'Channel Managers', 'Booking Engines', 'Revenue Platforms', 'Hospitality SaaS', 'Hotel Photographers', 'Website Developers'],
    ctaText: 'Become a Technology Partner',
    hasForm: true,
  },
  {
    id: 'activation',
    title: 'Activation Partners',
    description: 'Community creators and experience facilitators',
    items: ['Community Managers', 'Event Organizers', 'Musicians', 'DJs', 'Artists', 'Yoga Instructors', 'Wellness Facilitators', 'Workshop Hosts', 'Retreat Leaders', 'Photographers', 'Videographers', 'Experience Hosts'],
    ctaText: 'Join Activation Network',
    hasForm: true,
  },
];

function TechnologyPartnerForm({ onClose }: { onClose: () => void }) {
  const [formData, setFormData] = useState({
    company: '', contact: '', website: '', product: '', whatsapp: '', email: '', proposal: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const message = `Tech Partner Inquiry:\nCompany: ${formData.company}\nContact: ${formData.contact}\nWebsite: ${formData.website}\nProduct: ${formData.product}\nWhatsApp: ${formData.whatsapp}\nEmail: ${formData.email}\nProposal: ${formData.proposal}`;
    window.open(`${WHATSAPP_URL}?text=${encodeURIComponent(message)}`, '_blank');
    onClose();
  };

  const inputCls = 'w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm placeholder-white/40 focus:border-accent/50 focus:outline-none transition-colors';

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-neutral-900 border border-white/10 rounded-xl p-5 sm:p-6 max-w-md w-full max-h-[85vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <h4 className="font-display font-bold text-white text-lg">Technology Partnership</h4>
          <button onClick={onClose} className="text-white/50 hover:text-white transition-colors p-1" aria-label="Close">
            <X size={18} />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div><label className="block text-xs font-medium text-white/60 mb-1.5">Company Name</label><input type="text" required value={formData.company} onChange={(e) => setFormData({ ...formData, company: e.target.value })} className={inputCls} placeholder="Your company" /></div>
          <div><label className="block text-xs font-medium text-white/60 mb-1.5">Contact Name</label><input type="text" required value={formData.contact} onChange={(e) => setFormData({ ...formData, contact: e.target.value })} className={inputCls} placeholder="Your name" /></div>
          <div><label className="block text-xs font-medium text-white/60 mb-1.5">Website</label><input type="url" value={formData.website} onChange={(e) => setFormData({ ...formData, website: e.target.value })} className={inputCls} placeholder="https://example.com" /></div>
          <div><label className="block text-xs font-medium text-white/60 mb-1.5">Product Type</label><select value={formData.product} onChange={(e) => setFormData({ ...formData, product: e.target.value })} className={inputCls}><option value="">Select product type</option><option value="PMS">PMS</option><option value="Channel Manager">Channel Manager</option><option value="Booking Engine">Booking Engine</option><option value="Revenue System">Revenue System</option><option value="Other">Other</option></select></div>
          <div><label className="block text-xs font-medium text-white/60 mb-1.5">WhatsApp Number</label><input type="tel" required value={formData.whatsapp} onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })} className={inputCls} placeholder="+91 XXXXX XXXXX" /></div>
          <div><label className="block text-xs font-medium text-white/60 mb-1.5">Email</label><input type="email" required value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} className={inputCls} placeholder="your@email.com" /></div>
          <div><label className="block text-xs font-medium text-white/60 mb-1.5">Partnership Proposal</label><textarea value={formData.proposal} onChange={(e) => setFormData({ ...formData, proposal: e.target.value })} className={`${inputCls} resize-none h-20`} placeholder="Tell us about your partnership idea..." /></div>
          <button type="submit" className="w-full btn-primary justify-center text-sm"><Send size={14} /> Send via WhatsApp</button>
        </form>
      </div>
    </div>
  );
}

function ActivationPartnerForm({ onClose }: { onClose: () => void }) {
  const [formData, setFormData] = useState({
    name: '', category: '', location: '', whatsapp: '', instagram: '', experience: '', portfolio: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const message = `Activation Partner Inquiry:\nName: ${formData.name}\nCategory: ${formData.category}\nLocation: ${formData.location}\nWhatsApp: ${formData.whatsapp}\nInstagram: ${formData.instagram}\nExperience: ${formData.experience}\nPortfolio: ${formData.portfolio}`;
    window.open(`${WHATSAPP_URL}?text=${encodeURIComponent(message)}`, '_blank');
    onClose();
  };

  const inputCls = 'w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm placeholder-white/40 focus:border-accent/50 focus:outline-none transition-colors';

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-neutral-900 border border-white/10 rounded-xl p-5 sm:p-6 max-w-md w-full max-h-[85vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <h4 className="font-display font-bold text-white text-lg">Join Activation Network</h4>
          <button onClick={onClose} className="text-white/50 hover:text-white transition-colors p-1" aria-label="Close">
            <X size={18} />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div><label className="block text-xs font-medium text-white/60 mb-1.5">Full Name</label><input type="text" required value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className={inputCls} placeholder="Your name" /></div>
          <div><label className="block text-xs font-medium text-white/60 mb-1.5">Category</label><select value={formData.category} onChange={(e) => setFormData({ ...formData, category: e.target.value })} className={inputCls}><option value="">Select category</option><option value="Musician/DJ">Musician/DJ</option><option value="Yoga/Wellness">Yoga/Wellness</option><option value="Artist">Artist</option><option value="Event Organizer">Event Organizer</option><option value="Workshop Host">Workshop Host</option><option value="Photographer/Videographer">Photographer/Videographer</option><option value="Community Manager">Community Manager</option><option value="Other">Other</option></select></div>
          <div><label className="block text-xs font-medium text-white/60 mb-1.5">Location</label><input type="text" value={formData.location} onChange={(e) => setFormData({ ...formData, location: e.target.value })} className={inputCls} placeholder="City/Region" /></div>
          <div><label className="block text-xs font-medium text-white/60 mb-1.5">WhatsApp Number</label><input type="tel" required value={formData.whatsapp} onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })} className={inputCls} placeholder="+91 XXXXX XXXXX" /></div>
          <div><label className="block text-xs font-medium text-white/60 mb-1.5">Instagram Profile</label><input type="text" value={formData.instagram} onChange={(e) => setFormData({ ...formData, instagram: e.target.value })} className={inputCls} placeholder="@yourprofile" /></div>
          <div><label className="block text-xs font-medium text-white/60 mb-1.5">Years of Experience</label><input type="text" value={formData.experience} onChange={(e) => setFormData({ ...formData, experience: e.target.value })} className={inputCls} placeholder="e.g., 5 years" /></div>
          <div><label className="block text-xs font-medium text-white/60 mb-1.5">Portfolio Link</label><input type="url" value={formData.portfolio} onChange={(e) => setFormData({ ...formData, portfolio: e.target.value })} className={inputCls} placeholder="https://yourportfolio.com" /></div>
          <button type="submit" className="w-full btn-primary justify-center text-sm"><Send size={14} /> Send via WhatsApp</button>
        </form>
      </div>
    </div>
  );
}

export default function OtaStudioNetworkSection() {
  const { ref, isInView } = useInView(0.15);
  const [activeForm, setActiveForm] = useState<string | null>(null);

  return (
    <section ref={ref} className="relative py-16 sm:py-24 bg-neutral-950 text-white overflow-hidden">
      <div className="absolute top-0 left-1/4 w-[400px] h-[400px] bg-accent/6 rounded-full blur-3xl opacity-30" />
      <div className="absolute inset-0 section-grid opacity-15" />

      <div className="section-max section-padding relative">
        <div className={`text-center max-w-3xl mx-auto mb-10 sm:mb-14 ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/15 text-accent border border-accent/20 mb-4">Partnership Network</span>
          <h2 className="heading-lg text-white mb-4">Join the OTA Studio Ecosystem</h2>
          <p className="body-md text-white/70">
            Connect with property operators, technology partners, and activation specialists to build the future of hospitality.
          </p>
        </div>

        <div className="grid sm:grid-cols-3 gap-4 sm:gap-5">
          {partners.map((partner, i) => {
            const Icon = partnerIcons[partner.id];
            return (
              <div
                key={partner.id}
                className={`group relative p-5 sm:p-6 rounded-xl border border-white/10 bg-white/[0.03] backdrop-blur-sm hover:border-accent/30 hover:bg-white/[0.06] transition-all duration-300 ${
                  isInView ? 'animate-fade-up opacity-100' : 'opacity-0'
                }`}
                style={{ animationDelay: isInView ? `${i * 100}ms` : undefined }}
              >
                <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-accent/10 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                <div className="relative">
                  <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-lg bg-accent/15 flex items-center justify-center mb-4 group-hover:bg-accent/25 transition-colors">
                    <Icon size={18} className="text-accent" />
                  </div>

                  <h3 className="font-display font-bold text-sm sm:text-base mb-1.5 text-white">
                    {partner.title}
                  </h3>

                  <p className="text-xs text-white/50 mb-4">
                    {partner.description}
                  </p>

                  <div className="space-y-1.5 mb-5">
                    {partner.items.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <div className="w-1 h-1 rounded-full bg-accent/40" />
                        <span className="text-xs text-white/50">{item}</span>
                      </div>
                    ))}
                  </div>

                  {!partner.hasForm ? (
                    <a
                      href={partner.ctaLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn-primary w-full text-sm justify-center"
                    >
                      {partner.ctaText}
                      <ExternalLink size={14} />
                    </a>
                  ) : (
                    <button
                      onClick={() => setActiveForm(partner.id)}
                      className="btn-primary w-full text-sm justify-center"
                    >
                      {partner.ctaText}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <div className={`mt-10 sm:mt-14 p-5 sm:p-7 rounded-xl border border-accent/20 bg-accent/5 text-center ${isInView ? 'animate-fade-up opacity-100' : 'opacity-0'}`} style={{ animationDelay: isInView ? '300ms' : undefined }}>
          <h3 className="heading-md text-white mb-2">Let's Connect</h3>
          <p className="text-sm text-white/60 mb-4">Have questions? Reach out to us directly</p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 text-sm">
            <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer" className="text-accent font-semibold hover:text-accent-300 transition-colors">
              WhatsApp: +91 92705 98602
            </a>
            <span className="hidden sm:block text-white/30">|</span>
            <span className="text-white/50">Secondary: +91 85519 52391</span>
          </div>
        </div>
      </div>

      {activeForm === 'technology' && <TechnologyPartnerForm onClose={() => setActiveForm(null)} />}
      {activeForm === 'activation' && <ActivationPartnerForm onClose={() => setActiveForm(null)} />}
    </section>
  );
}
