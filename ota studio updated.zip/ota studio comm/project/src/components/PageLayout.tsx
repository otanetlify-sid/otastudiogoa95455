import type { ReactNode } from 'react';
import Header from './Header';
import Footer from './Footer';
import FloatingContact from './FloatingContact';
import useSEO from '../hooks/useSEO';

interface PageLayoutProps {
  children: ReactNode;
  title: string;
  description: string;
  canonical: string;
  schemaType?: 'service' | 'legal' | 'guide' | 'event' | 'community' | 'network' | 'page';
  breadcrumbs?: { name: string; href?: string }[];
}

export default function PageLayout({ children, title, description, canonical, schemaType, breadcrumbs }: PageLayoutProps) {
  useSEO({ title, description, canonical, schemaType, breadcrumbs });

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        {children}
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
