import { Handshake, Sparkles, Users, Megaphone, Lightbulb, Building2, Globe } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const techBenefits = [
  { icon: Handshake, label: 'Referral Opportunities' },
  { icon: Users, label: 'Hospitality Network Access' },
  { icon: Megaphone, label: 'Co-Marketing Opportunities' },
  { icon: Lightbulb, label: 'Strategic Collaborations' },
];

const activationBenefits = [
  { icon: Building2, label: 'Venue Opportunities' },
  { icon: Globe, label: 'Event Collaborations' },
  { icon: Users, label: 'Community Exposure' },
  { icon: Handshake, label: 'Hospitality Partnerships' },
];

export default function PartnerBenefits() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="partner-benefits"
      aria-labelledby="partner-benefits-heading"
      className="py-20 sm:py-28 bg-neutral-950 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-40" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-accent/3 rounded-full blur-3xl" />

      <div className="section-max section-padding relative">
        <div className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Partner Benefits</span>
          <h2 id="partner-benefits-heading" className="heading-lg text-white mb-4">
            Why Join the <span className="text-accent">OTA Studio Network</span>
          </h2>
          <p className="body-lg">
            Strategic benefits for both technology partners and activation partners.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          {/* Technology Partner Benefits */}
          <div className={`p-6 sm:p-8 rounded-2xl border border-white/15 bg-white/4 ${isInView ? 'animate-fade-up delay-100' : 'opacity-0'}`}>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center">
                <Handshake size={20} className="text-white" />
              </div>
              <h3 className="font-display font-bold text-xl text-white">Technology Partners</h3>
            </div>
            <div className="space-y-4">
              {techBenefits.map((benefit, i) => (
                <div key={i} className="flex items-center gap-4 group">
                  <div className="w-10 h-10 rounded-xl bg-white/6 border border-white/8 flex items-center justify-center group-hover:bg-white/10 group-hover:border-accent/20 transition-all">
                    <benefit.icon size={18} className="text-white/60 group-hover:text-accent transition-colors" />
                  </div>
                  <span className="text-sm text-white/70 font-medium">{benefit.label}</span>
                </div>
              ))}
            </div>
            <div className="mt-6 pt-4 border-t border-white/8">
              <a href="/technology-partners" className="text-xs text-white/50 font-medium hover:text-white/80 transition-colors">
                Learn more about Technology Partnerships &rarr;
              </a>
            </div>
          </div>

          {/* Activation Partner Benefits */}
          <div className={`p-6 sm:p-8 rounded-2xl border border-accent/20 bg-accent/5 ${isInView ? 'animate-fade-up delay-200' : 'opacity-0'}`}>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-accent/15 flex items-center justify-center">
                <Sparkles size={20} className="text-accent" />
              </div>
              <h3 className="font-display font-bold text-xl text-white">Activation Partners</h3>
            </div>
            <div className="space-y-4">
              {activationBenefits.map((benefit, i) => (
                <div key={i} className="flex items-center gap-4 group">
                  <div className="w-10 h-10 rounded-xl bg-accent/8 border border-accent/12 flex items-center justify-center group-hover:bg-accent/15 group-hover:border-accent/25 transition-all">
                    <benefit.icon size={18} className="text-accent/70 group-hover:text-accent transition-colors" />
                  </div>
                  <span className="text-sm text-white/70 font-medium">{benefit.label}</span>
                </div>
              ))}
            </div>
            <div className="mt-6 pt-4 border-t border-accent/15">
              <a href="/activation-partners" className="text-xs text-accent/70 font-medium hover:text-accent transition-colors">
                Learn more about Activation Partnerships &rarr;
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
