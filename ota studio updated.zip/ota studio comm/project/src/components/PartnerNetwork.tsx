import { useState } from 'react';
import { Handshake, Sparkles, Send } from 'lucide-react';
import { useInView } from '../hooks/useInView';
import FormField, { FormSelect } from './FormField';

function validatePhone(phone: string) {
  if (!phone) return 'WhatsApp number is required';
  if (!/^[+]?[\d\s-]{7,15}$/.test(phone)) return 'Enter a valid phone number';
  return '';
}

function validateRequired(value: string, field: string) {
  if (!value.trim()) return `${field} is required`;
  return '';
}

export default function PartnerNetwork() {
  const { ref, isInView } = useInView();
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    location: '',
    whatsapp: '',
    message: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: Record<string, string> = {};
    newErrors.name = validateRequired(formData.name, 'Name');
    newErrors.category = validateRequired(formData.category, 'Category');
    newErrors.location = validateRequired(formData.location, 'Location');
    newErrors.whatsapp = validatePhone(formData.whatsapp);
    setErrors(newErrors);

    if (Object.values(newErrors).some(e => e)) return;

    const text = `Hi, I'd like to join the OTA Studio Partner Network.\n\nName: ${formData.name}\nCategory: ${formData.category}\nLocation: ${formData.location}\nWhatsApp: ${formData.whatsapp}\nMessage: ${formData.message}`;
    const isActivationPartner = formData.category === 'Activation Partner';
    const phone = isActivationPartner ? '919309706263' : '919270598602';
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <section
      ref={ref}
      id="partner-network"
      aria-labelledby="partner-network-heading"
      className="py-20 sm:py-28 bg-neutral-900 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-30" />
      <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-accent/5 rounded-full blur-3xl" />

      <div className="section-max section-padding relative">
        <div className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Partner Network</span>
          <h2 id="partner-network-heading" className="heading-lg text-white mb-4">
            Join OTA Studio <span className="text-accent">Partner Network</span>
          </h2>
          <p className="body-lg">
            Whether you're a hospitality tech provider or a creative professional,
            there's a place for you in our network.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 mb-14">
          {/* OTA Partners */}
          <div className={`p-6 sm:p-8 rounded-2xl border border-accent/20 bg-accent/5 ${isInView ? 'animate-fade-up delay-100' : 'opacity-0'}`}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-accent/15 flex items-center justify-center">
                <Handshake size={20} className="text-accent" />
              </div>
              <h3 className="font-display font-bold text-xl text-white">OTA Partners</h3>
            </div>
            <p className="text-sm text-white/50 mb-5 leading-relaxed">
              For hotels, PMS companies, channel managers, and revenue tech providers.
            </p>
            <div className="flex flex-wrap gap-2 mb-6">
              {['Hotels', 'PMS Companies', 'Channel Managers', 'Revenue Tech', 'Distribution Platforms'].map((tag, i) => (
                <span key={i} className="px-3 py-1 rounded-lg bg-accent/10 border border-accent/15 text-xs font-medium text-accent">{tag}</span>
              ))}
            </div>
            <a
              href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20become%20an%20OTA%20Partner"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary"
            >
              Become OTA Partner
            </a>
          </div>

          {/* Activation Partners */}
          <div className={`p-6 sm:p-8 rounded-2xl border border-white/15 bg-white/4 ${isInView ? 'animate-fade-up delay-200' : 'opacity-0'}`}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center">
                <Sparkles size={20} className="text-white" />
              </div>
              <h3 className="font-display font-bold text-xl text-white">Activation Partners</h3>
            </div>
            <p className="text-sm text-white/50 mb-5 leading-relaxed">
              For musicians, DJs, yoga instructors, artists, workshop creators, and event hosts.
            </p>
            <div className="flex flex-wrap gap-2 mb-6">
              {['Musicians', 'DJs', 'Yoga Instructors', 'Artists', 'Workshop Creators', 'Event Hosts'].map((tag, i) => (
                <span key={i} className="px-3 py-1 rounded-lg bg-white/6 border border-white/10 text-xs font-medium text-white/60">{tag}</span>
              ))}
            </div>
            <a
              href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20join%20the%20Activation%20Network"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-secondary"
            >
              Join Activation Network
            </a>
          </div>
        </div>

        {/* Form */}
        <div className={`max-w-2xl mx-auto ${isInView ? 'animate-fade-up delay-300' : 'opacity-0'}`}>
          <div className="p-6 sm:p-8 rounded-2xl border border-white/8 bg-white/4">
            <h3 className="font-display font-bold text-lg text-white mb-6 text-center">Apply to Join</h3>
            <form onSubmit={handleSubmit} noValidate className="space-y-4">
              <FormField label="Your Name" name="pn-name" required placeholder="Your full name" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} error={errors.name} />
              <FormSelect label="Category" name="pn-category" required value={formData.category} onChange={(e) => setFormData({ ...formData, category: e.target.value })}>
                <option value="">Select a category</option>
                <option value="OTA Partner">OTA Partner</option>
                <option value="Activation Partner">Activation Partner</option>
              </FormSelect>
              <FormField label="Location" name="pn-location" required placeholder="Your city or area" value={formData.location} onChange={(e) => setFormData({ ...formData, location: e.target.value })} error={errors.location} />
              <FormField label="WhatsApp Number" name="pn-whatsapp" type="tel" required placeholder="+91 XXXXXXXXXX" value={formData.whatsapp} onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })} error={errors.whatsapp} />
              <FormField label="About You" name="pn-message" placeholder="Tell us about yourself and what you're looking for..." value={formData.message} onChange={(e) => setFormData({ ...formData, message: e.target.value })} rows={3} />
              <button type="submit" className="btn-primary w-full">
                <Send size={16} />
                Submit Application
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
