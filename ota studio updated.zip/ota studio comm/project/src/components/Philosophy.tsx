import { ArrowRight } from 'lucide-react';
import { useInView } from '../hooks/useInView';

export default function Philosophy() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="philosophy"
      aria-labelledby="philosophy-heading"
      className="py-24 sm:py-36 bg-neutral-900 relative overflow-hidden"
    >
      {/* Subtle glow */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(255,208,0,0.04)_0%,_transparent_70%)]" />
      <div className="absolute inset-0 section-grid opacity-40" />

      <div className="section-max section-padding relative text-center">
        <div
          className={`opacity-0 ${isInView ? 'animate-fade-up' : ''}`}
        >
          <p className="text-xs font-bold text-accent/70 tracking-[0.3em] uppercase mb-8 sm:mb-10">
            Our Philosophy
          </p>
          <h2
            id="philosophy-heading"
            className="font-display font-extrabold text-4xl sm:text-6xl md:text-7xl lg:text-8xl tracking-tight leading-[1.05] text-white mb-3"
          >
            We Don't Sell{' '}
            <span className="relative inline-block">
              <span className="text-white/20">Advice.</span>
              <span
                className="absolute inset-0 text-white/20 line-through"
                aria-hidden="true"
              />
            </span>
          </h2>
          <h2 className="font-display font-extrabold text-4xl sm:text-6xl md:text-7xl lg:text-8xl tracking-tight leading-[1.05] text-accent mb-14 sm:mb-16">
            We Execute.
          </h2>
        </div>

        <div
          className={`max-w-2xl mx-auto opacity-0 ${isInView ? 'animate-fade-up delay-200' : ''}`}
        >
          <p className="text-base sm:text-xl text-white/50 leading-relaxed mb-10">
            The OTA Studio helps hospitality businesses get listed, optimized, distributed
            and managed across major OTAs. No presentations. No theory.{' '}
            <span className="text-white/80 font-medium">Real execution.</span>
          </p>

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <a
              href="https://wa.me/919270598602?text=Hi%2C%20I%27d%20like%20to%20book%20a%20call%20with%20The%20OTA%20Studio"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary group"
            >
              Book a Call
              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </a>
            <a href="#services" className="btn-secondary">
              View Services
            </a>
          </div>
        </div>

        {/* Divider line */}
        <div
          className={`mt-20 sm:mt-24 w-px h-16 bg-gradient-to-b from-transparent via-white/20 to-transparent mx-auto opacity-0 ${
            isInView ? 'animate-fade-in delay-400' : ''
          }`}
        />
      </div>
    </section>
  );
}
