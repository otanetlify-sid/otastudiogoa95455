import { useInView } from '../hooks/useInView';

const partners = [
  'Cloudbeds',
  'SiteMinder',
  'eZee',
  'Hotelogix',
  'RMS',
];

export default function PmsPartners() {
  const { ref, isInView } = useInView();

  const doubled = [...partners, ...partners];

  return (
    <section ref={ref} className="py-16 sm:py-20 bg-neutral-950 overflow-hidden">
      <div className="section-max section-padding mb-8 sm:mb-10">
        <div className={`text-center opacity-0 ${isInView ? 'animate-fade-up' : ''}`}>
          <span className="badge bg-accent/20 text-accent mb-3">Technology Partners</span>
          <h3 className="heading-md !text-xl sm:!text-2xl !text-neutral-100">
            Supported PMS & Channel Managers
          </h3>
        </div>
      </div>

      <div className={`relative opacity-0 ${isInView ? 'animate-fade-in delay-200' : ''}`}>
        <div className="absolute left-0 top-0 bottom-0 w-16 sm:w-24 bg-gradient-to-r from-neutral-950 to-transparent z-10 pointer-events-none" />
        <div className="absolute right-0 top-0 bottom-0 w-16 sm:w-24 bg-gradient-to-l from-neutral-950 to-transparent z-10 pointer-events-none" />

        <div className="overflow-hidden">
          <div className="flex gap-5 sm:gap-8 marquee-track">
            {doubled.map((name, i) => (
              <div
                key={i}
                className="flex items-center justify-center px-6 sm:px-8 py-4 sm:py-5 rounded-xl bg-neutral-900 border border-neutral-800 shadow-sm hover:shadow-md hover:border-accent/30 transition-all duration-300 shrink-0"
              >
                <span className="font-display font-bold text-sm sm:text-base text-neutral-300 whitespace-nowrap">
                  {name}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
