import { Search, ClipboardCheck, Settings, Zap, TrendingUp } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';

const stages = [
  { icon: Search, label: 'Discovery', desc: 'Find your OTA gaps' },
  { icon: ClipboardCheck, label: 'OTA Audit', desc: 'Analyze current setup' },
  { icon: Settings, label: 'Strategy Setup', desc: 'Configure platforms' },
  { icon: Zap, label: 'Optimization', desc: 'Fine-tune performance' },
  { icon: TrendingUp, label: 'Growth Tracking', desc: 'Monitor & scale' },
];

export default function PropertyJourney() {
  const ref = useRef<HTMLDivElement>(null);
  const [isInView, setIsInView] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setIsInView(true); obs.unobserve(el); } }, { threshold: 0.15 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  const currentStage = 2;

  return (
    <div ref={ref} className={`transition-all duration-700 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
      <div className="flex items-center gap-2 sm:gap-3">
        {stages.map((stage, i) => {
          const Icon = stage.icon;
          const isActive = i <= currentStage;
          const isCurrent = i === currentStage;
          return (
            <div key={i} className="flex items-center gap-2 sm:gap-3">
              <div className="flex items-center gap-1.5 sm:gap-2">
                <div
                  className={`w-6 h-6 sm:w-7 sm:h-7 rounded-md flex items-center justify-center transition-all duration-500 ${
                    isCurrent ? 'bg-accent/20 border border-accent/40' : isActive ? 'bg-accent/10' : 'bg-white/5 border border-white/5'
                  }`}
                >
                  <Icon size={11} className={isCurrent ? 'text-accent' : isActive ? 'text-accent/60' : 'text-white/20'} />
                </div>
                <div className="hidden lg:block">
                  <div className={`text-[9px] font-medium ${isCurrent ? 'text-accent' : isActive ? 'text-white/50' : 'text-white/20'}`}>
                    {stage.label}
                  </div>
                </div>
              </div>
              {i < stages.length - 1 && (
                <div className={`w-4 sm:w-6 lg:w-8 h-px ${i < currentStage ? 'bg-accent/30' : 'bg-white/8'}`} />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
