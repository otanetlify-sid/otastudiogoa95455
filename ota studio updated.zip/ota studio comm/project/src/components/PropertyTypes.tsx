import { Hotel, Trees, Hop as Home, Building2, BedDouble } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const propertyTypes = [
  { icon: Hotel, title: 'Hotels', description: 'Boutique to chain hotels across India' },
  { icon: Trees, title: 'Resorts', description: 'Leisure and destination resorts' },
  { icon: BedDouble, title: 'Hostels', description: 'Budget-friendly social accommodation' },
  { icon: Home, title: 'Villas', description: 'Private luxury vacation homes' },
  { icon: Building2, title: 'Homestays', description: 'Authentic local guest experiences' },
];

export default function PropertyTypes() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="property-types"
      aria-labelledby="property-types-heading"
      className="py-20 sm:py-28 bg-neutral-900 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-30" />

      <div className="section-max section-padding relative">
        <div className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Property Types</span>
          <h2 id="property-types-heading" className="heading-lg text-white mb-4">
            We Support Hotels, Hostels, Villas, Homestays & Resorts
          </h2>
          <p className="body-lg">
            OTA services for every type of hospitality business across India.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-5">
          {propertyTypes.map((type, i) => (
            <div
              key={i}
              className={`group p-5 sm:p-6 rounded-2xl border border-white/8 bg-white/4 hover:bg-white/10 hover:border-accent/30 transition-all duration-300 text-center ${isInView ? `animate-fade-up delay-${Math.min(i * 80, 400)}` : 'opacity-0'}`}
            >
              <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-accent/20 transition-colors">
                <type.icon size={22} className="text-accent" aria-hidden="true" />
              </div>
              <h3 className="font-display font-bold text-sm sm:text-base text-white mb-1">{type.title}</h3>
              <p className="text-xs text-white/40">{type.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
