import { BookOpen, ArrowUpRight } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const resources = [
  {
    title: 'OTA Onboarding Guide',
    description: 'Step-by-step guide to getting your property listed on major OTAs.',
    tag: 'Guide',
  },
  {
    title: 'Booking.com Setup Guide',
    description: 'How to create, verify, and optimize your Booking.com listing.',
    tag: 'Guide',
  },
  {
    title: 'Airbnb Setup Guide',
    description: 'Complete walkthrough for launching your Airbnb listing.',
    tag: 'Guide',
  },
  {
    title: 'Hotel Distribution Guide',
    description: 'Understanding channel managers and multi-OTA distribution.',
    tag: 'Guide',
  },
  {
    title: 'Revenue Optimization Guide',
    description: 'Pricing strategies, occupancy optimization, and revenue growth.',
    tag: 'Guide',
  },
  {
    title: 'Hospitality Growth Tips',
    description: 'Weekly insights on growing your hospitality business.',
    tag: 'Tips',
  },
];

export default function Resources() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      className="py-20 sm:py-28 bg-neutral-900 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-30" />

      <div className="section-max section-padding relative">
        <div
          className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 opacity-0 ${
            isInView ? 'animate-fade-up' : ''
          }`}
        >
          <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">
            Resource Center
          </span>
          <h2 className="heading-lg text-white mb-4">
            Free Hospitality <span className="text-accent">Guides</span>
          </h2>
          <p className="body-lg">
            Practical resources to help you understand and improve your OTA
            performance.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
          {resources.map((res, i) => (
            <div
              key={i}
              className={`group p-6 sm:p-7 rounded-2xl border border-white/8 bg-white/4 hover:bg-white/7 hover:border-accent/30 transition-all duration-300 opacity-0 ${
                isInView
                  ? `animate-fade-up delay-${Math.min(i * 80, 600)}`
                  : ''
              }`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center group-hover:bg-accent/20 transition-colors">
                  <BookOpen size={18} className="text-accent" />
                </div>
                <span className="text-xs font-semibold text-white/40 tracking-wider uppercase">
                  {res.tag}
                </span>
              </div>
              <h3 className="font-display font-bold text-base sm:text-lg text-white mb-2 group-hover:text-accent transition-colors">
                {res.title}
              </h3>
              <p className="text-sm text-white/45 leading-relaxed mb-4">
                {res.description}
              </p>
              <a
                href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20request%20the%20free%20guide%20on%20"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-sm font-semibold text-accent hover:text-accent-300 transition-colors"
              >
                Request Guide
                <ArrowUpRight size={14} />
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
