import type { ReactNode } from 'react';
import useSEO from '../hooks/useSEO';

interface SEOHeadProps {
  title: string;
  description: string;
  canonical: string;
  schemaType?: 'service' | 'legal' | 'guide' | 'event' | 'community' | 'network' | 'page';
  breadcrumbs?: { name: string; href?: string }[];
  children: ReactNode;
}

export default function SEOHead({ children, title, description, canonical, schemaType, breadcrumbs }: SEOHeadProps) {
  useSEO({ title, description, canonical, schemaType, breadcrumbs });
  return <>{children}</>;
}
