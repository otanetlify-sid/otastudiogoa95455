import { useEffect, useRef } from 'react';

const ZONE_COLORS = [
  { r: 255, g: 208, b: 0 },   // accent yellow
  { r: 255, g: 255, b: 255 }, // white
];

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  baseOpacity: number;
  zone: number;
}

export default function ScrollNetworkOverlay() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particlesRef = useRef<Particle[]>([]);
  const scrollRef = useRef(0);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const onScroll = () => {
      const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
      scrollRef.current = maxScroll > 0 ? window.scrollY / maxScroll : 0;
    };
    window.addEventListener('scroll', onScroll, { passive: true });

    // Create sparse particles
    if (particlesRef.current.length === 0) {
      for (let i = 0; i < 12; i++) {
        particlesRef.current.push({
          x: Math.random() * window.innerWidth,
          y: Math.random() * window.innerHeight,
          vx: (Math.random() - 0.5) * 0.1,
          vy: (Math.random() - 0.5) * 0.1,
          r: Math.random() * 1.2 + 0.4,
          baseOpacity: Math.random() * 0.15 + 0.05,
          zone: Math.floor(Math.random() * 2),
        });
      }
    }

    const draw = () => {
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      const scroll = scrollRef.current;
      const particles = particlesRef.current;

      // Only render when scrolled past top
      if (scroll < 0.02) {
        rafRef.current = requestAnimationFrame(draw);
        return;
      }

      // Progressive activation based on scroll
      const activeRatio = Math.min(scroll * 3, 1);

      for (const p of particles) {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0 || p.x > w) p.vx *= -1;
        if (p.y < 0 || p.y > h) p.vy *= -1;

        const c = ZONE_COLORS[p.zone];
        const opacity = p.baseOpacity * activeRatio;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${c.r}, ${c.g}, ${c.b}, ${opacity})`;
        ctx.fill();
      }

      // Connect nearby particles with white lines
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 150) {
            const alpha = (1 - dist / 150) * 0.04 * activeRatio;
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.strokeStyle = `rgba(255, 255, 255, ${alpha})`;
            ctx.lineWidth = 0.3;
            ctx.stroke();

            // Traveling yellow pulse signal
            const pulsePos = (Date.now() / 3000 + i * 0.3 + j * 0.17) % 1;
            const pulseX = particles[i].x + (particles[j].x - particles[i].x) * pulsePos;
            const pulseY = particles[i].y + (particles[j].y - particles[i].y) * pulsePos;
            ctx.beginPath();
            ctx.arc(pulseX, pulseY, 1.2, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(255, 208, 0, ${alpha * 4})`;
            ctx.fill();
          }
        }
      }

      rafRef.current = requestAnimationFrame(draw);
    };

    rafRef.current = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener('resize', resize);
      window.removeEventListener('scroll', onScroll);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full pointer-events-none z-0"
      style={{ opacity: 0.7 }}
    />
  );
}
