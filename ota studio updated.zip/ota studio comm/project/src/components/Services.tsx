import { Rocket, Settings, Network, TrendingUp, ChartBar as BarChart3, ShieldCheck } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const services = [
  {
    icon: Rocket,
    title: 'OTA Onboarding',
    description: 'Complete OTA setup on Booking.com, Airbnb, Agoda, Expedia, MakeMyTrip, Goibibo, Hostelworld, and Trip.com. We handle account creation, verification, and optimization.',
    href: '/ota-onboarding-goa',
  },
  {
    icon: Settings,
    title: 'OTA Management',
    description: 'Ongoing OTA listing management including content optimization, pricing strategies, review responses, and performance tracking to maximize bookings.',
    href: '/ota-management-goa',
  },
  {
    icon: Network,
    title: 'Distribution Management',
    description: 'Multi-platform distribution and channel management. Sync inventory across all OTAs, eliminate overbookings, and maintain rate parity.',
    href: '/hotel-distribution-goa',
  },
  {
    icon: TrendingUp,
    title: 'Hospitality Growth Solutions',
    description: 'Complete growth strategies for hotels, hostels, villas, homestays, and resorts. Visibility, revenue optimization, and sustainable growth.',
    href: '/hotel-marketing-goa',
  },
  {
    icon: BarChart3,
    title: 'Revenue Optimization',
    description: 'Data-driven pricing strategies, demand analysis, and revenue management to maximize your property\'s earning potential.',
    href: '#contact',
  },
  {
    icon: ShieldCheck,
    title: 'Channel Management',
    description: 'Professional channel manager setup and integration. Real-time inventory updates across all connected OTAs.',
    href: '#contact',
  },
];

export default function Services() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="services"
      aria-labelledby="services-heading"
      className="py-20 sm:py-28 bg-neutral-900 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-30" />

      <div className="section-max section-padding relative">
        <div className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Our Services</span>
          <h2 id="services-heading" className="heading-lg text-white mb-4">
            OTA Onboarding, OTA Management & Distribution
          </h2>
          <p className="body-lg">
            Complete OTA services to improve visibility, drive bookings, and grow revenue
            for hospitality businesses.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
          {services.map((service, i) => (
            <a
              key={i}
              href={service.href}
              className={`group p-6 sm:p-7 rounded-2xl border border-white/8 bg-white/4 hover:bg-white/10 hover:border-accent/30 transition-all duration-300 ${isInView ? `animate-fade-up delay-${Math.min(i * 100, 500)}` : 'opacity-0'}`}
            >
              <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-5 group-hover:bg-accent/20 transition-colors">
                <service.icon size={22} className="text-accent" aria-hidden="true" />
              </div>
              <h3 className="font-display font-bold text-lg text-white mb-2">{service.title}</h3>
              <p className="text-sm text-white/50 leading-relaxed">{service.description}</p>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
