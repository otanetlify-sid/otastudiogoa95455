import { useEffect, useRef, useState } from 'react';
import { useInView } from '../hooks/useInView';

const stats = [
  { end: 100, suffix: '+', label: 'Properties Onboarded', desc: 'Across Goa and India' },
  { end: 8, suffix: '+', label: 'OTA Channels Managed', desc: 'Per property on average' },
  { end: 340, suffix: '%', label: 'Avg Visibility Uplift', desc: 'OTA search ranking growth' },
  { end: 3, suffix: 'x', label: 'Avg Booking Growth', desc: 'In first 90 days' },
];

function AnimatedCounter({ end, suffix, active }: { end: number; suffix: string; active: boolean }) {
  const [count, setCount] = useState(0);
  const started = useRef(false);

  useEffect(() => {
    if (!active || started.current) return;
    started.current = true;
    const duration = 1800;
    const steps = 60;
    const increment = end / steps;
    let current = 0;
    const interval = setInterval(() => {
      current += increment;
      if (current >= end) {
        setCount(end);
        clearInterval(interval);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);
    return () => clearInterval(interval);
  }, [active, end]);

  return (
    <span>
      {count}
      <span className="text-accent">{suffix}</span>
    </span>
  );
}

export default function Stats() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="stats"
      aria-labelledby="stats-heading"
      className="py-20 sm:py-28 bg-neutral-950 relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(255,208,0,0.05)_0%,_transparent_60%)]" />
      <div className="absolute inset-0 section-grid opacity-50" />

      <div className="section-max section-padding relative">
        <div
          className={`text-center mb-14 sm:mb-16 opacity-0 ${isInView ? 'animate-fade-up' : ''}`}
        >
          <h2 id="stats-heading" className="heading-lg text-white">
            Real Results. <span className="text-accent">Real Numbers.</span>
          </h2>
          <p className="body-lg mt-3">
            Our track record across Goa's hospitality market.
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
          {stats.map((stat, i) => (
            <div
              key={i}
              className={`group text-center p-6 sm:p-8 rounded-2xl bg-white/4 border border-white/8 hover:bg-white/6 hover:border-accent/20 transition-all duration-300 opacity-0 ${
                isInView ? `animate-fade-up delay-${Math.min(i * 100, 400)}` : ''
              }`}
            >
              <div className="font-display font-extrabold text-3xl sm:text-4xl lg:text-5xl text-white mb-2 leading-none tabular-nums">
                <AnimatedCounter end={stat.end} suffix={stat.suffix} active={isInView} />
              </div>
              <p className="font-display font-bold text-sm sm:text-base text-white/80 mb-1">
                {stat.label}
              </p>
              <p className="text-xs text-white/35">{stat.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
