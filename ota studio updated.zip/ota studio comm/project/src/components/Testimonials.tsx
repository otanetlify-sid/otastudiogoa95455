import { Star, Quote, Building2, BedDouble, Home } from 'lucide-react';
import { useInView } from '../hooks/useInView';

type PropertyType = 'Hotel' | 'Hostel' | 'Guesthouse';

const propertyIcons: Record<PropertyType, typeof Building2> = {
  Hotel: Building2,
  Hostel: BedDouble,
  Guesthouse: Home,
};

interface Testimonial {
  text: string;
  name: string;
  property: string;
  propertyType: PropertyType;
  location: string;
}

const testimonials: Testimonial[] = [
  {
    text: 'OTA Studio helped us get listed on Booking.com within days. Bookings improved immediately.',
    name: 'Rajesh Naik',
    property: 'Seaside Hotel',
    propertyType: 'Hotel',
    location: 'North Goa',
  },
  {
    text: 'Our hostel was not getting visibility. After optimization, occupancy increased significantly.',
    name: 'Amit Sharma',
    property: 'Backpacker Hub',
    propertyType: 'Hostel',
    location: 'Anjuna',
  },
  {
    text: 'Very smooth onboarding process. Everything was handled professionally.',
    name: "Sandra D'Souza",
    property: 'Palm View Guesthouse',
    propertyType: 'Guesthouse',
    location: 'Candolim',
  },
  {
    text: 'We were struggling with OTA setup. They fixed everything from A to Z.',
    name: 'Vikram Desai',
    property: 'Sunset Inn',
    propertyType: 'Hotel',
    location: 'Baga',
  },
  {
    text: 'Highly recommended for Goa hotel owners. Fast and reliable service.',
    name: 'Pratik Kavlekar',
    property: 'Beachside Stay',
    propertyType: 'Hotel',
    location: 'Calangute',
  },
  {
    text: 'Our Airbnb listing finally started getting consistent bookings.',
    name: 'Nisha Ferreira',
    property: 'Cozy Nest Hostel',
    propertyType: 'Hostel',
    location: 'Vagator',
  },
  {
    text: 'Great support in pricing and OTA optimization strategy.',
    name: 'Deepak Phadte',
    property: 'Heritage Guesthouse',
    propertyType: 'Guesthouse',
    location: 'Margao',
  },
  {
    text: 'Professional team that understands hospitality business in Goa.',
    name: 'Anita Rane',
    property: 'Royal Palms Hotel',
    propertyType: 'Hotel',
    location: 'Panaji',
  },
];

function TestimonialCard({ testimonial }: { testimonial: Testimonial }) {
  const Icon = propertyIcons[testimonial.propertyType];

  return (
    <div className="group w-[320px] sm:w-[360px] shrink-0 rounded-2xl p-6 sm:p-7 bg-white/5 backdrop-blur-xl border border-white/10 hover:bg-white/8 hover:border-accent/20 hover:shadow-[0_0_40px_rgba(255,208,0,0.06)] transition-all duration-500">
      <Quote size={18} className="text-accent/30 mb-4" aria-hidden="true" />
      {/* Stars */}
      <div className="flex gap-0.5 mb-4">
        {[...Array(5)].map((_, i) => (
          <Star key={i} size={12} className="text-accent fill-accent" aria-hidden="true" />
        ))}
      </div>
      <p className="text-sm sm:text-base text-white/65 leading-relaxed mb-6 min-h-[64px]">
        "{testimonial.text}"
      </p>
      <div className="flex items-center gap-3 pt-4 border-t border-white/8">
        <div className="w-9 h-9 rounded-full bg-accent/15 border border-accent/20 flex items-center justify-center shrink-0">
          <span className="font-display font-bold text-sm text-accent">
            {testimonial.name.charAt(0)}
          </span>
        </div>
        <div className="min-w-0">
          <div className="font-display font-semibold text-sm text-white truncate">
            {testimonial.name}
          </div>
          <div className="flex items-center gap-1.5 text-xs text-white/35">
            <Icon size={11} className="shrink-0" aria-hidden="true" />
            <span className="truncate">{testimonial.property}</span>
            <span className="text-white/20">·</span>
            <span>{testimonial.location}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Testimonials() {
  const { ref, isInView } = useInView();
  const doubled = [...testimonials, ...testimonials];

  return (
    <section
      ref={ref}
      id="reviews"
      aria-labelledby="reviews-heading"
      className="py-20 sm:py-28 bg-neutral-900 relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(255,208,0,0.04)_0%,_transparent_70%)]" />
      <div className="absolute top-0 -left-40 w-80 h-80 bg-accent/4 rounded-full blur-3xl" />
      <div className="absolute bottom-0 -right-40 w-80 h-80 bg-accent/4 rounded-full blur-3xl" />

      <div className="relative">
        {/* Header */}
        <div
          className={`section-max section-padding text-center max-w-2xl mx-auto mb-14 sm:mb-16 opacity-0 ${
            isInView ? 'animate-fade-up' : ''
          }`}
        >
          <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">
            <Star size={11} className="fill-accent" aria-hidden="true" />
            Reviews
          </span>
          <h2 id="reviews-heading" className="heading-lg text-white mb-4">
            Trusted by Hospitality Businesses{' '}
            <span className="text-accent">Across Goa</span>
          </h2>
          <p className="body-lg">
            100+ OTA onboarding &amp; optimization projects delivered for
            hotels, hostels, villas and resorts in Goa.
          </p>
        </div>

        {/* Carousel */}
        <div
          className={`relative opacity-0 ${isInView ? 'animate-fade-in delay-200' : ''}`}
        >
          <div className="absolute left-0 top-0 bottom-0 w-20 sm:w-32 bg-gradient-to-r from-neutral-900 to-transparent z-10 pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-20 sm:w-32 bg-gradient-to-l from-neutral-900 to-transparent z-10 pointer-events-none" />

          <div className="overflow-hidden">
            <div className="flex gap-4 sm:gap-5 carousel-track">
              {doubled.map((t, i) => (
                <TestimonialCard key={i} testimonial={t} />
              ))}
            </div>
          </div>
        </div>

        <div className="sr-only">
          hotel OTA onboarding reviews Goa, OTA optimization service feedback,
          Booking.com setup service Goa reviews
        </div>
      </div>
    </section>
  );
}
