import { useState } from 'react';
import { Activity, Calculator, ChevronRight, ArrowRight } from 'lucide-react';
import { useInView } from '../hooks/useInView';

// OTA Health Score
function HealthScoreTool() {
  const [step, setStep] = useState<'quiz' | 'lead' | 'result'>('quiz');
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');

  const questions = [
    { q: 'Is your property listed on Booking.com?', points: [0, 15] },
    { q: 'Is your property listed on Airbnb?', points: [0, 15] },
    { q: 'Do you have a channel manager connected?', points: [0, 15] },
    { q: 'Are your rates synced across all platforms?', points: [0, 10] },
    { q: 'Do you update your listing photos regularly?', points: [0, 10] },
    { q: 'Do you monitor competitor pricing?', points: [0, 10] },
    { q: 'Is your property on the first page of OTA search results?', points: [0, 15] },
    { q: 'Do you respond to guest reviews within 24 hours?', points: [0, 10] },
  ];

  const calculateScore = () => {
    let score = 0;
    questions.forEach((q, i) => {
      score += answers[i] === 1 ? q.points[1] : q.points[0];
    });
    return score;
  };

  const handleAnswer = (idx: number, val: number) => {
    setAnswers((prev) => ({ ...prev, [idx]: val }));
  };

  const allAnswered = questions.every((_, i) => answers[i] !== undefined);

  const score = calculateScore();
  let grade = 'F';
  let color = 'text-red-400';
  let message = 'Critical attention needed';
  if (score >= 80) {
    grade = 'A';
    color = 'text-green-400';
    message = 'Excellent OTA health';
  } else if (score >= 60) {
    grade = 'B';
    color = 'text-accent';
    message = 'Good, but room to improve';
  } else if (score >= 40) {
    grade = 'C';
    color = 'text-yellow-400';
    message = 'Needs improvement';
  } else if (score >= 20) {
    grade = 'D';
    color = 'text-orange-400';
    message = 'Significant gaps detected';
  }

  if (step === 'quiz') {
    return (
      <div className="bg-neutral-900 rounded-2xl border border-white/8 p-6 sm:p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-accent/15 flex items-center justify-center">
            <Activity size={20} className="text-accent" />
          </div>
          <div>
            <h3 className="font-display font-bold text-lg text-white">
              OTA Health Score
            </h3>
            <p className="text-xs text-white/40">
              8 quick questions to assess your OTA readiness
            </p>
          </div>
        </div>

        <div className="space-y-4 max-h-[320px] overflow-y-auto pr-2">
          {questions.map((q, i) => (
            <div key={i} className="p-4 rounded-xl bg-white/4 border border-white/8">
              <p className="text-sm text-white/80 mb-3">{q.q}</p>
              <div className="flex gap-2">
                <button
                  onClick={() => handleAnswer(i, 1)}
                  className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${
                    answers[i] === 1
                      ? 'bg-accent text-neutral-950'
                      : 'bg-white/8 text-white/60 hover:bg-white/12'
                  }`}
                >
                  Yes
                </button>
                <button
                  onClick={() => handleAnswer(i, 0)}
                  className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${
                    answers[i] === 0
                      ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                      : 'bg-white/8 text-white/60 hover:bg-white/12'
                  }`}
                >
                  No
                </button>
              </div>
            </div>
          ))}
        </div>

        <button
          onClick={() => setStep('lead')}
          disabled={!allAnswered}
          className={`w-full mt-6 py-3 rounded-xl font-display font-bold text-sm transition-all ${
            allAnswered
              ? 'bg-accent text-neutral-950 hover:bg-accent-300'
              : 'bg-white/8 text-white/30 cursor-not-allowed'
          }`}
        >
          Calculate My Score
          <ChevronRight size={16} className="inline ml-1" />
        </button>
      </div>
    );
  }

  if (step === 'lead') {
    return (
      <div className="bg-neutral-900 rounded-2xl border border-white/8 p-6 sm:p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-accent/15 flex items-center justify-center">
            <Activity size={20} className="text-accent" />
          </div>
          <div>
            <h3 className="font-display font-bold text-lg text-white">
              OTA Health Score
            </h3>
          </div>
        </div>

        <div className="text-center mb-6">
          <div className="text-5xl font-display font-extrabold text-accent mb-2">
            {score}
            <span className="text-lg text-white/40">/100</span>
          </div>
          <div className={`text-xl font-display font-bold ${color}`}>{grade}</div>
          <p className="text-sm text-white/50 mt-1">{message}</p>
        </div>

        <div className="space-y-3 mb-6">
          <div className="space-y-1.5">
            <label htmlFor="hs-name" className="block text-sm font-semibold text-white">
              Your Name <span className="text-accent">*</span>
            </label>
            <input
              id="hs-name"
              type="text"
              placeholder="Your full name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-white border border-neutral-200 text-sm text-neutral-950 placeholder:text-[#666666] focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent/30 transition-colors"
            />
          </div>
          <div className="space-y-1.5">
            <label htmlFor="hs-phone" className="block text-sm font-semibold text-white">
              Phone Number <span className="text-accent">*</span>
            </label>
            <input
              id="hs-phone"
              type="tel"
              placeholder="+91 XXXXXXXXXX"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-white border border-neutral-200 text-sm text-neutral-950 placeholder:text-[#666666] focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent/30 transition-colors"
            />
          </div>
        </div>

        <button
          onClick={() => setStep('result')}
          disabled={!name || !phone}
          className={`w-full py-3 rounded-xl font-display font-bold text-sm transition-all ${
            name && phone
              ? 'bg-accent text-neutral-950 hover:bg-accent-300'
              : 'bg-white/8 text-white/30 cursor-not-allowed'
          }`}
        >
          Get Full Report
        </button>
      </div>
    );
  }

  return (
    <div className="bg-neutral-900 rounded-2xl border border-white/8 p-6 sm:p-8 text-center">
      <div className="w-16 h-16 rounded-full bg-accent/15 flex items-center justify-center mx-auto mb-4">
        <Activity size={28} className="text-accent" />
      </div>
      <h3 className="font-display font-bold text-xl text-white mb-2">
        Report Sent!
      </h3>
      <p className="text-sm text-white/50 mb-6">
        We will reach out to you shortly with a detailed OTA health analysis and
        recommendations.
      </p>
      <a
        href="https://wa.me/919270598602"
        target="_blank"
        rel="noopener noreferrer"
        className="btn-primary text-sm"
      >
        WhatsApp Us Now
      </a>
    </div>
  );
}

// Revenue Calculator
function RevenueCalculator() {
  const [rooms, setRooms] = useState(10);
  const [adr, setAdr] = useState(3000);
  const [occupancy, setOccupancy] = useState(40);

  const currentRevenue = rooms * adr * (occupancy / 100) * 30;
  const optimizedRevenue = rooms * adr * (Math.min(occupancy + 25, 95) / 100) * 30;
  const potentialIncrease = optimizedRevenue - currentRevenue;

  return (
    <div className="bg-neutral-900 rounded-2xl border border-white/8 p-6 sm:p-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-lg bg-accent/15 flex items-center justify-center">
          <Calculator size={20} className="text-accent" />
        </div>
        <div>
          <h3 className="font-display font-bold text-lg text-white">
            Revenue Impact Calculator
          </h3>
          <p className="text-xs text-white/40">
            See what better OTA management could mean for you
          </p>
        </div>
      </div>

      <div className="space-y-5">
        <div>
          <div className="flex justify-between text-sm mb-2">
            <span className="text-white/50">Rooms</span>
            <span className="font-display font-bold text-white">{rooms}</span>
          </div>
          <input
            type="range"
            min="1"
            max="200"
            value={rooms}
            onChange={(e) => setRooms(Number(e.target.value))}
            className="w-full h-2 bg-white/8 rounded-lg appearance-none cursor-pointer accent-accent"
          />
        </div>

        <div>
          <div className="flex justify-between text-sm mb-2">
            <span className="text-white/50">ADR (Rs)</span>
            <span className="font-display font-bold text-white">
              {adr.toLocaleString()}
            </span>
          </div>
          <input
            type="range"
            min="500"
            max="50000"
            step="100"
            value={adr}
            onChange={(e) => setAdr(Number(e.target.value))}
            className="w-full h-2 bg-white/8 rounded-lg appearance-none cursor-pointer accent-accent"
          />
        </div>

        <div>
          <div className="flex justify-between text-sm mb-2">
            <span className="text-white/50">Current Occupancy</span>
            <span className="font-display font-bold text-white">{occupancy}%</span>
          </div>
          <input
            type="range"
            min="5"
            max="95"
            value={occupancy}
            onChange={(e) => setOccupancy(Number(e.target.value))}
            className="w-full h-2 bg-white/8 rounded-lg appearance-none cursor-pointer accent-accent"
          />
        </div>
      </div>

      <div className="mt-6 pt-5 border-t border-white/8 space-y-3">
        <div className="flex justify-between items-center">
          <span className="text-sm text-white/40">Current Monthly Revenue</span>
          <span className="font-display font-bold text-white/80">
            Rs {Math.round(currentRevenue).toLocaleString()}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-white/40">Optimized Monthly Revenue</span>
          <span className="font-display font-bold text-accent">
            Rs {Math.round(optimizedRevenue).toLocaleString()}
          </span>
        </div>
        <div className="flex justify-between items-center pt-2 border-t border-white/8">
          <span className="text-sm text-white/50">Potential Monthly Increase</span>
          <span className="font-display font-extrabold text-green-400">
            +Rs {Math.round(potentialIncrease).toLocaleString()}
          </span>
        </div>
      </div>

      <a
        href="https://wa.me/919270598602?text=Hi%2C%20I%20used%20your%20revenue%20calculator%20and%20want%20to%20discuss%20results"
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center justify-center gap-2 w-full mt-6 py-3 rounded-xl bg-accent text-neutral-950 font-display font-bold text-sm hover:bg-accent-300 transition-all"
      >
        Discuss My Numbers
        <ArrowRight size={16} />
      </a>
    </div>
  );
}

export default function Tools() {
  const { ref, isInView } = useInView();

  return (
    <section ref={ref} id="tools" className="py-20 sm:py-28 bg-neutral-950 relative overflow-hidden">
      <div className="absolute inset-0 section-grid opacity-40" />

      <div className="section-max section-padding relative">
        <div
          className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 opacity-0 ${
            isInView ? 'animate-fade-up' : ''
          }`}
        >
          <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">
            Free Tools
          </span>
          <h2 className="heading-lg text-white mb-4">
            Assess Your <span className="text-accent">OTA Readiness</span>
          </h2>
          <p className="body-lg">
            Use our free tools to understand your current OTA performance and
            revenue potential.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6 sm:gap-8">
          <div
            className={`opacity-0 ${isInView ? 'animate-fade-up delay-100' : ''}`}
          >
            <HealthScoreTool />
          </div>
          <div
            className={`opacity-0 ${isInView ? 'animate-fade-up delay-200' : ''}`}
          >
            <RevenueCalculator />
          </div>
        </div>
      </div>
    </section>
  );
}
