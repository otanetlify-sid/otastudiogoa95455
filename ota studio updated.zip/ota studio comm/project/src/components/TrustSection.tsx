import { useInView } from '../hooks/useInView';
import { Building2, Globe, Users, MapPin, Shield, Award } from 'lucide-react';

export default function TrustSection() {
  const { ref, isInView } = useInView(0.1);

  const trustItems = [
    {
      id: 1,
      icon: Building2,
      label: '8+ OTA Platforms',
      description: 'Managed across Booking.com, Airbnb, Agoda, Expedia, MakeMyTrip, Goibibo, Hostelworld and more',
      delay: 0,
    },
    {
      id: 2,
      icon: Globe,
      label: '30+ Properties',
      description: 'Hotels, resorts, villas, homestays, cafes and restaurants across Goa',
      delay: 100,
    },
    {
      id: 3,
      icon: Users,
      label: '6 Hospitality Categories',
      description: 'Hotels, hostels, villas, cafes, restaurants, beach clubs',
      delay: 200,
    },
    {
      id: 4,
      icon: MapPin,
      label: 'Goa Focused Network',
      description: 'Deep expertise in Goa tourism, regulations, and hospitality ecosystem',
      delay: 300,
    },
  ];

  const credibilityBadges = [
    { icon: Shield, label: 'Verified OTA Management' },
    { icon: Award, label: 'Goa Hospitality Expert' },
  ];

  return (
    <section ref={ref} className="relative bg-neutral-950 py-24 px-4 sm:px-6 lg:px-8">
      <style>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .trust-card {
          animation: fadeInUp 0.6s ease-out forwards;
          opacity: 0;
        }

        .trust-card.in-view {
          animation: fadeInUp 0.6s ease-out forwards;
        }

        .credibility-badge {
          animation: fadeInUp 0.6s ease-out forwards;
          opacity: 0;
          animation-delay: 400ms;
        }

        .credibility-badge.in-view {
          animation: fadeInUp 0.6s ease-out forwards;
          animation-delay: 400ms;
        }
      `}</style>

      <div className="max-w-7xl mx-auto">
        {/* Section Heading */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Why Properties Trust{' '}
            <span className="text-accent">OTA Studio</span>
          </h2>
          <p className="text-white/60 text-lg max-w-2xl mx-auto">
            Managing hospitality across Goa's most trusted platforms
          </p>
        </div>

        {/* Trust Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {trustItems.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.id}
                className={`trust-card ${isInView ? 'in-view' : ''}`}
                style={{ animationDelay: isInView ? `${item.delay}ms` : '0ms' }}
              >
                <div className="group relative rounded-2xl border border-white/10 bg-white/[0.02] backdrop-blur-sm hover:border-accent/25 transition-all duration-300 p-8 h-full flex flex-col">
                  {/* Icon Circle */}
                  <div className="mb-6 inline-flex">
                    <div className="w-16 h-16 rounded-full bg-accent/10 border border-accent/20 flex items-center justify-center group-hover:border-accent/50 transition-all duration-300">
                      <Icon className="w-8 h-8 text-accent" strokeWidth={1.5} />
                    </div>
                  </div>

                  {/* Content */}
                  <h3 className="text-xl font-semibold text-white mb-3">
                    {item.label}
                  </h3>
                  <p className="text-white/60 text-sm leading-relaxed flex-grow">
                    {item.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Credibility Badges Row */}
        <div className="flex flex-col sm:flex-row gap-6 justify-center">
          {credibilityBadges.map((badge, index) => {
            const Icon = badge.icon;
            return (
              <div
                key={index}
                className={`credibility-badge ${isInView ? 'in-view' : ''}`}
              >
                <div className="inline-flex items-center gap-3 px-6 py-4 rounded-2xl border border-white/10 bg-white/[0.02] backdrop-blur-sm hover:border-accent/25 transition-all duration-300">
                  <Icon className="w-5 h-5 text-accent flex-shrink-0" strokeWidth={1.5} />
                  <span className="text-sm font-medium text-white whitespace-nowrap">
                    {badge.label}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
