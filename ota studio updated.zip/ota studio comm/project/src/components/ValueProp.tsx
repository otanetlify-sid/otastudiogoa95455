import { useInView } from '../hooks/useInView';
import { ArrowRight } from 'lucide-react';

export default function ValueProp() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="value-prop"
      aria-labelledby="value-prop-heading"
      className="py-20 sm:py-28 bg-neutral-900 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-40" />

      <div className="section-max section-padding relative">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          <div className={`opacity-0 ${isInView ? 'animate-fade-up' : ''}`}>
            <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">
              What We Do
            </span>
            <h2 id="value-prop-heading" className="heading-lg text-white mb-5">
              We Don't Just Advise.
              <br />
              <span className="text-accent">We Execute.</span>
            </h2>
            <p className="body-lg mb-4">
              Many service providers tell you what should be done. We actually do the work.
            </p>
            <p className="text-sm text-white/45 leading-relaxed mb-8">
              From OTA onboarding and listing setup to channel management and distribution,
              we help properties launch faster and perform better across every booking platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <a
                href="https://wa.me/919270598602?text=Hi%2C%20I%27d%20like%20to%20book%20a%20call%20with%20The%20OTA%20Studio"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary group"
              >
                Book a Call
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </a>
              <a href="#services" className="btn-secondary">
                View Services
              </a>
            </div>
          </div>

          <div className={`opacity-0 ${isInView ? 'animate-fade-up delay-200' : ''}`}>
            <div className="relative">
              <div className="absolute -inset-4 bg-accent/6 rounded-3xl blur-2xl" />
              <div className="relative bg-neutral-950 rounded-2xl p-6 sm:p-8 border border-white/8">
                {/* Terminal dots */}
                <div className="flex items-center gap-2 mb-6">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-500/60" />
                  <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/60" />
                  <div className="w-2.5 h-2.5 rounded-full bg-green-500/60" />
                  <span className="text-xs text-white/20 ml-3 font-mono">ota-studio.process</span>
                </div>

                <div className="space-y-3">
                  {[
                    { num: '1', title: 'Property Assessment', sub: 'Full OTA health check' },
                    { num: '2', title: 'OTA Setup & Listing Build', sub: 'Complete profile creation' },
                    { num: '3', title: 'Distribution & Channel Sync', sub: 'Multi-platform inventory' },
                    { num: '4', title: 'Optimization & Growth', sub: 'Revenue maximization' },
                  ].map((item, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-3 p-3.5 rounded-xl bg-white/4 border border-white/8 hover:border-accent/20 transition-colors"
                    >
                      <div className="w-9 h-9 rounded-lg bg-accent/12 border border-accent/20 flex items-center justify-center shrink-0">
                        <span className="font-display font-bold text-accent text-sm">{item.num}</span>
                      </div>
                      <div>
                        <div className="font-display font-semibold text-sm text-white">
                          {item.title}
                        </div>
                        <div className="text-xs text-white/35">{item.sub}</div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-5 pt-4 border-t border-white/8 flex items-center justify-between">
                  <span className="text-xs text-white/30">
                    Go live in as little as{' '}
                    <span className="text-accent font-bold">7 days</span>
                  </span>
                  <div className="w-7 h-7 rounded-full bg-accent/20 border border-accent/30 flex items-center justify-center">
                    <ArrowRight size={13} className="text-accent" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
