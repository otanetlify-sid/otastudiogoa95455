import {
  Building2,
  BedDouble,
  Home,
  Trees,
  KeyRound,
  Hotel,
  Coffee,
  UtensilsCrossed,
  Beer,
  Lightbulb,
} from 'lucide-react';
import { useInView } from '../hooks/useInView';

const propertyTypes = [
  { icon: Hotel, title: 'Hotels', description: 'Boutique to chain properties in Goa' },
  { icon: Trees, title: 'Resorts', description: 'Beach and hillside leisure resorts' },
  { icon: BedDouble, title: 'Hostels', description: 'Budget-friendly social accommodation' },
  { icon: Home, title: 'Villas', description: 'Private luxury vacation homes' },
  { icon: Building2, title: 'Airbnb Hosts', description: 'Short-term rental properties' },
  { icon: Hotel, title: 'Boutique Hotels', description: 'Design-led intimate properties' },
  { icon: KeyRound, title: 'Homestays', description: 'Authentic local guest experiences' },
  { icon: Coffee, title: 'Cafes', description: 'Specialty and beachside cafes' },
  { icon: UtensilsCrossed, title: 'Restaurants', description: 'Dining establishments in Goa' },
  { icon: Beer, title: 'Bars', description: 'Beachfront and nightlife bars' },
  { icon: Building2, title: 'Vacation Rentals', description: 'Short-term rental apartments' },
  { icon: Lightbulb, title: 'Hospitality Entrepreneurs', description: 'New and scaling businesses' },
];

export default function WhoWeHelp() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="who-we-help"
      aria-labelledby="who-we-help-heading"
      className="py-20 sm:py-28 bg-neutral-950 relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(255,208,0,0.06)_0%,_transparent_70%)]" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-accent/5 rounded-full blur-3xl" />

      <div className="section-max section-padding relative">
        <div
          className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 opacity-0 ${
            isInView ? 'animate-fade-up' : ''
          }`}
        >
          <span className="badge bg-accent/20 text-accent mb-4">Who We Help</span>
          <h2
            id="who-we-help-heading"
            className="heading-lg !text-white"
          >
            Every Hospitality Business in Goa
          </h2>
          <p className="text-base sm:text-lg text-neutral-400 mt-4 leading-relaxed">
            From luxury resorts to beachside cafes — The OTA Studio serves every type of
            hospitality business in Goa with dedicated growth services.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-5">
          {propertyTypes.map((type, i) => (
            <article
              key={i}
              className={`group p-5 sm:p-6 rounded-2xl border border-neutral-800 bg-neutral-900/50 hover:bg-neutral-800/50 hover:border-accent/30 transition-all duration-300 text-center opacity-0 ${
                isInView
                  ? `animate-fade-up delay-${Math.min(i * 80, 600)}`
                  : ''
              }`}
            >
              <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-accent/20 transition-colors">
                <type.icon size={22} className="text-accent" aria-hidden="true" />
              </div>
              <h3 className="font-display font-bold text-sm sm:text-base text-white mb-1">
                {type.title}
              </h3>
              <p className="text-xs text-neutral-500">{type.description}</p>
            </article>
          ))}
        </div>

        <div
          className={`mt-12 text-center opacity-0 ${isInView ? 'animate-fade-up delay-600' : ''}`}
        >
          <a
            href="https://wa.me/919270598602?text=Hi%2C%20I%27d%20like%20to%20discuss%20growing%20my%20hospitality%20business%20in%20Goa"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary"
          >
            Start Growing Your Bookings
          </a>
        </div>
      </div>
    </section>
  );
}
