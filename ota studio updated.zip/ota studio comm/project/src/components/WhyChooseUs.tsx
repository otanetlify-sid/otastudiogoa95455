import { Award, Search, Network, TrendingUp, HeartHandshake, Zap } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const reasons = [
  {
    icon: Award,
    title: 'OTA Expertise',
    description: 'Deep knowledge of OTA algorithms for Booking.com, Airbnb, Agoda, Expedia, and more. Higher rankings, more bookings.',
    stat: '8+',
    statLabel: 'OTA Platforms',
  },
  {
    icon: Search,
    title: 'Listing Optimization',
    description: 'Compelling titles, descriptions, professional photo guidance, and amenity mapping for maximum conversion.',
    stat: '3x',
    statLabel: 'Avg Booking Lift',
  },
  {
    icon: Network,
    title: 'Distribution Management',
    description: 'Channel manager setup, real-time inventory sync, rate parity across all connected OTAs.',
    stat: '100+',
    statLabel: 'Properties Managed',
  },
  {
    icon: TrendingUp,
    title: 'Revenue Growth',
    description: 'Demand-based pricing, promotional campaigns, and occupancy optimization for consistent revenue growth.',
    stat: '2.8x',
    statLabel: 'Revenue Growth',
  },
  {
    icon: HeartHandshake,
    title: 'Complete Support',
    description: "We don't just advise—we execute. From onboarding to dispute resolution, we handle it all.",
    stat: '7-14',
    statLabel: 'Days to Go Live',
  },
  {
    icon: Zap,
    title: 'We Execute',
    description: 'No passive advice. We implement, optimize, and deliver measurable results for your property.',
    stat: 'Goa',
    statLabel: 'Based in India',
  },
];

export default function WhyChooseUs() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="why-choose-us"
      aria-labelledby="why-choose-heading"
      className="py-20 sm:py-28 bg-neutral-950 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-40" />
      <div className="absolute top-1/4 right-0 w-[400px] h-[400px] bg-accent/5 rounded-full blur-3xl" />

      <div className="section-max section-padding relative">
        <div className={`text-center max-w-2xl mx-auto mb-14 sm:mb-16 ${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
          <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Why Choose The OTA Studio</span>
          <h2 id="why-choose-heading" className="heading-lg text-white mb-4">
            Why Hospitality Businesses Choose The OTA Studio
          </h2>
          <p className="body-lg">
            We are executors, not advisors. Every strategy we create, we implement.
            Your growth is our responsibility.
          </p>
          <div className="mt-6 p-4 rounded-2xl bg-accent/10 border border-accent/20 text-center">
            <p className="font-display font-bold text-lg text-white">"We Don't Sell Advice. We Execute."</p>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {reasons.map((reason, i) => (
            <article
              key={i}
              className={`group p-6 sm:p-7 rounded-2xl border border-white/8 bg-white/4 hover:bg-white/10 hover:border-accent/30 transition-all duration-300 ${isInView ? `animate-fade-up delay-${Math.min(i * 100, 600)}` : 'opacity-0'}`}
            >
              <div className="flex items-start justify-between mb-5">
                <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center group-hover:bg-accent/20 transition-colors">
                  <reason.icon size={22} className="text-accent" aria-hidden="true" />
                </div>
                <div className="text-right">
                  <div className="font-display font-extrabold text-2xl text-accent leading-none">{reason.stat}</div>
                  <div className="text-xs text-white/40 mt-0.5">{reason.statLabel}</div>
                </div>
              </div>
              <h3 className="font-display font-bold text-base sm:text-lg text-white mb-2">{reason.title}</h3>
              <p className="text-sm text-white/50 leading-relaxed">{reason.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
