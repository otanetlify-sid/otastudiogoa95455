import { Layers, Globe2, Hotel, Zap, LifeBuoy, ArrowRight } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const features = [
  {
    icon: Layers,
    title: 'End-to-End Execution',
    description:
      'From onboarding to ongoing management, we handle every step of your OTA journey. You focus on your guests. We handle your platforms.',
    highlight: 'Full-stack OTA service',
  },
  {
    icon: Globe2,
    title: 'Multi-OTA Expertise',
    description:
      "Deep platform knowledge across Booking.com, Airbnb, Agoda, Expedia, MakeMyTrip, and more. We know what each algorithm rewards.",
    highlight: '8+ platforms mastered',
  },
  {
    icon: Hotel,
    title: 'Hospitality Focused',
    description:
      "We work exclusively with hospitality businesses. Every strategy is built on real experience from Goa's hotels, villas, resorts, and cafes.",
    highlight: 'Goa market expertise',
  },
  {
    icon: Zap,
    title: 'Fast Go-Live Process',
    description:
      'Properties live on all major OTAs in 7-14 days. Fast, clean, and fully optimized from the first day your listing is live.',
    highlight: '7-14 day launch',
  },
  {
    icon: LifeBuoy,
    title: 'Ongoing Support',
    description:
      'We don\'t disappear after onboarding. Continuous monitoring, optimization, and support ensure your properties keep growing month after month.',
    highlight: 'Continuous growth',
  },
];

export default function WhyOtaStudio() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="why-ota-studio"
      aria-labelledby="why-ota-heading"
      className="py-20 sm:py-28 bg-neutral-900 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-40" />
      <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-accent/5 rounded-full blur-3xl translate-x-1/2 -translate-y-1/2" />

      <div className="section-max section-padding relative">
        <div className="grid lg:grid-cols-2 gap-14 lg:gap-20 items-start">
          {/* Left — sticky headline */}
          <div
            className={`opacity-0 ${isInView ? 'animate-fade-up' : ''}`}
          >
            <div className="lg:sticky lg:top-28">
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">
                Why The OTA Studio
              </span>
              <h2
                id="why-ota-heading"
                className="heading-lg text-white mb-6"
              >
                What Makes Us{' '}
                <span className="text-accent">Different</span>
              </h2>
              <p className="body-lg mb-8">
                We are not a platform. We are not a marketing agency. We are a dedicated
                execution team that does the real work of growing your hospitality business.
              </p>

              <div className="p-6 rounded-2xl bg-white/5 border border-white/10 mb-8">
                <p className="text-sm text-white/50 mb-4">Trusted by hospitality businesses across Goa</p>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { n: '100+', l: 'Businesses' },
                    { n: '3x', l: 'Avg Growth' },
                    { n: '8+', l: 'OTAs' },
                    { n: 'Goa', l: 'Our Focus' },
                  ].map((s, i) => (
                    <div key={i}>
                      <p className="font-display font-extrabold text-xl text-accent">{s.n}</p>
                      <p className="text-xs text-white/40">{s.l}</p>
                    </div>
                  ))}
                </div>
              </div>

              <a
                href="https://wa.me/919270598602?text=Hi%2C%20I%27d%20like%20to%20book%20a%20call%20with%20The%20OTA%20Studio"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary group"
              >
                Book a Call
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </a>
            </div>
          </div>

          {/* Right — feature cards */}
          <div className="space-y-4">
            {features.map((feature, i) => (
              <article
                key={i}
                className={`group p-6 sm:p-7 rounded-2xl bg-white/4 border border-white/8 hover:bg-white/7 hover:border-accent/25 hover:shadow-[0_0_30px_rgba(255,208,0,0.06)] transition-all duration-300 opacity-0 ${
                  isInView ? `animate-fade-up delay-${Math.min(i * 100, 500)}` : ''
                }`}
              >
                <div className="flex items-start gap-5">
                  <div className="w-11 h-11 rounded-xl bg-accent/10 border border-accent/20 flex items-center justify-center shrink-0 group-hover:bg-accent/15 group-hover:border-accent/30 transition-colors">
                    <feature.icon size={20} className="text-accent" aria-hidden="true" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2 flex-wrap">
                      <h3 className="font-display font-bold text-base text-white">
                        {feature.title}
                      </h3>
                      <span className="text-[10px] font-bold text-accent/70 bg-accent/8 px-2 py-0.5 rounded-full border border-accent/15 whitespace-nowrap">
                        {feature.highlight}
                      </span>
                    </div>
                    <p className="text-sm text-white/50 leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
