import { MapPin, Layers, TrendingUp, MessageCircle, Target } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const reasons = [
  {
    icon: MapPin,
    title: 'Exclusive for Goa Hotels',
    description:
      'We only work with hotel and hostel owners in Goa. No travelers, no general tourism — 100% hotel-focused.',
  },
  {
    icon: Layers,
    title: 'End-to-End OTA Management',
    description:
      'From onboarding to optimization to revenue management — we handle the entire OTA lifecycle.',
  },
  {
    icon: TrendingUp,
    title: 'Focus on Visibility & Revenue',
    description:
      'Every action we take is driven by one goal: increasing your bookings and revenue through OTA platforms.',
  },
  {
    icon: MessageCircle,
    title: 'Fast WhatsApp-Based Support',
    description:
      'No emails, no tickets. Reach us directly on WhatsApp for quick, personal support whenever you need it.',
  },
  {
    icon: Target,
    title: 'Result-Driven Execution',
    description:
      'We don\'t just set things up — we measure, iterate, and optimize until your OTA performance improves.',
  },
];

export default function WhyUs() {
  const { ref, isInView } = useInView();

  return (
    <section ref={ref} id="why-us" className="py-20 sm:py-28">
      <div className="section-max section-padding">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
          <div className={`${isInView ? 'animate-fade-up' : 'opacity-0'}`}>
            <span className="badge bg-accent/10 text-accent-700 mb-4">
              Why OTA Studio
            </span>
            <h2 className="heading-lg !text-3xl sm:!text-4xl">
              Built Exclusively for Hotel Owners in Goa
            </h2>
            <p className="body-lg mt-5">
              We aren't a general marketing agency. We are an OTA-specific
              studio that understands the Goa hospitality market, OTA
              algorithms, and what it takes to get bookings.
            </p>

            <div className="mt-8 sm:mt-10 grid grid-cols-2 gap-4">
              {[
                { value: '50+', label: 'Hotels Served' },
                { value: '5+', label: 'OTA Platforms' },
                { value: '3x', label: 'Avg. Booking Lift' },
                { value: '10+', label: 'Years Experience' },
              ].map((stat) => (
                <div
                  key={stat.label}
                  className="bg-neutral-50 rounded-xl border border-neutral-100 p-4 sm:p-5"
                >
                  <div className="font-display font-extrabold text-xl sm:text-2xl text-accent-600">
                    {stat.value}
                  </div>
                  <div className="text-xs sm:text-sm text-neutral-500 mt-0.5">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-5">
            {reasons.map((reason, i) => (
              <div
                key={i}
                className={`flex items-start gap-4 p-5 sm:p-6 rounded-xl bg-neutral-50 border border-neutral-100 hover:bg-white hover:shadow-lg hover:shadow-neutral-200/40 transition-all duration-300 hover:-translate-y-0.5 group opacity-0 ${
                  isInView
                    ? `animate-fade-up delay-${Math.min(i * 100, 500)}`
                    : ''
                }`}
              >
                <div className="w-11 h-11 rounded-lg bg-accent/10 flex items-center justify-center shrink-0 group-hover:bg-accent/20 transition-colors">
                  <reason.icon
                    size={20}
                    className="text-accent-600 group-hover:text-accent-700 transition-colors"
                  />
                </div>
                <div>
                  <h3 className="font-display font-bold text-base sm:text-lg mb-1">
                    {reason.title}
                  </h3>
                  <p className="text-sm text-neutral-600 leading-relaxed">
                    {reason.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
