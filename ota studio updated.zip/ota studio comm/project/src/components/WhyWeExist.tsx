import { Quote, Target, Users, Zap } from 'lucide-react';
import { useInView } from '../hooks/useInView';

export default function WhyWeExist() {
  const { ref, isInView } = useInView();

  return (
    <section
      ref={ref}
      id="why-we-exist"
      aria-labelledby="why-we-exist-heading"
      className="py-20 sm:py-28 bg-neutral-900 relative overflow-hidden"
    >
      <div className="absolute inset-0 section-grid opacity-30" />

      <div className="section-max section-padding relative">
        <div className="grid lg:grid-cols-2 gap-14 lg:gap-20 items-center">
          <div className={`opacity-0 ${isInView ? 'animate-fade-up' : ''}`}>
            <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Why We Exist</span>
            <h2
              id="why-we-exist-heading"
              className="heading-lg text-white mb-6"
            >
              Built for Goa's <br className="hidden sm:block" />
              <span className="text-accent">Hospitality Community</span>
            </h2>

            <div className="relative pl-6 border-l-2 border-accent/30 mb-8">
              <Quote size={24} className="text-accent/40 mb-3" />
              <p className="text-base sm:text-lg text-white/70 leading-relaxed italic">
                "We started The OTA Studio because we saw too many great properties in Goa
                struggling with online visibility — not because their hospitality was poor,
                but because navigating OTAs, pricing, and distribution is genuinely complex.
                We decided to become the team that solves that."
              </p>
              <div className="mt-4">
                <div className="font-display font-bold text-white">The Founders</div>
                <div className="text-sm text-white/40">The OTA Studio, Goa</div>
              </div>
            </div>

            <a
              href="#contact"
              className="btn-primary"
            >
              Work With Us
            </a>
          </div>

          <div className={`space-y-5 opacity-0 ${isInView ? 'animate-fade-up delay-300' : ''}`}>
            <div className="p-6 rounded-2xl bg-white/4 border border-white/8 hover:border-accent/20 transition-colors">
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-xl bg-accent/10 flex items-center justify-center shrink-0">
                  <Target size={20} className="text-accent" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-base text-white mb-2">Our Mission</h3>
                  <p className="text-sm text-white/50 leading-relaxed">
                    To become Goa's most trusted hospitality growth partner — making professional
                    OTA management, visibility optimization, and revenue growth accessible
                    to every hospitality business, regardless of size.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-white/4 border border-white/8 hover:border-accent/20 transition-colors">
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-xl bg-accent/10 flex items-center justify-center shrink-0">
                  <Users size={20} className="text-accent" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-base text-white mb-2">Who We Are</h3>
                  <p className="text-sm text-white/50 leading-relaxed">
                    A team of hospitality professionals and digital growth specialists based in Goa.
                    We combine deep OTA expertise with genuine understanding of Goa's hospitality
                    market, guest behavior, and seasonal dynamics.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-white/4 border border-white/8 hover:border-accent/20 transition-colors">
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-xl bg-accent/10 flex items-center justify-center shrink-0">
                  <Zap size={20} className="text-accent" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-base text-white mb-2">How We Work</h3>
                  <p className="text-sm text-white/50 leading-relaxed">
                    We are executors, not advisors. Every strategy we create, we implement.
                    Every recommendation we make, we action. Your growth is our responsibility —
                    and we take that seriously.
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 mt-6">
              {[
                { num: '100+', label: 'Properties Served' },
                { num: '3x', label: 'Avg Booking Growth' },
                { num: 'Goa', label: 'Our Home Market' },
              ].map((stat, i) => (
                <div key={i} className="text-center p-4 rounded-xl bg-neutral-950 border border-accent/20">
                  <div className="font-display font-extrabold text-xl sm:text-2xl text-accent">
                    {stat.num}
                  </div>
                  <div className="text-xs text-white/40 mt-1">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
