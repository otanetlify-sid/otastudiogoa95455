import { useEffect, useRef, useState } from 'react';
import { useInView } from './useInView';

interface UseRevealOptions {
  threshold?: number;
  stagger?: number;
  delay?: number;
}

interface UseRevealReturn {
  ref: React.RefObject<HTMLElement | null>;
  isInView: boolean;
  className: string;
}

export function useReveal({
  threshold = 0.1,
  stagger = 0,
  delay = 0,
}: UseRevealOptions = {}): UseRevealReturn {
  const { ref, isInView } = useInView(threshold);
  const [hasTriggered, setHasTriggered] = useState(false);
  const childIndexRef = useRef(0);

  // Calculate effective delay based on stagger and delay props
  useEffect(() => {
    if (isInView && !hasTriggered) {
      const effectiveDelay = delay + childIndexRef.current * stagger;
      const timer = setTimeout(() => {
        setHasTriggered(true);
      }, effectiveDelay);

      return () => clearTimeout(timer);
    }
  }, [isInView, hasTriggered, delay, stagger]);

  // Build className based on visibility and trigger state
  const className = hasTriggered
    ? 'transition-all duration-1000 opacity-100 translate-y-0 scale-100'
    : 'opacity-0 translate-y-10 scale-[0.97]';

  return {
    ref,
    isInView,
    className,
  };
}

export function useRevealWithStaggerIndex(
  index: number,
  {
    threshold = 0.1,
    stagger = 100,
    delay = 0,
  }: UseRevealOptions = {}
): UseRevealReturn {
  const { ref, isInView } = useInView(threshold);
  const [hasTriggered, setHasTriggered] = useState(false);

  useEffect(() => {
    if (isInView && !hasTriggered) {
      const effectiveDelay = delay + index * stagger;
      const timer = setTimeout(() => {
        setHasTriggered(true);
      }, effectiveDelay);

      return () => clearTimeout(timer);
    }
  }, [isInView, hasTriggered, delay, stagger, index]);

  const className = hasTriggered
    ? 'transition-all duration-1000 opacity-100 translate-y-0 scale-100'
    : 'opacity-0 translate-y-10 scale-[0.97]';

  return {
    ref,
    isInView,
    className,
  };
}
