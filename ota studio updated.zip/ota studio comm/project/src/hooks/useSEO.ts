import { useEffect } from 'react';

interface SEOData {
  title: string;
  description: string;
  canonical: string;
  schemaType?: 'service' | 'legal' | 'guide' | 'event' | 'community' | 'network' | 'page';
  breadcrumbs?: { name: string; href?: string }[];
}

const BASE_URL = 'https://otastudio.in';

const schemaTemplates: Record<string, (data: SEOData) => object> = {
  service: (data) => ({
    '@context': 'https://schema.org',
    '@type': 'Service',
    name: data.title.replace(' | The OTA Studio', ''),
    description: data.description,
    provider: {
      '@type': 'Organization',
      name: 'The OTA Studio',
      url: BASE_URL,
    },
    areaServed: { '@type': 'State', name: 'Goa' },
    serviceType: 'Hospitality OTA Services',
  }),
  guide: (data) => ({
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: data.title.replace(' | The OTA Studio', ''),
    description: data.description,
    author: { '@type': 'Organization', name: 'The OTA Studio', url: BASE_URL },
    publisher: { '@type': 'Organization', name: 'The OTA Studio', url: BASE_URL },
  }),
  event: (data) => ({
    '@context': 'https://schema.org',
    '@type': 'Event',
    name: data.title.replace(' | The OTA Studio', ''),
    description: data.description,
    location: { '@type': 'State', name: 'Goa' },
    organizer: { '@type': 'Organization', name: 'The OTA Studio', url: BASE_URL },
  }),
  community: (data) => ({
    '@context': 'https://schema.org',
    '@type': 'Service',
    name: data.title.replace(' | The OTA Studio', ''),
    description: data.description,
    provider: { '@type': 'Organization', name: 'The OTA Studio', url: BASE_URL },
    areaServed: { '@type': 'State', name: 'Goa' },
    serviceType: 'Community & Hospitality Activations',
  }),
  network: (data) => ({
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: data.title.replace(' | The OTA Studio', ''),
    description: data.description,
    isPartOf: { '@type': 'WebSite', name: 'The OTA Studio', url: BASE_URL },
  }),
  page: (data) => ({
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: data.title.replace(' | The OTA Studio', ''),
    description: data.description,
  }),
  legal: (data) => ({
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: data.title.replace(' | The OTA Studio', ''),
    description: data.description,
  }),
};

function getOrCreateTag(selector: string, tagName: string, attributes: Record<string, string>): HTMLElement {
  let el = document.head.querySelector(selector) as HTMLElement | null;
  if (!el) {
    el = document.createElement(tagName);
    document.head.appendChild(el);
  }
  for (const [key, val] of Object.entries(attributes)) {
    el.setAttribute(key, val);
  }
  return el;
}

function setMeta(attrKey: string, attrVal: string, content: string) {
  const selector = `meta[${attrKey}="${attrVal}"]`;
  const el = getOrCreateTag(selector, 'meta', { [attrKey]: attrVal, content });
  el.setAttribute('content', content);
}

function setPropertyMeta(property: string, content: string) {
  setMeta('property', property, content);
}

function setNameMeta(name: string, content: string) {
  setMeta('name', name, content);
}

export default function useSEO(data: SEOData) {
  useEffect(() => {
    const fullCanonical = data.canonical.startsWith('http') ? data.canonical : `${BASE_URL}${data.canonical}`;

    // Title
    document.title = data.title;

    // Standard meta
    setNameMeta('description', data.description);
    setNameMeta('title', data.title);

    // Canonical link
    const canonicalEl = getOrCreateTag('link[rel="canonical"]', 'link', { rel: 'canonical' });
    canonicalEl.setAttribute('href', fullCanonical);

    // Open Graph
    setPropertyMeta('og:title', data.title);
    setPropertyMeta('og:description', data.description);
    setPropertyMeta('og:url', fullCanonical);
    setPropertyMeta('og:type', data.schemaType === 'guide' ? 'article' : 'website');

    // Twitter
    setNameMeta('twitter:title', data.title);
    setNameMeta('twitter:description', data.description);

    // Page-specific structured data
    if (data.schemaType) {
      const template = schemaTemplates[data.schemaType];
      if (template) {
        const existing = document.getElementById('page-schema');
        if (existing) existing.remove();

        const script = document.createElement('script');
        script.type = 'application/ld+json';
        script.id = 'page-schema';
        script.textContent = JSON.stringify(template(data));
        document.head.appendChild(script);
      }
    }

    // BreadcrumbList structured data
    if (data.breadcrumbs && data.breadcrumbs.length > 0) {
      const existing = document.getElementById('breadcrumb-schema');
      if (existing) existing.remove();

      const items = [
        { '@type': 'ListItem', position: 1, name: 'Home', item: BASE_URL },
        ...data.breadcrumbs.map((crumb, i) => ({
          '@type': 'ListItem',
          position: i + 2,
          name: crumb.name,
          ...(crumb.href ? { item: `${BASE_URL}${crumb.href}` } : {}),
        })),
      ];

      const script = document.createElement('script');
      script.type = 'application/ld+json';
      script.id = 'breadcrumb-schema';
      script.textContent = JSON.stringify({
        '@context': 'https://schema.org',
        '@type': 'BreadcrumbList',
        itemListElement: items,
      });
      document.head.appendChild(script);
    }

    return () => {
      const pageSchema = document.getElementById('page-schema');
      if (pageSchema) pageSchema.remove();
      const breadcrumbSchema = document.getElementById('breadcrumb-schema');
      if (breadcrumbSchema) breadcrumbSchema.remove();
    };
  }, [data.title, data.description, data.canonical, data.schemaType]);
}
