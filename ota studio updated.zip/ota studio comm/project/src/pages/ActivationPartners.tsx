import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Send, Sparkles } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  {
    q: 'Who can become an activation partner?',
    a: 'Musicians, DJs, yoga instructors, wellness facilitators, artists, workshop hosts, retreat leaders, photographers, videographers, event organizers, community managers, and experience hosts.',
  },
  {
    q: 'What opportunities do activation partners get?',
    a: 'Venue opportunities across our property network, event collaborations, recurring bookings, community exposure, and hospitality partnerships with hotels, cafes, restaurants, and beach clubs.',
  },
  {
    q: 'Do I need to be based in Goa?',
    a: 'While Goa-based partners get the most opportunities, we also work with professionals who can travel to Goa for activations and retreats.',
  },
  {
    q: 'How does OTA Studio promote my events?',
    a: 'We handle pre-event marketing through targeted social media, WhatsApp communities, influencer outreach, and OTA cross-promotion to build audiences for your activations.',
  },
  {
    q: 'How do I apply?',
    a: 'Fill out the form above or message us on WhatsApp with your details. We review applications within 24-48 hours.',
  },
];

const includes = [
  'Venue opportunities across Goa\'s hospitality network',
  'Event collaborations and recurring bookings',
  'Community exposure and audience building',
  'Hospitality partnerships with hotels, cafes, and beach clubs',
  'Marketing and promotional support for your events',
  'Featured listing in our partner directory',
];

const categories = [
  'Community Managers',
  'Event Organizers',
  'Musicians and DJs',
  'Yoga Instructors',
  'Wellness Facilitators',
  'Artists and Workshop Hosts',
];

export default function ActivationPartners() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    fullName: '',
    category: '',
    location: '',
    whatsappNumber: '',
    instagramProfile: '',
    portfolioLink: '',
    experienceDescription: '',
  });

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleFormSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    const message = `*Activation Partner Application*\n\nFull Name: ${formData.fullName}\nCategory: ${formData.category}\nLocation: ${formData.location}\nWhatsApp Number: ${formData.whatsappNumber}\nInstagram Profile: ${formData.instagramProfile}\nPortfolio Link: ${formData.portfolioLink}\nExperience Description: ${formData.experienceDescription}`;

    const encodedMessage = encodeURIComponent(message);
    window.open(`https://wa.me/919309706263?text=${encodedMessage}`, '_blank');

    setFormData({
      fullName: '',
      category: '',
      location: '',
      whatsappNumber: '',
      instagramProfile: '',
      portfolioLink: '',
      experienceDescription: '',
    });
  };

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white" itemProp="name">Activation Partners Goa</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Activation Partners · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Activation Partners Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Join OTA Studio's activation network. Musicians, DJs, yoga instructors, artists, wellness facilitators, photographers, and experience hosts — connect with hospitality venues across Goa.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20to%20join%20the%20activation%20network" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Join Activation Network <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="#benefits" className="btn-secondary">
                  View Partner Benefits
                </a>
              </div>
            </div>
          </div>

          <section id="benefits" className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">Activation Partnership Includes</h2>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 rounded-lg bg-accent/15 flex items-center justify-center">
                      <Sparkles size={20} className="text-accent" />
                    </div>
                    <h3 className="font-display font-bold text-xl text-white">Partner Categories</h3>
                  </div>
                  <div className="space-y-3 mb-8">
                    {categories.map((item, i) => (
                      <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-white/4 border border-white/8">
                        <CheckCircle2 size={16} className="text-accent shrink-0" />
                        <span className="text-sm text-white/70">{item}</span>
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '30+', label: 'Partner Venues' },
                      { metric: '25+', label: 'Active Creatives' },
                      { metric: '50+', label: 'Events Delivered' },
                      { metric: '4', label: 'Activation Categories' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="text-center mb-12">
                <h2 className="heading-lg text-white mb-4">Join Activation Network</h2>
                <p className="text-white/50 mb-8 max-w-xl mx-auto">Fill out the form below to apply as an activation partner.</p>
              </div>

              <form onSubmit={handleFormSubmit} className="max-w-3xl mx-auto space-y-6">
                <div>
                  <label htmlFor="ap-fullName" className="block text-sm font-semibold text-white mb-1.5">
                    Full Name <span className="text-accent">*</span>
                  </label>
                  <input
                    id="ap-fullName"
                    type="text"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleFormChange}
                    required
                    className="w-full px-4 py-3 bg-white border border-neutral-200 rounded-xl text-neutral-950 placeholder:text-[#666666] focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent/30 transition-colors"
                    placeholder="Your full name"
                  />
                </div>

                <div>
                  <label htmlFor="ap-category" className="block text-sm font-semibold text-white mb-1.5">
                    Category <span className="text-accent">*</span>
                  </label>
                  <select
                    id="ap-category"
                    name="category"
                    value={formData.category}
                    onChange={handleFormChange}
                    required
                    className="w-full px-4 py-3 bg-white border border-neutral-200 rounded-xl text-neutral-950 focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent/30 transition-colors appearance-none"
                  >
                    <option value="">Select a category</option>
                    <option value="Community Manager">Community Manager</option>
                    <option value="Event Organizer">Event Organizer</option>
                    <option value="Musician">Musician</option>
                    <option value="DJ">DJ</option>
                    <option value="Artist">Artist</option>
                    <option value="Yoga Instructor">Yoga Instructor</option>
                    <option value="Wellness Facilitator">Wellness Facilitator</option>
                    <option value="Workshop Host">Workshop Host</option>
                    <option value="Retreat Leader">Retreat Leader</option>
                    <option value="Photographer">Photographer</option>
                    <option value="Videographer">Videographer</option>
                    <option value="Experience Host">Experience Host</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="ap-location" className="block text-sm font-semibold text-white mb-1.5">
                    Location <span className="text-accent">*</span>
                  </label>
                  <input
                    id="ap-location"
                    type="text"
                    name="location"
                    value={formData.location}
                    onChange={handleFormChange}
                    required
                    className="w-full px-4 py-3 bg-white border border-neutral-200 rounded-xl text-neutral-950 placeholder:text-[#666666] focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent/30 transition-colors"
                    placeholder="Your city or area"
                  />
                </div>

                <div>
                  <label htmlFor="ap-whatsappNumber" className="block text-sm font-semibold text-white mb-1.5">
                    WhatsApp Number <span className="text-accent">*</span>
                  </label>
                  <input
                    id="ap-whatsappNumber"
                    type="tel"
                    name="whatsappNumber"
                    value={formData.whatsappNumber}
                    onChange={handleFormChange}
                    required
                    className="w-full px-4 py-3 bg-white border border-neutral-200 rounded-xl text-neutral-950 placeholder:text-[#666666] focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent/30 transition-colors"
                    placeholder="+91 XXXXXXXXXX"
                  />
                </div>

                <div>
                  <label htmlFor="ap-instagramProfile" className="block text-sm font-semibold text-white mb-1.5">
                    Instagram Profile
                  </label>
                  <input
                    id="ap-instagramProfile"
                    type="text"
                    name="instagramProfile"
                    value={formData.instagramProfile}
                    onChange={handleFormChange}
                    className="w-full px-4 py-3 bg-white border border-neutral-200 rounded-xl text-neutral-950 placeholder:text-[#666666] focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent/30 transition-colors"
                    placeholder="@yourinstagram"
                  />
                </div>

                <div>
                  <label htmlFor="ap-portfolioLink" className="block text-sm font-semibold text-white mb-1.5">
                    Portfolio Link
                  </label>
                  <input
                    id="ap-portfolioLink"
                    type="url"
                    name="portfolioLink"
                    value={formData.portfolioLink}
                    onChange={handleFormChange}
                    className="w-full px-4 py-3 bg-white border border-neutral-200 rounded-xl text-neutral-950 placeholder:text-[#666666] focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent/30 transition-colors"
                    placeholder="https://yourportfolio.com"
                  />
                </div>

                <div>
                  <label htmlFor="ap-experienceDescription" className="block text-sm font-semibold text-white mb-1.5">
                    Experience Description <span className="text-accent">*</span>
                  </label>
                  <textarea
                    id="ap-experienceDescription"
                    name="experienceDescription"
                    value={formData.experienceDescription}
                    onChange={handleFormChange}
                    required
                    rows={5}
                    className="w-full px-4 py-3 bg-white border border-neutral-200 rounded-xl text-neutral-950 placeholder:text-[#666666] focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent/30 transition-colors resize-none"
                    placeholder="Tell us about your experience, expertise, and what you're looking for in partnership with OTA Studio..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full px-6 py-3 bg-accent text-neutral-950 rounded-xl font-display font-bold hover:bg-accent-300 transition-colors flex items-center justify-center gap-2"
                >
                  Send Application
                  <Send size={18} />
                </button>
              </form>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Activation Partner FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20 text-center relative overflow-hidden">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <h2 className="heading-lg text-white mb-4">Join the Activation Network</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Connect with hospitality venues across Goa.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20to%20join%20the%20activation%20network" target="_blank" rel="noopener noreferrer" className="btn-primary">Join the Activation Network</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
