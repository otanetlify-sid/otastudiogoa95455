import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, MapPin, Award, Zap } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'Why is Agoda important for Goa properties?', a: 'Agoda is the dominant OTA in Asia-Pacific with over 400 million users, particularly strong in Southeast Asia, East Asia, and India. For Goa properties, Agoda unlocks bookings from Asian travelers and expat communities across the region.' },
  { q: 'How is Agoda\'s algorithm different?', a: 'Agoda\'s ranking system emphasizes booking frequency, guest reviews, response speed, and completion rate. The platform also rewards consistent availability and on-time confirmations, making operational excellence key to ranking high.' },
  { q: 'What are Agoda\'s rewards and promotions?', a: 'Agoda offers aggressive promotion tools including loyalty rewards, price matching, and promotional campaigns. We leverage these features strategically to boost visibility and conversions while protecting your margins.' },
  { q: 'How do you handle Agoda\'s cancellation policies?', a: 'Agoda guests appreciate flexible cancellations. We optimize your cancellation policy positioning to be competitive while implementing strategies to recover revenue from cancellations through alternative channels.' },
  { q: 'Can you help with Agoda\'s Best Price Guarantee?', a: 'Yes, we ensure your pricing is competitive across all channels to maintain Agoda\'s best price eligibility, which directly improves your search ranking and prevents ranking penalties.' },
  { q: 'How long before seeing Agoda booking growth?', a: 'Most properties see improved Agoda bookings within 3-6 weeks of optimization. Asian travelers book frequently, and optimized listings capture this high-volume traffic quickly.' },
];

const includes = [
  'Agoda listing optimization and SEO enhancement',
  'Asia-Pacific market targeting and localization',
  'Professional photo strategy for Asian markets',
  'Price matching and best price guarantee management',
  'Agoda rewards program optimization',
  'Guest communication and response templates',
  'Review strategy and reputation management',
  'Weekly Agoda performance analytics',
];

export default function AgodaManagementGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Agoda Management Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Agoda Management · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Agoda Management Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Expert Agoda management for Goa properties targeting Asia-Pacific travelers. We optimize listings, improve search rankings,
                leverage Agoda's rewards programs, and maximize bookings from the world's leading Asian travel platform.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20Agoda%20management%20for%20my%20Goa%20property" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Reach Asia-Pacific Markets <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">Agoda Management Includes</h2>
                  <p className="body-md text-white/70 mb-8">Complete Agoda optimization for Asia-Pacific market penetration and maximum bookings.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <h3 className="font-display font-bold text-xl text-white mb-6">Results We Deliver</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '290%', label: 'Booking Increase' },
                      { metric: '400M+', label: 'Agoda Users Reached' },
                      { metric: '4.8+', label: 'Average Guest Rating' },
                      { metric: '55+', label: 'Properties Managed' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid md:grid-cols-3 gap-8 mb-16">
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <Award size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Revenue Optimization</h3>
                  <p className="text-white/70 mb-4">Asian travelers are often willing to book quickly and frequently. We optimize pricing to capture high booking volume while maintaining margins through strategic Agoda rewards and promotional placements.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Asia-Pacific price optimization
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Agoda rewards program leverage
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Promotional campaign management
                    </li>
                  </ul>
                </div>

                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <MapPin size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Listing Optimization</h3>
                  <p className="text-white/70 mb-4">We optimize listings for Asian traveler preferences, including family-friendly features, convenience amenities, and local experience highlights. Photos and descriptions are tailored for Asia-Pacific markets.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Asian market localization
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Family accommodation highlighting
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Convenience amenity focus
                    </li>
                  </ul>
                </div>

                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <Zap size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Ranking Improvement</h3>
                  <p className="text-white/70 mb-4">Agoda's algorithm rewards operational excellence: fast confirmations, high review scores, and consistent availability. We optimize all these factors to ensure your property ranks prominently in Asian search results.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Fast confirmation optimization
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Review score maximization
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Best price guarantee maintenance
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Benefits for Goa Hotels</h2>
              <div className="grid md:grid-cols-2 gap-8">
                {[
                  'Access to 400+ million Agoda users across Asia-Pacific region',
                  'Strong presence among Chinese, Southeast Asian, and Indian travelers',
                  'High booking frequency from Asian travelers increases occupancy rates',
                  'Agoda\'s loyalty rewards drive repeat bookings from frequent Asia-Pacific travelers',
                  'Less competition from Western hotels on Agoda compared to Booking.com',
                  'Asian travelers often have flexible dates and spontaneous booking patterns',
                  'Agoda\'s mobile app provides highest conversion rates in Asia-Pacific',
                  'Promotional tools and flash sales boost visibility and capture price-sensitive travelers',
                ].map((benefit, i) => (
                  <div key={i} className="flex items-start gap-4 p-6 rounded-xl border border-white/8 bg-white/4">
                    <CheckCircle2 size={24} className="text-accent mt-1 shrink-0" />
                    <p className="text-white/70">{benefit}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Why Choose Us for Agoda?</h2>
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Asia-Pacific Market Expertise</h3>
                  <p className="text-white/70">We understand the diverse Asian travel markets, including preferences of Chinese, Southeast Asian, Indian, and Australian travelers. This expertise ensures your listing appeals to your target Asia-Pacific audience.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Agoda Platform Mastery</h3>
                  <p className="text-white/70">Our team has deep knowledge of Agoda's ranking algorithm, rewards program, promotional tools, and best practices. We leverage every feature to maximize your visibility and bookings on this critical platform.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Documented Success</h3>
                  <p className="text-white/70">55+ Goa properties have increased bookings significantly through our Agoda optimization strategies. Average booking increase: 290%. Average guest rating: 4.8+ stars.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Related Services</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <a href="/property-management-goa" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Property Management Goa</h3>
                  <p className="text-white/70 mb-4">Complete property management including OTA management, operations, and revenue optimization.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/vision-mission" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Our Vision & Mission</h3>
                  <p className="text-white/70 mb-4">Learn about our approach to hospitality growth and property management excellence in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/founders" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Meet Our Founders</h3>
                  <p className="text-white/70 mb-4">Discover the team behind successful Agoda management strategies for Goa properties.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Agoda Management FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-64' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ready to Dominate Agoda in Goa?</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Let's optimize your Agoda presence and tap into Asia-Pacific's largest travel platform for consistent, high-volume bookings.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20Agoda%20management%20for%20my%20property" target="_blank" rel="noopener noreferrer" className="btn-primary">Reach Asia-Pacific Markets</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
