import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What are the current Airbnb rules and regulations in Goa?', a: 'Goa has specific regulations for short-term rentals through Airbnb and similar platforms. Properties must have proper registration with Goa Tourism Department or operate as classified guest houses. Buildings with ongoing financial contributions to housing societies may face restrictions. Properties must comply with fire safety, health standards, and local zoning regulations. Tourist area properties have different rules than residential neighborhoods.' },
  { q: 'Do I need tourism department approval to list on Airbnb in Goa?', a: 'Tourism Department approval is increasingly important. Properties should ideally have tourism license or homestay registration for credibility and legal compliance. Without official registration, you face operational risks and potential enforcement action. Registered properties appear in tourism databases, improving visibility beyond just Airbnb. Registration also qualifies properties for tourism incentives and schemes.' },
  { q: 'What is the homestay policy in Goa for Airbnb listings?', a: 'Homestay policy encourages owner-occupied properties offering authentic Goan hospitality. Regulations require: property owner involvement in guest services, limited number of rooms (typically 5-20), adherence to local zoning laws, and maintenance of residential character. Homestay properties face lower licensing complexity than commercial hotels but must still comply with fire safety and health standards.' },
  { q: 'Is GST required for Airbnb rental income in Goa?', a: 'Yes, GST is applicable on short-term accommodation rental income if annual turnover exceeds ₹20 lakhs. GST rate for homestays is 5%, for other rentals varies. You must: register for GST, maintain detailed records of bookings and income, issue GST invoices, and file monthly/quarterly GST returns. Airbnb may assist with documentation, but compliance responsibility is yours.' },
  { q: 'What are tourism department rules for short-term rentals in Goa?', a: 'Tourism Department regulates short-term rentals through registration and compliance requirements. Rules include: registration with Directorate of Tourism or municipal authorities, adherence to fire safety and health standards, payment of applicable taxes, compliance with local municipal regulations, and residential area restrictions. Unregistered properties risk enforcement action and property seizure. Registration provides credibility and legal protection.' },
  { q: 'What compliance checklist should I follow for Airbnb in Goa?', a: 'Comprehensive compliance checklist: Register with Goa Tourism or Municipal authorities, obtain Fire Safety NOC, ensure Health Trade License compliance, register for GST if applicable, maintain house rules and guest policies, regular property maintenance and cleanliness standards, safety features (first aid, fire extinguishers), accurate listing information, responsive guest communication, proper income declaration for tax purposes, and annual license renewals.' },
];

export default function AirbnbRulesInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Airbnb Rules in Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Airbnb Regulations · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Airbnb Rules in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Complete guide to Airbnb regulations and rules in Goa. Learn about tourism department requirements, homestay policy, GST compliance, registration obligations, and essential compliance checklist for legal Airbnb operations.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20help%20with%20Airbnb%20rules%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Goa Airbnb Regulations Overview</h2>
              <div className="grid md:grid-cols-2 gap-8">
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Tourism Department Approval</h3>
                  <p className="text-white/70 mb-4">Goa Directorate of Tourism encourages regulated short-term rentals through official registration. Properties should have tourism license, guest house classification, or homestay certification. Registration provides: legal legitimacy, credibility with guests and platforms, eligibility for tourism incentives, and protection from enforcement action. Unregistered properties face risk of operational disruption.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Official tourism department listing
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Legal compliance documentation
                    </li>
                  </ul>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Local Municipal Rules</h3>
                  <p className="text-white/70 mb-4">Municipal Corporations regulate Airbnb operations through zoning, housing society approvals, and fire/health standards. Rules vary by area: tourist zones have different regulations than residential neighborhoods. Properties in housing societies require General Body approval. Fire safety, water supply, and waste management compliance is mandatory. Municipal approval ensures legal operation without disruption.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Municipal zoning compliance
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Housing society permissions
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Compliance Requirements & Standards</h2>
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <h3 className="heading-md text-white mb-4">Fire Safety Standards</h3>
                  <p className="text-white/70">Airbnb properties must meet fire safety standards: emergency exit routes and signage, fire extinguishers on all floors, emergency lighting, first aid kits, and clear evacuation procedures. Properties should undergo Fire Department inspection or NOC verification. Many enforcement issues stem from fire safety violations, making this compliance critical.</p>
                </div>
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <h3 className="heading-md text-white mb-4">Health & Cleanliness Standards</h3>
                  <p className="text-white/70">Health Department standards require: regular property cleaning and sanitation, pest control measures, clean water supply and testing, proper food handling if meals provided, waste management systems, and maintenance of hygiene standards. High cleanliness standards improve Airbnb ratings and guest satisfaction. Health Department can conduct inspections and issue notices for violations.</p>
                </div>
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <h3 className="heading-md text-white mb-4">GST & Tax Compliance</h3>
                  <p className="text-white/70">GST registration is mandatory for annual rental income exceeding ₹20 lakhs. GST rate: 5% for homestays, 12-28% for other accommodations. Compliance requires: GST registration and regular returns, accurate income declaration in tax returns, maintenance of booking records and invoices, coordination with Airbnb for payment documentation. Tax compliance avoids penalties and demonstrates legitimate business operation.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Airbnb Compliance Checklist</h2>
              <div className="grid md:grid-cols-2 gap-8 max-w-3xl mx-auto">
                {[
                  'Register with Goa Tourism Department or municipality',
                  'Obtain Fire Safety NOC or certification',
                  'Ensure Health Trade License compliance',
                  'Register for GST (if income exceeds ₹20 lakhs)',
                  'Get housing society approval (if applicable)',
                  'Maintain fire extinguishers and first aid kits',
                  'Ensure clean water supply and sanitation',
                  'Create house rules and guest policies',
                  'Maintain high cleanliness standards',
                  'Keep accurate booking and payment records',
                  'Declare rental income in tax returns',
                  'Renew licenses and certifications annually',
                ].map((item, i) => (
                  <div key={i} className="flex items-start gap-3 p-4 rounded-xl border border-white/8 bg-white/4">
                    <CheckCircle2 size={20} className="text-accent mt-1 shrink-0" />
                    <span className="text-white/70 text-sm">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Related Services</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <a href="/property-management-goa" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Property Management Goa</h3>
                  <p className="text-white/70 mb-4">Ensure Airbnb compliance and optimize your property management.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/vision-mission" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Our Vision & Mission</h3>
                  <p className="text-white/70 mb-4">Learn about our commitment to Airbnb host success in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/founders" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Meet Our Founders</h3>
                  <p className="text-white/70 mb-4">Discover expertise in Airbnb compliance and operations in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Airbnb Regulations FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-64' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer" itemScope itemType="https://schema.org/Answer"><span itemProp="text">{faq.a}</span></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ensure Airbnb Compliance in Goa</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Let us help you navigate Airbnb regulations, obtain required approvals, and ensure full compliance for legal and successful property management in Goa.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20help%20with%20Airbnb%20rules%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="/" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
