import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Wine } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'How do you grow a bar business in Goa?', a: 'We combine digital optimization (Zomato, Google, social media) with experiential activations. DJ nights, live music, themed parties, and OTA Studio community activations drive consistent footfall and build loyal patrons.' },
  { q: 'What is the best bar activation strategy?', a: 'Recurring events create predictable revenue. Weekly DJ nights, monthly themed parties, live music performances, and special celebrations ensure your bar becomes a destination with packed crowds.' },
  { q: 'How do you book quality DJs and musicians?', a: 'Our Partner Network includes verified DJs, live musicians, and performers across Goa. We handle all bookings, technical setup, promotion, and execution to guarantee quality events.' },
  { q: 'How much revenue can bar activations generate?', a: 'Bars with consistent activations see 2-3x weeknight revenue increase and 60-80% higher weekend traffic. Monthly recurring events create predictable 35-50% revenue growth.' },
  { q: 'Do you handle bar promotion and marketing?', a: 'Yes. We manage social media promotion, WhatsApp communities, influencer outreach, Google Business optimization, and Zomato visibility for every event.' },
  { q: 'What makes a bar community successful?', a: 'Consistency, quality experiences, and community focus. Regular patrons who anticipate your events, bring friends, and become your best promoters.' },
];

const services = [
  'Bar growth strategy and market analysis',
  'Google and Zomato Business optimization',
  'DJ and live music curation',
  'Event design and programming',
  'Themed party and activation planning',
  'Social media and promotional strategy',
  'Community building and loyalty programs',
  'Monthly performance reporting',
];

const activations = [
  'Weekly DJ nights',
  'Live music performances',
  'Karaoke events',
  'Stand-up comedy shows',
  'Trivia and game nights',
  'Themed party nights',
  'Seasonal celebrations',
  'Member-exclusive events',
];

export default function BarGrowthGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Bar Growth Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Bar Growth · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Bar Growth Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Complete bar growth service combining digital optimization with experiential activations. DJ nights, live music, themed parties, and community building drive consistent footfall and 2-3x revenue growth.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20grow%20my%20bar" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Grow My Bar <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20a%20Bar%20Audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Get A Bar Audit
                </a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What We Deliver</h2>
                  <p className="body-md mb-8">Complete bar growth service for maximum revenue and customer loyalty.</p>
                  <ul className="space-y-3">
                    {services.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Wine size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Bar Activations</h3>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {activations.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-white/70">
                        <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                        {item}
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '3x', label: 'Weeknight Revenue' },
                      { metric: '2x', label: 'Weekend Footfall' },
                      { metric: '20+', label: 'DJs & Artists' },
                      { metric: '50%', label: 'Growth Average' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-8">Bar Growth Methodology</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Digital Optimization</h3>
                  <p className="text-white/70 text-sm">Google Business, Zomato, and social media optimization ensures your bar appears first when people search for nightlife in Goa.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Event Programming</h3>
                  <p className="text-white/70 text-sm">Recurring DJ nights, live music, and themed parties create reasons for people to visit repeatedly and bring friends.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Community Activation</h3>
                  <p className="text-white/70 text-sm">Build a loyal patron base through member programs, exclusive events, and consistent engagement that turns visitors into regulars.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Bar Growth FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Transform Your Bar Into A Destination</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Consistent activations and digital visibility drive 2-3x revenue growth and packed crowds.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Grow My Bar</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
