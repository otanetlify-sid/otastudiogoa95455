import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Wine } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'How do you market bars in Goa?', a: 'We combine digital optimization (Zomato, Google, social) with curated nightlife activations — DJ nights, live music, themed parties — to drive consistent footfall and revenue.' },
  { q: 'What bar activations work in Goa?', a: 'DJ nights, live music, karaoke, comedy shows, trivia nights, and themed parties. Each is tailored to your venue vibe and target audience.' },
  { q: 'Do you provide DJ bookings?', a: 'Yes. Our Partner Network includes curated DJs, musicians, and performers across Goa. We handle booking, coordination, and execution.' },
  { q: 'How do you promote bar events?', a: 'Targeted social media, WhatsApp communities, influencer outreach, and OTA cross-promotion to build audiences for every activation.' },
  { q: 'Can you run recurring nightlife events?', a: 'Absolutely. Recurring events like weekly DJ nights or monthly themed parties are the most effective way to build a loyal crowd.' },
];

const includes = [
  'Zomato and Google Business Profile optimization',
  'Photo and content strategy for bar listings',
  'Review response and reputation management',
  'DJ night and live music curation',
  'Themed party and event design',
  'Karaoke and comedy night programming',
  'Social media amplification for events',
  'Monthly performance and footfall reports',
];

const activations = [
  'Live music curation',
  'DJ nights and electronic sessions',
  'Karaoke nights',
  'Stand-up comedy shows',
  'Trivia and game nights',
  'Themed party nights',
];

export default function BarMarketingGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white" itemProp="name">Bar Marketing Goa</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Bar Marketing · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Bar Marketing Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Marketing and hospitality activations for bars in Goa. DJ nights, live music, themed parties, and digital optimization — we create the experiences that pack your bar and build a loyal crowd.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20need%20help%20marketing%20my%20bar%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Market My Bar <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20a%20Venue%20Audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Get A Venue Audit
                </a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What We Deliver</h2>
                  <p className="body-md mb-8">Complete bar marketing and activation service for maximum visibility and footfall.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Wine size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Bar Activations</h3>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {activations.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-white/70">
                        <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                        {item}
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '2x', label: 'Weeknight Revenue' },
                      { metric: '3x', label: 'Weekend Footfall' },
                      { metric: '15+', label: 'DJs & Artists' },
                      { metric: '85%', label: 'Repeat Attendance' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Bar Marketing FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Pack Your Goa Bar</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Curated nightlife activations that build loyal crowds and revenue.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Market My Bar</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
