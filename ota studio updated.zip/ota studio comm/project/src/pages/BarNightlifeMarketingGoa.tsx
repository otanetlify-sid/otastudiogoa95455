import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Wine } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'How do you market bars and nightlife venues in Goa?', a: 'We combine digital presence optimization (Zomato, Google, social) with curated nightlife activations — live music, DJ nights, karaoke, comedy, and themed parties — to drive consistent footfall and revenue.' },
  { q: 'What nightlife activations do you offer?', a: 'We offer live music curation, DJ nights, karaoke nights, stand-up comedy shows, trivia and game nights, and themed party nights. Each is tailored to your venue and audience.' },
  { q: 'Do you provide DJ and artist bookings?', a: 'Yes. Our Partner Network includes curated DJs, musicians, comedians, and performers across Goa. We handle booking, coordination, and execution.' },
  { q: 'How do you promote nightlife events?', a: 'We use targeted social media, WhatsApp communities, influencer outreach, and OTA cross-promotion to build audiences for every activation.' },
  { q: 'Can you run recurring nightlife events?', a: 'Absolutely. Recurring events (weekly live music, monthly themed nights) are the most effective way to build a loyal audience. We design and manage ongoing schedules.' },
];

const includes = [
  'Nightlife venue digital optimization', 'Google Business Profile and Zomato management',
  'Live music and DJ night curation', 'Karaoke, comedy, and themed party design',
  'Artist booking and talent management', 'Event marketing and audience building',
  'Social media amplification', 'Recurring schedule planning and execution',
];

export default function BarNightlifeMarketingGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white" itemProp="name">Bar & Nightlife Marketing Goa</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Bar & Nightlife Marketing · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Bar & Nightlife Marketing Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Marketing and activations for bars and nightlife venues in Goa. From DJ nights to comedy shows,
                we create experiences that pack your venue and build a loyal crowd.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20need%20marketing%20for%20my%20bar%2Fnightlife%20venue%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Market My Venue <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20a%20nightlife%20venue%20audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Get A Venue Audit
                </a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What Bar & Nightlife Marketing Includes</h2>
                  <p className="body-md mb-8">Digital optimization and nightlife activations for Goa bars.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 rounded-lg bg-accent/15 flex items-center justify-center">
                      <Wine size={20} className="text-accent" />
                    </div>
                    <h3 className="font-display font-bold text-xl text-white">Nightlife Activations</h3>
                  </div>
                  <div className="space-y-3 mb-6">
                    {['Live music curation', 'DJ nights and electronic sessions', 'Karaoke nights', 'Stand-up comedy shows', 'Trivia & game nights', 'Themed party nights'].map((item, i) => (
                      <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-white/4 border border-white/8">
                        <CheckCircle2 size={16} className="text-accent shrink-0" />
                        <span className="text-sm text-white/70">{item}</span>
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '2x', label: 'Weeknight Revenue' },
                      { metric: '3x', label: 'Weekend Footfall' },
                      { metric: '15+', label: 'DJs & Artists' },
                      { metric: '85%', label: 'Repeat Attendance' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Bar & Nightlife Marketing FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Pack Your Goa Venue</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Curated nightlife activations that build loyal crowds and revenue.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20need%20marketing%20for%20my%20bar%2Fnightlife%20venue%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary">Market My Venue</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
