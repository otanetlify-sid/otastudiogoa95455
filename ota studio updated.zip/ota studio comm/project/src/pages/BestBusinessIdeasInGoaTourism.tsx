import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What is the most profitable tourism business idea in Goa?', a: 'Resort and luxury property management typically offers highest profitability with proper OTA optimization. However, profitability depends on your capital investment capacity. Budget guesthouses can achieve 40-50% margins with lower investment. Premium resorts achieve 60%+ margins but require ₹2-8 crore investment. Water sports and adventure tourism offer 50-70% margins with lower capital requirements. Choose based on your investment capacity and expertise.' },
  { q: 'What is the minimum investment required for tourism business ideas in Goa?', a: 'Investment varies significantly: Budget guesthouses (₹30-50 lakhs), mid-range hotels (₹1-2 crores), water sports operations (₹5-15 lakhs), tour guide services (₹1-3 lakhs), and restaurant operations (₹20-50 lakhs). Start-up tourism consulting and property management require minimal investment (₹3-5 lakhs). Consider capital constraints when selecting your business model.' },
  { q: 'How can OTA Studio support different tourism business ideas?', a: 'OTA Studio provides specialized support: property management and OTA optimization for accommodation businesses, reservation system integration for restaurants and activities, guest experience management, revenue optimization tools, multi-channel listing management, and marketing automation. Our support helps maximize bookings and revenue regardless of your tourism business type.' },
  { q: 'What tourism businesses have the fastest ROI in Goa?', a: 'Water sports activities, adventure tourism, and tour guide services typically offer quickest ROI (6-12 months) due to lower capital requirements. F&B businesses and restaurants achieve ROI in 12-18 months. Guesthouses and budget hotels achieve ROI in 18-24 months. Luxury resorts require 3-5 years for ROI due to higher initial investment but generate higher absolute returns.' },
  { q: 'Are there government incentives for tourism businesses in Goa?', a: 'Yes, Goa offers incentives for tourism businesses: tax holidays for new hospitality units, subsidy on infrastructure development, stamp duty exemptions, and promotional support through tourism board. Registered properties with tourism licenses qualify for these schemes. Incentives vary based on location, classification, and business type. Registration with Goa Tourism Department unlocks these benefits.' },
  { q: 'How do I choose the right tourism business idea for my skills and capital?', a: 'Evaluate your strengths: Capital availability (determines property vs service-based models), operational experience (hospitality, F&B, or adventure tourism), local network (for activities and guides), and risk tolerance. Match your profile with business models: Service-based businesses (tours, guides) suit lower capital; property management requires significant investment but offers stability; F&B businesses suit experienced hospitality operators. Start with aligned business model.' },
];

export default function BestBusinessIdeasInGoaTourism() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Best Business Ideas in Goa Tourism</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Business Ideas · Goa Tourism</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Best Business Ideas in Goa Tourism</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Explore the top tourism business ideas in Goa with investment ranges, market potential, and OTA Studio support for each model. From budget guesthouses to luxury resorts, adventure tourism to restaurants, discover which business aligns with your capital and expertise.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20explore%20tourism%20business%20ideas%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Top Tourism Business Models in Goa</h2>
              <div className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                    <h3 className="heading-md text-white mb-2">Budget Guesthouses</h3>
                    <p className="text-white/70 mb-4 text-sm">Entry-level hospitality option targeting budget-conscious tourists and backpackers.</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between"><span className="text-white/50">Investment:</span><span className="text-white">₹30-50 lakhs</span></div>
                      <div className="flex justify-between"><span className="text-white/50">ROI Timeline:</span><span className="text-white">18-24 months</span></div>
                      <div className="flex justify-between"><span className="text-white/50">Profit Margin:</span><span className="text-white">40-50%</span></div>
                      <div className="flex justify-between"><span className="text-white/50">Annual Turnover:</span><span className="text-white">₹15-25 lakhs</span></div>
                    </div>
                  </div>
                  <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                    <h3 className="heading-md text-white mb-2">Mid-Range Hotels (3-Star)</h3>
                    <p className="text-white/70 mb-4 text-sm">Comfortable hotels targeting business and leisure travelers.</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between"><span className="text-white/50">Investment:</span><span className="text-white">₹1-2 crores</span></div>
                      <div className="flex justify-between"><span className="text-white/50">ROI Timeline:</span><span className="text-white">2-3 years</span></div>
                      <div className="flex justify-between"><span className="text-white/50">Profit Margin:</span><span className="text-white">50-60%</span></div>
                      <div className="flex justify-between"><span className="text-white/50">Annual Turnover:</span><span className="text-white">₹50-100 lakhs</span></div>
                    </div>
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                    <h3 className="heading-md text-white mb-2">Luxury Resorts (4-5 Star)</h3>
                    <p className="text-white/70 mb-4 text-sm">Premium properties targeting high-value international tourists.</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between"><span className="text-white/50">Investment:</span><span className="text-white">₹2-8 crores</span></div>
                      <div className="flex justify-between"><span className="text-white/50">ROI Timeline:</span><span className="text-white">3-5 years</span></div>
                      <div className="flex justify-between"><span className="text-white/50">Profit Margin:</span><span className="text-white">60-70%</span></div>
                      <div className="flex justify-between"><span className="text-white/50">Annual Turnover:</span><span className="text-white">₹1-3 crores</span></div>
                    </div>
                  </div>
                  <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                    <h3 className="heading-md text-white mb-2">Restaurants & Cafes</h3>
                    <p className="text-white/70 mb-4 text-sm">F&B establishments targeting tourists and local communities.</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between"><span className="text-white/50">Investment:</span><span className="text-white">₹20-50 lakhs</span></div>
                      <div className="flex justify-between"><span className="text-white/50">ROI Timeline:</span><span className="text-white">12-18 months</span></div>
                      <div className="flex justify-between"><span className="text-white/50">Profit Margin:</span><span className="text-white">35-45%</span></div>
                      <div className="flex justify-between"><span className="text-white/50">Annual Turnover:</span><span className="text-white">₹30-80 lakhs</span></div>
                    </div>
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                    <h3 className="heading-md text-white mb-2">Water Sports & Adventure</h3>
                    <p className="text-white/70 mb-4 text-sm">Adventure tourism offering water sports and activity packages.</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between"><span className="text-white/50">Investment:</span><span className="text-white">₹5-15 lakhs</span></div>
                      <div className="flex justify-between"><span className="text-white/50">ROI Timeline:</span><span className="text-white">6-12 months</span></div>
                      <div className="flex justify-between"><span className="text-white/50">Profit Margin:</span><span className="text-white">50-70%</span></div>
                      <div className="flex justify-between"><span className="text-white/50">Annual Turnover:</span><span className="text-white">₹15-40 lakhs</span></div>
                    </div>
                  </div>
                  <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                    <h3 className="heading-md text-white mb-2">Guided Tours & Travel Guides</h3>
                    <p className="text-white/70 mb-4 text-sm">Tourism service offering local expertise and guided experiences.</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between"><span className="text-white/50">Investment:</span><span className="text-white">₹1-3 lakhs</span></div>
                      <div className="flex justify-between"><span className="text-white/50">ROI Timeline:</span><span className="text-white">3-6 months</span></div>
                      <div className="flex justify-between"><span className="text-white/50">Profit Margin:</span><span className="text-white">60-75%</span></div>
                      <div className="flex justify-between"><span className="text-white/50">Annual Turnover:</span><span className="text-white">₹10-25 lakhs</span></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">OTA Studio Support by Business Type</h2>
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <h3 className="heading-md text-white mb-4">Property Management Businesses</h3>
                  <p className="text-white/70 mb-4">For guesthouses, hotels, and resorts: OTA optimization for Booking.com, Agoda, Expedia. Professional listing optimization, dynamic pricing management, revenue optimization, review reputation management, multi-channel coordination, and guest communication systems.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Maximize bookings across 10+ OTA platforms
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Increase occupancy rates by 25-40%
                    </li>
                  </ul>
                </div>
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <h3 className="heading-md text-white mb-4">F&B & Restaurant Businesses</h3>
                  <p className="text-white/70 mb-4">For restaurants and cafes: Swiggy, Zomato, Google Maps optimization. Menu management, online ordering system integration, reservation management, food photography and presentation, review management, and customer engagement tools.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Increase delivery orders and walk-ins
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Boost online visibility and customer ratings
                    </li>
                  </ul>
                </div>
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <h3 className="heading-md text-white mb-4">Adventure & Activity Businesses</h3>
                  <p className="text-white/70 mb-4">For water sports and adventure tourism: Viator, GetYourGuide, activity OTA listings. Activity package optimization, booking system integration, pricing strategy, customer reviews and ratings management, and dynamic scheduling.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Connect with global adventure seekers
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Maximize booking rates and pricing
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Related Services</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <a href="/property-management-goa" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Property Management Goa</h3>
                  <p className="text-white/70 mb-4">Maximize profits from your tourism property investment.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/vision-mission" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Our Vision & Mission</h3>
                  <p className="text-white/70 mb-4">Learn about our commitment to tourism business growth in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/founders" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Meet Our Founders</h3>
                  <p className="text-white/70 mb-4">Discover the expertise behind successful Goa tourism ventures.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Business Ideas FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-64' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer" itemScope itemType="https://schema.org/Answer"><span itemProp="text">{faq.a}</span></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Find Your Best Tourism Business Idea</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Let us help you evaluate your options, assess market potential, and launch your tourism business idea in Goa with OTA Studio's comprehensive support.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20explore%20tourism%20business%20ideas%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="/" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
