import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const posts = [
  { title: 'OTA Onboarding Guide', category: 'OTA Onboarding', excerpt: 'Step-by-step guide to getting your property listed on major OTAs.', slug: '/blog/ota-onboarding-guide' },
  { title: 'Booking.com Setup Guide', category: 'Booking.com', excerpt: 'How to create, verify, and optimize your Booking.com listing.', slug: '/blog/booking-com-setup-guide' },
  { title: 'Airbnb Setup Guide', category: 'Airbnb', excerpt: 'Complete walkthrough for launching your Airbnb listing.', slug: '/blog/airbnb-setup-guide' },
  { title: 'OTA Management Guide', category: 'OTA Management', excerpt: 'Understanding ongoing OTA management and optimization.', slug: '/blog/ota-management-guide' },
  { title: 'Hotel Distribution Guide', category: 'Distribution', excerpt: 'Understanding channel managers and multi-OTA distribution.', slug: '/blog/hotel-distribution-guide' },
  { title: 'Channel Manager vs PMS', category: 'Technology', excerpt: 'Differences between channel managers and property management systems.', slug: '/blog/channel-manager-vs-pms' },
  { title: 'How to Increase Hotel Occupancy', category: 'Revenue', excerpt: 'Strategies to improve your property occupancy through OTAs.', slug: '/blog/how-to-increase-hotel-occupancy' },
  { title: 'How to Improve Hotel Revenue', category: 'Revenue', excerpt: 'Revenue optimization strategies for hospitality businesses.', slug: '/blog/how-to-improve-hotel-revenue' },
];

export default function BlogPage() {
  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <div className="relative overflow-hidden bg-neutral-950 py-20">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
              <ol className="flex items-center gap-2">
                <li><a href="/" className="hover:text-white">Home</a></li>
                <li>/</li>
                <li className="text-white">Blog</li>
              </ol>
            </nav>
            <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Insights & Resources</span>
            <h1 className="heading-xl text-white mb-4">Hospitality Growth Insights</h1>
            <p className="body-lg text-lg max-w-3xl">
              OTA management tips, revenue strategies, and hospitality growth guides
              for hotels, villas, Airbnb properties, and more.
            </p>
          </div>
        </div>

        <section className="bg-neutral-900 py-16 sm:py-20">
          <div className="section-max section-padding">
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {posts.map((post, i) => (
                <article key={i} className="group p-6 rounded-2xl border border-white/8 bg-white/4 hover:bg-white/10 hover:border-accent/30 transition-all">
                  <div className="h-40 bg-white/4 flex items-center justify-center mb-4 rounded-xl">
                    <span className="text-xs font-medium text-white/40 px-3 py-1.5 rounded-full border border-white/8">Coming Soon</span>
                  </div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-semibold text-accent uppercase tracking-wide">{post.category}</span>
                  </div>
                  <h2 className="font-display font-bold text-base text-white mb-2 group-hover:text-accent transition-colors">{post.title}</h2>
                  <p className="text-sm text-white/50 leading-relaxed line-clamp-2">{post.excerpt}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="bg-neutral-950 py-16 sm:py-20 text-center">
          <div className="section-max section-padding">
            <h2 className="heading-lg text-white mb-4">Want Personalized Hospitality Advice?</h2>
            <p className="text-white/50 mb-8 max-w-xl mx-auto">Get a free Property Growth Audit today.</p>
            <a href="https://wa.me/919270598602" target="_blank" rel="noopener noreferrer" className="btn-primary">Get A Property Growth Audit</a>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
