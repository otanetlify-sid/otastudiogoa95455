import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, TrendingUp, Star, Zap } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'Why is Booking.com management crucial for Goa hotels?', a: 'Booking.com is one of the most visited travel websites globally and drives 40%+ of bookings for Goa properties. Professional management ensures your listing ranks high, attracts more guests, and maximizes revenue from this critical channel.' },
  { q: 'How do you optimize Booking.com rankings?', a: 'We optimize through photographic quality, compelling descriptions, competitive pricing, review management, response times, and keyword targeting. Higher review scores and faster response rates directly improve your search ranking position.' },
  { q: 'What is Booking.com rate management?', a: 'Rate management ensures your prices remain competitive while maximizing revenue. We monitor competitor rates daily, adjust for demand seasonality, and maintain price parity across other OTAs to prevent revenue leakage.' },
  { q: 'How long before I see ranking improvements?', a: 'Most properties see search ranking improvements within 2-4 weeks of optimization. Booking-related improvements typically follow within 30-60 days as the algorithm recognizes improvements in your performance metrics.' },
  { q: 'Do you handle guest communication on Booking.com?', a: 'Yes, we manage all guest inquiries, booking confirmations, and reviews. Quick, professional responses significantly boost your ranking score and build the reputation that drives more bookings.' },
  { q: 'Can you recover properties penalized by Booking.com?', a: 'Yes, we help properties improve metrics that led to ranking penalties, including response times, review scores, and guest satisfaction metrics.' },
];

const includes = [
  'Booking.com listing optimization and SEO enhancement',
  'Professional photo sequencing and quality review',
  'Compelling title and description copywriting',
  'Rate management and price monitoring',
  'Guest communication and response management',
  'Review strategy and reputation building',
  'Ranking improvement through metadata optimization',
  'Monthly performance analytics and reporting',
];

export default function BookingComManagementGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Booking.com Management Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Booking.com Management · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Booking.com Management Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Expert Booking.com management for Goa hotels, resorts, villas, and hostels. We optimize your listings, improve rankings,
                manage rates strategically, and maximize bookings on the world's largest OTA platform.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20Booking.com%20management%20for%20my%20Goa%20property" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Grow Your Booking.com Bookings <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">Booking.com Management Includes</h2>
                  <p className="body-md text-white/70 mb-8">Complete Booking.com optimization and management to maximize visibility and bookings.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <h3 className="font-display font-bold text-xl text-white mb-6">Results We Deliver</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '4.8+', label: 'Average Guest Rating' },
                      { metric: '250%', label: 'Booking Increase' },
                      { metric: '2-4', label: 'Weeks to Top Rankings' },
                      { metric: '100+', label: 'Properties Managed' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid md:grid-cols-3 gap-8 mb-16">
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <TrendingUp size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Revenue Optimization</h3>
                  <p className="text-white/70 mb-4">We analyze market demand, competitor pricing, and seasonal trends to set optimal rates that maximize revenue per available room. Our dynamic pricing strategy captures every opportunity without sacrificing occupancy.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Daily rate monitoring and adjustment
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Event-based pricing surge capture
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Seasonal demand optimization
                    </li>
                  </ul>
                </div>

                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <Star size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Listing Optimization</h3>
                  <p className="text-white/70 mb-4">Professional photos, compelling descriptions, and strategic keyword placement ensure your property stands out in search results. We optimize every element that influences click-through rates and bookings.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Professional photo sequencing
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      SEO-optimized titles and descriptions
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Amenity highlighting and positioning
                    </li>
                  </ul>
                </div>

                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <Zap size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Ranking Improvement</h3>
                  <p className="text-white/70 mb-4">Booking.com's algorithm prioritizes response speed, review scores, and guest satisfaction. We implement strategies to boost all these metrics, ensuring your property climbs search rankings and gets more visibility.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Sub-1 hour response times
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Review score maximization
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Algorithm-aligned optimization
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Benefits for Goa Hotels</h2>
              <div className="grid md:grid-cols-2 gap-8">
                {[
                  'Access to millions of Booking.com users searching for Goa accommodations',
                  'Booking.com is the #1 source of bookings for Indian hotels and resorts',
                  'Higher search rankings mean more visibility and organic bookings without paid ads',
                  'Strategic rate management maximizes revenue without losing occupancy',
                  'Professional review management builds trust and attracts quality guests',
                  'Real-time monitoring ensures you never miss booking opportunities',
                  'Competitive advantage through superior listing presentation',
                  'Complete guest communication in one place with professional templates',
                ].map((benefit, i) => (
                  <div key={i} className="flex items-start gap-4 p-6 rounded-xl border border-white/8 bg-white/4">
                    <CheckCircle2 size={24} className="text-accent mt-1 shrink-0" />
                    <p className="text-white/70">{benefit}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Why Choose Us for Booking.com?</h2>
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Goa Market Expertise</h3>
                  <p className="text-white/70">We understand the unique Goa tourism market, seasonal patterns, guest expectations, and local competition. This expertise translates to better optimization and higher performance.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Booking.com Algorithm Knowledge</h3>
                  <p className="text-white/70">We stay updated on Booking.com's ranking algorithm changes and optimization best practices. We implement strategies that align with their current priorities to maximize your visibility.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Proven Track Record</h3>
                  <p className="text-white/70">100+ Goa properties now rank in top positions on Booking.com under our management. Average booking increase: 250%. Average guest rating improvement: 0.5+ points.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Related Services</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <a href="/property-management-goa" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Property Management Goa</h3>
                  <p className="text-white/70 mb-4">Complete property management including OTA management, operations, and revenue optimization.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/vision-mission" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Our Vision & Mission</h3>
                  <p className="text-white/70 mb-4">Learn about our approach to hospitality growth and property management excellence in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/founders" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Meet Our Founders</h3>
                  <p className="text-white/70 mb-4">Discover the team behind successful Booking.com management strategies for Goa properties.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Booking.com Management FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-64' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ready to Maximize Your Booking.com Revenue?</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Let's optimize your Booking.com listing and get you ranking higher, attracting more guests, and earning more revenue.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20Booking.com%20management%20for%20my%20property" target="_blank" rel="noopener noreferrer" className="btn-primary">Start Growing Your Bookings</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
