import { useState } from 'react';
import { ChevronDown, Coffee, Users, Sparkles, Heart } from 'lucide-react';
import PageLayout from '../components/PageLayout';
import Breadcrumbs from '../components/Breadcrumbs';

const faqs = [
  {
    q: 'How do community events help cafes build a loyal customer base?',
    a: 'Community events transform cafes into gathering spaces where customers return not just for coffee, but for experiences and connections. Regular attendees become loyal customers who visit more frequently, spend more per visit, and recommend the cafe to others. Event attendees become your core community.',
  },
  {
    q: 'What types of community events work best for cafes in Goa?',
    a: 'Open mic nights, acoustic music sessions, art exhibitions, book clubs, writing circles, coffee tastings, creative workshops, and networking brunches all work beautifully. The best events align with your cafe brand and attract customers who want community alongside their coffee.',
  },
  {
    q: 'How often should cafes host community events?',
    a: 'Weekly recurring events build strong community momentum. Many successful cafes host 2-3 events per week (e.g., open mics, art nights, book clubs). Consistency matters more than frequency—regulars build anticipation for your events.',
  },
  {
    q: 'Can small cafes afford to run community events?',
    a: 'Absolutely. Community events often cost very little to organize. Open mics, art displays, and writing circles require minimal investment but create huge value. Small cafes often build tighter, more engaged communities than larger venues.',
  },
  {
    q: 'How do you measure the success of cafe community events?',
    a: 'We track attendance, average check size on event nights, repeat visitor rates, social media engagement, and customer retention. Event attendees typically spend more and visit more frequently than non-attendees.',
  },
  {
    q: 'How do you promote cafe community events?',
    a: 'We promote through social media, email newsletters, Google Business Profile, local partnerships, and word-of-mouth. Building a regular event subscriber base is key to packed events.',
  },
];

const services = [
  {
    icon: Coffee,
    title: 'Event Curation & Programming',
    desc: 'Designing a recurring event calendar that builds community and aligns with your cafe brand. From open mics to art nights, we create experiences that bring people together.',
    features: [
      'Event type selection',
      'Weekly programming design',
      'Artist and host recruitment',
      'Thematic planning',
    ],
  },
  {
    icon: Users,
    title: 'Community Building & Engagement',
    desc: 'Creating a real community around your cafe. We build event subscriber lists, manage attendee relationships, and create experiences that turn customers into loyal friends.',
    features: [
      'Attendee database management',
      'Email and WhatsApp groups',
      'Regular event participants',
      'Community ambassador program',
    ],
  },
  {
    icon: Sparkles,
    title: 'Creative Workshops & Experiences',
    desc: 'Curating workshops—from creative writing to coffee tastings—that showcase your cafe as a cultural and creative hub, not just a coffee shop.',
    features: [
      'Workshop curation',
      'Instructor recruitment',
      'Experience design',
      'Skill-sharing programs',
    ],
  },
  {
    icon: Heart,
    title: 'Marketing & Audience Building',
    desc: 'Strategic promotion to build awareness of your events and attract the right community. Social media, email, partnerships, and word-of-mouth drive consistent, strong attendance.',
    features: [
      'Social media campaigns',
      'Email marketing',
      'Community partnerships',
      'Word-of-mouth strategies',
    ],
  },
];

export default function CafeCommunityBuildingGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <PageLayout
      title="Cafe Community Building in Goa | Build Loyal Customers | The OTA Studio"
      description="Cafe community building strategies in Goa. Creative workshops, open mics, coffee tastings and recurring community events to build a loyal customer base."
      canonical="https://otastudio.in/cafe-community-building-goa"
      schemaType="community"
    >
      <article>
        <div className="bg-neutral-950 pt-16 pb-20 sm:pt-20 sm:pb-28 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <div className="text-white/50 pb-2">
              <Breadcrumbs crumbs={[{ label: 'Community' }, { label: 'Cafe Community Building' }]} />
            </div>
            <div className="max-w-3xl">
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Community Events · Goa</span>
              <h1 className="heading-xl text-white mb-6">
                Cafe Community <br className="hidden sm:block" />
                <span className="text-accent">Building in Goa</span>
              </h1>
              <p className="text-base sm:text-xl text-white/70 leading-relaxed mb-8">
                Build a thriving community around your cafe. The OTA Studio designs and executes
                community events—open mics, art nights, workshops, and gatherings—that transform your
                cafe into a beloved community hub and turn casual customers into lifelong regulars.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20build%20community%20at%20my%20cafe"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary"
                >
                  Start Building Your Cafe Community
                </a>
                <a
                  href="https://wa.me/919309706263?text=Tell%20me%20about%20cafe%20community%20strategy"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-secondary"
                >
                  Get Community Strategy Consult
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="section-max section-padding py-16 sm:py-20 bg-neutral-900">
          <h2 className="heading-lg text-center text-white mb-12">
            Cafe Community Building Services
          </h2>
          <div className="grid sm:grid-cols-2 gap-6">
            {services.map((service, i) => (
              <div
                key={i}
                className="p-7 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/7 hover:shadow-[0_0_20px_rgba(255,208,0,0.05)] hover:-translate-y-1 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-5">
                  <service.icon size={22} className="text-accent" />
                </div>
                <h3 className="font-display font-bold text-xl text-white mb-3">{service.title}</h3>
                <p className="text-sm text-white/50 leading-relaxed mb-5">{service.desc}</p>
                <div className="flex flex-wrap gap-2">
                  {service.features.map((feature, j) => (
                    <span
                      key={j}
                      className="px-3 py-1 rounded-full bg-white/8 border border-white/8 text-xs font-medium text-white/60"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-neutral-950 py-16 sm:py-20 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="heading-lg text-white mb-6">
                  How We Build Cafe Communities
                </h2>
                <div className="space-y-4">
                  {[
                    { num: '1', title: 'Discovery & Brand Alignment', desc: 'Understanding your cafe vibe, target community, and brand personality to design fitting events.' },
                    { num: '2', title: 'Event Calendar Design', desc: 'Creating a recurring event schedule—weekly open mics, art nights, workshops—that builds anticipation.' },
                    { num: '3', title: 'Host & Talent Recruitment', desc: 'Finding musicians, artists, facilitators, and community leaders who embody your cafe brand.' },
                    { num: '4', title: 'Community Engagement', desc: 'Building attendee relationships through email lists, WhatsApp groups, and personalized connections.' },
                    { num: '5', title: 'Marketing & Promotion', desc: 'Social media, email, partnerships, and word-of-mouth to ensure consistent event attendance.' },
                    { num: '6', title: 'Loyalty & Retention', desc: 'Converting event attendees into regular customers who visit between events and become brand ambassadors.' },
                  ].map((step, i) => (
                    <div key={i} className="flex items-start gap-4">
                      <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center shrink-0">
                        <span className="font-display font-bold text-sm text-accent">{step.num}</span>
                      </div>
                      <div>
                        <div className="font-display font-bold text-white text-sm">{step.title}</div>
                        <div className="text-xs text-white/40 mt-0.5">{step.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div className="p-7 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white text-xl mb-6">
                    Community Event Ideas for Cafes
                  </h3>
                  <ul className="space-y-3">
                    {[
                      'Weekly open mic nights for musicians and poets',
                      'Art exhibitions and rotating local artist displays',
                      'Book clubs and literature discussions',
                      'Writing circles and creative workshops',
                      'Coffee tasting and barista skill-sharing',
                      'Acoustic music performances',
                      'Photography and visual art showcases',
                      'Networking brunches and professional meetups',
                      'Seasonal community celebrations',
                      'Creative skill workshops (art, writing, music)',
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 shrink-0" />
                        <span className="text-sm text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-neutral-900 py-16 sm:py-20 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-30" />
          <div className="section-max section-padding relative">
            <h2 className="heading-lg text-center text-white mb-12">
              Cafe Community Building FAQs — Goa
            </h2>
            <div className="max-w-3xl mx-auto space-y-3">
              {faqs.map((faq, i) => (
                <div
                  key={i}
                  className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden"
                >
                  <button
                    onClick={() => setOpenIdx(openIdx === i ? null : i)}
                    className="w-full flex items-center justify-between p-5 sm:p-6 text-left"
                    aria-expanded={openIdx === i}
                  >
                    <span className="font-display font-bold text-base sm:text-lg text-white pr-4">
                      {faq.q}
                    </span>
                    <ChevronDown
                      size={20}
                      className={`shrink-0 text-white/40 transition-transform duration-300 ${
                        openIdx === i ? 'rotate-180 text-accent' : ''
                      }`}
                    />
                  </button>
                  <div
                    className={`overflow-hidden transition-all duration-300 ${
                      openIdx === i ? 'max-h-48' : 'max-h-0'
                    }`}
                  >
                    <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-sm sm:text-base text-white/50 leading-relaxed">
                      {faq.a}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-neutral-950 py-16 sm:py-20 text-center relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <h2 className="heading-lg text-white mb-4">
              Make Your Cafe a Community Hub
            </h2>
            <p className="text-white/50 mb-8 max-w-xl mx-auto">
              Let The OTA Studio help you build a thriving community around your cafe.
              Create experiences that turn customers into lifelong regulars and brand ambassadors.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <a
                href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20build%20community%20at%20my%20cafe"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
              >
                Start Building Your Community
              </a>
              <a href="/" className="btn-secondary">
                Back to Home
              </a>
            </div>
          </div>
        </div>
      </article>
    </PageLayout>
  );
}
