import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'How do you market cafes in Goa?', a: 'We combine digital presence optimization (Zomato, Swiggy, Google) with curated activations like live acoustic nights, art pop-ups, and community events to drive both online orders and walk-in footfall.' },
  { q: 'What activations work best for cafes?', a: 'Acoustic nights, art exhibitions, pottery workshops, painting sessions, photography walks, and community meetups. These create shareable moments that drive social media visibility and repeat visits.' },
  { q: 'Which platforms do you optimize for cafes?', a: 'Zomato, Swiggy, Google Business Profile, and social media. We ensure your cafe is discoverable and appealing across every platform your customers use.' },
  { q: 'How quickly will I see results?', a: 'Online optimization improvements show within 2-4 weeks. Activation-driven footfall increases are visible from the first event, with compounding growth over recurring schedules.' },
  { q: 'Can you run weekly events at my cafe?', a: 'Yes. Recurring activations (weekly music, monthly art pop-ups) are the most effective way to build a loyal customer base. We design and manage ongoing schedules.' },
];

const includes = [
  'Zomato, Swiggy & Google Business Profile optimization',
  'Photo and content strategy for cafe listings',
  'Review response and reputation management',
  'Live music and acoustic night curation',
  'Art pop-up and creative workshop design',
  'Community event programming',
  'Social media amplification for activations',
  'Monthly performance and footfall reports',
];

export default function CafeMarketingGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white" itemProp="name">Cafe Marketing Goa</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Cafe Marketing · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Cafe Marketing Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Marketing and hospitality activations for cafes in Goa. From OTA optimization to live music nights, art pop-ups, and community events — we help cafes create experiences that fill seats and build loyal regulars.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20cafe%20marketing%20help%20for%20my%20Goa%20cafe" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Market My Cafe <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%27d%20like%20a%20Growth%20Audit%20for%20my%20cafe" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Get A Growth Audit
                </a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What Cafe Marketing Includes</h2>
                  <p className="body-md mb-8">Digital optimization plus curated activations for consistent footfall.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <h3 className="font-display font-bold text-xl text-white mb-6">Results We Deliver</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '3x', label: 'Online Visibility' },
                      { metric: '2.5x', label: 'Dine-in Footfall' },
                      { metric: '4.5', label: 'Avg Rating Improvement' },
                      { metric: '5+', label: 'Platforms Optimized' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Cafe Marketing FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Grow Your Goa Cafe</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Digital optimization + curated activations for consistent footfall.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602" target="_blank" rel="noopener noreferrer" className="btn-primary">Market My Cafe</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
