import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Music, Mic2, Laugh, Gamepad2, PartyPopper } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'What is community activation?', a: 'Community activation is about creating recurring, curated experiences at hospitality venues that build loyal audiences. Think live music nights, wellness sessions, art pop-ups — all designed to turn your venue into a community hub.' },
  { q: 'How does community activation help my venue?', a: 'Regular activations create repeat footfall, social media content, word-of-mouth, and higher spend per visit. They differentiate your venue from competitors and build a loyal customer base.' },
  { q: 'Do you organize events at your own space?', a: 'No. We are not a physical space. All activations happen at your venue. We bring the talent, concept, marketing, and execution.' },
  { q: 'How do you source talent for activations?', a: 'We have a curated network of musicians, DJs, yoga instructors, artists, and workshop creators across Goa. We match the right talent to your venue and audience.' },
  { q: 'Can I join the activation network as a creative professional?', a: 'Yes! Musicians, DJs, yoga instructors, artists, and workshop creators can join our Partner Network. Reach out via WhatsApp to apply.' },
];

const includes = [
  'Audience profiling and venue matching', 'Talent curation from our partner network',
  'Experience concept and theme design', 'Pre-activation marketing and audience building',
  'Day-of execution and coordination', 'Social media amplification',
  'Post-activation reporting and analytics', 'Recurring schedule planning',
];

const entertainmentTypes = [
  { icon: Music, label: 'Live Music' },
  { icon: Mic2, label: 'Karaoke Nights' },
  { icon: Laugh, label: 'Comedy Shows' },
  { icon: Gamepad2, label: 'Trivia & Games' },
  { icon: PartyPopper, label: 'Themed Parties' },
];

export default function CommunityActivationGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white" itemProp="name">Community Activation Goa</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Community Activation · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Community Activation Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Turn your venue into a community hub with curated activations. Live music, wellness sessions,
                creative pop-ups, and themed nights — all designed to build loyal audiences across Goa.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20community%20activations%20at%20my%20Goa%20venue" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Start Community Activation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20join%20the%20Activation%20Network%20as%20a%20creative" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Join as a Creative
                </a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What Community Activation Includes</h2>
                  <p className="body-md mb-8">Full-service community building for hospitality venues in Goa.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <h3 className="font-display font-bold text-xl text-white mb-6">Entertainment Activations</h3>
                  <div className="space-y-3 mb-6">
                    {entertainmentTypes.map((item, i) => (
                      <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-white/4 border border-white/8">
                        <div className="w-8 h-8 rounded-lg bg-accent/10 flex items-center justify-center">
                          <item.icon size={16} className="text-accent" />
                        </div>
                        <span className="text-sm text-white/70 font-medium">{item.label}</span>
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '40+', label: 'Community Events' },
                      { metric: '25+', label: 'Partner Creatives' },
                      { metric: '5x', label: 'Social Engagement' },
                      { metric: '60%', label: 'Repeat Visitors' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Community Activation FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Build Your Community in Goa</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Curated activations that turn your venue into a destination.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20community%20activations%20at%20my%20Goa%20venue" target="_blank" rel="noopener noreferrer" className="btn-primary">Start Community Activation</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
