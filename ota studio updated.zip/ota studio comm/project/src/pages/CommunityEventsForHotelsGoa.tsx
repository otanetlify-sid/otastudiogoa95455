import { useState } from 'react';
import { ChevronDown, Music, Users, Sparkles, Heart } from 'lucide-react';
import PageLayout from '../components/PageLayout';
import Breadcrumbs from '../components/Breadcrumbs';

const faqs = [
  {
    q: 'How do community events increase hotel bookings?',
    a: 'Community events create experiences that guests seek out and share on social media. They increase hotel visibility, generate word-of-mouth marketing, drive direct bookings from event attendees, and boost occupancy during low seasons. Events also enhance guest satisfaction and drive repeat visits.',
  },
  {
    q: 'What types of community events work best for hotels in Goa?',
    a: 'Yoga sessions, live music nights, wellness workshops, farm-to-table dining, cultural performances, networking events, and seasonal celebrations all perform well. The best events align with your target audience and hotel brand positioning.',
  },
  {
    q: 'How often should hotels host community events?',
    a: 'We recommend at least 2-4 events per month depending on your hotel size and location. Weekly recurring events (like weekly yoga) build community loyalty. Frequency depends on your target audience and operational capacity.',
  },
  {
    q: 'Can small hotels run successful community events?',
    a: 'Absolutely. Community events work for hotels of all sizes. Small properties often create more intimate, memorable experiences that guests prefer. The key is consistent execution, authentic positioning, and good curation.',
  },
  {
    q: 'How do you measure the success of community events?',
    a: 'We track attendance, direct bookings from event attendees, social media engagement, guest reviews mentioning events, repeat visit rates, and revenue impact. Clear metrics help optimize future events.',
  },
  {
    q: 'Do you handle event promotion and marketing?',
    a: 'Yes. We manage event promotion across social media, email, Google Business Profile, and local partnerships. Our strategy ensures maximum attendance and visibility for your hotel.',
  },
];

const services = [
  {
    icon: Music,
    title: 'Event Curation & Strategy',
    desc: 'We design a year-round event calendar aligned with your hotel brand, target audience, and seasonal opportunities. Each event is strategically planned to drive bookings and build community.',
    features: [
      'Event type selection and scheduling',
      'Brand alignment strategy',
      'Seasonal event planning',
      'Audience targeting',
    ],
  },
  {
    icon: Users,
    title: 'Artist & Vendor Management',
    desc: 'From live musicians to wellness instructors, we handle all talent acquisition, negotiations, coordination, and logistics. Your hotel hosts — we manage the rest.',
    features: [
      'Artist and performer booking',
      'Vendor coordination',
      'Contract negotiations',
      'Technical setup oversight',
    ],
  },
  {
    icon: Sparkles,
    title: 'Event Promotion & Marketing',
    desc: 'Maximum visibility through social media, email campaigns, Google Business Profile optimization, and local community partnerships to ensure strong attendance.',
    features: [
      'Social media promotion',
      'Email marketing campaigns',
      'Google Business updates',
      'Local partnership outreach',
    ],
  },
  {
    icon: Heart,
    title: 'Guest Experience & Conversion',
    desc: 'We ensure seamless guest experiences during events, optimize conversion from attendees to hotel guests, and manage post-event engagement for repeat bookings.',
    features: [
      'On-event coordination',
      'Guest journey optimization',
      'Follow-up engagement',
      'Repeat booking conversion',
    ],
  },
];

export default function CommunityEventsForHotelsGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <PageLayout
      title="Community Events for Hotels in Goa | Hotel Event Programming | The OTA Studio"
      description="Community event strategies for hotels in Goa. Yoga sessions, live music, wellness workshops and curated experiences that increase guest satisfaction and drive direct bookings."
      canonical="https://otastudio.in/community-events-for-hotels-goa"
      schemaType="community"
    >
      <article>
        <div className="bg-neutral-950 pt-16 pb-20 sm:pt-20 sm:pb-28 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <div className="text-white/50 pb-2">
              <Breadcrumbs crumbs={[{ label: 'Community' }, { label: 'Community Events for Hotels' }]} />
            </div>
            <div className="max-w-3xl">
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Community Events · Goa</span>
              <h1 className="heading-xl text-white mb-6">
                Community Events <br className="hidden sm:block" />
                <span className="text-accent">for Hotels in Goa</span>
              </h1>
              <p className="text-base sm:text-xl text-white/70 leading-relaxed mb-8">
                Drive bookings, build loyalty, and create unforgettable experiences with strategic
                community events. The OTA Studio designs, manages, and promotes hotel events that
                turn attendees into guests and guests into repeat customers.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20host%20community%20events%20at%20my%20hotel"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary"
                >
                  Start Hosting Community Events
                </a>
                <a
                  href="https://wa.me/919309706263?text=Tell%20me%20about%20event%20strategy%20for%20my%20hotel"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-secondary"
                >
                  Get Event Strategy Consultation
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="section-max section-padding py-16 sm:py-20 bg-neutral-900">
          <h2 className="heading-lg text-center text-white mb-12">
            Event Services for Hotels in Goa
          </h2>
          <div className="grid sm:grid-cols-2 gap-6">
            {services.map((service, i) => (
              <div
                key={i}
                className="p-7 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/7 hover:shadow-[0_0_20px_rgba(255,208,0,0.05)] hover:-translate-y-1 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-5">
                  <service.icon size={22} className="text-accent" />
                </div>
                <h3 className="font-display font-bold text-xl text-white mb-3">{service.title}</h3>
                <p className="text-sm text-white/50 leading-relaxed mb-5">{service.desc}</p>
                <div className="flex flex-wrap gap-2">
                  {service.features.map((feature, j) => (
                    <span
                      key={j}
                      className="px-3 py-1 rounded-full bg-white/8 border border-white/8 text-xs font-medium text-white/60"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-neutral-950 py-16 sm:py-20 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="heading-lg text-white mb-6">
                  How We Build Community Events for Hotels
                </h2>
                <div className="space-y-4">
                  {[
                    { num: '1', title: 'Discovery & Brand Alignment', desc: 'Understanding your hotel brand, guest profile, and business goals to design fitting events.' },
                    { num: '2', title: 'Event Calendar Design', desc: 'Creating a strategic year-round event calendar with recurring and seasonal experiences.' },
                    { num: '3', title: 'Talent & Vendor Sourcing', desc: 'Curating and booking the right artists, instructors, and service providers for each event.' },
                    { num: '4', title: 'Promotion & Marketing', desc: 'Launching integrated marketing campaigns to maximize attendance and visibility.' },
                    { num: '5', title: 'Event Execution', desc: 'Managing all logistics, coordination, and on-the-day execution for seamless experiences.' },
                    { num: '6', title: 'Conversion & Reporting', desc: 'Converting event attendees to hotel guests and tracking impact on bookings and revenue.' },
                  ].map((step, i) => (
                    <div key={i} className="flex items-start gap-4">
                      <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center shrink-0">
                        <span className="font-display font-bold text-sm text-accent">{step.num}</span>
                      </div>
                      <div>
                        <div className="font-display font-bold text-white text-sm">{step.title}</div>
                        <div className="text-xs text-white/40 mt-0.5">{step.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div className="p-7 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white text-xl mb-6">
                    Event Types We Organize
                  </h3>
                  <ul className="space-y-3">
                    {[
                      'Weekly yoga & wellness sessions',
                      'Live music and cultural performances',
                      'Farm-to-table and chef collaboration dinners',
                      'Wine and craft beverage tastings',
                      'Networking events for professionals',
                      'Themed seasonal celebrations',
                      'Art exhibitions and cultural showcases',
                      'Wellness workshops and talks',
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 shrink-0" />
                        <span className="text-sm text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-neutral-900 py-16 sm:py-20 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-30" />
          <div className="section-max section-padding relative">
            <h2 className="heading-lg text-center text-white mb-12">
              Community Events FAQs — Goa Hotels
            </h2>
            <div className="max-w-3xl mx-auto space-y-3">
              {faqs.map((faq, i) => (
                <div
                  key={i}
                  className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden"
                >
                  <button
                    onClick={() => setOpenIdx(openIdx === i ? null : i)}
                    className="w-full flex items-center justify-between p-5 sm:p-6 text-left"
                    aria-expanded={openIdx === i}
                  >
                    <span className="font-display font-bold text-base sm:text-lg text-white pr-4">
                      {faq.q}
                    </span>
                    <ChevronDown
                      size={20}
                      className={`shrink-0 text-white/40 transition-transform duration-300 ${
                        openIdx === i ? 'rotate-180 text-accent' : ''
                      }`}
                    />
                  </button>
                  <div
                    className={`overflow-hidden transition-all duration-300 ${
                      openIdx === i ? 'max-h-48' : 'max-h-0'
                    }`}
                  >
                    <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-sm sm:text-base text-white/50 leading-relaxed">
                      {faq.a}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-neutral-950 py-16 sm:py-20 text-center relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <h2 className="heading-lg text-white mb-4">
              Build a Thriving Community at Your Hotel
            </h2>
            <p className="text-white/50 mb-8 max-w-xl mx-auto">
              Let The OTA Studio design and execute community events that drive bookings,
              build guest loyalty, and create lasting brand moments.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <a
                href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20host%20community%20events%20at%20my%20hotel"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
              >
                Start Planning Your Events
              </a>
              <a href="/" className="btn-secondary">
                Back to Home
              </a>
            </div>
          </div>
        </div>
      </article>
    </PageLayout>
  );
}
