import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Users } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'What are community events?', a: 'Community events are curated gatherings at hospitality venues designed to build loyal, recurring audiences. Think trivia nights, creative workshops, cultural events, and wellness sessions.' },
  { q: 'How do community events help my venue?', a: 'Regular community events create repeat footfall, social media content, word-of-mouth, and higher spend per visit. They turn your venue into a destination.' },
  { q: 'What types of community events work in Goa?', a: 'Trivia nights, art and pottery workshops, cultural Goa evenings, wellness sessions, networking events, and food and music pairings are all effective community builders.' },
  { q: 'How do you build audiences for events?', a: 'We use targeted social media, WhatsApp communities, local influencer outreach, and OTA cross-promotion to build audiences for every event.' },
  { q: 'Can I host weekly community events?', a: 'Yes. Weekly or bi-weekly events are the most effective for building community. We design recurring schedules with varied programming to keep audiences engaged.' },
];

const includes = [
  'Community audience profiling and venue matching',
  'Event concept and theme design',
  'Talent and facilitator curation from partner network',
  'Pre-event marketing and community building',
  'Day-of execution and coordination',
  'Social media amplification and content creation',
  'Post-event reporting and analytics',
  'Recurring event scheduling and management',
];

const eventTypes = [
  'Community meetups and gatherings',
  'Trivia and game nights',
  'Cultural Goa events',
  'Creative workshops and pop-ups',
  'Wellness community sessions',
  'Networking and social events',
];

export default function CommunityEventsGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white" itemProp="name">Community Events Goa</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Community Events · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Community Events Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Community-led events for hospitality venues in Goa. We curate and execute community events that turn your venue into a local hub — building loyal audiences and sustained footfall.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20host%20community%20events%20at%20my%20venue" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Host Community Events <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20to%20join%20as%20an%20event%20organizer" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Join as Event Organizer
                </a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What's Included</h2>
                  <p className="body-md mb-8">End-to-end community event management for your venue.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Users size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Community Events</h3>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {eventTypes.map((type, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={16} className="text-accent/60 mt-1 shrink-0" />
                        <span className="text-white/70 text-sm">{type}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { metric: '40+', label: 'Community Events' },
                      { metric: '25+', label: 'Partner Creatives' },
                      { metric: '5x', label: 'Social Engagement' },
                      { metric: '60%', label: 'Repeat Visitors' },
                    ].map((r, i) => (
                      <div key={i} className="p-3 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Community Events FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Build Your Community in Goa</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Curated community events that turn your venue into a destination.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Host Community Events</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
