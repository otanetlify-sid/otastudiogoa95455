import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Coffee } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'How do you build cafe communities in Goa?', a: 'We create regular hangout experiences, member programs, coffee events, and creative workshops that turn coffee drinkers into daily cafe patrons. Community members visit 4x more often and become your strongest advocates.' },
  { q: 'What types of cafe events build the strongest community?', a: 'Coffee tastings, latte art classes, poetry nights, open mic sessions, book clubs, creative workshops, and member-exclusive discounts. Consistency and community focus are key.' },
  { q: 'How do loyalty programs work for cafes?', a: 'Points per visit, free drinks after X purchases, exclusive member events, early access to new blends, and special seating areas. Programs reward frequency and create belonging.' },
  { q: 'Can cafe communities increase daily traffic?', a: 'Yes. Community programs typically increase weekday traffic by 60-80% and create consistent customer flow. Regular members become your predictable daily revenue base.' },
  { q: 'How do you engage cafe customers digitally?', a: 'Email newsletters about events, Instagram content showcasing community moments, WhatsApp updates about new blends and specials, and member-only digital perks.' },
  { q: 'What is the cost of a cafe community program?', a: 'Cafe programs are the most cost-effective hospitality growth strategy. Typically 1-2% of revenue increase cost, making ROI positive within 2-3 months.' },
];

const services = [
  'Cafe community strategy and member research',
  'Recurring event programming (tastings, workshops)',
  'Loyalty and rewards program design',
  'Content creation for cafe social media',
  'Email and WhatsApp community engagement',
  'Member experience design and execution',
  'Feedback collection and analysis',
  'Monthly community growth reporting',
];

const programs = [
  'Coffee tasting events',
  'Latte art workshops',
  'Creative and artistic events',
  'Book clubs and reading groups',
  'Open mic nights',
  'Member loyalty rewards',
  'Seasonal celebrations',
  'Local artist collaborations',
];

export default function CommunityGrowthForCafes() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Community Growth for Cafes</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Cafe Community · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Community Growth for Cafes Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Build thriving cafe communities through member programs, coffee events, and consistent engagement. Turn coffee drinkers into daily regulars who visit 4x more often.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20build%20a%20cafe%20community" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Grow My Cafe <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20a%20Community%20Audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Get A Community Audit
                </a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What We Deliver</h2>
                  <p className="body-md mb-8">Complete cafe community and engagement service.</p>
                  <ul className="space-y-3">
                    {services.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Coffee size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Cafe Programs</h3>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {programs.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-white/70">
                        <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                        {item}
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '4x', label: 'Visit Frequency' },
                      { metric: '70%', label: 'Weekday Growth' },
                      { metric: '300+', label: 'Active Members' },
                      { metric: '90%', label: 'Retention' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-8">Cafe Community Growth Strategy</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Regular Events</h3>
                  <p className="text-white/70 text-sm">Weekly or bi-weekly events that give community members reasons to visit consistently and bring friends.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Member Rewards</h3>
                  <p className="text-white/70 text-sm">Points programs, free drink rewards, and exclusive perks that recognize loyalty and encourage higher frequency.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Community Connection</h3>
                  <p className="text-white/70 text-sm">Creating spaces where community members connect with each other, making your cafe the social hub of the neighborhood.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Cafe Community FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Make Your Cafe a Daily Destination</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Build a community of regular customers who visit daily and love your space.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Grow My Cafe</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
