import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, UtensilsCrossed } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'How do you build restaurant communities in Goa?', a: 'We create recurring dining experiences, member programs, themed food events, and chef collaborations that turn customers into loyal patrons. Community members visit 3x more often and spend 2x per visit.' },
  { q: 'What restaurant events build the strongest communities?', a: 'Chef tasting menus, ingredient focus nights, wine pairings, cooking classes, themed cuisine weeks, and member-exclusive previews. Each drives repeat visits and conversation around your food.' },
  { q: 'How do loyalty programs work for restaurants?', a: 'Points-based rewards, exclusive member perks, early reservation access, special pricing on new dishes, and private dining experiences. Programs reward frequent guests and drive consistent reservations.' },
  { q: 'Can community building increase restaurant revenue?', a: 'Absolutely. Community members dine 3x more frequently, spend 40-60% more per visit, and bring 2-3 new customers through word-of-mouth. Annual revenue increase of 35-50% is typical.' },
  { q: 'How do you promote restaurant community events?', a: 'Email to members, WhatsApp groups, Instagram stories and posts, influencer previews, and local partnerships. Member referrals drive 40%+ of new guests.' },
  { q: 'What is the cost of a restaurant community program?', a: 'Programs typically cost 2-3% of expected revenue increase. A 40% revenue increase makes the program ROI positive within 3 months.' },
];

const services = [
  'Restaurant community strategy and member research',
  'Recurring event programming and curation',
  'Loyalty and rewards program design',
  'Chef collaboration and food event execution',
  'Email and WhatsApp member engagement',
  'Social media content for food events',
  'Member feedback and satisfaction tracking',
  'Monthly community growth reports',
];

const events = [
  'Chef tasting menus',
  'Wine and food pairings',
  'Themed cuisine weeks',
  'Cooking workshops',
  'Ingredient focus nights',
  'Member-exclusive previews',
  'Collaborative chef events',
  'Seasonal celebrations',
];

export default function CommunityGrowthForRestaurants() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Community Growth for Restaurants</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Restaurant Community · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Community Growth for Restaurants Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Build loyal restaurant communities through events, loyalty programs, and member experiences. Transform occasional diners into regular patrons who visit 3x more often and spend significantly more.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20build%20a%20restaurant%20community" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Grow My Restaurant <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20a%20Community%20Audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Get A Community Audit
                </a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What We Deliver</h2>
                  <p className="body-md mb-8">Complete restaurant community and event service for consistent growth.</p>
                  <ul className="space-y-3">
                    {services.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <UtensilsCrossed size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Restaurant Events</h3>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {events.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-white/70">
                        <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                        {item}
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '3x', label: 'Visit Frequency' },
                      { metric: '45%', label: 'Revenue Increase' },
                      { metric: '200+', label: 'Active Members' },
                      { metric: '88%', label: 'Retention' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-8">Restaurant Community Growth Approach</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Curated Events</h3>
                  <p className="text-white/70 text-sm">Monthly food events, chef specials, and themed dinners that create memorable experiences and reasons to visit regularly.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Loyalty Programs</h3>
                  <p className="text-white/70 text-sm">Rewards, exclusive perks, and member benefits that recognize and incentivize frequent visits and higher spending.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Active Engagement</h3>
                  <p className="text-white/70 text-sm">Regular communication through email and WhatsApp, feedback collection, and community building around your restaurant.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Restaurant Community FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Build a Loyal Restaurant Community</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Create recurring revenue through community loyalty and member engagement.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Grow My Restaurant</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
