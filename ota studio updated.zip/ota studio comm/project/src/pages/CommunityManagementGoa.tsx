import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Users } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What is community management for hospitality venues?', a: 'Community management builds engaged audiences for hospitality venues through event programming, content strategy, and audience engagement. We create experiences that encourage repeat visits and build loyal communities around your venue.' },
  { q: 'How do you build a community for a hospitality venue?', a: 'We combine event programming, social media engagement, member benefits programs, and curated experiences. Regular touchpoints through events and communications keep your audience engaged and coming back.' },
  { q: 'What types of events build community engagement?', a: 'Themed nights, live performances, workshops, networking events, member-exclusive experiences, and seasonal celebrations all build community. The key is consistency and relevance to your audience.' },
  { q: 'Can you manage multiple venues in Goa?', a: 'Yes. We manage community programs across restaurants, cafes, bars, and resorts. Each program is customized to the venue vibe and audience demographics.' },
  { q: 'How do you measure community engagement success?', a: 'We track repeat visit rates, event attendance growth, social media engagement, member retention, and revenue impact. Monthly reports show community building progress.' },
  { q: 'What is the typical timeline for community growth?', a: 'Initial engagement builds within 4-6 weeks with consistent programming. Significant growth in repeat visitors appears by 3-4 months. Long-term loyalty develops over 6+ months of regular engagement.' },
];

const services = [
  'Community strategy and audience research',
  'Event programming and curation',
  'Member benefits and loyalty programs',
  'Social media engagement and content',
  'Email and WhatsApp community management',
  'Experience design and execution',
  'Monthly community growth reports',
  'Member feedback and engagement tracking',
];

const benefits = [
  'Repeat customer increase',
  'Revenue per visitor growth',
  'Long-term customer loyalty',
  'Organic word-of-mouth marketing',
  'Reduced customer acquisition cost',
  'Stronger brand community',
];

export default function CommunityManagementGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Community Management Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Community Management · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Community Management Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Community management and hospitality growth services for Goa venues. We build engaged audiences through event programming, member benefits, and consistent engagement. Transform casual visitors into loyal community members.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20build%20a%20community%20for%20my%20venue" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Build My Community <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20a%20Community%20Audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Get A Community Audit
                </a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What We Deliver</h2>
                  <p className="body-md mb-8">Complete community building and engagement service for sustainable growth.</p>
                  <ul className="space-y-3">
                    {services.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Users size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Community Benefits</h3>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {benefits.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-white/70">
                        <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                        {item}
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '3x', label: 'Repeat Visits' },
                      { metric: '45%', label: 'Revenue Growth' },
                      { metric: '500+', label: 'Active Members' },
                      { metric: '92%', label: 'Retention Rate' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-8">Community Building Strategy</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Event Programming</h3>
                  <p className="text-white/70 text-sm">Regular themed events, workshops, and experiences that bring your community together and create reasons for repeated visits.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Member Benefits</h3>
                  <p className="text-white/70 text-sm">Exclusive perks, discounts, and early access that reward loyalty and create belonging for your community members.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Engagement & Communication</h3>
                  <p className="text-white/70 text-sm">Consistent touchpoints through email, WhatsApp, and social media that keep your community informed and engaged.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Community Management FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ready to Build Your Community?</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Transform your venue into a destination with an engaged, loyal community.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Build My Community</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
