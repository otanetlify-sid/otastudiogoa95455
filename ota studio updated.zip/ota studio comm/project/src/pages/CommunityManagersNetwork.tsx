import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Users } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What is a community managers network?', a: 'It is a curated network of professional community managers who specialize in hospitality community building. Venues access vetted managers for strategic community programming and day-to-day management.' },
  { q: 'What services do community managers provide?', a: 'Member program management, event coordination, community engagement, loyalty program administration, guest feedback collection, community reporting, and strategic growth planning.' },
  { q: 'How does the network model benefit venues?', a: 'Access to vetted professionals, shared best practices, scalable operations, and peace of mind knowing your community is managed by experts. Venues save 40-50% compared to in-house hiring.' },
  { q: 'Can managers work across multiple venues?', a: 'Yes. Our managers efficiently manage 2-3 venues, allowing economies of scale and consistent quality across properties while reducing per-venue costs.' },
  { q: 'What is the cost of community manager services?', a: 'Typically 2-3% of revenue increase generated. A 40% revenue increase makes the service ROI positive within 3-4 months.' },
  { q: 'How are managers trained and supported?', a: 'All managers are trained in community strategy, member program management, event coordination, and hospitality growth. Ongoing training ensures consistent excellence.' },
];

const services = [
  'Vetted community manager network',
  'Manager matching to venue needs',
  'Community strategy implementation',
  'Member program management',
  'Event planning and execution',
  'Community engagement and growth',
  'Shared best practices platform',
  'Performance tracking and reporting',
];

const managerRoles = [
  'Community strategy development',
  'Member program administration',
  'Event planning and coordination',
  'Guest engagement and communication',
  'Loyalty program management',
  'Community feedback collection',
  'Growth analysis and optimization',
  'Cross-venue knowledge sharing',
];

export default function CommunityManagersNetwork() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Community Managers Network</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Community Network · OTA Studio</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Community Managers Network</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Access professional community managers through our vetted network. Strategic community building for hospitality venues with experienced managers who drive engagement, loyalty, and revenue growth.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20need%20a%20community%20manager" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Find A Community Manager <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20to%20join%20the%20manager%20network" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Join Manager Network
                </a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What We Provide</h2>
                  <p className="body-md mb-8">Complete community manager matching and support service for hospitality venues.</p>
                  <ul className="space-y-3">
                    {services.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Users size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Manager Responsibilities</h3>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {managerRoles.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-white/70">
                        <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                        {item}
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '30+', label: 'Managers Network' },
                      { metric: '50+', label: 'Venues Served' },
                      { metric: '40%', label: 'Avg Revenue Growth' },
                      { metric: '92%', label: 'Client Satisfaction' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-8">Community Manager Network Model</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Vetted Professionals</h3>
                  <p className="text-white/70 text-sm">All managers are vetted, trained, and experienced in hospitality community building. You get professionals, not generalists.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Scalable Operations</h3>
                  <p className="text-white/70 text-sm">Managers efficiently manage multiple venues while maintaining personalized service and deep venue relationships.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Cost Efficiency</h3>
                  <p className="text-white/70 text-sm">Network model reduces costs 40-50% vs in-house hiring while maintaining or exceeding quality and results.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Community Managers Network FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Access Professional Community Management</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Vetted managers who specialize in hospitality community building and revenue growth.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Find A Manager</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
