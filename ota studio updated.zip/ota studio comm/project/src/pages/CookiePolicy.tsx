import PageLayout from '../components/PageLayout';
import Breadcrumbs from '../components/Breadcrumbs';

export default function CookiePolicy() {
  return (
    <PageLayout
      title="Cookie Policy | The OTA Studio"
      description="Cookie policy for The OTA Studio. Learn about how we use cookies on our website."
      canonical="https://otastudio.in/cookie-policy"
    >
      <div className="section-max section-padding py-12 sm:py-16 bg-neutral-900">
        <Breadcrumbs crumbs={[{ label: 'Cookie Policy' }]} />
        <div className="max-w-3xl mt-8">
          <h1 className="heading-lg text-white mb-4">Cookie Policy</h1>
          <p className="text-sm text-white/40 mb-10">Last updated: June 10, 2026</p>

          <div className="space-y-8">
            <section>
              <h2 className="font-display font-bold text-xl text-white mb-3">What Are Cookies?</h2>
              <p className="text-white/60 leading-relaxed">
                Cookies are small text files stored on your device when you visit a website.
                They help websites remember your preferences and improve your browsing experience.
                The OTA Studio's website (otastudio.in) uses cookies to provide a better
                experience and to understand how visitors interact with our site.
              </p>
            </section>

            <section>
              <h2 className="font-display font-bold text-xl text-white mb-3">Types of Cookies We Use</h2>
              <div className="space-y-4">
                {[
                  {
                    type: 'Essential Cookies',
                    desc: 'Required for the website to function properly. These cannot be disabled and do not collect personal data.',
                  },
                  {
                    type: 'Analytics Cookies',
                    desc: 'Used to understand how visitors interact with our website (pages visited, time on site, etc.). This helps us improve our website. We may use Google Analytics for this purpose.',
                  },
                  {
                    type: 'Marketing Cookies',
                    desc: 'Used to track visitors across websites for advertising purposes. We may use Google Ads and Meta Pixel to serve relevant ads about our services.',
                  },
                  {
                    type: 'Preference Cookies',
                    desc: 'Remember your preferences such as language settings to provide a personalized experience.',
                  },
                ].map((cookie, i) => (
                  <div key={i} className="p-5 rounded-xl bg-white/4 border border-white/8">
                    <h3 className="font-display font-bold text-base text-white mb-2">{cookie.type}</h3>
                    <p className="text-sm text-white/60 leading-relaxed">{cookie.desc}</p>
                  </div>
                ))}
              </div>
            </section>

            <section>
              <h2 className="font-display font-bold text-xl text-white mb-3">Third-Party Cookies</h2>
              <p className="text-white/60 leading-relaxed mb-3">
                We may use third-party services that set their own cookies:
              </p>
              <ul className="list-disc pl-5 space-y-2 text-white/60">
                <li><strong className="text-white/80">Google Analytics</strong> — Website traffic analysis</li>
                <li><strong className="text-white/80">Google Tag Manager</strong> — Tag management</li>
                <li><strong className="text-white/80">Google Ads</strong> — Advertising and conversion tracking</li>
                <li><strong className="text-white/80">Meta (Facebook) Pixel</strong> — Social media advertising</li>
              </ul>
              <p className="text-white/60 leading-relaxed mt-3">
                Each of these services has its own privacy and cookie policies. We encourage
                you to review them directly.
              </p>
            </section>

            <section>
              <h2 className="font-display font-bold text-xl text-white mb-3">Managing Cookies</h2>
              <p className="text-white/60 leading-relaxed mb-3">
                You can control and manage cookies in several ways:
              </p>
              <ul className="list-disc pl-5 space-y-2 text-white/60">
                <li><strong className="text-white/80">Browser settings:</strong> Most browsers allow you to refuse cookies or delete existing ones. Check your browser's help section for instructions.</li>
                <li><strong className="text-white/80">Opt-out tools:</strong> Google Analytics provides an opt-out browser add-on at tools.google.com/dlpage/gaoptout</li>
                <li><strong className="text-white/80">Device settings:</strong> Mobile devices allow you to limit ad tracking in your device settings.</li>
              </ul>
              <p className="text-white/60 leading-relaxed mt-3">
                Note: Disabling certain cookies may affect the functionality of our website.
              </p>
            </section>

            <section>
              <h2 className="font-display font-bold text-xl text-white mb-3">Changes to This Policy</h2>
              <p className="text-white/60 leading-relaxed">
                We may update this Cookie Policy from time to time. We will notify users
                of significant changes by updating the "Last updated" date at the top of
                this page.
              </p>
            </section>

            <section>
              <h2 className="font-display font-bold text-xl text-white mb-3">Contact Us</h2>
              <div className="p-5 rounded-xl bg-white/4 border border-white/8">
                <p className="text-sm text-white"><strong>The OTA Studio</strong></p>
                <p className="text-sm text-white/60">Email: theotastudios@gmail.com</p>
                <p className="text-sm text-white/60">Phone: +91 85519 52391</p>
              </div>
            </section>
          </div>

          <div className="mt-10 pt-8 border-t border-white/8 flex flex-wrap gap-4 text-sm">
            <a href="/privacy-policy" className="text-accent hover:underline">
              Privacy Policy
            </a>
            <a href="/terms-and-conditions" className="text-accent hover:underline">
              Terms &amp; Conditions
            </a>
            <a href="/" className="text-white/50 hover:underline">
              Back to Home
            </a>
          </div>
        </div>
      </div>
    </PageLayout>
  );
}
