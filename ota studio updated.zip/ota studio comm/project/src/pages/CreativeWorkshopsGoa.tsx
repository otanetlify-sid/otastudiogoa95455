import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Palette } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What types of creative workshops work at venues?', a: 'Art, pottery, painting, jewelry making, textile arts, photography, creative writing, and crafting workshops all attract engaged audiences. These experiences create memorable moments and drive repeat visits.' },
  { q: 'Who attends creative workshops?', a: 'Art enthusiasts, tourists seeking local experiences, creative professionals, corporate team builders, and people looking for new hobbies. They typically stay longer and spend more when workshop quality is high.' },
  { q: 'How do creative workshops build venue loyalty?', a: 'Workshops create lasting memories, friendships within the workshop community, and reasons for repeat visits. Participants often return and bring friends to future workshops.' },
  { q: 'Can venues run monthly creative programs?', a: 'Yes. Monthly or weekly workshops create a creative community, consistent foot traffic, and recurring revenue. Rotating workshops keep experiences fresh for regular participants.' },
  { q: 'How do you coordinate instructors for workshops?', a: 'Our network includes skilled art instructors, craftspeople, and creative professionals. We handle booking, curriculum design, material sourcing, and coordination.' },
  { q: 'What materials and setup do workshops need?', a: 'We coordinate all workshop requirements including materials, tools, tables, seating, and cleanup. Your venue provides the space; we handle the rest.' },
];

const services = [
  'Creative instructor and artist network',
  'Workshop curriculum and design',
  'Material sourcing and supply coordination',
  'Studio space optimization',
  'Guest experience coordination',
  'Event promotion and marketing',
  'Creative community building',
  'Monthly workshop program reporting',
];

const workshopTypes = [
  'Painting and drawing',
  'Pottery and ceramics',
  'Jewelry making',
  'Textile and fiber arts',
  'Photography workshops',
  'Creative writing',
  'Mixed media art',
  'Collaborative art projects',
];

export default function CreativeWorkshopsGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Creative Workshops Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Creative Workshops · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Creative Workshops Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Art, pottery, painting, and creative workshops at Goa hospitality venues. Professional instructors, curated experiences, and community building for memorable guest experiences.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20host%20creative%20workshops" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Host Workshops <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20to%20plan%20a%20workshop%20series" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Plan Workshop Series
                </a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What We Deliver</h2>
                  <p className="body-md mb-8">Complete creative workshop and program service.</p>
                  <ul className="space-y-3">
                    {services.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Palette size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Workshop Types</h3>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {workshopTypes.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-white/70">
                        <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                        {item}
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '80+', label: 'Workshops Hosted' },
                      { metric: '32%', label: 'Revenue Increase' },
                      { metric: '25+', label: 'Instructors' },
                      { metric: '93%', label: 'Satisfaction' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-8">Creative Experience Strategy</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Expert Instruction</h3>
                  <p className="text-white/70 text-sm">Skilled instructors create engaging, learning-focused workshops where participants gain real skills and create beautiful work.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Creative Community</h3>
                  <p className="text-white/70 text-sm">Workshops build creative communities where participants connect, inspire each other, and become loyal venue supporters.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Memorable Experiences</h3>
                  <p className="text-white/70 text-sm">Create lasting memories that guests associate with your venue, driving repeat visits and enthusiastic word-of-mouth promotion.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Creative Workshops FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Create Memorable Creative Experiences</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Professional workshops that build creative communities and drive venue loyalty and revenue.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Host Workshops</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
