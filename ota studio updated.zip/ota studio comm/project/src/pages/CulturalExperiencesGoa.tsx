import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Globe } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What are cultural experiences at hospitality venues?', a: 'Cultural experiences include local cuisine tastings, traditional music and dance performances, local artisan showcases, cultural storytelling, and authentic Goan traditions. These create meaningful connections between guests and local culture.' },
  { q: 'Why do guests pay for cultural experiences?', a: 'Tourists and travelers seek authentic local experiences to understand the destination. Cultural programming creates memorable experiences that guests value highly and willingly pay premium prices for.' },
  { q: 'What types of cultural events attract tourists?', a: 'Goan folk music and dance, traditional cooking demonstrations, local artisan showcases, cultural storytelling, traditional instrument workshops, and heritage site narratives all attract engaged audiences.' },
  { q: 'How do cultural experiences increase venue revenue?', a: 'Cultural event tickets, higher average bills through extended stays, additional food and beverage sales, merchandise sales, and tourist packages all increase revenue. Guests also spend more when feeling culturally connected.' },
  { q: 'Can venues run ongoing cultural programming?', a: 'Yes. Monthly or weekly cultural events create cultural tourism destinations, build loyal audiences, and attract tour operators looking for authentic experiences for their guests.' },
  { q: 'How do you ensure cultural authenticity?', a: 'We partner with local cultural organizations, traditional practitioners, and community leaders. Authentic programming respects local culture while creating engaging experiences for guests.' },
];

const services = [
  'Cultural programming and experience design',
  'Local artisan and performer partnerships',
  'Authentic cuisine and dining experiences',
  'Cultural storytelling and narrative curation',
  'Heritage and tradition documentation',
  'Tourist and cultural package creation',
  'Community engagement and cultural respect',
  'Monthly cultural event reporting',
];

const experiences = [
  'Traditional Goan cuisine tastings',
  'Folk music and dance performances',
  'Artisan craft demonstrations',
  'Cultural storytelling sessions',
  'Traditional craft workshops',
  'Heritage tours and narratives',
  'Seasonal cultural celebrations',
  'Local community collaborations',
];

export default function CulturalExperiencesGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Cultural Experiences Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Cultural Experiences · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Cultural Experiences Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Authentic cultural events and local experiences at Goa hospitality venues. Traditional performances, local cuisine, artisan showcases, and heritage programming for memorable guest experiences.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20host%20cultural%20experiences" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Create Cultural Events <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20to%20plan%20cultural%20programming" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Plan Cultural Program
                </a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What We Deliver</h2>
                  <p className="body-md mb-8">Complete cultural experience and event service.</p>
                  <ul className="space-y-3">
                    {services.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Globe size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Experience Types</h3>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {experiences.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-white/70">
                        <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                        {item}
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '60+', label: 'Events Hosted' },
                      { metric: '40%', label: 'Revenue Increase' },
                      { metric: '50+', label: 'Local Partners' },
                      { metric: '94%', label: 'Guest Satisfaction' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-8">Cultural Experience Strategy</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Authentic Partnerships</h3>
                  <p className="text-white/70 text-sm">Work with local communities, artisans, and cultural organizations to create genuine, respectful cultural programming.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Premium Positioning</h3>
                  <p className="text-white/70 text-sm">Position your venue as a destination for authentic cultural tourism, attracting guests willing to pay premium rates for genuine experiences.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Guest Connection</h3>
                  <p className="text-white/70 text-sm">Create meaningful connections between guests and local culture, building loyalty and attracting repeat visitors and tour operators.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Cultural Experiences FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Showcase Authentic Goan Culture</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Cultural programming that attracts travelers seeking authentic experiences and builds community loyalty.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Create Cultural Events</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
