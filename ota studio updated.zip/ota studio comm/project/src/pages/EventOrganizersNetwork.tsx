import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Zap } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What is an event organizers network?', a: 'A curated network of professional event organizers who specialize in hospitality activations. Venues access vetted organizers for music events, cultural programming, wellness experiences, and community activations.' },
  { q: 'What types of events do organizers coordinate?', a: 'Live music, DJ nights, wellness events, cultural experiences, creative workshops, themed parties, product launches, team building, and community activations. Every event type venues need.' },
  { q: 'How does the network model work for venues?', a: 'Venues submit event requests. We match with the right organizer from our network. Organizer handles complete event execution, promotion, and coordination. You focus on hospitality.' },
  { q: 'What is the advantage of the network model?', a: 'Access to specialized event organizers without hiring. Lower costs, consistent quality, flexibility to scale events, and proven experience in hospitality activations.' },
  { q: 'Can venues run multiple events per month?', a: 'Yes. Our network supports venues running frequent events. Multiple organizers coordinate different event types to keep your venue dynamic and exciting.' },
  { q: 'How are event results tracked and reported?', a: 'Every event generates attendance, revenue, satisfaction, and growth metrics. Monthly reports show event impact and optimization opportunities.' },
];

const services = [
  'Vetted event organizers network',
  'Event organizer matching',
  'Complete event coordination',
  'Music and entertainment booking',
  'Wellness and wellness programming',
  'Cultural event curation',
  'Workshop and class organization',
  'Post-event analytics and reporting',
];

const eventTypes = [
  'Live music performances',
  'DJ and nightlife events',
  'Yoga and wellness classes',
  'Sound healing sessions',
  'Creative workshops',
  'Cultural experiences',
  'Themed parties',
  'Corporate team building',
];

export default function EventOrganizersNetwork() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Event Organizers Network</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Event Organizers · OTA Studio</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Event Organizers Network</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Professional event organizers for hospitality activations. Access vetted organizers specializing in live music, wellness, cultural experiences, and community programming for consistent venue engagement.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20need%20event%20organizers" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Find Event Organizers <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20to%20join%20the%20organizer%20network" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Join Organizer Network
                </a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What We Provide</h2>
                  <p className="body-md mb-8">Complete event organizer network for hospitality activations.</p>
                  <ul className="space-y-3">
                    {services.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Zap size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Event Types</h3>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {eventTypes.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-white/70">
                        <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                        {item}
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '50+', label: 'Organizers Network' },
                      { metric: '200+', label: 'Events Organized' },
                      { metric: '35%', label: 'Avg Revenue Boost' },
                      { metric: '91%', label: 'Client Satisfaction' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-8">Event Organizer Network Model</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Specialist Organizers</h3>
                  <p className="text-white/70 text-sm">Network includes specialists in every event type. Each organizer brings expertise and established networks for their specialty.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Full Event Execution</h3>
                  <p className="text-white/70 text-sm">Organizers handle complete event from concept through execution, promotion, vendor coordination, and guest satisfaction.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Flexible Scalability</h3>
                  <p className="text-white/70 text-sm">Scale from one event per month to multiple events weekly. Network flexibility supports any event frequency or scale.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Event Organizers Network FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Activate Your Venue With Events</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Professional event organizers who drive attendance, engagement, and revenue growth through strategic activations.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Find Event Organizers</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
