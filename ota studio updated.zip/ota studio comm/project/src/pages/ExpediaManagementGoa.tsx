import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Globe, Zap, TrendingUp } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'Why should Goa properties focus on Expedia?', a: 'Expedia is the second-largest online travel agency globally with strong international reach. For Goa properties targeting international guests, especially Americans, Australians, and Europeans, Expedia is essential for capturing this high-value segment.' },
  { q: 'How does Expedia differ from Booking.com?', a: 'While both are large OTAs, Expedia has different user demographics (more Americans), distinct ranking algorithms, and unique features like bundle deals. Optimization strategies and pricing approaches need to be tailored specifically for Expedia.' },
  { q: 'How do you optimize for international guests on Expedia?', a: 'We tailor listings for international travelers by using international payment methods, currencies, measurements, and descriptions. We highlight features that appeal to foreign guests like visa information, airport transfers, and local experiences.' },
  { q: 'What is Expedia\'s Featured Placement program?', a: 'Featured placement on Expedia results in 5-8x more visibility compared to standard listings. We help properties qualify and maintain featured status through high ratings, quick response times, and competitive pricing.' },
  { q: 'How long does it take to see international booking growth?', a: 'International bookings typically increase within 4-8 weeks after optimization. Foreign travelers often have longer planning horizons, so improvements take slightly longer than domestic markets but result in higher average rates.' },
  { q: 'Can you help with Expedia\'s Affiliate programs?', a: 'Yes, we can help you leverage Expedia\'s affiliate and partnership programs to reach travel agents and maximize commission efficiency while maintaining rate parity.' },
];

const includes = [
  'Expedia listing optimization for international markets',
  'Global payment method and currency integration',
  'International guest targeting and localization',
  'Featured placement achievement and maintenance',
  'International traveler communication templates',
  'Expedia Review Express management',
  'Multi-currency pricing strategy',
  'Weekly international booking analytics',
];

export default function ExpediaManagementGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Expedia Management Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Expedia Management · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Expedia Management Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Expert Expedia management for Goa properties seeking international bookings. We optimize listings for global travelers,
                secure featured placement, and maximize revenue from high-value international guests on the world's second-largest OTA.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20Expedia%20management%20for%20my%20Goa%20property" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Attract International Guests <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">Expedia Management Includes</h2>
                  <p className="body-md text-white/70 mb-8">Comprehensive Expedia optimization for international market reach and featured placement.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <h3 className="font-display font-bold text-xl text-white mb-6">Results We Deliver</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '5-8x', label: 'Featured Visibility' },
                      { metric: '310%', label: 'Booking Increase' },
                      { metric: '35%+', label: 'Higher Avg Rate' },
                      { metric: '45+', label: 'Properties Managed' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid md:grid-cols-3 gap-8 mb-16">
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <TrendingUp size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Revenue Optimization</h3>
                  <p className="text-white/70 mb-4">International guests typically have higher budgets and less price sensitivity. We optimize multi-currency pricing to maximize revenue per booking while remaining competitive for feature placement.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Multi-currency rate optimization
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      International demand pricing
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Premium positioning strategy
                    </li>
                  </ul>
                </div>

                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <Globe size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Listing Optimization</h3>
                  <p className="text-white/70 mb-4">We create international-focused listing content highlighting Goa's unique appeal, local experiences, and features that attract global travelers. Professional translation and cultural adaptation ensure maximum appeal.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      International appeal optimization
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Local experience highlighting
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Multi-language descriptions
                    </li>
                  </ul>
                </div>

                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <Zap size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Ranking Improvement</h3>
                  <p className="text-white/70 mb-4">Expedia's algorithm prioritizes customer reviews, response speed, and booking frequency. We optimize all factors to achieve featured placement status, which delivers exponentially more visibility and bookings.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Featured placement achievement
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Review score maximization
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Priority search positioning
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Benefits for Goa Hotels</h2>
              <div className="grid md:grid-cols-2 gap-8">
                {[
                  'Access to hundreds of millions of international travelers globally',
                  'Featured placement delivers 5-8x more visibility than standard listings',
                  'International guests typically have 35%+ higher average daily rates',
                  'Multi-currency support simplifies international guest bookings',
                  'Global payment methods increase conversion rates from international markets',
                  'Longer stay lengths from international tourists boost revenue',
                  'English-speaking support improves satisfaction and reviews from international guests',
                  'Expedia\'s global promotion and marketing support featured properties',
                ].map((benefit, i) => (
                  <div key={i} className="flex items-start gap-4 p-6 rounded-xl border border-white/8 bg-white/4">
                    <CheckCircle2 size={24} className="text-accent mt-1 shrink-0" />
                    <p className="text-white/70">{benefit}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Why Choose Us for Expedia?</h2>
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">International Market Expertise</h3>
                  <p className="text-white/70">We understand the preferences, booking patterns, and expectations of international travelers from different regions. This expertise helps us position your property optimally for global markets.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Expedia Algorithm Mastery</h3>
                  <p className="text-white/70">We have deep knowledge of Expedia's ranking algorithms, featured placement criteria, and optimization strategies. Our methods consistently achieve featured status for our clients.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Proven International Results</h3>
                  <p className="text-white/70">45+ Goa properties have achieved featured placement on Expedia. Average international booking increase: 310%. Average rate increase from international guests: 35%+.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Related Services</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <a href="/property-management-goa" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Property Management Goa</h3>
                  <p className="text-white/70 mb-4">Complete property management including OTA management, operations, and revenue optimization.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/vision-mission" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Our Vision & Mission</h3>
                  <p className="text-white/70 mb-4">Learn about our approach to hospitality growth and property management excellence in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/founders" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Meet Our Founders</h3>
                  <p className="text-white/70 mb-4">Discover the team behind successful Expedia management strategies for Goa properties.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Expedia Management FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-64' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ready to Go Global on Expedia?</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Let's optimize your Expedia presence, achieve featured placement, and attract high-value international bookings to your Goa property.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20Expedia%20management%20for%20my%20property" target="_blank" rel="noopener noreferrer" className="btn-primary">Attract International Guests</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
