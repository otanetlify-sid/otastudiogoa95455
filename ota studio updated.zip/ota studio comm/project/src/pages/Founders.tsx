import { CircleCheck as CheckCircle2, ArrowRight, Building2, Users } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const founderCards = [
  {
    name: 'Siddharth',
    title: 'Founder, OTA Strategy & Growth',
    icon: Building2,
    focus: ['OTA systems', 'Revenue optimization', 'Hospitality scaling'],
  },
  {
    name: 'Suchit',
    title: 'Co-Founder, Community Experience Specialist & Operations',
    icon: Users,
    focus: ['Hospitality operations', 'Guest experience systems', 'Property workflows', 'Community-driven hospitality standards'],
  },
  {
    name: 'Bhavana Rana',
    title: 'Founding Builder – Community Experiences & Partnerships',
    icon: Users,
    focus: ['Community building', 'Hospitality experiences', 'Creator collaborations', 'Partnerships', 'Networking', 'Ecosystem development'],
  },
];

const stats = [
  { metric: '15+', label: 'Years Combined Hospitality Experience' },
  { metric: '30+', label: 'Properties Managed' },
  { metric: '8+', label: 'OTA Platforms' },
  { metric: '50+', label: 'Events Delivered' },
];

const philosophy = [
  'Data-driven decisions over guesswork',
  'Long-term partnerships over quick wins',
  'System-driven growth over manual effort',
  'Community-first hospitality over isolated operations',
];

const purpose = [
  'Make OTA growth accessible to every hospitality business',
  'Build systems that reduce manual management dependency',
  'Create a network where properties, technology, and experiences grow together',
  'Prove that strategic OTA management beats random listing',
];

export default function Founders() {
  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Organization">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white" itemProp="name">Founders</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Leadership · OTA Studio</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">The OTA Studio Founders</h1>
              <p className="body-lg text-lg max-w-3xl mb-8">
                Meet the team building the most trusted OTA growth and hospitality optimization system for modern hoteliers.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%27d%20like%20to%20connect%20with%20the%20OTA%20Studio%20team" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Connect With Our Team <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Leadership Team</h2>
              <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                {founderCards.map((founder, i) => {
                  const Icon = founder.icon;
                  return (
                    <div key={i} className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                      <div className="w-12 h-12 rounded-lg bg-accent/15 flex items-center justify-center mb-4">
                        <Icon size={20} className="text-accent" />
                      </div>
                      <h3 className="font-display font-bold text-xl text-white mb-1">{founder.name}</h3>
                      <p className="text-accent text-sm mb-4">{founder.title}</p>
                      <p className="text-white/70 text-sm">
                        Focus: {founder.focus.join(', ')}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">15+ Years Combined Experience</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
                {stats.map((stat, i) => (
                  <div key={i} className="p-6 rounded-xl bg-white/4 border border-white/8 text-center">
                    <div className="font-display font-extrabold text-2xl text-accent mb-2">{stat.metric}</div>
                    <div className="text-xs text-white/50">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-md text-center text-white mb-6">Our Vision</h2>
                <p className="text-lg text-white text-center leading-relaxed">
                  Building the most trusted OTA growth and hospitality optimization system for modern hoteliers.
                </p>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Leadership Philosophy</h2>
              <div className="max-w-3xl mx-auto space-y-4">
                {philosophy.map((item, i) => (
                  <div key={i} className="flex items-start gap-4 p-5 rounded-xl bg-white/4 border border-white/8">
                    <CheckCircle2 size={20} className="text-accent mt-0.5 shrink-0" />
                    <span className="text-white/70">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Company Purpose</h2>
              <div className="max-w-3xl mx-auto space-y-4">
                {purpose.map((item, i) => (
                  <div key={i} className="flex items-start gap-4 p-5 rounded-xl bg-white/4 border border-white/8">
                    <CheckCircle2 size={20} className="text-accent mt-0.5 shrink-0" />
                    <span className="text-white/70">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Connect With Our Team</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Let's talk about your hospitality growth strategy.</p>
              <a href="https://wa.me/919270598602?text=Hi%2C%20I%27d%20like%20to%20connect%20with%20the%20OTA%20Studio%20team" target="_blank" rel="noopener noreferrer" className="btn-primary inline-block">
                Message Us on WhatsApp
              </a>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
