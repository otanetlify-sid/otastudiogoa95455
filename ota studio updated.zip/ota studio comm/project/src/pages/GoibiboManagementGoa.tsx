import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Users, BarChart3, Target } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'What is Goibibo and why do Goa properties need it?', a: 'Goibibo is a major Indian OTA specializing in domestic travel with strong presence in tier-2 and tier-3 cities. Many Indian travelers prefer Goibibo for its competitive pricing and extensive inventory, making it essential for capturing volume bookings.' },
  { q: 'How is Goibibo different from Booking.com or MakeMyTrip?', a: 'Goibibo focuses on value-conscious Indian travelers, offers direct booking incentives, and has a strong app-based user base. The guest demographics and booking patterns are different, requiring specialized optimization strategies.' },
  { q: 'Can you help me get featured on Goibibo?', a: 'Yes, we optimize your listing to achieve featured placement on Goibibo\'s search results. Featured properties receive 3-5x more visibility and bookings compared to standard listings.' },
  { q: 'How do you manage pricing on Goibibo?', a: 'We maintain competitive pricing specific to Goibibo\'s market while ensuring rate parity. Goibibo guests appreciate value, and our strategies balance occupancy with optimal revenue per room.' },
  { q: 'What response time is expected on Goibibo?', a: 'Goibibo guests expect responses within 2 hours. We ensure rapid response management to maintain high communication scores, which directly improve your search ranking.' },
  { q: 'Does Goibibo have corporate partnerships?', a: 'Yes, Goibibo has corporate contracts. We help you tap into this segment for consistent mid-week bookings and longer stay lengths with potentially higher margins.' },
];

const includes = [
  'Goibibo listing optimization and search ranking',
  'Value-conscious traveler targeting',
  'Competitive rate management and optimization',
  'Featured property placement strategy',
  'Guest communication and response management',
  'Review building and reputation optimization',
  'Corporate partnership identification',
  'Bi-weekly performance analytics',
];

export default function GoibiboManagementGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Goibibo Management Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Goibibo Management · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Goibibo Management Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Expert Goibibo management for Goa properties. We optimize listings, improve search rankings, manage competitive pricing,
                and help you capture high-volume domestic bookings from value-conscious Indian travelers.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20Goibibo%20management%20for%20my%20Goa%20property" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Boost Goibibo Bookings <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">Goibibo Management Includes</h2>
                  <p className="body-md text-white/70 mb-8">Complete optimization tailored to Goibibo's unique market and user base.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <h3 className="font-display font-bold text-xl text-white mb-6">Results We Deliver</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '280%', label: 'Booking Increase' },
                      { metric: '3-5x', label: 'Featured Visibility' },
                      { metric: '4.7+', label: 'Average Guest Rating' },
                      { metric: '60+', label: 'Properties Managed' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid md:grid-cols-3 gap-8 mb-16">
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <BarChart3 size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Revenue Optimization</h3>
                  <p className="text-white/70 mb-4">Goibibo guests are price-sensitive but driven by value perception. We optimize pricing to capture maximum bookings while maintaining margins through strategic seasonal adjustments and promotional alignment.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Value-based pricing strategy
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Seasonal promotion planning
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Volume-optimized rate structure
                    </li>
                  </ul>
                </div>

                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <Target size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Listing Optimization</h3>
                  <p className="text-white/70 mb-4">We optimize listings to appeal to Goibibo's core audience: budget-conscious travelers seeking value. High-quality photos, keyword optimization, and clear amenity highlighting drive search visibility and conversions.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Value proposition highlighting
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Budget traveler targeting
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Featured placement optimization
                    </li>
                  </ul>
                </div>

                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <Users size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Ranking Improvement</h3>
                  <p className="text-white/70 mb-4">Goibibo's algorithm rewards response speed, guest satisfaction, and consistent bookings. We optimize all these factors to achieve featured placement, which delivers 3-5x more visibility and bookings.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Featured property positioning
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      2-hour response management
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Guest satisfaction optimization
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Benefits for Goa Hotels</h2>
              <div className="grid md:grid-cols-2 gap-8">
                {[
                  'Access to millions of Indian travelers seeking value accommodations in Goa',
                  'Featured placement drives 3-5x more visibility than standard listings',
                  'High booking frequency from value-conscious travelers increases occupancy',
                  'Strong repeat booking potential from satisfied budget-conscious guests',
                  'Corporate travel partnerships provide consistent mid-week bookings',
                  'Direct booking incentives available on Goibibo for strategic revenue moves',
                  'App-based user base provides mobile conversion opportunities',
                  'Tier-2 and tier-3 city access expands market reach beyond major metros',
                ].map((benefit, i) => (
                  <div key={i} className="flex items-start gap-4 p-6 rounded-xl border border-white/8 bg-white/4">
                    <CheckCircle2 size={24} className="text-accent mt-1 shrink-0" />
                    <p className="text-white/70">{benefit}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Why Choose Us for Goibibo?</h2>
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Goibibo Platform Mastery</h3>
                  <p className="text-white/70">We understand Goibibo's unique ranking algorithm, featured placement criteria, and user behavior patterns. Our strategies are proven to achieve featured status and maximize visibility.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Value Market Expertise</h3>
                  <p className="text-white/70">We specialize in the value segment of Indian travel market. We know how to appeal to budget-conscious travelers while maintaining healthy profit margins through strategic pricing and positioning.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Documented Success</h3>
                  <p className="text-white/70">60+ Goa properties now achieve featured placement on Goibibo under our management. Our average clients see 280%+ booking increases within 90 days of optimization launch.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Related Services</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <a href="/property-management-goa" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Property Management Goa</h3>
                  <p className="text-white/70 mb-4">Complete property management including OTA management, operations, and revenue optimization.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/vision-mission" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Our Vision & Mission</h3>
                  <p className="text-white/70 mb-4">Learn about our approach to hospitality growth and property management excellence in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/founders" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Meet Our Founders</h3>
                  <p className="text-white/70 mb-4">Discover the team behind successful Goibibo management strategies for Goa properties.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Goibibo Management FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-64' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ready to Get Featured on Goibibo?</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Let's optimize your listing, achieve featured placement, and capture high-volume bookings from value-conscious Indian travelers.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20Goibibo%20management%20for%20my%20property" target="_blank" rel="noopener noreferrer" className="btn-primary">Boost Goibibo Bookings</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
