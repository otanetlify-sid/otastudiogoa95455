import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Music, Leaf, Palette, Coffee } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'What is hospitality activation?', a: 'Hospitality activation is the process of curating and executing real-world experiences at hospitality venues — from live music nights to wellness retreats — to drive footfall, revenue, and brand differentiation.' },
  { q: 'How is OTA Studio different from an event company?', a: 'We are not an event company. We are a hospitality activation company that combines OTA growth with real-world activations. Every activation is designed to complement your digital presence and drive measurable results.' },
  { q: 'Which venues do you activate?', a: 'We work with cafes, restaurants, bars, hotels, beach clubs, and resorts across Goa. All activations happen at your venue — we bring the talent, concept, and audience.' },
  { q: 'What types of activations do you offer?', a: 'We offer four categories: Nightlife & Entertainment (live music, karaoke, comedy, trivia, themed nights), Wellness & Retreat (yoga, meditation, fitness, sound healing), Creative & Cultural (art pop-ups, pottery, photography walks), and Hospitality Experience (cafe takeovers, beach club activations, food + music pairings).' },
  { q: 'How do I request an activation?', a: 'Simply reach out via WhatsApp with your venue details. We will assess your space, audience, and goals, then propose a tailored activation plan.' },
];

const includes = [
  'Venue assessment and audience analysis', 'Concept design and experience curation',
  'Talent booking and artist management', 'Marketing and audience acquisition',
  'On-site experience execution', 'Post-activation performance reporting',
  'OTA listing integration and cross-promotion', 'Recurring activation scheduling',
];

const categories = [
  { icon: Music, title: 'Nightlife & Entertainment', color: 'accent' },
  { icon: Leaf, title: 'Wellness & Retreat', color: 'white' },
  { icon: Palette, title: 'Creative & Cultural', color: 'white' },
  { icon: Coffee, title: 'Hospitality Experience', color: 'accent' },
];

export default function HospitalityActivationGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white" itemProp="name">Hospitality Activation Goa</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Hospitality Activation · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Hospitality Activation Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Goa's first hospitality activation company. We curate real-world experiences at your venue
                — live music, wellness sessions, creative pop-ups, and more — to drive footfall, revenue, and brand loyalty.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20request%20a%20hospitality%20activation%20for%20my%20Goa%20venue" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Request Activation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20to%20learn%20about%20hospitality%20activations%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Learn More
                </a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What Hospitality Activation Includes</h2>
                  <p className="body-md mb-8">End-to-end activation management for hospitality venues across Goa.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <h3 className="font-display font-bold text-xl text-white mb-6">Activation Categories</h3>
                  <div className="space-y-4">
                    {categories.map((cat, i) => (
                      <div key={i} className="flex items-center gap-4 p-4 rounded-xl bg-white/4 border border-white/8">
                        <div className={`w-10 h-10 rounded-lg ${cat.color === 'accent' ? 'bg-accent/15' : 'bg-white/10'} flex items-center justify-center`}>
                          <cat.icon size={18} className={cat.color === 'accent' ? 'text-accent' : 'text-white/80'} />
                        </div>
                        <span className="font-display font-bold text-sm text-white">{cat.title}</span>
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-2 gap-4 mt-6">
                    {[
                      { metric: '50+', label: 'Activations Delivered' },
                      { metric: '4', label: 'Activation Categories' },
                      { metric: '30+', label: 'Partner Venues' },
                      { metric: '2x', label: 'Average Footfall Increase' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Hospitality Activation FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Activate Your Goa Venue</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">From concept to execution, we deliver experiences that drive revenue.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20request%20a%20hospitality%20activation%20for%20my%20Goa%20venue" target="_blank" rel="noopener noreferrer" className="btn-primary">Request Activation</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
