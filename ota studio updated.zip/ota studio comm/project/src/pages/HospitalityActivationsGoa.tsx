import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Music, Leaf, Palette, Coffee } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'What are hospitality activations?', a: 'Hospitality activations are curated real-world experiences — live music, wellness sessions, creative workshops, cultural events — designed to drive footfall, engagement, and revenue at hospitality venues in Goa.' },
  { q: 'How are activations different from events?', a: 'Activations are strategically designed experiences tied to your venue brand and business goals. Unlike one-off events, activations create recurring engagement, build community, and integrate with your OTA and digital presence.' },
  { q: 'Which venues can benefit from activations?', a: 'Hotels, resorts, cafes, restaurants, bars, beach clubs, and homestays across Goa. Any hospitality venue looking to increase footfall and create memorable guest experiences.' },
  { q: 'Does OTA Studio have its own venue?', a: 'No. OTA Studio is not a physical venue. All activations happen at partner venues. We bring the talent, concept, marketing, and execution to your property.' },
  { q: 'How do I get started with activations?', a: 'Reach out via WhatsApp with your venue details. We assess your space, audience, and goals, then propose a tailored activation plan.' },
];

const includes = [
  'Venue assessment and audience profiling', 'Experience concept and theme design',
  'Talent booking from curated partner network', 'Pre-activation marketing and audience building',
  'On-site experience execution and coordination', 'Post-activation performance reporting',
  'OTA listing integration and cross-promotion', 'Recurring activation scheduling and management',
];

const categories = [
  { icon: Music, title: 'Music & Entertainment', color: 'accent' },
  { icon: Leaf, title: 'Wellness Experiences', color: 'white' },
  { icon: Palette, title: 'Creative & Cultural', color: 'white' },
  { icon: Coffee, title: 'Venue Activations', color: 'accent' },
];

export default function HospitalityActivationsGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white" itemProp="name">Hospitality Activations Goa</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Hospitality Activations · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Hospitality Activations Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Goa's first hospitality activation company. We curate music, wellness, creative, and cultural
                experiences at your venue to drive footfall, repeat visits, and revenue growth.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20hospitality%20activations%20for%20my%20Goa%20venue" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Request an Activation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/partner-network" className="btn-secondary">Join Partner Network</a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What Hospitality Activations Include</h2>
                  <p className="body-md mb-8">End-to-end activation management for hospitality venues across Goa.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <h3 className="font-display font-bold text-xl text-white mb-6">Activation Categories</h3>
                  <div className="space-y-4">
                    {categories.map((cat, i) => (
                      <div key={i} className="flex items-center gap-4 p-4 rounded-xl bg-white/4 border border-white/8">
                        <div className={`w-10 h-10 rounded-lg ${cat.color === 'accent' ? 'bg-accent/15' : 'bg-white/10'} flex items-center justify-center`}>
                          <cat.icon size={18} className={cat.color === 'accent' ? 'text-accent' : 'text-white/80'} />
                        </div>
                        <span className="font-display font-bold text-sm text-white">{cat.title}</span>
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-2 gap-4 mt-6">
                    {[
                      { metric: '50+', label: 'Activations Delivered' },
                      { metric: '4', label: 'Experience Categories' },
                      { metric: '30+', label: 'Partner Venues' },
                      { metric: '2x', label: 'Footfall Increase' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Hospitality Activations FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Activate Your Goa Venue</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">From concept to execution, we deliver experiences that drive revenue.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20hospitality%20activations%20for%20my%20Goa%20venue" target="_blank" rel="noopener noreferrer" className="btn-primary">Request an Activation</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
