import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Building2 } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What is hospitality community building?', a: 'It is creating engaged, loyal communities around your hospitality venue through consistent guest engagement, member programs, and curated experiences. Communities drive repeat visits, higher spending, and organic promotion.' },
  { q: 'How is it different from hospitality marketing?', a: 'Marketing focuses on bringing new customers. Community building focuses on turning customers into loyal members who visit frequently, spend more, and promote your venue enthusiastically.' },
  { q: 'What is a guest loyalty system?', a: 'A structured program that rewards repeat visits and higher spending with points, exclusive perks, early access, special pricing, and member-only experiences. Loyalty systems increase visit frequency by 3-4x.' },
  { q: 'How do you build hospitality communities?', a: 'Through consistent engagement: member programs, regular events, personalized communication, community spaces, feedback loops, and exclusive member benefits that create belonging and loyalty.' },
  { q: 'Can hospitality community building increase revenue?', a: 'Significantly. Community members visit 3-4x more often, spend 40-60% more per visit, and bring 2-3 new customers. Annual revenue increases of 40-60% are typical.' },
  { q: 'What is needed to start a community program?', a: 'A commitment to consistency, a member management system, regular event programming, member benefits, communication channels (email, WhatsApp), and dedicated community management.' },
];

const services = [
  'Hospitality community strategy and design',
  'Loyalty program creation and management',
  'Member benefits and rewards design',
  'Event programming and execution',
  'Community communication systems',
  'Member feedback and satisfaction tracking',
  'Guest experience optimization',
  'Monthly community growth and revenue reporting',
];

const programs = [
  'Points-based loyalty rewards',
  'Tiered membership levels',
  'Exclusive member events',
  'Early access and previews',
  'Special member pricing',
  'VIP experiences',
  'Referral rewards',
  'Anniversary and birthday perks',
];

export default function HospitalityCommunityBuildingGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Hospitality Community Building</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Community Building · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Hospitality Community Building Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Build engaged hospitality communities for Goa hotels, resorts, and venues. Member programs, loyalty systems, and guest engagement strategies that drive 3-4x visit frequency and 40-60% revenue growth.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20build%20a%20hospitality%20community" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Build Community <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20a%20Strategy%20Consultation" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Get Strategy Consultation
                </a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What We Deliver</h2>
                  <p className="body-md mb-8">Complete hospitality community building and management service.</p>
                  <ul className="space-y-3">
                    {services.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Building2 size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Community Programs</h3>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {programs.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-white/70">
                        <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                        {item}
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '4x', label: 'Visit Frequency' },
                      { metric: '50%', label: 'Revenue Growth' },
                      { metric: '1000+', label: 'Active Members' },
                      { metric: '91%', label: 'Retention Rate' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-8">Community Building Approach</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Strategy & Design</h3>
                  <p className="text-white/70 text-sm">Custom community strategies tailored to your venue type, audience, and business goals. We design programs that work for your specific context.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Loyalty & Rewards</h3>
                  <p className="text-white/70 text-sm">Points systems, tiered memberships, and exclusive perks that reward loyalty and incentivize higher frequency and spending.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Execution & Growth</h3>
                  <p className="text-white/70 text-sm">We manage day-to-day community operations, events, member communications, and continuously optimize for growth and satisfaction.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Hospitality Community FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Transform Guests Into Loyal Community</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Strategic community building that drives consistent revenue growth and strong brand loyalty.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Build Community</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
