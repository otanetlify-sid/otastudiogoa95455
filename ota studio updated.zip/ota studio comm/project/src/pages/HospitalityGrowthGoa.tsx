import { useState } from 'react';
import { ChevronDown, CheckCircle2, TrendingUp, Users, Coffee, UtensilsCrossed } from 'lucide-react';
import PageLayout from '../components/PageLayout';
import Breadcrumbs from '../components/Breadcrumbs';

const faqs = [
  {
    q: 'Do you help cafes and restaurants in Goa?',
    a: 'Yes. The OTA Studio supports cafes, restaurants, and bars in Goa with Google Business Profile optimization, platform listings, digital visibility, and hospitality growth strategies to attract more guests and increase footfall.',
  },
  {
    q: 'What does hospitality growth mean for my business?',
    a: 'Hospitality growth encompasses everything that improves your visibility, bookings, occupancy, and revenue. This includes OTA optimization, distribution management, pricing strategy, reputation management, and digital presence — all working together.',
  },
  {
    q: 'Do you support hospitality entrepreneurs in Goa?',
    a: 'Absolutely. Whether you are planning a new property, launching a cafe, or scaling an existing hospitality business in Goa, The OTA Studio provides the strategy and execution support you need.',
  },
  {
    q: 'What results can I expect?',
    a: 'Results vary by property type and starting point, but our typical clients in Goa see a 2-3x increase in bookings within 60-90 days of working with us. Revenue growth averages 2.8x across our managed portfolio.',
  },
  {
    q: 'Do you offer a property growth audit?',
    a: 'Yes. We offer a complimentary Property Growth Audit where we review your current online presence, OTA performance, listing quality, and growth opportunities specific to your Goa hospitality business.',
  },
];

const segments = [
  {
    icon: TrendingUp,
    title: 'Hotels & Resorts',
    desc: 'Full OTA management, distribution, revenue optimization, and growth strategy for hotels and resorts of all sizes in Goa.',
    services: ['OTA Management', 'Revenue Optimization', 'Channel Management', 'Distribution Strategy'],
  },
  {
    icon: Users,
    title: 'Villas & Airbnb',
    desc: 'Complete Airbnb and OTA management for villa owners, Airbnb hosts, and vacation rental properties across Goa.',
    services: ['Airbnb Optimization', 'Superhost Support', 'Pricing Strategy', 'Guest Experience'],
  },
  {
    icon: Coffee,
    title: 'Cafes & Bars',
    desc: 'Digital visibility, platform presence, and hospitality growth strategies to increase footfall for cafes and bars in Goa.',
    services: ['Google Profile', 'Platform Listings', 'Online Visibility', 'Review Management'],
  },
  {
    icon: UtensilsCrossed,
    title: 'Restaurants',
    desc: 'Complete digital growth for restaurants in Goa — from platform setup to online ordering and visibility improvement.',
    services: ['Platform Setup', 'Menu Optimization', 'Review Strategy', 'Visibility Growth'],
  },
];

export default function HospitalityGrowthGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <PageLayout
      title="Hospitality Growth Goa | Hotels, Cafes, Restaurants | The OTA Studio"
      description="Complete hospitality growth services in Goa for hotels, resorts, villas, cafes, restaurants and bars. The OTA Studio — Goa's one-stop hospitality growth partner."
      canonical="https://otastudio.in/hospitality-growth-goa"
    >
      <article>
        <div className="bg-neutral-950 pt-16 pb-20 sm:pt-20 sm:pb-28 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <div className="text-white/50 pb-2">
              <Breadcrumbs crumbs={[{ label: 'Hospitality Growth Goa' }]} />
            </div>
            <div className="max-w-3xl">
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Hospitality Growth · Goa</span>
              <h1 className="heading-xl text-white mb-6">
                Goa's One-Stop <br className="hidden sm:block" />
                <span className="text-accent">Hospitality Growth Partner</span>
              </h1>
              <p className="text-base sm:text-xl text-white/70 leading-relaxed mb-8">
                The OTA Studio is Goa's dedicated hospitality growth team — serving hotels,
                resorts, villas, Airbnb properties, cafes, restaurants, and bars with
                complete growth solutions that deliver real, measurable results.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20grow%20my%20hospitality%20business%20in%20Goa"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary"
                >
                  Start Growing Your Bookings
                </a>
                <a
                  href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20a%20Property%20Growth%20Audit"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-secondary"
                >
                  Get A Property Growth Audit
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="section-max section-padding py-16 sm:py-20 bg-neutral-900">
          <h2 className="heading-lg text-center text-white mb-12">
            Hospitality Growth for Every Business in Goa
          </h2>
          <div className="grid sm:grid-cols-2 gap-6">
            {segments.map((seg, i) => (
              <div
                key={i}
                className="p-7 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/7 hover:shadow-[0_0_20px_rgba(255,208,0,0.05)] hover:-translate-y-1 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-5">
                  <seg.icon size={22} className="text-accent" />
                </div>
                <h3 className="font-display font-bold text-xl text-white mb-3">{seg.title}</h3>
                <p className="text-sm text-white/50 leading-relaxed mb-5">{seg.desc}</p>
                <div className="flex flex-wrap gap-2">
                  {seg.services.map((s, j) => (
                    <span
                      key={j}
                      className="px-3 py-1 rounded-full bg-white/8 border border-white/8 text-xs font-medium text-white/60"
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-neutral-950 py-16 sm:py-20 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="heading-lg text-white mb-6">
                  Our Hospitality Growth Process
                </h2>
                <div className="space-y-4">
                  {[
                    { num: '1', title: 'Discovery', desc: 'We understand your business, goals, and current performance.' },
                    { num: '2', title: 'Property Review', desc: 'Full audit of your online presence, listings, and growth gaps.' },
                    { num: '3', title: 'Setup', desc: 'Platform setup, listing optimization, and technical configuration.' },
                    { num: '4', title: 'Optimization', desc: 'Content, pricing, photos, and visibility improvements go live.' },
                    { num: '5', title: 'Distribution', desc: 'Multi-platform distribution to reach the right guests everywhere.' },
                    { num: '6', title: 'Growth Support', desc: 'Ongoing monitoring, reporting, and continuous improvement.' },
                  ].map((step, i) => (
                    <div key={i} className="flex items-start gap-4">
                      <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center shrink-0">
                        <span className="font-display font-bold text-sm text-accent">{step.num}</span>
                      </div>
                      <div>
                        <div className="font-display font-bold text-white text-sm">{step.title}</div>
                        <div className="text-xs text-white/40 mt-0.5">{step.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div className="p-7 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white text-xl mb-6">
                    What We Deliver
                  </h3>
                  <ul className="space-y-3">
                    {[
                      'Increased OTA visibility and search rankings',
                      'More bookings and higher occupancy',
                      'Improved revenue per available room',
                      'Multi-platform distribution management',
                      'Stronger online reputation and reviews',
                      'Seasonal strategy and campaign management',
                      'Complete accountability — we own your results',
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={16} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-sm text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="mt-8 pt-6 border-t border-white/8">
                    <p className="text-xs text-white/50 mb-4">Also explore our specific services:</p>
                    <div className="flex flex-col gap-2">
                      {[
                        { label: 'OTA Management Goa', href: '/ota-management-goa' },
                        { label: 'Hotel Onboarding Goa', href: '/hotel-onboarding-goa' },
                        { label: 'Airbnb Management Goa', href: '/airbnb-management-goa' },
                      ].map((link, i) => (
                        <a
                          key={i}
                          href={link.href}
                          className="text-sm text-accent hover:text-accent-300 transition-colors underline underline-offset-2"
                        >
                          {link.label}
                        </a>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-neutral-900 py-16 sm:py-20 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-30" />
          <div className="section-max section-padding relative">
            <h2 className="heading-lg text-center text-white mb-12">
              Hospitality Growth FAQs — Goa
            </h2>
            <div className="max-w-3xl mx-auto space-y-3">
              {faqs.map((faq, i) => (
                <div
                  key={i}
                  className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden"
                >
                  <button
                    onClick={() => setOpenIdx(openIdx === i ? null : i)}
                    className="w-full flex items-center justify-between p-5 sm:p-6 text-left"
                    aria-expanded={openIdx === i}
                  >
                    <span className="font-display font-bold text-base sm:text-lg text-white pr-4">
                      {faq.q}
                    </span>
                    <ChevronDown
                      size={20}
                      className={`shrink-0 text-white/40 transition-transform duration-300 ${
                        openIdx === i ? 'rotate-180 text-accent' : ''
                      }`}
                    />
                  </button>
                  <div
                    className={`overflow-hidden transition-all duration-300 ${
                      openIdx === i ? 'max-h-48' : 'max-h-0'
                    }`}
                  >
                    <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-sm sm:text-base text-white/50 leading-relaxed">
                      {faq.a}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-neutral-950 py-16 sm:py-20 text-center relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <h2 className="heading-lg text-white mb-4">
              Grow Your Hospitality Business in Goa
            </h2>
            <p className="text-white/50 mb-8 max-w-xl mx-auto">
              Whether you run a hotel, a villa, a cafe, or a restaurant — The OTA Studio
              is your dedicated growth partner in Goa.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <a
                href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20grow%20my%20hospitality%20business%20in%20Goa"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
              >
                Start Growing Your Bookings
              </a>
              <a href="/" className="btn-secondary">
                Back to Home
              </a>
            </div>
          </div>
        </div>
      </article>
    </PageLayout>
  );
}
