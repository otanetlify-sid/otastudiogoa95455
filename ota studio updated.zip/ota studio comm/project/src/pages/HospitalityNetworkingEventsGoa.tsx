import { useState } from 'react';
import { ChevronDown, Users, Handshake, TrendingUp, Globe } from 'lucide-react';
import PageLayout from '../components/PageLayout';
import Breadcrumbs from '../components/Breadcrumbs';

const faqs = [
  {
    q: 'Who should attend hospitality networking events in Goa?',
    a: 'Hotel owners and managers, restaurateurs, cafe owners, homestay operators, Airbnb hosts, tour operators, travel agencies, event organizers, and hospitality suppliers all benefit. These events create partnerships and business opportunities across the entire hospitality ecosystem.',
  },
  {
    q: 'How do networking events help hospitality businesses grow?',
    a: 'Networking creates partnership opportunities for cross-promotion, referral networks, joint events, and collaborations. Hotel owners connect with activity providers, restaurants discover catering partners, and businesses build the relationships that drive growth.',
  },
  {
    q: 'What types of networking events work best for hospitality in Goa?',
    a: 'Breakfast networking sessions, industry panels, destination workshops, B2B speed networking, and collaborative dining events all work well. The key is creating value for attendees and facilitating genuine connections.',
  },
  {
    q: 'How often should networking events be held?',
    a: 'Monthly or quarterly events build momentum and create a regular community gathering. Many successful hospitality communities host monthly breakfast or evening sessions with rotating hosts.',
  },
  {
    q: 'Can small hospitality businesses benefit from networking?',
    a: 'Absolutely. Small businesses often benefit most from networking as it levels the playing field. Meaningful relationships and collaborations can drive significant growth without large marketing budgets.',
  },
  {
    q: 'How do you measure the success of networking events?',
    a: 'We track attendance, participant satisfaction, partnerships formed, referrals generated, and business deals that result from connections. Surveys and follow-up conversations help assess impact.',
  },
];

const services = [
  {
    icon: Handshake,
    title: 'Event Design & Curation',
    desc: 'We design networking events that facilitate genuine business connections. Each event is structured to maximize interaction, conversation, and relationship building among hospitality professionals.',
    features: [
      'Event format design',
      'Speaker and panel curation',
      'Discussion topic selection',
      'Venue and logistics',
    ],
  },
  {
    icon: Users,
    title: 'Community Building & Engagement',
    desc: 'Building and nurturing a community of hospitality entrepreneurs and professionals in Goa. We maintain engagement between events and create ongoing support networks.',
    features: [
      'Community membership programs',
      'WhatsApp and email groups',
      'Resource sharing platforms',
      'Member spotlighting',
    ],
  },
  {
    icon: Globe,
    title: 'Partnership & Collaboration Facilitation',
    desc: 'Actively connecting members for collaborations, joint events, cross-promotions, and business partnerships. We facilitate the relationships that drive growth.',
    features: [
      'Partnership introductions',
      'Joint event coordination',
      'Cross-promotion support',
      'Collaboration tracking',
    ],
  },
  {
    icon: TrendingUp,
    title: 'Business Growth Support',
    desc: 'Beyond networking, we provide mentorship, industry insights, and growth strategies to help members scale their hospitality businesses in Goa.',
    features: [
      'Industry workshops',
      'Growth strategy sessions',
      'Resource library',
      'One-on-one consulting',
    ],
  },
];

export default function HospitalityNetworkingEventsGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <PageLayout
      title="Hospitality Networking Events in Goa | Industry Connections | The OTA Studio"
      description="Hospitality networking events in Goa. Connect hotel owners, restaurateurs, cafe owners and hospitality professionals for partnerships and growth opportunities."
      canonical="https://otastudio.in/hospitality-networking-events-goa"
      schemaType="community"
    >
      <article>
        <div className="bg-neutral-950 pt-16 pb-20 sm:pt-20 sm:pb-28 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <div className="text-white/50 pb-2">
              <Breadcrumbs crumbs={[{ label: 'Community' }, { label: 'Hospitality Networking' }]} />
            </div>
            <div className="max-w-3xl">
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Community Events · Goa</span>
              <h1 className="heading-xl text-white mb-6">
                Hospitality Networking <br className="hidden sm:block" />
                <span className="text-accent">Events in Goa</span>
              </h1>
              <p className="text-base sm:text-xl text-white/70 leading-relaxed mb-8">
                Connect, collaborate, and grow. The OTA Studio brings together hospitality entrepreneurs,
                hotel owners, restaurateurs, and industry professionals in Goa to build relationships,
                share insights, and create business partnerships that drive mutual growth.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20join%20hospitality%20networking%20events"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary"
                >
                  Join Our Community
                </a>
                <a
                  href="https://wa.me/919309706263?text=Tell%20me%20about%20hosting%20networking%20events"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-secondary"
                >
                  Host a Networking Event
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="section-max section-padding py-16 sm:py-20 bg-neutral-900">
          <h2 className="heading-lg text-center text-white mb-12">
            How Hospitality Networking Works
          </h2>
          <div className="grid sm:grid-cols-2 gap-6">
            {services.map((service, i) => (
              <div
                key={i}
                className="p-7 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/7 hover:shadow-[0_0_20px_rgba(255,208,0,0.05)] hover:-translate-y-1 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-5">
                  <service.icon size={22} className="text-accent" />
                </div>
                <h3 className="font-display font-bold text-xl text-white mb-3">{service.title}</h3>
                <p className="text-sm text-white/50 leading-relaxed mb-5">{service.desc}</p>
                <div className="flex flex-wrap gap-2">
                  {service.features.map((feature, j) => (
                    <span
                      key={j}
                      className="px-3 py-1 rounded-full bg-white/8 border border-white/8 text-xs font-medium text-white/60"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-neutral-950 py-16 sm:py-20 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="heading-lg text-white mb-6">
                  Our Networking Model in Goa
                </h2>
                <div className="space-y-4">
                  {[
                    { num: '1', title: 'Monthly Gatherings', desc: 'Regular networking events bring hospitality professionals together to build relationships and share insights.' },
                    { num: '2', title: 'Curated Connections', desc: 'We actively facilitate introductions and partnerships among members based on complementary business interests.' },
                    { num: '3', title: 'Industry Learning', desc: 'Workshops, panels, and guest speakers provide practical knowledge and growth strategies for hospitality businesses.' },
                    { num: '4', title: 'Community Support', desc: 'Members get access to a shared knowledge base, mentorship, and peer support from fellow hospitality entrepreneurs.' },
                    { num: '5', title: 'Collaboration Opportunities', desc: 'From joint events to cross-promotions, we help members collaborate for mutual growth.' },
                    { num: '6', title: 'Ongoing Engagement', desc: 'Beyond events, we maintain community engagement through digital platforms and direct relationship management.' },
                  ].map((step, i) => (
                    <div key={i} className="flex items-start gap-4">
                      <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center shrink-0">
                        <span className="font-display font-bold text-sm text-accent">{step.num}</span>
                      </div>
                      <div>
                        <div className="font-display font-bold text-white text-sm">{step.title}</div>
                        <div className="text-xs text-white/40 mt-0.5">{step.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div className="p-7 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white text-xl mb-6">
                    Partnership Benefits
                  </h3>
                  <ul className="space-y-3">
                    {[
                      'Access to hotel owners and decision makers',
                      'Referral network for cross-promotions',
                      'Collaborations on joint events and packages',
                      'Supplier and vendor connections',
                      'Guest activity and experience providers',
                      'Marketing and tech service providers',
                      'Industry insights and best practices',
                      'Community reputation and credibility',
                      'Direct booking and partnership leads',
                      'Peer mentorship and support network',
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 shrink-0" />
                        <span className="text-sm text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-neutral-900 py-16 sm:py-20 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-30" />
          <div className="section-max section-padding relative">
            <h2 className="heading-lg text-center text-white mb-12">
              Networking FAQs — Goa Hospitality
            </h2>
            <div className="max-w-3xl mx-auto space-y-3">
              {faqs.map((faq, i) => (
                <div
                  key={i}
                  className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden"
                >
                  <button
                    onClick={() => setOpenIdx(openIdx === i ? null : i)}
                    className="w-full flex items-center justify-between p-5 sm:p-6 text-left"
                    aria-expanded={openIdx === i}
                  >
                    <span className="font-display font-bold text-base sm:text-lg text-white pr-4">
                      {faq.q}
                    </span>
                    <ChevronDown
                      size={20}
                      className={`shrink-0 text-white/40 transition-transform duration-300 ${
                        openIdx === i ? 'rotate-180 text-accent' : ''
                      }`}
                    />
                  </button>
                  <div
                    className={`overflow-hidden transition-all duration-300 ${
                      openIdx === i ? 'max-h-48' : 'max-h-0'
                    }`}
                  >
                    <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-sm sm:text-base text-white/50 leading-relaxed">
                      {faq.a}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-neutral-950 py-16 sm:py-20 text-center relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <h2 className="heading-lg text-white mb-4">
              Join Goa's Hospitality Community
            </h2>
            <p className="text-white/50 mb-8 max-w-xl mx-auto">
              Connect with fellow hospitality entrepreneurs, build partnerships, and grow your business
              through meaningful relationships and shared learning in Goa's vibrant hospitality community.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <a
                href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20join%20hospitality%20networking%20events"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
              >
                Join Our Community
              </a>
              <a href="/" className="btn-secondary">
                Back to Home
              </a>
            </div>
          </div>
        </div>
      </article>
    </PageLayout>
  );
}
