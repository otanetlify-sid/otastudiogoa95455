import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Users, TrendingUp, Activity } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'Why should Goa hostels use Hostelworld?', a: 'Hostelworld is the world\'s largest hostel-specific platform with 50+ million annual travelers. For Goa hostels and budget accommodations, Hostelworld is essential for reaching backpackers, long-term stayers, and budget-conscious travelers globally.' },
  { q: 'How is Hostelworld different from Booking.com for hostels?', a: 'Hostelworld is purpose-built for hostels with features like social community, activity boards, and hostel-specific amenities. Hostelworld guests are younger, more socially-focused, and book differently than business travelers on Booking.com.' },
  { q: 'What makes Hostelworld guests special for Goa hostels?', a: 'Hostelworld guests are primarily backpackers and young travelers seeking authentic experiences, social activities, and budget accommodations. They tend to book longer stays, participate in hostel events, and leave detailed reviews about social experience.' },
  { q: 'Can you help improve my Hostelworld ranking?', a: 'Yes, Hostelworld ranking is based on review scores, response rates, cleanliness ratings, and booking activity. We optimize all these factors plus leverage the social features to boost visibility and bookings.' },
  { q: 'How do you handle pricing for backpacker markets?', a: 'We optimize bed pricing to remain competitive while maintaining viability. Hostelworld guests are price-sensitive but willing to pay for quality social experiences and cleanliness, which we help you deliver and showcase.' },
  { q: 'Can you help with social features and activities?', a: 'Yes, we help you leverage Hostelworld\'s community features including event posting, activity boards, and social atmospheres to attract social travelers and increase repeat bookings and word-of-mouth.' },
];

const includes = [
  'Hostelworld listing optimization for backpackers',
  'Bed pricing optimization and rate management',
  'Cleanliness and social atmosphere highlighting',
  'Activity and event board management',
  'Guest communication and community engagement',
  'Review strategy focused on social experience',
  'Backpacker market targeting and positioning',
  'Weekly Hostelworld performance monitoring',
];

export default function HostelworldManagementGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Hostelworld Management Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Hostelworld Management · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Hostelworld Management Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Expert Hostelworld management for Goa hostels and budget accommodations. We optimize listings for backpacker markets,
                improve rankings, boost bed occupancy, and create vibrant social atmospheres that drive bookings and repeat guests.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20Hostelworld%20management%20for%20my%20Goa%20hostel" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Fill Your Hostel Beds <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">Hostelworld Management Includes</h2>
                  <p className="body-md text-white/70 mb-8">Complete Hostelworld optimization tailored for backpacker markets and budget accommodations.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <h3 className="font-display font-bold text-xl text-white mb-6">Results We Deliver</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '260%', label: 'Bed Occupancy Growth' },
                      { metric: '4.9+', label: 'Average Hostel Rating' },
                      { metric: '50M+', label: 'Travelers on Platform' },
                      { metric: '35+', label: 'Hostels Managed' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid md:grid-cols-3 gap-8 mb-16">
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <Activity size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Revenue Optimization</h3>
                  <p className="text-white/70 mb-4">Backpackers are price-sensitive but value experience and social atmosphere. We optimize bed pricing to maximize occupancy while implementing ancillary revenue strategies like activities, tours, and social events.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Backpacker-friendly bed pricing
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Occupancy-maximizing strategies
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Activity revenue opportunities
                    </li>
                  </ul>
                </div>

                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <Users size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Listing Optimization</h3>
                  <p className="text-white/70 mb-4">We highlight what backpackers seek: cleanliness, social atmosphere, communal areas, activities, and authentic experiences. Photos and descriptions showcase your hostel as a social hub, not just a place to sleep.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Social atmosphere highlighting
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Communal spaces showcase
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Cleanliness and safety emphasis
                    </li>
                  </ul>
                </div>

                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <TrendingUp size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Ranking Improvement</h3>
                  <p className="text-white/70 mb-4">Hostelworld ranking depends on review scores, response speed, cleanliness ratings, and social engagement. We optimize all metrics plus activate community features to boost visibility and establish your hostel as a top destination.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Top listing achievement
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Review score maximization
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Community engagement boost
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Benefits for Goa Hostels</h2>
              <div className="grid md:grid-cols-2 gap-8">
                {[
                  'Access to 50+ million annual backpackers seeking accommodations globally',
                  'Reach young travelers (18-35) who prefer authentic, social experiences',
                  'Book longer stays from backpackers traveling through India',
                  'Strong word-of-mouth and repeat bookings from satisfied guests',
                  'International traveler base provides year-round steady bookings',
                  'Hostelworld travelers are highly engaged and active on the platform',
                  'Community features drive hostel reputation and organic bookings',
                  'Lower marketing costs through strong organic Hostelworld bookings',
                ].map((benefit, i) => (
                  <div key={i} className="flex items-start gap-4 p-6 rounded-xl border border-white/8 bg-white/4">
                    <CheckCircle2 size={24} className="text-accent mt-1 shrink-0" />
                    <p className="text-white/70">{benefit}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Why Choose Us for Hostelworld?</h2>
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Backpacker Market Expertise</h3>
                  <p className="text-white/70">We specialize in the backpacker market, understanding their travel patterns, booking behaviors, budget consciousness, and desire for authentic social experiences. Our strategies attract and retain this lucrative segment.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Hostelworld Platform Mastery</h3>
                  <p className="text-white/70">Our team has deep expertise in Hostelworld's algorithms, ranking factors, and community features. We know exactly how to position your hostel for maximum visibility and create the social atmosphere that drives bookings.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Proven Hostel Growth</h3>
                  <p className="text-white/70">35+ Goa hostels have dramatically increased bed occupancy through our Hostelworld management. Average bed occupancy growth: 260%. Average hostel rating: 4.9+ stars from verified guests.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Related Services</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <a href="/property-management-goa" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Property Management Goa</h3>
                  <p className="text-white/70 mb-4">Complete property management including OTA management, operations, and revenue optimization.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/vision-mission" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Our Vision & Mission</h3>
                  <p className="text-white/70 mb-4">Learn about our approach to hospitality growth and property management excellence in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/founders" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Meet Our Founders</h3>
                  <p className="text-white/70 mb-4">Discover the team behind successful Hostelworld management strategies for Goa hostels.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Hostelworld Management FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-64' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ready to Fill Your Hostel Beds?</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Let's optimize your Hostelworld presence and attract a steady stream of backpackers and budget travelers from around the world.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20Hostelworld%20management%20for%20my%20hostel" target="_blank" rel="noopener noreferrer" className="btn-primary">Fill Your Hostel Beds</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
