import { useState } from 'react';
import { ChevronDown, Network, CircleCheck as CheckCircle2 } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'What is OTA distribution?', a: 'OTA distribution is the process of listing your property across multiple online booking platforms simultaneously, ensuring consistent availability and pricing.' },
  { q: 'What is channel management?', a: 'Channel management is a system that synchronizes your property\'s inventory, rates, and availability across all OTAs in real-time to prevent overbookings.' },
  { q: 'Which channel managers do you support?', a: 'We work with Cloudbeds, SiteMinder, eZee, Hotelogix, RMS, and other major channel managers.' },
  { q: 'How does distribution improve bookings?', a: 'Multi-platform distribution increases visibility, captures guests on their preferred booking sites, and maximizes occupancy.' },
];

const platforms = ['Booking.com', 'Airbnb', 'Agoda', 'Expedia', 'Hostelworld', 'MakeMyTrip', 'Goibibo', 'Trip.com'];

export default function HotelDistributionGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white">Hotel Distribution Goa</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Hotel Distribution · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Hotel Distribution Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Professional OTA distribution and channel management for hotels, resorts, villas, and homestays
                across Goa. Real-time inventory sync across all major booking platforms.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20hotel%20distribution%20services" target="_blank" rel="noopener noreferrer" className="btn-primary">
                  Start Distribution Setup <Network size={16} />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Distribution Across All Major OTAs</h2>
              <div className="flex flex-wrap justify-center gap-4 mb-12">
                {platforms.map((platform, i) => (
                  <div key={i} className="px-6 py-3 rounded-xl bg-white/4 border border-white/8 text-sm font-medium text-white/70">
                    {platform}
                  </div>
                ))}
              </div>
              <div className="grid md:grid-cols-3 gap-6">
                {[
                  { title: 'Channel Manager Setup', desc: 'Professional setup and configuration of your channel manager.', features: ['Real-time sync', 'Rate parity', 'Inventory management'] },
                  { title: 'Multi-OTA Distribution', desc: 'List your property on all relevant booking platforms.', features: ['8+ platforms', 'Consistent pricing', 'Maximum visibility'] },
                  { title: 'Overbooking Prevention', desc: 'Synchronized inventory prevents double bookings.', features: ['Zero conflicts', 'Automated updates', 'Guest satisfaction'] },
                ].map((item, i) => (
                  <div key={i} className="p-6 rounded-2xl border border-white/8 bg-white/4">
                    <h3 className="font-display font-bold text-lg text-white mb-2">{item.title}</h3>
                    <p className="text-sm text-white/50 mb-4">{item.desc}</p>
                    <ul className="space-y-2">
                      {item.features.map((f, j) => (
                        <li key={j} className="flex items-center gap-2 text-sm text-white/70">
                          <CheckCircle2 size={14} className="text-accent" /> {f}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Hotel Distribution FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Expand Your Distribution</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Reach more guests on more platforms.</p>
              <a href="https://wa.me/919270598602" target="_blank" rel="noopener noreferrer" className="btn-primary">Start Distribution Setup</a>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
