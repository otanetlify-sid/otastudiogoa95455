import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What is the complete list of licenses required to operate a hotel in Goa?', a: 'Operating a hotel in Goa requires multiple licenses: Tourism License/Hotel Registration from Goa Directorate of Tourism, FSSAI registration for food operations, Fire Safety NOC from Fire Department, Health Trade License from Municipal Corporation, Building Completion Certificate, GST registration, Shop and Establishment License, Liquor License (if serving alcohol), and Environmental Clearance. Each license has specific renewal requirements.' },
  { q: 'What is a Fire Safety NOC and how do I obtain it?', a: 'Fire Safety NOC (No Objection Certificate) is issued by the Fire Department confirming your property meets fire safety standards. Requirements include: proper fire exits and signage, fire extinguishers on all floors, emergency lighting systems, adequate water supply for firefighting, staff training on fire safety, and electrical safety standards. Application requires building plans, fire safety design approval, and inspection by Fire Department officials. Timeline: 2-4 weeks.' },
  { q: 'What is the Health Trade License requirement for hotels?', a: 'Health Trade License confirms your food handling facilities meet municipal health standards. Required for any food service operation (restaurant, room service, banquets). Inspection covers: kitchen cleanliness and equipment standards, food storage and handling procedures, water supply and sanitation facilities, staff health certificates, pest control measures, and waste management systems. License renewal is annual with periodic inspections.' },
  { q: 'Do I need GST registration for a hotel in Goa?', a: 'Yes, GST registration is mandatory for hotels with annual turnover exceeding ₹20 lakhs. GST is charged on room tariffs and F&B services at applicable rates (typically 5% for economy hotels, 12-28% for luxury properties). Proper GST registration ensures: legal tax compliance, credibility with guests and OTA platforms, ability to claim input tax credits on business expenses, and avoidance of penalties.' },
  { q: 'What is FSSAI registration and is it required for hotels?', a: 'FSSAI (Food Safety and Standards Authority of India) registration is mandatory if your hotel serves food. Based on turnover, you need either State License (₹200,000-300,000) or Central License (for large chains). Requirements include: food handler training, facility inspection, food safety protocols, and regular inspections. Non-compliance results in heavy fines and operational shutdown.' },
  { q: 'Is a bar/liquor license separate from hotel license?', a: 'Yes, bar or liquor license is separate from hotel license and requires independent application to Excise Department. Requirements include: specific distance from sensitive areas (schools, hospitals), approval from local administration, police verification, and payment of license fees (varies by license type). Renewal is annual. Serving alcohol without proper license results in criminal penalties and property seizure.' },
];

export default function HotelLicenseRequirementsGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Hotel License Requirements in Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Hotel Licensing · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Hotel License Requirements in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Complete checklist of all hotel licenses required to legally operate in Goa. Learn about fire NOC, health trade license, GST, FSSAI, bar license, and tourism department approvals needed for compliant hotel operations.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20help%20with%20hotel%20licenses%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Essential Hotel Licenses Checklist</h2>
              <div className="max-w-3xl mx-auto space-y-4">
                {[
                  { title: 'Tourism License/Hotel Registration', desc: 'Goa Directorate of Tourism registration with star classification' },
                  { title: 'Fire Safety NOC', desc: 'Fire Department approval for fire safety standards and emergency procedures' },
                  { title: 'Health Trade License', desc: 'Municipal Corporation approval for food safety and hygiene standards' },
                  { title: 'FSSAI Registration', desc: 'Food Safety Authority registration for food service operations' },
                  { title: 'GST Registration', desc: 'Tax registration for hotel operations and F&B services' },
                  { title: 'Building Completion Certificate', desc: 'Municipal Corporation approval confirming building standards' },
                  { title: 'Shop & Establishment License', desc: 'Basic operational license from Municipal Corporation' },
                  { title: 'Liquor/Bar License', desc: 'Excise Department approval if serving alcoholic beverages' },
                  { title: 'Environmental Clearance', desc: 'Required for hotels in sensitive environmental zones' },
                ].map((license, i) => (
                  <div key={i} className="p-6 rounded-2xl border border-accent/20 bg-accent/5">
                    <div className="flex items-start gap-4">
                      <CheckCircle2 size={24} className="text-accent mt-1 shrink-0" />
                      <div>
                        <h3 className="font-display font-bold text-white mb-2">{license.title}</h3>
                        <p className="text-white/70 text-sm">{license.desc}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Key License Details & Requirements</h2>
              <div className="grid md:grid-cols-2 gap-8">
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Fire Safety Standards</h3>
                  <p className="text-white/70 mb-4">Fire NOC requires: proper emergency exits on each floor, fire extinguishers at required intervals, emergency lighting systems, clear fire safety signage, sprinkler systems (for large hotels), electrical safety certification, and regular staff fire safety training. Building plans must be pre-approved by Fire Department before construction completion.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Regular fire safety inspections
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Staff fire safety training annually
                    </li>
                  </ul>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Health & Food Safety</h3>
                  <p className="text-white/70 mb-4">Health Trade License inspection covers: kitchen equipment and cleanliness standards, food storage facilities with proper temperature control, water supply testing and certification, waste disposal systems, pest control procedures, and staff health certificates. FSSAI registration requires kitchen design approval and regular food handler training for all staff.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Quarterly health department inspections
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Food handler certification programs
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Tax & Compliance Requirements</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">GST Registration</h3>
                  <p className="text-white/70 mb-4">GST registration is mandatory for hotels with annual turnover above ₹20 lakhs. Tax rates: 5% for economy hotels, 12% for mid-range, 28% for luxury hotels. Proper GST registration enables: input tax credit on business expenses, compliance with tax authorities, and credibility with OTA platforms and guests. Monthly/quarterly GST returns required.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">FSSAI Compliance</h3>
                  <p className="text-white/70 mb-4">FSSAI registration costs ₹200,000-300,000 for State License. Compliance requires: regular food handler training, kitchen audits, supplier verification, and food safety documentation. Violations result in heavy fines (₹2-5 lakhs) and operational shutdown. Renewal is annual with periodic surprise inspections by food safety officials.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Tourism Department Approval</h3>
                  <p className="text-white/70 mb-4">Tourism license with star classification opens eligibility for government schemes, tax incentives, and tourism promotion support. Classification is based on amenities, service standards, and infrastructure. Regular inspections ensure continued compliance. License renewal is annual with required facility inspections and documentation updates.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Related Services</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <a href="/property-management-goa" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Property Management Goa</h3>
                  <p className="text-white/70 mb-4">Ensure hotel license compliance and operational excellence.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/vision-mission" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Our Vision & Mission</h3>
                  <p className="text-white/70 mb-4">Learn about our commitment to hotel license compliance and success.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/founders" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Meet Our Founders</h3>
                  <p className="text-white/70 mb-4">Discover expertise in hotel licensing and compliance in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Hotel Licensing FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-64' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer" itemScope itemType="https://schema.org/Answer"><span itemProp="text">{faq.a}</span></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ensure Full Hotel License Compliance</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Let us help you navigate all hotel licensing requirements, from fire safety to FSSAI compliance, ensuring your hotel operates legally and successfully.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20help%20with%20hotel%20licenses%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="/" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
