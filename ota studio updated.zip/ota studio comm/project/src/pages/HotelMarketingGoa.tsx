import { useState } from 'react';
import { ChevronDown, TrendingUp, Users, Coffee, UtensilsCrossed } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'What is hotel marketing?', a: 'Hotel marketing includes OTA optimization, content strategy, pricing, visibility enhancement, and digital presence management to attract more guests.' },
  { q: 'Do you help cafes and restaurants?', a: 'Yes, we support cafes, restaurants, and bars with digital visibility, platform listings, and hospitality growth strategies.' },
  { q: 'What results can I expect?', a: 'Typical clients see 2-3x increase in bookings within 60-90 days of working with us.' },
  { q: 'Do you offer a property growth audit?', a: 'Yes, we offer a complimentary Property Growth Audit to review your current online presence.' },
];

const segments = [
  { icon: TrendingUp, title: 'Hotels & Resorts', desc: 'Full marketing, distribution, and revenue optimization.' },
  { icon: Users, title: 'Villas & Airbnb', desc: 'Complete Airbnb and vacation rental marketing.' },
  { icon: Coffee, title: 'Cafes & Bars', desc: 'Digital visibility and growth strategies.' },
  { icon: UtensilsCrossed, title: 'Restaurants', desc: 'Platform setup and visibility improvement.' },
];

export default function HotelMarketingGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white">Hotel Marketing Goa</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Hotel Marketing · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Hotel Marketing Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Complete hospitality marketing services for hotels, resorts, villas, homestays, cafes,
                and restaurants across Goa and India.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20hotel%20marketing%20services" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Start Growing Your Bookings <TrendingUp size={16} />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Hospitality Marketing for Every Business</h2>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {segments.map((seg, i) => (
                  <div key={i} className="p-6 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all">
                    <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-4">
                      <seg.icon size={22} className="text-accent" />
                    </div>
                    <h3 className="font-display font-bold text-lg text-white mb-2">{seg.title}</h3>
                    <p className="text-sm text-white/50">{seg.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Hotel Marketing FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Grow Your Hospitality Business</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Complete growth strategies for hotels, villas, cafes, and restaurants.</p>
              <a href="https://wa.me/919270598602" target="_blank" rel="noopener noreferrer" className="btn-primary">Start Growing Your Bookings</a>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
