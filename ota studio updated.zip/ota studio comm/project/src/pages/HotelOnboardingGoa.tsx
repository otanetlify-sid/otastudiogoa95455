import { useState } from 'react';
import { ChevronDown, CheckCircle2, ArrowRight } from 'lucide-react';
import PageLayout from '../components/PageLayout';
import Breadcrumbs from '../components/Breadcrumbs';

const faqs = [
  {
    q: 'How long does hotel onboarding take in Goa?',
    a: 'Most hotels in Goa go live on major OTAs within 7 to 14 days. The timeline depends on the number of platforms, property complexity, photo readiness, and document availability.',
  },
  {
    q: 'What documents do I need for hotel onboarding?',
    a: 'Typically you need FSSAI or hotel license, bank account details for payout, property photos, ID proof of owner, and property registration documents. We guide you through everything specific to your case.',
  },
  {
    q: 'Do you handle onboarding for small hotels and guesthouses in Goa?',
    a: 'Absolutely. We work with properties of every size — from large hotels to small guesthouses and boutique properties in Goa. Our process is tailored to your specific situation.',
  },
  {
    q: 'Which OTAs do you onboard on?',
    a: 'We onboard on all major platforms: Booking.com, Airbnb, Agoda, Expedia, MakeMyTrip, Goibibo, Hostelworld, and Trip.com. We also handle regional platforms as needed.',
  },
  {
    q: 'Is onboarding a one-time service or ongoing?',
    a: 'We offer both. One-time onboarding gets your property live and optimized. Our monthly management packages keep your listings performing and growing continuously.',
  },
];

const steps = [
  { num: '01', title: 'Discovery Call', desc: 'We understand your property, goals, and target guests to build the right strategy.' },
  { num: '02', title: 'Property Review', desc: 'Full audit of your current setup, photos, amenities, and competitive positioning.' },
  { num: '03', title: 'Content Creation', desc: 'We write compelling titles, descriptions, and room details optimized for OTA search.' },
  { num: '04', title: 'Platform Setup', desc: 'We create and configure your accounts on all relevant OTA platforms.' },
  { num: '05', title: 'Optimization', desc: 'Pricing strategy, photo sequencing, amenity mapping, and listing enhancement.' },
  { num: '06', title: 'Go Live & Monitor', desc: 'Your property goes live. We monitor rankings, bookings, and adjust rapidly.' },
];

export default function HotelOnboardingGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <PageLayout
      title="Hotel Onboarding Goa | OTA Onboarding Service | The OTA Studio"
      description="Professional hotel onboarding service in Goa. Get your hotel listed on Booking.com, Airbnb, Agoda and all major OTAs in 7-14 days. The OTA Studio, Goa."
      canonical="https://otastudio.in/hotel-onboarding-goa"
    >
      <article>
        <div className="bg-neutral-950 pt-16 pb-20 sm:pt-20 sm:pb-28 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <div className="text-white/50 pb-2">
              <Breadcrumbs crumbs={[{ label: 'Hotel Onboarding Goa' }]} />
            </div>
            <div className="max-w-3xl">
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Hotel Onboarding · Goa</span>
              <h1 className="heading-xl text-white mb-6">
                Hotel Onboarding on Every <br className="hidden sm:block" />
                <span className="text-accent">OTA in Goa</span>
              </h1>
              <p className="text-base sm:text-xl text-white/70 leading-relaxed mb-8">
                Get your hotel, resort, hostel, or villa listed on all major booking platforms
                in Goa — fast, correctly, and fully optimized from day one. The OTA Studio
                handles the entire onboarding process for you.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20help%20onboarding%20my%20hotel%20on%20OTAs%20in%20Goa"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary"
                >
                  Start Growing Your Bookings
                </a>
                <a
                  href="https://wa.me/919270598602?text=Hi%2C%20I%27d%20like%20a%20Property%20Growth%20Audit"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-secondary"
                >
                  Get A Property Growth Audit
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="section-max section-padding py-16 sm:py-20 bg-neutral-900">
          <h2 className="heading-lg text-center text-white mb-12">
            Our Hotel Onboarding Process in Goa
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {steps.map((step, i) => (
              <div
                key={i}
                className="p-6 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/7 hover:shadow-[0_0_20px_rgba(255,208,0,0.05)] transition-all duration-300"
              >
                <div className="font-display font-extrabold text-3xl text-accent/40 mb-4">
                  {step.num}
                </div>
                <h3 className="font-display font-bold text-base sm:text-lg text-white mb-2">{step.title}</h3>
                <p className="text-sm text-white/50 leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-neutral-950 py-16 sm:py-20 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <div className="grid lg:grid-cols-2 gap-12">
              <div>
                <h2 className="heading-lg text-white mb-6">
                  Everything Included in Our Onboarding Service
                </h2>
                <ul className="space-y-3">
                  {[
                    'OTA account creation and verification',
                    'Full listing content in English (and Hindi on request)',
                    'Room type setup and configuration',
                    'Rate plan creation (flexible, non-refundable, etc.)',
                    'Amenity and facility mapping',
                    'Photo upload and sequencing strategy',
                    'Policies setup (cancellation, check-in, house rules)',
                    'Payment and payout configuration',
                    'Channel manager setup (if applicable)',
                    'Go-live quality check and optimization',
                    'First 30 days performance monitoring',
                    'Handover and management transition',
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span className="text-sm sm:text-base text-white/70">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="space-y-5">
                <div className="p-6 rounded-2xl bg-white/4 border border-white/8">
                  <h3 className="font-display font-bold text-lg text-white mb-4">
                    Also Explore Our Other Services
                  </h3>
                  <div className="space-y-3">
                    {[
                      { label: 'OTA Management Goa', href: '/ota-management-goa' },
                      { label: 'Airbnb Management Goa', href: '/airbnb-management-goa' },
                      { label: 'Hospitality Growth Goa', href: '/hospitality-growth-goa' },
                    ].map((link, i) => (
                      <a
                        key={i}
                        href={link.href}
                        className="flex items-center justify-between py-3 border-b border-white/8 last:border-0 text-white/70 hover:text-accent transition-colors group"
                      >
                        <span className="text-sm font-medium">{link.label}</span>
                        <ArrowRight size={16} className="text-white/30 group-hover:text-accent transition-colors" />
                      </a>
                    ))}
                  </div>
                </div>

                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h4 className="font-display font-bold text-base text-white mb-3">Who We Help in Goa</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {['Hotels', 'Resorts', 'Hostels', 'Villas', 'Boutique Hotels', 'Guesthouses'].map(
                      (t, i) => (
                        <span
                          key={i}
                          className="px-3 py-2 rounded-lg bg-white/4 border border-white/8 text-xs sm:text-sm font-medium text-white/70 text-center"
                        >
                          {t}
                        </span>
                      )
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="section-max section-padding py-16 sm:py-20 bg-neutral-900">
          <h2 className="heading-lg text-center text-white mb-12">
            Hotel Onboarding FAQs — Goa
          </h2>
          <div className="max-w-3xl mx-auto space-y-3">
            {faqs.map((faq, i) => (
              <div
                key={i}
                className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden"
              >
                <button
                  onClick={() => setOpenIdx(openIdx === i ? null : i)}
                  className="w-full flex items-center justify-between p-5 sm:p-6 text-left"
                  aria-expanded={openIdx === i}
                >
                  <span className="font-display font-bold text-base sm:text-lg text-white pr-4">{faq.q}</span>
                  <ChevronDown
                    size={20}
                    className={`shrink-0 text-white/40 transition-transform duration-300 ${
                      openIdx === i ? 'rotate-180 text-accent' : ''
                    }`}
                  />
                </button>
                <div
                  className={`overflow-hidden transition-all duration-300 ${
                    openIdx === i ? 'max-h-48' : 'max-h-0'
                  }`}
                >
                  <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-sm sm:text-base text-white/50 leading-relaxed">
                    {faq.a}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-neutral-950 py-16 sm:py-20 text-center relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <h2 className="heading-lg text-white mb-4">
              Get Your Hotel Listed in Goa
            </h2>
            <p className="text-white/50 mb-8 max-w-xl mx-auto">
              Go live on all major OTAs in 7-14 days with complete optimization from day one.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <a
                href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20onboard%20my%20hotel%20on%20OTAs%20in%20Goa"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
              >
                Start Growing Your Bookings
              </a>
              <a href="/" className="btn-secondary">
                Back to Home
              </a>
            </div>
          </div>
        </div>
      </article>
    </PageLayout>
  );
}
