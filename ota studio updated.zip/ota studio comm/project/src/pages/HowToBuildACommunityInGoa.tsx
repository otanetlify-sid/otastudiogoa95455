import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'How do I attract community members to my hospitality space?', a: 'Use targeted social media, local partnerships, regular events, and online community platforms. OTA Studio helps integrate your community strategy with your property management and revenue model.' },
  { q: 'What types of communities work best for hospitality businesses?', a: 'Interest-based communities (wellness, fitness, wellness, creatives), neighborhood communities, and regular guest communities all work well. The key is consistent engagement and value delivery.' },
  { q: 'Can a community help increase my property revenue?', a: 'Absolutely. Communities drive repeat bookings, premium pricing, referrals, and event revenue. Regular community members book more often and spend 30-50% more than average guests.' },
  { q: 'How do I manage an online community platform?', a: 'Use platforms like Discord, Slack, or Mighty Networks. Assign community managers, create engagement calendars, facilitate discussions, and reward active members with exclusive benefits.' },
  { q: 'What metrics show my community is growing?', a: 'Track member count, engagement rates, event attendance, booking frequency from members, lifetime value, and net promoter score.' },
];

const steps = [
  'Define your community mission and core values',
  'Identify your target audience and their pain points',
  'Choose platforms (online and offline)',
  'Create engaging content and discussion themes',
  'Host regular events and meetups',
  'Build moderation and engagement guidelines',
  'Reward loyal members with exclusive benefits',
  'Measure growth and continuously improve',
];

export default function HowToBuildACommunityInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li><span itemProp="name">How to Build a Community in Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Community Building · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">How to Build a Community in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Create a thriving community around your hospitality business in Goa. Learn how to attract engaged members, leverage community for business growth, and build lasting relationships that drive revenue and brand loyalty.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20build%20a%20community%20for%20my%20business%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">Community Building Steps</h2>
                  <ol className="space-y-4">
                    {steps.map((step, i) => (
                      <li key={i} className="flex items-start gap-4">
                        <span className="flex items-center justify-center w-8 h-8 rounded-full bg-accent/20 text-accent font-display font-bold shrink-0">{i + 1}</span>
                        <span className="text-white/70 pt-0.5">{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
                <div className="space-y-6">
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Platform Options</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Discord or Slack (real-time chat)</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Mighty Networks (dedicated app)</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Facebook Groups (large reach)</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">In-person meetups and events</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Hybrid (online + offline)</span>
                      </li>
                    </ul>
                  </div>
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Investment & Timeline</h3>
                    <div className="space-y-2 text-white/70 text-sm">
                      <p><span className="text-accent font-semibold">Platform setup:</span> ₹10,000-50,000</p>
                      <p><span className="text-accent font-semibold">Monthly management:</span> ₹20,000-1,00,000</p>
                      <p><span className="text-accent font-semibold">ROI timeline:</span> 3-6 months</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Community Strategy & Growth</h2>
              <div className="grid md:grid-cols-2 gap-8 mb-12">
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Content & Engagement</h3>
                  <p className="text-white/70 mb-4">Create daily discussions, polls, events, and exclusive content. Share member stories, host expert sessions, and facilitate peer-to-peer connections that keep members engaged.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Membership Benefits</h3>
                  <p className="text-white/70 mb-4">Offer exclusive discounts, early access to bookings, special events, community merchandise, and recognition. Premium tiers unlock VIP experiences and personalized services.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Revenue Models</h3>
                  <p className="text-white/70 mb-4">Premium memberships, sponsored events, partner commissions, and premium accommodation packages. Communities increase property ADR by 25-40% through loyalty and repeat bookings.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">OTA Integration</h3>
                  <p className="text-white/70 mb-4">Promote community perks on Airbnb and Booking.com. Create exclusive community packages and use OTA Studio to integrate community programs with property management seamlessly.</p>
                </div>
              </div>
              <div className="p-8 rounded-2xl bg-neutral-900 border border-white/8">
                <h3 className="font-display font-bold text-xl text-white mb-4">Common Mistakes to Avoid</h3>
                <ul className="grid md:grid-cols-2 gap-4">
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Launching without clear mission</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Inconsistent engagement</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Poor moderation and spam</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Not providing real value</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Ignoring member feedback</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Not tracking member metrics</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Expert Tips for Success</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Start Small</h3>
                  <p className="text-white/70">Begin with 20-50 engaged members rather than 1000 inactive ones. Quality over quantity. Early members become ambassadors who attract others.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Be Authentic</h3>
                  <p className="text-white/70">Your community reflects your brand values. Participate actively, share your journey, and create genuine connections. Authentic communities grow organically through word-of-mouth.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Measure Success</h3>
                  <p className="text-white/70">Track growth, engagement, booking frequency, lifetime value, and NPS. Communities that improve these metrics by 50% generate 3x revenue per member.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Frequently Asked Questions</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="text">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`} itemScope itemType="https://schema.org/Answer">
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="text">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-4">Related Services</h2>
              <p className="text-center text-white/50 mb-8">Explore more ways to grow your hospitality business</p>
              <div className="grid md:grid-cols-3 gap-6">
                <a href="/property-management-goa" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Property Management</h3>
                  <p className="text-white/50 text-sm">Comprehensive management for your Goa properties</p>
                </a>
                <a href="/vision-mission" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Our Vision & Mission</h3>
                  <p className="text-white/50 text-sm">Understand our commitment to Goa's hospitality</p>
                </a>
                <a href="/founders" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Meet Our Founders</h3>
                  <p className="text-white/50 text-sm">Learn from our hospitality industry experts</p>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Build Your Community Today</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">OTA Studio helps you build, manage, and monetize communities that drive repeat bookings and revenue growth.</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="#" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
