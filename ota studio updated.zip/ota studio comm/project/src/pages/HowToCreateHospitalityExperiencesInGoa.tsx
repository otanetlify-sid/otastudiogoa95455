import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What makes a hospitality experience memorable?', a: 'Personalization, attention to detail, authentic local connections, and premium amenities create memorable experiences. Goa\'s natural beauty combined with personalized service commands premium pricing and generates 5+ referrals per guest.' },
  { q: 'How do I price hospitality experiences?', a: 'Calculate costs (accommodations, activities, staff, meals) and add 100-150% margin for profit. Experience packages typically range ₹50,000-2,00,000+ depending on duration, exclusivity, and personalization.' },
  { q: 'What experiences resonate most with guests?', a: 'Wellness retreats, adventure activities, cultural immersion, culinary experiences, and romantic getaways are top performers. Personalized itineraries based on guest interests increase satisfaction by 50-70%.' },
  { q: 'Can experiences boost property revenue?', a: 'Yes significantly. Experience packages increase ADR by 50-100%, boost occupancy by 30-40%, and create repeat bookings. Guests paying for curated experiences have 5-10x higher lifetime value.' },
  { q: 'How do I market hospitality experiences?', a: 'Target experience-seekers through lifestyle media, travel bloggers, social media, and OTA channels. Create compelling content showing transformation and results. OTA Studio integrates experiences with global distribution.' },
];

const steps = [
  'Define experience concept and target audience',
  'Design detailed itineraries and activities',
  'Partner with local guides and facilitators',
  'Set up activity logistics and equipment',
  'Create pricing structure and packages',
  'Build marketing content (photos, videos)',
  'Integrate with booking system',
  'Execute and collect guest testimonials',
];

export default function HowToCreateHospitalityExperiencesInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li><span itemProp="name">How to Create Hospitality Experiences in Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Hospitality Experiences · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">How to Create Hospitality Experiences in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Design transformative hospitality experiences in Goa that command premium pricing and create lasting guest relationships. Learn how to build curated experiences that increase revenue and generate exceptional reviews.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20create%20hospitality%20experiences%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">Experience Design Steps</h2>
                  <ol className="space-y-4">
                    {steps.map((step, i) => (
                      <li key={i} className="flex items-start gap-4">
                        <span className="flex items-center justify-center w-8 h-8 rounded-full bg-accent/20 text-accent font-display font-bold shrink-0">{i + 1}</span>
                        <span className="text-white/70 pt-0.5">{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
                <div className="space-y-6">
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Top Experience Types</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Wellness and yoga retreats</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Adventure and outdoor activities</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Cultural immersion tours</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Culinary and cooking experiences</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Romantic and honeymoon packages</span>
                      </li>
                    </ul>
                  </div>
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Revenue Model</h3>
                    <div className="space-y-2 text-white/70 text-sm">
                      <p><span className="text-accent font-semibold">3-day experience:</span> ₹50,000-1,00,000</p>
                      <p><span className="text-accent font-semibold">7-day experience:</span> ₹1.5-3 lakhs</p>
                      <p><span className="text-accent font-semibold">Premium packages:</span> ₹3+ lakhs</p>
                      <p><span className="text-accent font-semibold">Profit margin:</span> 50-70%</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Experience Execution & Growth</h2>
              <div className="grid md:grid-cols-2 gap-8 mb-12">
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Personalization</h3>
                  <p className="text-white/70 mb-4">Tailor experiences to individual preferences, interests, and needs. Pre-arrival communication, custom activities, and thoughtful touches increase satisfaction by 50-70% and drive repeat bookings.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Local Partnerships</h3>
                  <p className="text-white/70 mb-4">Collaborate with local guides, instructors, and businesses. Authentic local connections enhance experiences and support community. Local partnerships reduce costs by 20-30% while improving quality.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Premium Positioning</h3>
                  <p className="text-white/70 mb-4">Position as curated, exclusive experiences. High prices attract quality guests. Premium-positioned experiences have 5-10x higher profit margins and generate more referrals than budget options.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Storytelling & Marketing</h3>
                  <p className="text-white/70 mb-4">Create compelling stories showing transformation and results. Video testimonials, before/after narratives, and guest stories drive bookings. Strong storytelling increases conversion rates 3-5x.</p>
                </div>
              </div>
              <div className="p-8 rounded-2xl bg-neutral-900 border border-white/8">
                <h3 className="font-display font-bold text-xl text-white mb-4">Common Mistakes to Avoid</h3>
                <ul className="grid md:grid-cols-2 gap-4">
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Generic, impersonal experiences</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Overcommitting on activities</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Poor activity coordination</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Inadequate contingency plans</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Not collecting testimonials</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">No post-experience engagement</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Expert Tips for Success</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Focus on Results</h3>
                  <p className="text-white/70">Design experiences that create measurable transformation - wellness improvements, skills learned, memories created. Guests seeking transformation spend 5-10x more than casual tourists.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Build Communities</h3>
                  <p className="text-white/70">Engage past guests in ongoing communities. Host alumni events, exclusive content, and networking. Community members generate 3x revenue through repeat bookings and referrals.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Leverage Reviews</h3>
                  <p className="text-white/70">Exceptional experiences generate exceptional reviews. Great reviews are worth ₹10+ lakhs in marketing equivalent. One 5-star experience review drives 10+ bookings.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Frequently Asked Questions</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="text">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`} itemScope itemType="https://schema.org/Answer">
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="text">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-4">Related Services</h2>
              <p className="text-center text-white/50 mb-8">Explore more ways to grow your hospitality business</p>
              <div className="grid md:grid-cols-3 gap-6">
                <a href="/property-management-goa" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Property Management</h3>
                  <p className="text-white/50 text-sm">Comprehensive management for your Goa properties</p>
                </a>
                <a href="/vision-mission" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Our Vision & Mission</h3>
                  <p className="text-white/50 text-sm">Understand our commitment to Goa's hospitality</p>
                </a>
                <a href="/founders" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Meet Our Founders</h3>
                  <p className="text-white/50 text-sm">Learn from our hospitality industry experts</p>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Design Your Experience Today</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">OTA Studio helps you create, price, and market transformative hospitality experiences that command premium revenue.</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="#" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
