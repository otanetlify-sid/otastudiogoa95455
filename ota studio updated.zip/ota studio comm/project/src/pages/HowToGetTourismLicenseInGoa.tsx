import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What is a tourism license in Goa and why is it important?', a: 'A tourism license is an official recognition from the Goa Directorate of Tourism certifying that your hospitality property meets defined standards. It\'s essential for: legal authorization to operate, credibility with guests and OTA platforms, eligibility for government tourism schemes and incentives, and marketing recognition. Properties with valid tourism licenses command higher booking rates and attract more guests.' },
  { q: 'What is GTDC registration and how does it differ from tourism license?', a: 'GTDC (Goa Tourism Development Corporation) registration formally registers your property with the state tourism authority. It enables your property to appear in official tourism databases and government promotion channels. Tourism license is the star classification (3-star, 4-star, etc.), while GTDC registration is the baseline official registration. Both are recommended for maximum visibility and credibility.' },
  { q: 'What documents are required for tourism license application in Goa?', a: 'Required documentation includes: property ownership proof or lease agreement, building completion certificate, NOC from Municipal Corporation, Fire Safety NOC, Health Trade License, Proof of FSSAI registration (if serving food), Property photographs and architectural plans, Detailed property amenities list, Environmental clearance (if applicable), and GST registration certificate. Complete documentation ensures smooth approval.' },
  { q: 'How long does tourism license approval take in Goa?', a: 'The approval timeline varies: initial application verification takes 1-2 weeks, property inspection by tourism department officials takes 1 week, and final approval takes 1-2 weeks. Total timeline: typically 4-8 weeks from complete application submission. Delayed approvals often result from incomplete documentation. We recommend starting early and ensuring all papers are complete.' },
  { q: 'What is the cost of obtaining a tourism license in Goa?', a: 'Application fees vary by star classification and property size: 2-star properties (₹5,000-10,000), 3-star properties (₹10,000-15,000), 4-star properties (₹15,000-25,000), 5-star properties (₹25,000+). Additional costs include processing fees, inspection fees, and potential consultant fees if hiring professional assistance. Budget ₹10,000-50,000 total including all associated expenses.' },
  { q: 'What are the renewal requirements for tourism license?', a: 'Tourism licenses must be renewed annually or per classification validity period. Renewal requires: updated property photographs, compliance confirmation with safety and quality standards, renewed health and fire safety NOCs, and completion of any required improvements since last inspection. Timely renewal maintains legal operation status and prevents penalties.' },
];

export default function HowToGetTourismLicenseInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">How to Get a Tourism License in Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Tourism License · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">How to Get a Tourism License in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Step-by-step guide to obtaining a tourism license in Goa. Learn about GTDC registration, required documents, approval timelines, costs, renewal requirements, and how tourism licensing improves your property's visibility and credibility.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20help%20with%20tourism%20license%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Tourism License Process in Goa</h2>
              <div className="grid md:grid-cols-2 gap-8">
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Documentation Requirements</h3>
                  <p className="text-white/70 mb-4">Prepare comprehensive documentation before application submission. Essential documents: property ownership deed or lease agreement, municipal building completion certificate, detailed architectural drawings, property photographs (indoor/outdoor), complete amenities list, fire and health safety certificates, FSSAI registration (if applicable), and GST documents. Complete documentation speeds approval.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Organized document submission
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Official certificate acquisition
                    </li>
                  </ul>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Application Process</h3>
                  <p className="text-white/70 mb-4">Submit application to Goa Directorate of Tourism with complete documentation. Application review takes 1-2 weeks. Property inspection by tourism officials follows, examining facilities, safety standards, and amenities. Final approval and license issuance takes additional 1-2 weeks. Maintain communication with tourism department for status updates.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Online or offline application options
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Professional inspection coordination
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Star Classification & Amenity Requirements</h2>
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <h3 className="heading-md text-white mb-4">2-Star & 3-Star Hotels</h3>
                  <p className="text-white/70">2-star classifications require basic amenities: adequate room size, clean facilities, basic safety standards, and functional guest services. 3-star requires additional amenities: better furnishings, additional facilities (restaurant or breakfast area), enhanced housekeeping standards, and improved guest services. Meeting amenity requirements improves guest satisfaction and OTA ratings.</p>
                </div>
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <h3 className="heading-md text-white mb-4">4-Star & 5-Star Hotels</h3>
                  <p className="text-white/70">4-star properties require premium amenities: luxury furnishings, multiple dining options, concierge services, enhanced facilities (gym, spa basics), and high-quality room service. 5-star demands: exceptional design, premium services (spa, fine dining, room service), personalized guest experiences, and state-of-the-art facilities. Higher classifications command premium pricing and attract international guests.</p>
                </div>
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <h3 className="heading-md text-white mb-4">Guest House & Homestay Classification</h3>
                  <p className="text-white/70">Guest houses and homestays have separate classification tracks focusing on cleanliness, comfort, hospitality, and safety rather than extensive amenities. Requirements are simpler and more affordable than hotel classifications, making them accessible for smaller properties. These classifications emphasize authentic Goan hospitality and personalized guest experiences.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Tourism License Benefits</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Legal Credibility</h3>
                  <p className="text-white/70 mb-4">Tourism license provides legal authorization to operate hospitality business. It protects your operations from regulatory challenges and enforcement actions. Guests trust licensed properties more than unlicensed ones. OTA platforms and booking agencies prefer licensed properties, improving your marketplace credibility.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Marketing & Visibility</h3>
                  <p className="text-white/70 mb-4">Licensed properties receive inclusion in official Goa tourism directories and promotional channels. Tourist information centers list licensed accommodations. Government tourism websites feature classified properties. This official recognition increases visibility among tourists seeking trusted accommodations and improves booking rates.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Government Incentives</h3>
                  <p className="text-white/70 mb-4">Licensed properties become eligible for government tourism schemes, grants, and incentives. Goa Tourism Department offers support programs for hospitality businesses. Some incentives include tax benefits, infrastructure development grants, and promotional support. Licensing opens doors to business development opportunities.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Related Services</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <a href="/property-management-goa" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Property Management Goa</h3>
                  <p className="text-white/70 mb-4">Manage tourism license compliance and hospitality operations effectively.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/vision-mission" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Our Vision & Mission</h3>
                  <p className="text-white/70 mb-4">Learn about our commitment to tourism business success in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/founders" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Meet Our Founders</h3>
                  <p className="text-white/70 mb-4">Discover the expertise behind successful tourism licensing in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Tourism License FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-64' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer" itemScope itemType="https://schema.org/Answer"><span itemProp="text">{faq.a}</span></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ready to Get Your Tourism License in Goa?</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Let us guide you through the tourism license application process, from documentation preparation to final approval and GTDC registration.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20help%20with%20tourism%20license%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="/" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
