import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What accommodations do yoga retreat guests expect?', a: 'Guests expect comfortable rooms, quality bedding, peaceful ambiance, and wellness amenities. Goa offers natural advantages with beaches, gardens, and wellness-focused infrastructure that support premium retreat experiences.' },
  { q: 'How do I find certified yoga instructors in Goa?', a: 'Partner with yoga studios, training centers, and certified instructors through local networks. OTA Studio connects you with qualified facilitators and helps integrate retreat bookings with your property management.' },
  { q: 'What is the ideal retreat duration?', a: 'Most successful retreats are 3-7 days. This provides enough time for transformation while being accessible to busy professionals. Weekend intensives (2-3 days) also work well for budget-conscious guests.' },
  { q: 'How do I price yoga retreats competitively?', a: 'Factor in instructor fees, meals, activities, and overhead. Goa retreats typically range ₹15,000-50,000+ for 3-7 days. Premium experiences command premium pricing based on instructor reputation and amenities.' },
  { q: 'Can I market retreats internationally?', a: 'Yes. Goa attracts international yoga tourists. Use Booking.com, Airbnb, specialized yoga platforms, and global yoga communities. OTA Studio amplifies your reach through multiple channels.' },
];

const steps = [
  'Secure retreat dates and lock accommodation availability',
  'Hire certified yoga instructors and wellness facilitators',
  'Design retreat schedule and activities',
  'Plan meals and dietary accommodations',
  'Get liability insurance and wellness waivers',
  'Create marketing collateral and promotional strategy',
  'Build booking and payment system',
  'Execute seamless retreat experience',
];

export default function HowToHostYogaRetreatsInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li><span itemProp="name">How to Host Yoga Retreats in Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Yoga Retreats · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">How to Host Yoga Retreats in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Launch successful yoga retreats in Goa. Learn how to design transformative experiences, manage operations, attract international guests, and generate ₹50,000+ revenue per retreat while building your wellness brand.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20host%20yoga%20retreats%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">Retreat Setup Steps</h2>
                  <ol className="space-y-4">
                    {steps.map((step, i) => (
                      <li key={i} className="flex items-start gap-4">
                        <span className="flex items-center justify-center w-8 h-8 rounded-full bg-accent/20 text-accent font-display font-bold shrink-0">{i + 1}</span>
                        <span className="text-white/70 pt-0.5">{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
                <div className="space-y-6">
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Legal & Insurance</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Liability insurance</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Wellness liability waiver</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Instructor credentials verification</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Health & safety compliance</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Guest privacy agreements</span>
                      </li>
                    </ul>
                  </div>
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Revenue Model</h3>
                    <div className="space-y-2 text-white/70 text-sm">
                      <p><span className="text-accent font-semibold">3-day retreat:</span> ₹15,000-25,000 per person</p>
                      <p><span className="text-accent font-semibold">7-day retreat:</span> ₹35,000-60,000 per person</p>
                      <p><span className="text-accent font-semibold">12-person retreat:</span> ₹3-7 lakhs total</p>
                      <p><span className="text-accent font-semibold">Profit margin:</span> 40-60%</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Retreat Operations & Growth</h2>
              <div className="grid md:grid-cols-2 gap-8 mb-12">
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Guest Experience Design</h3>
                  <p className="text-white/70 mb-4">Create transformative itineraries with daily yoga, meditation, healthy meals, wellness activities, and free time. Personalized touch points (welcome packets, customized sessions) increase satisfaction and reviews.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">International Marketing</h3>
                  <p className="text-white/70 mb-4">List on Yoga Alliance directories, Airbnb, Booking.com, and yoga-specific platforms. Build email lists, create retreat videos, leverage yoga influencers, and use paid ads targeting yoga enthusiasts globally.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Operational Efficiency</h3>
                  <p className="text-white/70 mb-4">Use property management software for bookings, payments, and communication. Automate confirmations, reminders, and post-retreat follow-ups. Train staff for wellness hospitality standards.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Partnerships & OTA Strategy</h3>
                  <p className="text-white/70 mb-4">Partner with yoga platforms, wellness centers, and travel companies. Promote via OTA Studio to reach international wellness tourists. Create package deals combining accommodation with retreat experiences.</p>
                </div>
              </div>
              <div className="p-8 rounded-2xl bg-neutral-900 border border-white/8">
                <h3 className="font-display font-bold text-xl text-white mb-4">Common Mistakes to Avoid</h3>
                <ul className="grid md:grid-cols-2 gap-4">
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Poor instructor quality or credentials</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Inadequate meal planning</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Overbooking accommodations</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">No contingency plans</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Poor communication with guests</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Neglecting post-retreat engagement</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Expert Tips for Success</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Quality Over Volume</h3>
                  <p className="text-white/70">Smaller, high-quality retreats (8-12 guests) build reputation faster than large events. Excellent reviews and testimonials lead to repeat bookings and referrals worth 10x marketing spend.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Leverage Instructors</h3>
                  <p className="text-white/70">Partner with established yoga instructors who have their own audiences. Their followers become your retreat guests. Co-marketing with instructors amplifies reach 3-5x.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Create Communities</h3>
                  <p className="text-white/70">Keep retreat alumni engaged. Email lists, WhatsApp groups, and exclusive perks create repeat bookings. Alumni spend 60% more and have 2x higher referral rates.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Frequently Asked Questions</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="text">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`} itemScope itemType="https://schema.org/Answer">
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="text">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-4">Related Services</h2>
              <p className="text-center text-white/50 mb-8">Explore more ways to grow your hospitality business</p>
              <div className="grid md:grid-cols-3 gap-6">
                <a href="/property-management-goa" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Property Management</h3>
                  <p className="text-white/50 text-sm">Comprehensive management for your Goa properties</p>
                </a>
                <a href="/vision-mission" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Our Vision & Mission</h3>
                  <p className="text-white/50 text-sm">Understand our commitment to Goa's hospitality</p>
                </a>
                <a href="/founders" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Meet Our Founders</h3>
                  <p className="text-white/50 text-sm">Learn from our hospitality industry experts</p>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Launch Your Yoga Retreat</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">OTA Studio helps you design, market, and manage yoga retreats that attract international guests and generate premium revenue.</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="#" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
