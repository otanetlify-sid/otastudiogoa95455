import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What types of wellness events perform best in Goa?', a: 'Yoga retreats, meditation workshops, nutrition seminars, fitness bootcamps, spa days, and wellness festivals attract large audiences. Goa\'s wellness-focused tourism means premium pricing opportunities for quality experiences.' },
  { q: 'How do I attract wellness event participants?', a: 'Target wellness communities, health-conscious travelers, and corporate groups. Use social media, wellness platforms, hotel partnerships, and OTA Studio to reach international wellness tourists globally.' },
  { q: 'What is the revenue potential for wellness events?', a: 'Small events (30-50 people): ₹1-2 lakhs. Medium events (50-150 people): ₹2-5 lakhs. Large festivals (150+ people): ₹5+ lakhs. Wellness events have 60-70% profit margins compared to standard events.' },
  { q: 'Do I need special insurance for wellness events?', a: 'Yes. Liability insurance covering health/wellness activities is essential. Ensure instructors are certified and carry malpractice insurance. Document waivers and health disclosures for all participants.' },
  { q: 'Can I integrate wellness events with property bookings?', a: 'Absolutely. Package wellness events with accommodation for premium pricing. Participants book rooms for event duration, increasing occupancy and ADR by 40-60%.' },
];

const steps = [
  'Define wellness event concept and target audience',
  'Identify qualified wellness practitioners',
  'Plan venue, schedule, and logistics',
  'Obtain appropriate insurance coverage',
  'Create compelling marketing materials',
  'Build registration and payment system',
  'Coordinate accommodation for participants',
  'Execute and gather feedback for future events',
];

export default function HowToOrganizeWellnessEventsInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li><span itemProp="name">How to Organize Wellness Events in Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Wellness Events · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">How to Organize Wellness Events in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Create transformative wellness events in Goa. Learn how to coordinate practitioners, attract participants, generate premium revenue, and integrate events with property bookings for maximum business impact.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20organize%20wellness%20events%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">Wellness Event Steps</h2>
                  <ol className="space-y-4">
                    {steps.map((step, i) => (
                      <li key={i} className="flex items-start gap-4">
                        <span className="flex items-center justify-center w-8 h-8 rounded-full bg-accent/20 text-accent font-display font-bold shrink-0">{i + 1}</span>
                        <span className="text-white/70 pt-0.5">{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
                <div className="space-y-6">
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Key Requirements</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Wellness liability insurance</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Certified practitioners</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Health disclosure forms</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Medical emergency protocols</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Appropriate venue amenities</span>
                      </li>
                    </ul>
                  </div>
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Revenue Potential</h3>
                    <div className="space-y-2 text-white/70 text-sm">
                      <p><span className="text-accent font-semibold">Workshop (30 people):</span> ₹1-2 lakhs</p>
                      <p><span className="text-accent font-semibold">Day retreat (50 people):</span> ₹2-4 lakhs</p>
                      <p><span className="text-accent font-semibold">Weekend event (100 people):</span> ₹4-8 lakhs</p>
                      <p><span className="text-accent font-semibold">Profit margin:</span> 60-70%</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Event Marketing & Operations</h2>
              <div className="grid md:grid-cols-2 gap-8 mb-12">
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Participant Acquisition</h3>
                  <p className="text-white/70 mb-4">Target wellness communities, corporate wellness programs, and health-conscious travelers. Use wellness directories, social media, email marketing, and partnerships with health practitioners for authentic reach.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Practitioner Coordination</h3>
                  <p className="text-white/70 mb-4">Partner with certified yoga instructors, nutritionists, massage therapists, and wellness coaches. Clear agreements on fees, credentials, and liability ensure professional execution and participant safety.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Accommodation Integration</h3>
                  <p className="text-white/70 mb-4">Bundle event participation with property bookings. Participants stay overnight, attending sessions throughout their stay. This increases ADR 25-40% and generates multiple revenue streams.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">OTA Opportunity</h3>
                  <p className="text-white/70 mb-4">List wellness events on Airbnb, Booking.com, and OTA Studio. Package events with accommodation for seamless booking experience. Global reach increases participation 3-5x versus local marketing alone.</p>
                </div>
              </div>
              <div className="p-8 rounded-2xl bg-neutral-900 border border-white/8">
                <h3 className="font-display font-bold text-xl text-white mb-4">Common Mistakes to Avoid</h3>
                <ul className="grid md:grid-cols-2 gap-4">
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Unqualified practitioners</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Missing insurance coverage</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Poor venue conditions</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Inadequate health screening</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Poor participant communication</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">No follow-up or community building</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Expert Tips for Success</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Quality First</h3>
                  <p className="text-white/70">Invest in certified practitioners and quality venues. Wellness event reputation is built on transformative participant experiences. One great event generates 5+ referrals.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Premium Positioning</h3>
                  <p className="text-white/70">Goa attracts wellness-focused, high-spending tourists. Position events as premium experiences with exclusive benefits. Premium events achieve 2x profitability vs standard events.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Build Community</h3>
                  <p className="text-white/70">Keep participants engaged post-event through groups, newsletters, and exclusive content. Engaged communities generate repeat bookings and sustained revenue growth.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Frequently Asked Questions</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="text">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`} itemScope itemType="https://schema.org/Answer">
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="text">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-4">Related Services</h2>
              <p className="text-center text-white/50 mb-8">Explore more ways to grow your hospitality business</p>
              <div className="grid md:grid-cols-3 gap-6">
                <a href="/property-management-goa" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Property Management</h3>
                  <p className="text-white/50 text-sm">Comprehensive management for your Goa properties</p>
                </a>
                <a href="/vision-mission" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Our Vision & Mission</h3>
                  <p className="text-white/50 text-sm">Understand our commitment to Goa's hospitality</p>
                </a>
                <a href="/founders" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Meet Our Founders</h3>
                  <p className="text-white/50 text-sm">Learn from our hospitality industry experts</p>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Organize Your Wellness Event</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">OTA Studio helps you plan, promote, and execute wellness events that attract participants globally and drive premium revenue.</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="#" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
