import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What types of community events work best for cafes?', a: 'Open mic nights, poetry readings, art exhibitions, book clubs, trivia nights, gaming tournaments, and live acoustic music build community and increase foot traffic. Goa\'s vibrant culture supports creative events.' },
  { q: 'How do community events increase cafe revenue?', a: 'Events attract new customers, increase order frequency, extend visit duration, and create loyalty. Community event attendees spend 40-60% more than regular café customers and become repeat visitors.' },
  { q: 'How often should I host community events?', a: 'Weekly or bi-weekly events maintain momentum and build reliable audiences. Consistent schedules help customers plan around events. Regular events increase café footfall by 30-50%.' },
  { q: 'Do I need permits for cafe community events?', a: 'Most cafe events don\'t require special permits if conducted during normal operating hours. Live music or larger gatherings may need approval. Check with local authorities for compliance.' },
  { q: 'How do I attract people to cafe events?', a: 'Social media, email lists, local partnerships, flyers, and word-of-mouth are most effective. Promote events consistently starting 2 weeks before. Free or low-cost first event builds initial audience.' },
];

const steps = [
  'Choose event types matching your cafe vibe',
  'Set regular schedule (weekly or bi-weekly)',
  'Identify local performers or facilitators',
  'Plan logistics and space arrangement',
  'Create marketing strategy',
  'Set up simple registration or booking system',
  'Promote through social media and local networks',
  'Execute and gather feedback for improvement',
];

export default function HowToRunCommunityEventsForCafes() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li><span itemProp="name">How to Run Community Events for Cafes</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Cafe Events · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">How to Run Community Events for Cafes</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Build thriving cafe communities in Goa. Learn how to organize events that attract loyal customers, increase revenue, and create memorable experiences that keep people coming back.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20run%20community%20events%20for%20my%20cafe%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">Event Setup Steps</h2>
                  <ol className="space-y-4">
                    {steps.map((step, i) => (
                      <li key={i} className="flex items-start gap-4">
                        <span className="flex items-center justify-center w-8 h-8 rounded-full bg-accent/20 text-accent font-display font-bold shrink-0">{i + 1}</span>
                        <span className="text-white/70 pt-0.5">{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
                <div className="space-y-6">
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Event Ideas for Cafes</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Open mic nights</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Art exhibitions and artist talks</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Book clubs and author readings</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Trivia nights and quiz competitions</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Live acoustic music performances</span>
                      </li>
                    </ul>
                  </div>
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Revenue Impact</h3>
                    <div className="space-y-2 text-white/70 text-sm">
                      <p><span className="text-accent font-semibold">Without events:</span> ₹30,000-50,000/month</p>
                      <p><span className="text-accent font-semibold">With weekly events:</span> ₹45,000-75,000/month</p>
                      <p><span className="text-accent font-semibold">Revenue increase:</span> 40-60%</p>
                      <p><span className="text-accent font-semibold">Customer retention:</span> +50%</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Event Execution & Growth</h2>
              <div className="grid md:grid-cols-2 gap-8 mb-12">
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Community Building</h3>
                  <p className="text-white/70 mb-4">Consistent events create familiar faces and friendships. Enable regular attendees to connect. Strong cafe communities become brand ambassadors with 3-5x word-of-mouth referrals.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Performer Partnerships</h3>
                  <p className="text-white/70 mb-4">Build relationships with local artists, musicians, and performers. Recurring monthly events with same performers develop fan bases. Performers promote events to their audiences organically.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Space Optimization</h3>
                  <p className="text-white/70 mb-4">Arrange cafe seating to facilitate conversations and networking. Create dedicated stage/performance area. Good lighting and sound enhance event experience and encourage longer stays.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Marketing Strategy</h3>
                  <p className="text-white/70 mb-4">Instagram, Facebook, email lists, and WhatsApp groups are most effective for cafe events. Consistent promotion 2 weeks before. Offer early-bird discounts for advance sign-ups.</p>
                </div>
              </div>
              <div className="p-8 rounded-2xl bg-neutral-900 border border-white/8">
                <h3 className="font-display font-bold text-xl text-white mb-4">Common Mistakes to Avoid</h3>
                <ul className="grid md:grid-cols-2 gap-4">
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Inconsistent event scheduling</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Poor sound or event quality</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Inadequate marketing</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Not measuring attendance or revenue</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Poor hospitality to new guests</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Neglecting regular customer service</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Expert Tips for Success</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Start Small</h3>
                  <p className="text-white/70">Begin with monthly events, then scale to weekly. Small, consistent events build loyal audiences. Quality over quantity creates lasting communities.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Focus on Experience</h3>
                  <p className="text-white/70">Event quality drives word-of-mouth. Good sound, comfortable seating, great beverages matter. Memorable experiences create loyal customers worth ₹50,000+ annual revenue each.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Build Loyalty</h3>
                  <p className="text-white/70">Reward regular event attendees with discounts, loyalty cards, exclusive perks. Loyal community members spend 3-5x more than occasional customers.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Frequently Asked Questions</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="text">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`} itemScope itemType="https://schema.org/Answer">
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="text">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-4">Related Services</h2>
              <p className="text-center text-white/50 mb-8">Explore more ways to grow your hospitality business</p>
              <div className="grid md:grid-cols-3 gap-6">
                <a href="/property-management-goa" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Property Management</h3>
                  <p className="text-white/50 text-sm">Comprehensive management for your Goa properties</p>
                </a>
                <a href="/vision-mission" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Our Vision & Mission</h3>
                  <p className="text-white/50 text-sm">Understand our commitment to Goa's hospitality</p>
                </a>
                <a href="/founders" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Meet Our Founders</h3>
                  <p className="text-white/50 text-sm">Learn from our hospitality industry experts</p>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Start Your Cafe Event Program</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">OTA Studio helps you plan and execute community events that build loyalty and increase cafe revenue.</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="#" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
