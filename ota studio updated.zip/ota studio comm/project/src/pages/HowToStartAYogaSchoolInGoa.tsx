import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What qualifications do yoga instructors need in Goa?', a: 'Instructors should be certified by recognized yoga bodies (RYT-200 minimum). Goa doesn\'t mandate specific registration, but certifications build credibility and attract quality students. OTA Studio helps vet and connect qualified instructors.' },
  { q: 'Can I run a yoga school from a villa or property?', a: 'Yes. Convert dedicated rooms into studios with proper flooring, mirrors, and sound. Ensure zoning compliance and safety standards. Property must support 15+ students comfortably for classes.' },
  { q: 'How do I price yoga classes in Goa?', a: 'Monthly memberships typically range ₹2,000-8,000 depending on location and instructor reputation. Drop-in classes: ₹300-1,000. Premium classes (specialized styles): ₹1,500-3,000. Goa tourists pay premium rates.' },
  { q: 'How many students do I need to break even?', a: 'A basic yoga school breaks even at 15-20 regular students taking 3-4 classes per week. Premium schools target 50+ active members for strong profitability and financial stability.' },
  { q: 'Can I integrate yoga school with property rentals?', a: 'Absolutely. Create retreat packages combining accommodation with yoga classes. Guests pay ₹50,000+ for 7-day packages. This increases property occupancy by 30-50% and improves guest reviews.' },
];

const steps = [
  'Obtain business registration and GST if needed',
  'Secure appropriate venue space',
  'Set up studio with mats, blocks, bolsters',
  'Hire certified yoga instructors',
  'Create class schedule and pricing',
  'Build online presence and booking system',
  'Market through local and online channels',
  'Build community and foster loyalty',
];

export default function HowToStartAYogaSchoolInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li><span itemProp="name">How to Start a Yoga School in Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Yoga School · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">How to Start a Yoga School in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Launch a profitable yoga school in Goa. Learn registration, studio setup, instructor hiring, pricing strategies, and how to attract both local students and international tourists for sustainable revenue growth.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20start%20a%20yoga%20school%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">Startup Steps</h2>
                  <ol className="space-y-4">
                    {steps.map((step, i) => (
                      <li key={i} className="flex items-start gap-4">
                        <span className="flex items-center justify-center w-8 h-8 rounded-full bg-accent/20 text-accent font-display font-bold shrink-0">{i + 1}</span>
                        <span className="text-white/70 pt-0.5">{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
                <div className="space-y-6">
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Legal Requirements</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Business registration (DIC/SSI)</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Pan and GST registration</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Liability and health insurance</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Venue lease compliance</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Health and safety standards</span>
                      </li>
                    </ul>
                  </div>
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Initial Investment</h3>
                    <div className="space-y-2 text-white/70 text-sm">
                      <p><span className="text-accent font-semibold">Studio setup:</span> ₹2-5 lakhs</p>
                      <p><span className="text-accent font-semibold">Equipment:</span> ₹50,000-1 lakh</p>
                      <p><span className="text-accent font-semibold">Marketing:</span> ₹1-2 lakhs</p>
                      <p><span className="text-accent font-semibold">Total startup:</span> ₹3.5-8 lakhs</p>
                      <p><span className="text-accent font-semibold">Break-even:</span> 6-12 months</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Operations & Growth Strategy</h2>
              <div className="grid md:grid-cols-2 gap-8 mb-12">
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Studio Setup & Equipment</h3>
                  <p className="text-white/70 mb-4">Invest in quality mats, blocks, bolsters, mirrors, and sound system. Good flooring (wood or yoga-specific) prevents injuries. Create serene environment with lighting, plants, and aromatherapy for premium experience.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Instructor Network</h3>
                  <p className="text-white/70 mb-4">Hire 2-3 certified instructors part-time initially. Specialized classes (Hatha, Vinyasa, Yin, Power yoga) attract different demographics. Instructor quality directly impacts student retention and referrals.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Revenue Streams</h3>
                  <p className="text-white/70 mb-4">Monthly memberships, drop-in classes, workshops, corporate programs, private sessions, and retreats. Diversified revenue reduces dependency on memberships and increases profitability by 50%+.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Digital Integration</h3>
                  <p className="text-white/70 mb-4">Booking system, online classes, app for schedules, hybrid models. OTA Studio integrates yoga school with property rentals and multi-channel marketing for maximum reach.</p>
                </div>
              </div>
              <div className="p-8 rounded-2xl bg-neutral-900 border border-white/8">
                <h3 className="font-display font-bold text-xl text-white mb-4">Common Mistakes to Avoid</h3>
                <ul className="grid md:grid-cols-2 gap-4">
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Poor location selection</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Hiring unqualified instructors</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Inadequate marketing efforts</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Inconsistent class schedules</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Ignoring student feedback</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">No community building focus</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Expert Tips for Success</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Location Matters</h3>
                  <p className="text-white/70">Choose high-traffic areas near wellness zones, beaches, or popular neighborhoods. Goa location can increase student acquisition by 40-60% and support premium pricing.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Build Community</h3>
                  <p className="text-white/70">Create loyalty programs, group events, and social activities. Community-focused studios have 60% higher retention and 3x higher referral rates than transactional models.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Leverage Tourism</h3>
                  <p className="text-white/70">Goa's tourist market offers premium pricing opportunities. Market to hotels, resorts, and tourists through OTA channels. Tourists spend 5-10x more than locals on wellness.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Frequently Asked Questions</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="text">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`} itemScope itemType="https://schema.org/Answer">
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="text">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-4">Related Services</h2>
              <p className="text-center text-white/50 mb-8">Explore more ways to grow your hospitality business</p>
              <div className="grid md:grid-cols-3 gap-6">
                <a href="/property-management-goa" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Property Management</h3>
                  <p className="text-white/50 text-sm">Comprehensive management for your Goa properties</p>
                </a>
                <a href="/vision-mission" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Our Vision & Mission</h3>
                  <p className="text-white/50 text-sm">Understand our commitment to Goa's hospitality</p>
                </a>
                <a href="/founders" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Meet Our Founders</h3>
                  <p className="text-white/50 text-sm">Learn from our hospitality industry experts</p>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Launch Your Yoga School Today</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">OTA Studio helps you establish and grow your yoga school with integrated property rentals and global marketing reach.</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="#" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
