import { useState } from 'react';
import {
  ChevronDown, CircleCheck as CheckCircle2, ArrowRight,
  Camera, DollarSign, MessageSquare, Sparkles, Globe,
  TrendingUp, AlertTriangle, Home, Shield, Users, Star, Zap,
} from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const seoSchemas = {
  article: {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: 'How to Start an Airbnb in Goa (Complete Guide 2026)',
    description:
      'Learn how to start an Airbnb in Goa, including registration, setup, pricing, guest management, OTA listings, operations, and growth strategies for hosts.',
    author: { '@type': 'Organization', name: 'OTA Studio' },
    publisher: {
      '@type': 'Organization',
      name: 'OTA Studio',
      logo: { '@type': 'ImageObject', url: 'https://otastudio.in/logo.png' },
    },
    datePublished: '2026-01-01',
    dateModified: '2026-06-18',
    url: 'https://otastudio.in/how-to-start-airbnb-in-goa',
    mainEntityOfPage: 'https://otastudio.in/how-to-start-airbnb-in-goa',
  },
  breadcrumb: {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://otastudio.in/' },
      { '@type': 'ListItem', position: 2, name: 'How-To Guides', item: 'https://otastudio.in/#guides' },
      {
        '@type': 'ListItem',
        position: 3,
        name: 'How to Start an Airbnb in Goa',
        item: 'https://otastudio.in/how-to-start-airbnb-in-goa',
      },
    ],
  },
  faq: {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: [
      {
        '@type': 'Question',
        name: 'What documents do I need to start an Airbnb in Goa?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: "You'll need property ownership documents, identity proof (Aadhaar/Passport), PAN card, bank account details, and property photos. For some properties, municipal approval or a short-term rental registration may apply.",
        },
      },
      {
        '@type': 'Question',
        name: 'How much does it cost to start an Airbnb listing in Goa?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: 'Creating an Airbnb listing is free — Airbnb charges hosts a 3% service fee per booking. Initial setup costs (photography, furnishings, maintenance) typically range from ₹43,000 to ₹1,75,000+ depending on property condition.',
        },
      },
      {
        '@type': 'Question',
        name: "How can I achieve Airbnb Superhost status quickly in Goa?",
        acceptedAnswer: {
          '@type': 'Answer',
          text: 'Maintain a 4.8+ overall rating, respond to guests within 24 hours, accept 90%+ reservation requests, and avoid cancellations. OTA Studio helps properties achieve Superhost status through professional listing optimization and guest management.',
        },
      },
      {
        '@type': 'Question',
        name: 'What is the best pricing strategy for Airbnb in Goa?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: 'Use dynamic pricing adjusted weekly to season, local events, and competitor rates. Peak season (October–March) commands 2–3x higher rates. Dynamic pricing can increase annual revenue by 20–35% compared to flat pricing.',
        },
      },
      {
        '@type': 'Question',
        name: 'Should I list only on Airbnb or on multiple OTAs?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: 'Multi-platform distribution is strongly recommended. Listing on Airbnb, Booking.com, Agoda, and MakeMyTrip simultaneously increases total bookings by 60–100% and reduces dependency on any single platform. OTA Studio manages multi-platform distribution for Goa properties.',
        },
      },
      {
        '@type': 'Question',
        name: 'Does OTA Studio help with Airbnb setup and management in Goa?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: 'Yes. OTA Studio provides end-to-end Airbnb management in Goa including listing creation, photography guidance, pricing strategy, guest communication, and multi-OTA distribution.',
        },
      },
    ],
  },
};

const steps = [
  { num: 1, title: 'Prepare Your Property', icon: Home, desc: 'Deep clean, fix maintenance issues, add quality amenities, and stage with local decor to create a memorable first impression.' },
  { num: 2, title: 'Professional Photography', icon: Camera, desc: 'Hire a property photographer. High-quality photos increase inquiries by 60% and support 23% higher nightly rates.' },
  { num: 3, title: 'Create Your Airbnb Account', icon: Shield, desc: 'Register, verify identity, complete host profile, and link your bank account for seamless payouts.' },
  { num: 4, title: 'Craft Listing Title & Description', icon: Sparkles, desc: 'Write SEO-friendly titles highlighting unique features. Include location benefits and clear house rules.' },
  { num: 5, title: 'Set Competitive Pricing', icon: DollarSign, desc: 'Research comparable properties, implement seasonal pricing (peak: Oct–Mar), and adjust dynamically each week.' },
  { num: 6, title: 'OTA Distribution Setup', icon: Globe, desc: 'Expand beyond Airbnb onto Booking.com, Agoda, MakeMyTrip to increase total bookings by 60–100%.' },
  { num: 7, title: 'Guest Communication System', icon: MessageSquare, desc: 'Prepare templates for inquiries, check-in instructions, mid-stay messages, and review requests.' },
  { num: 8, title: 'Go Live & Optimize', icon: TrendingUp, desc: 'Publish, accept bookings, collect reviews, and iterate monthly based on performance data.' },
];

const legalItems = [
  { title: 'Property Ownership Documents', desc: 'Must own or have written permission to rent the property.' },
  { title: 'PAN & GST Registration', desc: 'Register for PAN card and GST if rental income exceeds applicable thresholds.' },
  { title: 'Municipal Approval', desc: 'Some properties may need approval from Panjim Municipal Corporation or local panchayat.' },
  { title: 'Short-Term Rental Compliance', desc: "Follow Goa's evolving short-term rental regulations — check Airbnb's rules page for current requirements." },
  { title: 'Property Insurance', desc: 'Obtain insurance covering short-term rentals and guest liability.' },
  { title: 'Guest Records', desc: 'Maintain check-in/check-out records for local compliance purposes.' },
];

const revenueRows = [
  { type: 'Budget Room/Apartment', rate: '₹1,500–3,000/night', occ: '60%', monthly: '₹27,000–54,000', annual: '₹3.24–6.48 L' },
  { type: 'Mid-Range Villa', rate: '₹4,000–7,000/night', occ: '70%', monthly: '₹84,000–1,47,000', annual: '₹10.08–17.64 L' },
  { type: 'Luxury Villa', rate: '₹8,000–15,000/night', occ: '75%', monthly: '₹1,80,000–3,37,500', annual: '₹21.6–40.5 L' },
];

const mistakes = [
  { title: 'Poor Quality Photos', desc: 'Low-quality or outdated photos slash inquiries. Invest in professional photography — it pays back in 1–2 bookings.' },
  { title: 'Ignoring Seasonality', desc: 'Static pricing leaves revenue on the table during peak season. Dynamic pricing adjusted weekly can add 20–35% annually.' },
  { title: 'Slow Guest Communication', desc: 'Slow responses drop your response rate metric and hurt search ranking. Target under-1-hour replies for Superhost eligibility.' },
  { title: 'Neglecting Maintenance', desc: 'Broken amenities and cleanliness issues destroy ratings. Schedule preventive maintenance and professional cleaning between guests.' },
  { title: 'Only Listing on Airbnb', desc: 'Single-platform dependency limits income and makes you vulnerable to algorithm changes. Multi-OTA distribution is essential.' },
  { title: 'Skipping Channel Manager', desc: 'Managing availability manually across OTAs leads to double bookings. Use a channel manager or professional distribution service.' },
];

const revenueTips = [
  { icon: Star, title: 'Chase Superhost Status', desc: 'Superhost listings appear higher in search and command 15–25% premium pricing. Aim for it from your first month.' },
  { icon: Globe, title: 'Expand to 5+ OTAs', desc: 'Each additional OTA adds 5–15% more bookings. Airbnb + Booking.com + Agoda + MakeMyTrip is the minimum stack for Goa.' },
  { icon: Zap, title: 'Automate Operations', desc: 'Use automated messaging, smart locks, and channel managers to reduce manual work and enable scaling to multiple properties.' },
  { icon: TrendingUp, title: 'Seasonal Rate Blocking', desc: 'Block high-value dates during peak festivals (Sunburn, Carnival, NYE) for direct bookings at 3–5x OTA rates.' },
  { icon: Users, title: 'Build Repeat Guests', desc: 'A returning guest costs zero acquisition. Offer loyalty discounts or personal touches that drive direct re-bookings.' },
  { icon: Camera, title: 'Refresh Photos Seasonally', desc: 'Update listing photos every 6–12 months. Fresh content signals an active host and improves Airbnb search ranking.' },
];

const faqs = [
  {
    q: 'What documents do I need to start an Airbnb in Goa?',
    a: "You'll need property ownership documents, identity proof (Aadhaar/Passport), PAN card, bank account details, and property photos. For some properties, municipal approval or a short-term rental registration may apply.",
  },
  {
    q: 'How much does it cost to start an Airbnb listing in Goa?',
    a: 'Creating an Airbnb listing is free — Airbnb charges hosts a 3% service fee per booking. Initial setup costs (photography, furnishings, maintenance) typically range from ₹43,000 to ₹1,75,000+ depending on property condition.',
  },
  {
    q: 'How can I achieve Airbnb Superhost status quickly in Goa?',
    a: 'Maintain a 4.8+ overall rating, respond to guests within 24 hours, accept 90%+ reservation requests, and avoid cancellations. OTA Studio helps properties achieve Superhost status through professional listing optimization and guest management.',
  },
  {
    q: 'What is the best pricing strategy for Airbnb in Goa?',
    a: 'Use dynamic pricing adjusted weekly to season, local events, and competitor rates. Peak season (October–March) commands 2–3x higher rates. Dynamic pricing can increase annual revenue by 20–35% compared to flat pricing.',
  },
  {
    q: 'Should I list only on Airbnb or on multiple OTAs?',
    a: 'Multi-platform distribution is strongly recommended. Listing on Airbnb, Booking.com, Agoda, and MakeMyTrip simultaneously increases total bookings by 60–100% and reduces dependency on any single platform.',
  },
  {
    q: 'Does OTA Studio help with Airbnb setup and management in Goa?',
    a: 'Yes. OTA Studio provides end-to-end Airbnb management in Goa including listing creation, photography guidance, pricing strategy, guest communication, and multi-OTA distribution. Contact us for a free consultation.',
  },
];

export default function HowToStartAirbnbInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      {/* JSON-LD Schemas */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(seoSchemas.article) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(seoSchemas.breadcrumb) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(seoSchemas.faq) }} />

      {/* SEO head overrides via meta tags in body (React SPA) */}
      <title>How to Start an Airbnb in Goa (Complete Guide 2026) | OTA Studio</title>

      <Header />

      <main className="pt-16 sm:pt-20">
        <article>

          {/* ── HERO ── */}
          <div className="relative overflow-hidden bg-neutral-950 py-20 sm:py-28">
            <div className="absolute inset-0 section-grid opacity-30 pointer-events-none" />
            <div className="absolute top-0 left-0 w-[500px] h-[500px] rounded-full pointer-events-none"
              style={{ background: 'radial-gradient(circle, rgba(255,208,0,0.07) 0%, transparent 70%)', transform: 'translate(-30%, -30%)' }} />

            <div className="section-max section-padding relative">
              {/* Breadcrumb */}
              <nav aria-label="Breadcrumb" className="mb-6">
                <ol className="flex flex-wrap items-center gap-2 text-sm text-white/40">
                  <li><a href="/" className="hover:text-white transition-colors">Home</a></li>
                  <li className="text-white/20">/</li>
                  <li><a href="/#guides" className="hover:text-white transition-colors">How-To Guides</a></li>
                  <li className="text-white/20">/</li>
                  <li className="text-white/70">How to Start an Airbnb in Goa</li>
                </ol>
              </nav>

              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Airbnb Setup Guide · Goa · 2026</span>
              <h1 className="heading-xl text-white mb-5 max-w-4xl">
                How to Start an Airbnb in Goa{' '}
                <span className="text-accent">(Complete Guide 2026)</span>
              </h1>
              <p className="body-lg text-lg max-w-3xl mb-3 text-white/70 leading-relaxed">
                Learn how to start an Airbnb in Goa — from property preparation and registration to listing optimization, pricing strategy, guest management, and multi-OTA distribution. Everything you need to launch a profitable short-term rental business.
              </p>
              <p className="text-sm text-accent font-semibold mb-8">
                Goa sees 7M+ annual tourists. The opportunity for Airbnb hosts has never been larger.
              </p>

              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20start%20Airbnb%20in%20Goa"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary group"
                >
                  Book Free Consultation
                  <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a
                  href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20a%20free%20OTA%20audit"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-secondary"
                >
                  Get Free OTA Audit
                </a>
              </div>
            </div>
          </div>

          {/* ── 1. INTRODUCTION ── */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl">
                <h2 className="heading-lg text-white mb-6">Introduction</h2>
                <p className="body-md text-white/70 mb-5 leading-relaxed">
                  Goa is one of India's most visited destinations — attracting over 7 million tourists annually. The short-term rental market is thriving, with well-managed Airbnb properties earning ₹2–5 lakhs monthly during peak season. Whether you own a villa, apartment, homestay, or unique property, Airbnb offers a flexible, low-overhead path to hospitality income.
                </p>
                <p className="body-md text-white/70 mb-5 leading-relaxed">
                  But starting an Airbnb in Goa isn't just about listing your property online. Success requires understanding Airbnb's algorithm, legal compliance, professional photography, dynamic pricing, and multi-channel distribution. This guide covers every step — from day one setup to long-term revenue optimization.
                </p>
                <p className="body-md text-white/70 leading-relaxed">
                  If you're looking for professional <a href="/airbnb-management-goa" className="text-accent underline underline-offset-2 hover:text-accent-300 transition-colors">Airbnb management in Goa</a>, OTA Studio helps property owners launch, optimize, and scale their listings across all major platforms.
                </p>
              </div>
            </div>
          </section>

          {/* ── 2. WHY GOA IS IDEAL ── */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl">
                <h2 className="heading-lg text-white mb-6">Why Goa Is Ideal for Airbnb Hosting</h2>
                <p className="body-md text-white/70 mb-8 leading-relaxed">
                  Goa's year-round tourism, coastal lifestyle, and growing international visitor base create exceptional conditions for Airbnb hosts. Here's why the market is compelling:
                </p>
                <div className="grid sm:grid-cols-2 gap-4 mb-8">
                  {[
                    { stat: '7M+', label: 'Annual tourists to Goa' },
                    { stat: '60–80%', label: 'Avg occupancy for managed properties' },
                    { stat: '3x', label: 'Higher peak-season rates (Oct–Mar)' },
                    { stat: '₹2–5L', label: 'Monthly revenue potential per villa' },
                    { stat: '30–50%', label: 'Revenue uplift from professional management' },
                    { stat: '8+', label: 'OTAs active in Goa market' },
                  ].map((item) => (
                    <div key={item.label} className="flex items-center gap-4 p-4 rounded-xl border border-white/8 bg-white/3">
                      <span className="font-display font-extrabold text-2xl text-accent shrink-0">{item.stat}</span>
                      <span className="text-white/60 text-sm">{item.label}</span>
                    </div>
                  ))}
                </div>
                <p className="body-md text-white/70 leading-relaxed">
                  Goa's peak season (October–March) delivers 50–60% of annual revenue. Off-season months still see strong domestic tourism. Properties in North Goa (Calangute, Baga, Anjuna, Vagator) and South Goa (Palolem, Colva, Benaulim) perform consistently well across all seasons.
                </p>
              </div>
            </div>
          </section>

          {/* ── 3. PROPERTY REQUIREMENTS ── */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl">
                <h2 className="heading-lg text-white mb-6">Property Requirements</h2>
                <p className="body-md text-white/70 mb-6 leading-relaxed">
                  Any type of property can be listed on Airbnb — apartments, rooms, villas, homestays, beach huts, and unique stays. However, guest expectations in Goa are high. To attract bookings and maintain strong ratings, your property needs:
                </p>
                <ul className="space-y-3 mb-8">
                  {[
                    'Fast, reliable WiFi (minimum 25 Mbps)',
                    'Air conditioning in all bedrooms',
                    'Clean, functional bathroom with hot water',
                    'Kitchen or kitchenette with basic supplies',
                    'Quality bedding, towels, and linen',
                    'Smoke detector and basic first aid kit',
                    'Clear check-in instructions and house rules',
                    'Local area guidebook (restaurants, beaches, pharmacies)',
                  ].map((item) => (
                    <li key={item} className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span className="text-white/70">{item}</span>
                    </li>
                  ))}
                </ul>
                <div className="p-5 rounded-xl border border-accent/20 bg-accent/5">
                  <p className="text-sm text-white/70">
                    <strong className="text-accent">Pro tip:</strong> Properties with unique local touches (Goan art, Portuguese tiles, outdoor hammocks, rooftop areas) command 20–40% premium pricing and generate stronger reviews.
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* ── 4. LEGAL & REGISTRATION ── */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl">
                <h2 className="heading-lg text-white mb-6">Legal & Registration Considerations</h2>
                <p className="body-md text-white/70 mb-8 leading-relaxed">
                  Airbnb is a peer-to-peer platform but operating a short-term rental in Goa still requires attention to local regulations. Key compliance areas:
                </p>
                <div className="space-y-4 mb-8">
                  {legalItems.map((item) => (
                    <div key={item.title} className="flex items-start gap-4 p-4 rounded-xl border border-white/8 bg-white/3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <div>
                        <p className="text-white font-semibold mb-1">{item.title}</p>
                        <p className="text-white/60 text-sm">{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <p className="body-md text-white/70 leading-relaxed">
                  For a detailed walkthrough of legal requirements, see our guide on{' '}
                  <a href="/airbnb-rules-in-goa" className="text-accent underline underline-offset-2 hover:text-accent-300 transition-colors">Airbnb rules in Goa</a>.
                  OTA Studio helps properties navigate registration and compliance as part of our onboarding process.
                </p>
              </div>
            </div>
          </section>

          {/* ── 5. SETTING UP YOUR LISTING ── */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Setting Up Your Airbnb Listing</h2>
              <p className="body-md text-white/70 mb-10 max-w-2xl leading-relaxed">
                Your listing is your storefront. Follow these 8 steps to create a high-converting listing from day one.
              </p>
              <div className="grid md:grid-cols-2 gap-5">
                {steps.map((step) => {
                  const Icon = step.icon;
                  return (
                    <div key={step.num} className="flex items-start gap-4 p-5 rounded-2xl border border-white/8 bg-white/3 hover:border-accent/25 transition-colors">
                      <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-accent/15 shrink-0">
                        <Icon size={18} className="text-accent" />
                      </div>
                      <div>
                        <p className="text-white font-display font-bold mb-1">
                          <span className="text-accent/60 mr-2">0{step.num}.</span>{step.title}
                        </p>
                        <p className="text-white/60 text-sm leading-relaxed">{step.desc}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </section>

          {/* ── 6. PHOTOGRAPHY & CONTENT ── */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl">
                <h2 className="heading-lg text-white mb-6">Photography & Content Optimization</h2>
                <p className="body-md text-white/70 mb-6 leading-relaxed">
                  Airbnb's own data shows that professional photos increase bookings by up to 40% and support 23% higher nightly rates. Photography is your single highest-ROI investment when starting an Airbnb.
                </p>
                <div className="grid sm:grid-cols-2 gap-4 mb-8">
                  {[
                    { label: 'Minimum photos', value: '25–35 images' },
                    { label: 'Must-have shots', value: 'Every room + outdoor' },
                    { label: 'Lighting', value: 'Natural light, golden hour' },
                    { label: 'ROI on photography', value: 'Paid back in 1–2 bookings' },
                  ].map((item) => (
                    <div key={item.label} className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                      <span className="text-white/60 text-sm">{item.label}</span>
                      <span className="text-accent font-semibold text-sm">{item.value}</span>
                    </div>
                  ))}
                </div>
                <h3 className="font-display font-bold text-white mb-3">Listing Copy Checklist</h3>
                <ul className="space-y-2 mb-6">
                  {[
                    'Title includes property type + top feature + location (e.g., "Beachside Villa with Private Pool · North Goa")',
                    'Description opens with the guest experience, not property specs',
                    'All amenities listed — WiFi speed, AC units, parking, pool dimensions',
                    'House rules are clear, specific, and friendly in tone',
                    'Check-in/check-out times and process explained upfront',
                    'Nearby attractions, restaurants, and beaches mentioned by name',
                  ].map((item) => (
                    <li key={item} className="flex items-start gap-3">
                      <CheckCircle2 size={16} className="text-accent mt-0.5 shrink-0" />
                      <span className="text-white/65 text-sm">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </section>

          {/* ── 7. PRICING STRATEGY ── */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl">
                <h2 className="heading-lg text-white mb-6">Pricing Strategy</h2>
                <p className="body-md text-white/70 mb-8 leading-relaxed">
                  Pricing is the lever that separates average hosts from top performers. Goa has pronounced seasonality — understanding demand cycles is critical.
                </p>

                {/* Season breakdown */}
                <div className="space-y-3 mb-8">
                  {[
                    { season: 'Peak Season', months: 'October – March', rate: '2–3x base rate', color: 'border-accent/30 bg-accent/5' },
                    { season: 'Shoulder Season', months: 'April – June', rate: '1.2–1.5x base rate', color: 'border-white/10 bg-white/3' },
                    { season: 'Off Season', months: 'July – September', rate: '0.7–0.9x base rate', color: 'border-white/8 bg-white/2' },
                  ].map((s) => (
                    <div key={s.season} className={`flex items-center justify-between p-4 rounded-xl border ${s.color}`}>
                      <div>
                        <p className="text-white font-semibold text-sm">{s.season}</p>
                        <p className="text-white/40 text-xs">{s.months}</p>
                      </div>
                      <span className="text-accent font-display font-bold text-sm">{s.rate}</span>
                    </div>
                  ))}
                </div>

                {/* Revenue table */}
                <h3 className="font-display font-bold text-white mb-4">Revenue Potential by Property Type</h3>
                <div className="rounded-2xl border border-white/8 overflow-hidden mb-6">
                  <div className="grid grid-cols-4 bg-white/4 px-4 py-3 border-b border-white/8">
                    {['Property Type', 'Rate/Night', 'Occupancy', 'Annual Revenue'].map((h) => (
                      <span key={h} className="text-[11px] font-semibold text-white/40 uppercase tracking-wide">{h}</span>
                    ))}
                  </div>
                  {revenueRows.map((row, i) => (
                    <div key={i} className={`grid grid-cols-4 px-4 py-4 border-b border-white/5 last:border-0 ${i % 2 === 0 ? 'bg-white/[0.01]' : ''}`}>
                      <span className="text-white text-sm font-medium">{row.type}</span>
                      <span className="text-white/60 text-sm">{row.rate}</span>
                      <span className="text-white/60 text-sm">{row.occ}</span>
                      <span className="text-accent font-semibold text-sm">{row.annual}</span>
                    </div>
                  ))}
                </div>
                <p className="text-sm text-white/50">Dynamic pricing + professional management adds 20–35% on top of these projections.</p>
              </div>
            </div>
          </section>

          {/* ── 8. GUEST COMMUNICATION ── */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl">
                <h2 className="heading-lg text-white mb-6">Guest Communication</h2>
                <p className="body-md text-white/70 mb-6 leading-relaxed">
                  Guest communication is a major driver of Airbnb ratings. Slow, unclear, or impersonal responses hurt your ranking. The goal is to feel like a premium hotel concierge, not a landlord.
                </p>
                <div className="grid sm:grid-cols-2 gap-4 mb-8">
                  {[
                    { stage: 'Inquiry Response', target: 'Under 1 hour', note: 'Critical for Superhost' },
                    { stage: 'Booking Confirmation', target: 'Immediate auto-message', note: 'Set via templates' },
                    { stage: 'Pre-Arrival Message', target: '3 days before check-in', note: 'Include check-in details' },
                    { stage: 'Check-In Day', target: 'Morning of arrival', note: 'Directions + contacts' },
                    { stage: 'Mid-Stay Check-In', target: 'Day 2 if multi-night', note: 'Offer help proactively' },
                    { stage: 'Review Request', target: '24h after checkout', note: 'Drives 5-star cycle' },
                  ].map((item) => (
                    <div key={item.stage} className="p-4 rounded-xl border border-white/8 bg-white/3">
                      <p className="text-white font-semibold text-sm mb-1">{item.stage}</p>
                      <p className="text-accent text-sm font-medium mb-0.5">{item.target}</p>
                      <p className="text-white/40 text-xs">{item.note}</p>
                    </div>
                  ))}
                </div>
                <div className="p-5 rounded-xl border border-accent/20 bg-accent/5">
                  <p className="text-sm text-white/70">
                    <strong className="text-accent">OTA Studio tip:</strong> We build complete guest communication playbooks for all managed properties — from inquiry to post-stay review requests — so hosts never miss a touchpoint.
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* ── 9. CLEANING & OPERATIONS ── */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl">
                <h2 className="heading-lg text-white mb-6">Cleaning & Operations</h2>
                <p className="body-md text-white/70 mb-6 leading-relaxed">
                  Operational consistency is what separates 4.5-star listings from Superhosts. A single bad cleanliness review can cost you weeks of bookings.
                </p>
                <ul className="space-y-3 mb-8">
                  {[
                    'Hire a dedicated cleaning team trained on Airbnb standards (not general house cleaners)',
                    'Use a room checklist per checkout — beds, bathroom, kitchen, AC filters, WiFi router',
                    'Restock essentials every turn: toiletries, coffee, tea, sugar, paper rolls',
                    'Schedule preventive maintenance quarterly: plumbing, AC servicing, electrical checks',
                    'Keep emergency contacts on-site: plumber, electrician, locksmith',
                    'Set a cleaning fee on Airbnb that covers actual cleaning cost without deterring bookings',
                  ].map((item) => (
                    <li key={item} className="flex items-start gap-3">
                      <CheckCircle2 size={16} className="text-accent mt-0.5 shrink-0" />
                      <span className="text-white/70 text-sm">{item}</span>
                    </li>
                  ))}
                </ul>
                <p className="body-md text-white/70 leading-relaxed">
                  For owners managing multiple properties, we recommend using a property management system (PMS) to track cleaning schedules, maintenance tasks, and guest arrivals. See our{' '}
                  <a href="/technology-partners" className="text-accent underline underline-offset-2 hover:text-accent-300 transition-colors">technology partners</a> page for recommended tools.
                </p>
              </div>
            </div>
          </section>

          {/* ── 10. OTA DISTRIBUTION ── */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl">
                <h2 className="heading-lg text-white mb-6">OTA Distribution & Channel Management</h2>
                <p className="body-md text-white/70 mb-6 leading-relaxed">
                  Airbnb alone is not enough. The most profitable Goa hosts are listed on 5–8 OTAs simultaneously. Multi-platform distribution increases total bookings by 60–100% and protects you from algorithm changes on any single platform.
                </p>
                <div className="grid sm:grid-cols-2 gap-4 mb-8">
                  {[
                    { platform: 'Airbnb', strength: 'International travellers, premium stays', share: '28%' },
                    { platform: 'Booking.com', strength: 'Highest global volume, business travel', share: '32%' },
                    { platform: 'MakeMyTrip', strength: 'Dominant domestic Indian market', share: '18%' },
                    { platform: 'Agoda', strength: 'Southeast Asian travellers', share: '10%' },
                    { platform: 'Goibibo', strength: 'Budget domestic segment', share: '8%' },
                    { platform: 'Expedia', strength: 'Western market, corporate travel', share: '4%' },
                  ].map((p) => (
                    <div key={p.platform} className="flex items-center justify-between p-4 rounded-xl border border-white/8 bg-white/3 gap-3">
                      <div>
                        <p className="text-white font-semibold text-sm">{p.platform}</p>
                        <p className="text-white/40 text-xs">{p.strength}</p>
                      </div>
                      <span className="text-accent font-display font-bold text-sm shrink-0">{p.share}</span>
                    </div>
                  ))}
                </div>
                <p className="body-md text-white/70 mb-4 leading-relaxed">
                  To manage availability across multiple OTAs without double bookings, you need a channel manager or a professional distribution service. OTA Studio manages full multi-platform distribution for Goa properties — see our{' '}
                  <a href="/hotel-distribution-goa" className="text-accent underline underline-offset-2 hover:text-accent-300 transition-colors">hotel distribution service</a>{' '}
                  and{' '}
                  <a href="/airbnb-management-goa" className="text-accent underline underline-offset-2 hover:text-accent-300 transition-colors">Airbnb management service</a>.
                </p>
              </div>
            </div>
          </section>

          {/* ── 11. COMMON MISTAKES ── */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Common Mistakes to Avoid</h2>
              <p className="body-md text-white/70 mb-10 max-w-2xl">Most Airbnb hosts in Goa struggle with the same preventable issues. Here's what to watch for:</p>
              <div className="grid md:grid-cols-2 gap-5 max-w-4xl">
                {mistakes.map((m) => (
                  <div key={m.title} className="flex items-start gap-4 p-5 rounded-2xl border border-white/8 bg-white/3">
                    <AlertTriangle size={18} className="text-accent shrink-0 mt-0.5" />
                    <div>
                      <p className="text-white font-semibold mb-1">{m.title}</p>
                      <p className="text-white/60 text-sm leading-relaxed">{m.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* ── 12. REVENUE OPTIMIZATION ── */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Revenue Optimization Tips</h2>
              <p className="body-md text-white/70 mb-10 max-w-2xl">Once you're live, these strategies separate top-earning hosts from average performers:</p>
              <div className="grid md:grid-cols-3 gap-5">
                {revenueTips.map((tip) => {
                  const Icon = tip.icon;
                  return (
                    <div key={tip.title} className="p-6 rounded-2xl border border-white/8 bg-white/3 hover:border-accent/25 transition-colors">
                      <div className="w-10 h-10 rounded-xl bg-accent/15 flex items-center justify-center mb-4">
                        <Icon size={18} className="text-accent" />
                      </div>
                      <h3 className="font-display font-bold text-white mb-2">{tip.title}</h3>
                      <p className="text-white/60 text-sm leading-relaxed">{tip.desc}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          </section>

          {/* ── 13. FAQs ── */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Frequently Asked Questions</h2>
              <div className="max-w-3xl mx-auto space-y-3">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden">
                    <button
                      onClick={() => setOpenIdx(openIdx === i ? null : i)}
                      className="w-full flex items-center justify-between p-5 sm:p-6 text-left"
                      aria-expanded={openIdx === i}
                    >
                      <span className="font-display font-bold text-white pr-4">{faq.q}</span>
                      <ChevronDown
                        size={20}
                        className={`shrink-0 text-white/40 transition-transform duration-300 ${openIdx === i ? 'rotate-180 text-accent' : ''}`}
                      />
                    </button>
                    <div className={`overflow-hidden transition-all duration-300 ${openIdx === i ? 'max-h-64' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/60 text-sm leading-relaxed">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* ── 14. CONCLUSION + INTERNAL LINKS ── */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mb-16">
                <h2 className="heading-lg text-white mb-6">Conclusion</h2>
                <p className="body-md text-white/70 mb-5 leading-relaxed">
                  Starting an Airbnb in Goa is one of the most accessible ways to generate hospitality income from your property. The market is large, the demand is consistent, and the barrier to entry is low. But the difference between an underperforming listing and a top-earning Superhost comes down to execution — professional photography, smart pricing, multi-platform distribution, and consistent guest experience.
                </p>
                <p className="body-md text-white/70 mb-5 leading-relaxed">
                  OTA Studio helps Goa property owners launch and manage Airbnb listings with the same rigour as a professional hospitality operation. From initial setup to ongoing OTA management, we handle the complexity so you focus on the income.
                </p>
                <p className="body-md text-white/70 leading-relaxed">
                  Ready to start? Book a free consultation below or explore our related guides.
                </p>
              </div>

              {/* Related guides — internal links */}
              <div>
                <h3 className="font-display font-bold text-white text-xl mb-6">Related Guides & Services</h3>
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {[
                    { href: '/airbnb-management-goa', title: 'Airbnb Management Goa', desc: 'Professional Airbnb management for Goa properties' },
                    { href: '/hotel-onboarding-goa', title: 'Hotel OTA Onboarding', desc: 'Get your property listed on all major OTAs' },
                    { href: '/how-to-start-homestay-in-goa', title: 'How to Start a Homestay', desc: 'Complete guide to homestay setup in Goa' },
                    { href: '/how-to-start-resort-in-goa', title: 'How to Start a Resort', desc: 'End-to-end guide to launching a resort in Goa' },
                  ].map((link) => (
                    <a
                      key={link.href}
                      href={link.href}
                      className="p-5 rounded-2xl border border-white/8 bg-white/3 hover:border-accent/30 hover:bg-accent/5 transition-all group"
                    >
                      <h4 className="font-display font-bold text-white text-sm mb-1.5 group-hover:text-accent transition-colors">{link.title}</h4>
                      <p className="text-white/50 text-xs leading-relaxed">{link.desc}</p>
                      <ArrowRight size={14} className="text-accent/40 group-hover:text-accent mt-2 transition-colors" />
                    </a>
                  ))}
                </div>
              </div>
            </div>
          </section>

          {/* ── CTA ── */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-2xl">
                <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Free Consultation</span>
                <h2 className="heading-lg text-white mb-4">Ready to Launch Your Airbnb in Goa?</h2>
                <p className="text-white/60 mb-8 leading-relaxed">
                  OTA Studio handles everything — listing setup, photography guidance, dynamic pricing, multi-OTA distribution, and guest management. Join 100+ properties we've helped grow across Goa.
                </p>
                <div className="flex flex-col sm:flex-row gap-3">
                  <a
                    href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20start%20Airbnb%20in%20Goa"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-primary group"
                  >
                    Book Free Consultation
                    <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                  </a>
                  <a
                    href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20a%20free%20OTA%20audit"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-secondary"
                  >
                    Get Free OTA Audit
                  </a>
                  <a href="/" className="btn-secondary">Back to Home</a>
                </div>
              </div>
            </div>
          </section>

        </article>
      </main>

      <Footer />
      <FloatingContact />
    </div>
  );
}
