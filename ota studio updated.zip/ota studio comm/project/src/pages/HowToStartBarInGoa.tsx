import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  {
    q: 'What licenses do I need to start a bar in Goa?',
    a: 'You need liquor license (L-7 or L-8), FSSAI registration, trade license, and police approval. Excise department approval is critical. Location restrictions apply - bars cannot be near schools or religious institutions.'
  },
  {
    q: 'How much capital is needed to start a bar?',
    a: 'A small bar requires ₹20-50 lakhs including licensing, setup, alcohol inventory, and working capital. Premium bars cost ₹50-150+ lakhs depending on location and ambiance.'
  },
  {
    q: 'What is the best location for a bar in Goa?',
    a: 'Nightlife hubs like Baga, Calangute, Panjim, or areas near beaches and tourist zones work best. Visibility, foot traffic, parking, and entertainment infrastructure are critical success factors.'
  },
  {
    q: 'How do I obtain liquor license in Goa?',
    a: 'Apply to Goa Excise Department with property documents, identity, police verification, and environmental clearance. Process takes 2-4 months. License renewal is annual.'
  },
  {
    q: 'Can I list my bar on OTA platforms?',
    a: 'Yes. List on Google Business, Zomato, and Swiggy for visibility. Also leverage hospitality platforms for event marketing and promotions.'
  },
  {
    q: 'What makes a bar successful in Goa?',
    a: 'Unique theme/ambiance, quality drinks, entertainment (DJ, live music), social events, and strategic location drive success. Build community through regular events and maintain high service standards.'
  }
];

export default function HowToStartBarInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          {/* Hero Section */}
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white"><span itemProp="name">Home</span></a>
                    <meta itemProp="position" content="1" />
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white">
                    <span itemProp="name">How to Start Bar in Goa</span>
                    <meta itemProp="position" content="2" />
                  </li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Bar Startup · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">How to Start a Bar in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Complete guide to launching a profitable bar business in Goa. Learn liquor licensing, excise compliance, location strategy, menu development, entertainment programming,
                and revenue scaling strategies to build a thriving nightlife venue that attracts tourists and locals.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20start%20a%20bar%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20need%20a%20free%20OTA%20audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </div>

          {/* GrowthDashboard - Right after hero */}
          <GrowthDashboard />

          {/* Introduction Section */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Bar Business Opportunity in Goa</h2>
                <p className="body-md text-white/70 mb-6">
                  Goa's nightlife scene is world-renowned, attracting millions of tourists seeking entertainment, drinks, and social experiences. The bar market thrives year-round
                  with peak demand during tourist season (October to March). Successful bars generate ₹3-10+ lakhs monthly revenue with 30-40% profit margins through efficient
                  operations, strategic pricing, and strong entertainment programming.
                </p>
                <p className="body-md text-white/70 mb-6">
                  Modern bar businesses differentiate through unique themes, quality beverages, live entertainment, and curated events. With proper licensing, strategic location,
                  and strong management, a bar can achieve rapid profitability and become a destination venue for tourists and locals alike.
                </p>
              </div>
            </div>
          </section>

          {/* Step-by-Step Guide */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-12">Step-by-Step Guide to Starting a Bar</h2>
              <div className="max-w-3xl mx-auto space-y-8">
                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 1: Market Research and Location Selection</h3>
                  <p className="text-white/70 mb-4">
                    Identify high-traffic nightlife areas with tourism concentration. Research competitor bars, local regulations, licensing requirements, and market demand.
                    Evaluate location for visibility, parking, accessibility, and entertainment infrastructure compatibility.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Identify nightlife hubs and high-traffic entertainment areas</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Analyze competitor bars and market demand</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Check licensing restrictions and location requirements</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Verify proximity to hotels, restaurants, and attractions</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 2: Secure Property and Financing</h3>
                  <p className="text-white/70 mb-4">
                    Identify suitable property that meets licensing requirements and has appropriate utilities infrastructure. Secure financing through personal capital,
                    bank loans, or investors. Budget should cover property, licenses, setup, inventory, and working capital.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Identify property with appropriate utilities and layout</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Verify property compliance with licensing requirements</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Negotiate favorable lease terms with flexibility</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Secure financing covering all startup and working capital needs</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 3: Obtain Liquor License and Compliance</h3>
                  <p className="text-white/70 mb-4">
                    Apply for liquor license (L-7 for bars, L-8 for hotels) from Goa Excise Department. This is the critical gating item. Also obtain FSSAI registration,
                    trade license, police verification, and pollution control clearance. Process typically takes 2-4 months.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Gather documents: property ownership, identity, police verification</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Apply for L-7 or L-8 liquor license from Excise Department</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Obtain FSSAI registration for food/beverage service</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Get municipal trade license and fire safety approval</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 4: Design Bar Concept and Space</h3>
                  <p className="text-white/70 mb-4">
                    Create unique bar concept that differentiates in competitive market. Design layout for optimal customer flow, bar service efficiency, and entertainment.
                    Invest in quality decor, lighting, sound systems, and ambiance creation that matches your target audience and positioning.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Develop unique bar concept and theme differentiation</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Design layout for bar, seating, and entertainment areas</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Install professional sound, lighting, and AV systems</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Invest in quality furniture, fixtures, and decor elements</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 5: Install Bar Equipment and Beverage Setup</h3>
                  <p className="text-white/70 mb-4">
                    Invest in professional bar equipment including counter, refrigeration, glassware, and bottle displays. Source quality spirits, beer, wine, and ingredients.
                    Develop drink menu with signature cocktails, premium offerings, and competitive pricing. Train staff on mixology and beverage service.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Install professional bar counter and equipment</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Source quality spirits, beer, wine, and mixers</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Develop signature cocktail menu with pricing</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Train bartenders and staff on mixology and service</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 6: Organize Entertainment and Events</h3>
                  <p className="text-white/70 mb-4">
                    Plan entertainment programming including DJs, live bands, karaoke, or other attractions. Create weekly event calendar with theme nights and special events.
                    Build partnerships with promoters and entertainment providers. Use entertainment to differentiate and drive consistent customer traffic.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Partner with DJs and entertainment providers</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Plan weekly event calendar with theme nights</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Organize special events for holidays and peak seasons</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Create promotional campaigns for events and special offers</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 7: Hire and Train Staff</h3>
                  <p className="text-white/70 mb-4">
                    Recruit experienced bartenders, service staff, and management. Invest in comprehensive training on mixology, customer service, responsible service of alcohol,
                    and operational procedures. Strong, motivated staff directly impacts customer experience and reputation.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Hire experienced bar manager and bartenders</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Recruit attentive service and security staff</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Train on mixology, responsible alcohol service</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Establish operational manuals and service standards</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 8: Marketing and Launch</h3>
                  <p className="text-white/70 mb-4">
                    List on Google Business, Zomato, Swiggy, and tourism platforms. Build social media presence on Instagram and Facebook. Create buzz through influencer
                    partnerships and media coverage. Plan grand opening with special promotions and events.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Create Google Business profile with photos and details</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Build social media presence (Instagram, Facebook)</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Partner with influencers for promotion and coverage</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Plan grand opening with special offers and events</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          {/* Legal Requirements */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Legal Requirements for Bars in Goa</h2>
                <p className="body-md text-white/70 mb-6">
                  Operating a bar in Goa involves strict regulatory compliance:
                </p>
                <ul className="space-y-3 text-white/70">
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Liquor License (L-7/L-8):</strong> Mandatory from Goa Excise Department. L-7 for standalone bars, L-8 for hotel bars. Annual renewal required.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">FSSAI Licensing:</strong> Required for serving food and beverages. Comply with food safety standards.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Trade License:</strong> Mandatory from municipal corporation for business operation.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Excise Regulations:</strong> Comply with Goa Excise Rules including hours of operation, pricing, and responsible service requirements.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Police Verification:</strong> Required for liquor license. Maintain good standing with local authorities.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Fire Safety:</strong> Comply with fire safety standards, emergency exits, and equipment requirements.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Location Restrictions:</strong> Bars cannot operate near schools, temples, or religious institutions.</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          {/* Investment Breakdown */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Investment Breakdown for Bar Startup</h2>
                <p className="body-md text-white/70 mb-6">
                  For a 60-80 capacity bar in a good nightlife location:
                </p>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Rent deposit and renovation (3-4 months)</span>
                    <span className="text-accent font-semibold">₹8 - 15 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Bar counter and equipment</span>
                    <span className="text-accent font-semibold">₹3 - 7 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Sound system, lighting, and AV</span>
                    <span className="text-accent font-semibold">₹2 - 5 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Furniture, decor, and fixtures</span>
                    <span className="text-accent font-semibold">₹2 - 4 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Licenses and regulatory approvals</span>
                    <span className="text-accent font-semibold">₹1.5 - 3 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Initial alcohol inventory</span>
                    <span className="text-accent font-semibold">₹1 - 2 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Marketing and launch</span>
                    <span className="text-accent font-semibold">₹50,000 - 1 lakh</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-accent/10 border border-accent/20">
                    <span className="text-white font-semibold">Total Investment</span>
                    <span className="text-accent font-semibold">₹18 - 37 lakhs</span>
                  </div>
                </div>
                <p className="body-md text-white/70 mt-6">
                  Monthly operating costs: Staff (₹80,000-120,000), rent (₹30,000-100,000), inventory (₹50,000-100,000), entertainment (₹20,000-50,000), utilities (₹8,000-15,000).
                </p>
              </div>
            </div>
          </section>

          {/* Revenue Potential */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Revenue Potential</h2>
                <p className="body-md text-white/70 mb-6">
                  For a 60-80 capacity bar with efficient operations:
                </p>
                <div className="space-y-4 mb-6">
                  <div className="p-5 rounded-lg bg-white/4 border border-white/8">
                    <h4 className="text-white font-semibold mb-2">Budget Bar (Average ₹400-500/customer)</h4>
                    <p className="text-white/70 text-sm">
                      At 100 customers/night, 25 nights/month: ₹1-1.25 lakhs/month. Annual: ₹12-15 lakhs (gross)
                    </p>
                  </div>
                  <div className="p-5 rounded-lg bg-white/4 border border-white/8">
                    <h4 className="text-white font-semibold mb-2">Mid-Range Bar (Average ₹700-800/customer)</h4>
                    <p className="text-white/70 text-sm">
                      At 120 customers/night, 26 nights/month: ₹2.18-2.5 lakhs/month. Annual: ₹26-30 lakhs (gross)
                    </p>
                  </div>
                  <div className="p-5 rounded-lg bg-white/4 border border-white/8">
                    <h4 className="text-white font-semibold mb-2">Premium Bar (Average ₹1,000+/customer)</h4>
                    <p className="text-white/70 text-sm">
                      At 150 customers/night, 27 nights/month: ₹4-4.5 lakhs/month. Annual: ₹48-54 lakhs (gross)
                    </p>
                  </div>
                </div>
                <p className="body-md text-white/70">
                  Peak season (Oct-Mar) generates 60-70% of annual revenue. After operating costs (50-60%), net profit margin: 25-35%. Additional revenue from food sales and events adds 10-20%.
                </p>
              </div>
            </div>
          </section>

          {/* Mistakes to Avoid */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Common Mistakes to Avoid</h2>
                <div className="space-y-4">
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Poor Location Choice</h3>
                    <p className="text-white/70 text-sm">
                      Location is critical for bar success. Low-traffic areas struggle to generate volume. Invest in premium nightlife zones despite higher rent.
                    </p>
                  </div>
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Underestimating Licensing Complexity</h3>
                    <p className="text-white/70 text-sm">
                      Liquor licensing takes 2-4 months. Start process early. Neglecting proper licensing leads to operational issues and legal problems.
                    </p>
                  </div>
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Weak Entertainment Programming</h3>
                    <p className="text-white/70 text-sm">
                      Bars thrive on entertainment. Poor DJs or lack of events lead to slow nights and reduced customer loyalty.
                    </p>
                  </div>
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Inadequate Service Standards</h3>
                    <p className="text-white/70 text-sm">
                      Poor service, slow bartenders, or unfriendly staff directly reduce customer satisfaction and repeat visits.
                    </p>
                  </div>
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Pricing Misalignment</h3>
                    <p className="text-white/70 text-sm">
                      Prices too high reduce volume; too low reduce margins. Research competitor pricing carefully to position appropriately.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Expert Tips */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Expert Tips for Bar Success</h2>
                <ul className="space-y-3 text-white/70">
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Unique Theme/Concept:</strong> Differentiate with unique design, music style, or signature cocktails to stand out in competitive market.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Strong Entertainment Schedule:</strong> Weekly events (themed nights, DJ, live music) drive consistent customer traffic.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Signature Cocktails:</strong> Develop unique drinks that become iconic to your bar, driving repeat visits and word-of-mouth.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Social Media Marketing:</strong> Build Instagram presence showcasing events, drinks, and atmosphere to attract tourists and locals.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Seasonal Campaigns:</strong> Plan special promotions and events during peak and off-seasons to maintain consistent revenue.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Partnership Strategy:</strong> Build relationships with hotels, tour operators, and hospitality platforms for referrals and cross-promotion.</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          {/* Related Services */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Related Services</h2>
              <div className="grid sm:grid-cols-3 gap-6 max-w-3xl mx-auto">
                <a href="/property-management-goa" className="p-6 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all text-center">
                  <h3 className="font-display font-bold text-lg text-white mb-2">Property Management</h3>
                  <p className="text-sm text-white/50">Professional management for your Goa properties</p>
                </a>
                <a href="/vision-mission" className="p-6 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all text-center">
                  <h3 className="font-display font-bold text-lg text-white mb-2">Our Vision</h3>
                  <p className="text-sm text-white/50">Learn about OTA Studio's hospitality mission</p>
                </a>
                <a href="/founders" className="p-6 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all text-center">
                  <h3 className="font-display font-bold text-lg text-white mb-2">Meet Our Team</h3>
                  <p className="text-sm text-white/50">Hospitality experts with 50+ years experience</p>
                </a>
              </div>
            </div>
          </section>

          {/* FAQs */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Frequently Asked Questions</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} itemScope itemType="https://schema.org/Question" className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span itemProp="name" className="font-display font-bold text-white pr-4">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div itemScope itemType="https://schema.org/Answer" className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div itemProp="text" className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* CTA Section */}
          <section className="bg-neutral-950 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ready to Launch Your Bar?</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Get expert guidance on licensing, location strategy, entertainment programming, and hospitality marketing to build a thriving bar business.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20start%20a%20bar%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20need%20a%20free%20OTA%20audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
