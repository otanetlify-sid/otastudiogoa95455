import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What permits are needed for a beach club in Goa?', a: 'Beach license, liquor license, food safety permits, police permission, and environmental clearance. Goa\'s coast permits commercial beach clubs with proper regulation compliance and lease agreements.' },
  { q: 'What is the investment for a beach club?', a: 'Budget ₹30-75 lakhs for infrastructure, furniture, permits, and initial marketing. Premium beach clubs with bars and water sports run ₹50-1 crore+. ROI timeline is 2-3 years with proper management.' },
  { q: 'What amenities should a beach club have?', a: 'Comfortable lounging areas, shade structures, bars, food service, water sports, and clean facilities. Premium clubs add pools, DJs, premium seating, and seasonal activities, commanding ₹500-2000+ per person daily spend.' },
  { q: 'How do beach clubs generate revenue?', a: 'Entry/day use fees, food and beverage sales, event hosting, water sports, and VIP table packages. Successful clubs generate ₹20-50 lakhs+ monthly with 60-70% margins during peak season.' },
  { q: 'Can I integrate beach club with accommodation?', a: 'Absolutely. Package beach club access with rooms for premium rates. Guests spending nights spend 3-5x more on food, beverages, and activities than day-trippers. Combined packages are highly profitable.' },
];

const steps = [
  'Secure beach lease and permits',
  'Design layout and infrastructure',
  'Set up water sports and amenities',
  'Establish food and beverage operations',
  'Create marketing and promotional strategy',
  'Build booking and reservation system',
  'Recruit and train staff',
  'Launch and optimize operations',
];

export default function HowToStartBeachClubInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li><span itemProp="name">How to Start a Beach Club in Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Beach Club Startup · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">How to Start a Beach Club in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Launch a thriving beach club in Goa. Learn about permits, amenities, revenue models, and operational strategies to maximize profitability and create iconic beach experiences that draw locals and tourists alike.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20start%20a%20beach%20club%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">Beach Club Setup Steps</h2>
                  <ol className="space-y-4">
                    {steps.map((step, i) => (
                      <li key={i} className="flex items-start gap-4">
                        <span className="flex items-center justify-center w-8 h-8 rounded-full bg-accent/20 text-accent font-display font-bold shrink-0">{i + 1}</span>
                        <span className="text-white/70 pt-0.5">{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
                <div className="space-y-6">
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Key Requirements</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Beach lease/concession</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Environmental clearance</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Liquor and food licenses</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Safety and liability insurance</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Water sports permits</span>
                      </li>
                    </ul>
                  </div>
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Revenue Potential</h3>
                    <div className="space-y-2 text-white/70 text-sm">
                      <p><span className="text-accent font-semibold">Peak season day revenue:</span> ₹2-5 lakhs</p>
                      <p><span className="text-accent font-semibold">Monthly peak season:</span> ₹30-1.5 crores</p>
                      <p><span className="text-accent font-semibold">Annual revenue:</span> ₹2-5 crores</p>
                      <p><span className="text-accent font-semibold">Profit margin:</span> 60-70%</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Operations & Growth Strategy</h2>
              <div className="grid md:grid-cols-2 gap-8 mb-12">
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Guest Experience</h3>
                  <p className="text-white/70 mb-4">Comfortable lounging, quality food and beverages, excellent service, and entertainment create memorable experiences. Great experiences generate 5+ referrals per guest and command premium pricing.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Water Sports & Activities</h3>
                  <p className="text-white/70 mb-4">Offer jet skis, kayaks, paddleboards, snorkeling. Water sports generate high-margin revenue and create differentiation. Clubs with water sports see 40-60% higher daily revenue than basic clubs.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Premium Offerings</h3>
                  <p className="text-white/70 mb-4">VIP cabanas, premium seating, sunset packages, couples experiences, and exclusive events command premium pricing. 20% of guests generate 60% of revenue through premium purchases.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Seasonal Management</h3>
                  <p className="text-white/70 mb-4">Peak season (Oct-March) generates 70-80% of annual revenue. Off-season promotions, events, and wedding packages maintain cash flow. Diversify revenue to handle seasonality.</p>
                </div>
              </div>
              <div className="p-8 rounded-2xl bg-neutral-900 border border-white/8">
                <h3 className="font-display font-bold text-xl text-white mb-4">Common Mistakes to Avoid</h3>
                <ul className="grid md:grid-cols-2 gap-4">
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Neglecting safety and maintenance</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Poor food and beverage quality</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Inadequate staffing</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Poor crowd management</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Regulatory compliance issues</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Weak marketing and promotion</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Expert Tips for Success</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Location Excellence</h3>
                  <p className="text-white/70">Best beach clubs are at prime locations with easy access, scenic views, and natural shelter. Location drives 50% of success. Premium locations justify premium pricing and attract quality clientele.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Brand & Events</h3>
                  <p className="text-white/70">Create iconic brand with signature events, parties, and experiences. Monthly events build community and social buzz. Clubs known for great events fill 80%+ capacity year-round.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Hospitality Excellence</h3>
                  <p className="text-white/70">Train staff for exceptional service. Word-of-mouth from great service is worth ₹1+ crore in marketing. High-service clubs achieve 4.8+ ratings and book 3-5x more via OTAs.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Frequently Asked Questions</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="text">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`} itemScope itemType="https://schema.org/Answer">
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="text">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-4">Related Services</h2>
              <p className="text-center text-white/50 mb-8">Explore more ways to grow your hospitality business</p>
              <div className="grid md:grid-cols-3 gap-6">
                <a href="/property-management-goa" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Property Management</h3>
                  <p className="text-white/50 text-sm">Comprehensive management for your Goa properties</p>
                </a>
                <a href="/vision-mission" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Our Vision & Mission</h3>
                  <p className="text-white/50 text-sm">Understand our commitment to Goa's hospitality</p>
                </a>
                <a href="/founders" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Meet Our Founders</h3>
                  <p className="text-white/50 text-sm">Learn from our hospitality industry experts</p>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Start Your Beach Club Today</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">OTA Studio helps you launch, manage, and scale a profitable beach club that becomes iconic in Goa's hospitality scene.</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="#" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
