import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  {
    q: 'How much investment is needed to start a cafe in Goa?',
    a: 'A small cafe requires ₹15-40 lakhs investment including rent deposit, kitchen equipment, furniture, and licenses. Location and size significantly impact costs.'
  },
  {
    q: 'What location is best for a cafe in Goa?',
    a: 'High footfall areas near beaches, markets, or tourist zones work best. Look for spaces with visibility, parking, and good traffic flow. Rental rates vary from ₹5,000-50,000+ monthly.'
  },
  {
    q: 'Do I need FSSAI license for a cafe?',
    a: 'Yes, FSSAI license is mandatory for serving food and beverages. You also need trade license, pollution certificate, and possibly municipal approval.'
  },
  {
    q: 'Can I list my cafe on OTA platforms?',
    a: 'Yes. List on Swiggy, Zomato, Google Business, and tourism platforms. OTA listings drive significant orders and visibility for cafes.'
  },
  {
    q: 'What makes a cafe successful in Goa?',
    a: 'Unique ambiance, quality coffee/food, good service, social media presence, and strategic location are key. Build community through events and maintain consistent quality.'
  },
  {
    q: 'How much revenue can a cafe generate?',
    a: 'A 30-40 seat cafe can generate ₹2-5 lakhs monthly revenue depending on location, menu pricing, and operations. Peak season (Oct-Mar) drives 50-60% of annual revenue.'
  }
];

export default function HowToStartCafeInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          {/* Hero Section */}
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white"><span itemProp="name">Home</span></a>
                    <meta itemProp="position" content="1" />
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white">
                    <span itemProp="name">How to Start Cafe in Goa</span>
                    <meta itemProp="position" content="2" />
                  </li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Cafe Startup · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">How to Start a Cafe in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Complete guide to launching a profitable cafe business in Goa. Learn location selection, licensing, menu development, OTA integration, hospitality activations,
                and revenue scaling strategies to build a thriving cafe that attracts tourists and locals alike.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20start%20a%20cafe%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20need%20a%20free%20OTA%20audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </div>

          {/* GrowthDashboard - Right after hero */}
          <GrowthDashboard />

          {/* Introduction Section */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Cafe Business Opportunity in Goa</h2>
                <p className="body-md text-white/70 mb-6">
                  Goa's cafe culture is booming with millions of tourists and a growing local coffee culture. The market spans budget cafes to premium specialty coffee shops,
                  creating opportunities across price points. Successful cafes in Goa generate ₹2-5 lakhs monthly revenue with 25-35% profit margins through quality products,
                  strong positioning, and strategic location selection.
                </p>
                <p className="body-md text-white/70 mb-6">
                  Modern cafes leverage OTA platforms (Swiggy, Zomato), social media marketing, and hospitality activations to drive customer acquisition. The cafe market thrives
                  on unique ambiance, quality offerings, and community engagement, making Goa an ideal location for cafe entrepreneurs.
                </p>
              </div>
            </div>
          </section>

          {/* Step-by-Step Guide */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-12">Step-by-Step Guide to Starting a Cafe</h2>
              <div className="max-w-3xl mx-auto space-y-8">
                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 1: Research and Location Selection</h3>
                  <p className="text-white/70 mb-4">
                    Location is critical for cafe success. Research high-footfall areas near beaches, markets, tourist zones, or commercial centers. Analyze foot traffic,
                    competitor presence, rental costs, and demographic appeal. Pick location with visibility, parking, and good accessibility.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Identify high footfall locations near tourist areas</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Analyze competitor cafes in the area</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Negotiate favorable rental terms</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Verify space layout, utilities, and parking availability</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 2: Develop Business Plan and Finances</h3>
                  <p className="text-white/70 mb-4">
                    Create detailed business plan including startup costs, operating expenses, revenue projections, and break-even analysis. Secure financing through personal
                    savings, bank loans, or investors. Budget should cover rent, equipment, licenses, initial inventory, and 6 months working capital.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Calculate total startup investment and ongoing costs</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Project revenue based on location and seating capacity</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Plan pricing strategy and menu positioning</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Secure financing through loans or investors</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 3: Obtain Licenses and Regulatory Compliance</h3>
                  <p className="text-white/70 mb-4">
                    Register with municipal corporation, obtain FSSAI license, food handler certification, and other required permits. Ensure full compliance with food safety,
                    health, and local regulations before opening.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Obtain FSSAI registration or license</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Get municipal trade license and building permission</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Obtain pollution control and fire safety clearance</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Register for GST if applicable</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 4: Design and Set Up Cafe Space</h3>
                  <p className="text-white/70 mb-4">
                    Create unique, welcoming ambiance that differentiates your cafe. Invest in quality furniture, decor, and lighting. Design layout for comfortable customer
                    experience and efficient staff operations. Install modern POS systems and payment infrastructure.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Plan layout with optimal customer seating and flow</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Invest in quality, aesthetically pleasing furniture and decor</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Install professional kitchen equipment and appliances</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Set up modern POS system and payment solutions</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 5: Develop Menu and Sourcing</h3>
                  <p className="text-white/70 mb-4">
                    Create curated menu with specialty coffee, teas, snacks, and light meals. Source quality coffee beans, ingredients, and supplies from reliable vendors.
                    Focus on quality over quantity. Consider unique menu items that differentiate your cafe from competitors.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Develop curated menu with specialty offerings</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Source quality coffee beans and specialty ingredients</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Plan food cost structure and pricing strategy</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Include unique, signature items to build differentiation</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 6: Hire and Train Staff</h3>
                  <p className="text-white/70 mb-4">
                    Recruit experienced baristas, kitchen staff, and service personnel. Invest in training on coffee preparation, customer service, and food safety. Strong
                    team directly impacts customer experience and cafe reputation.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Hire skilled barista and kitchen staff</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Conduct barista training for espresso and latte art</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Train on food safety, hygiene, and service standards</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Create operational manuals and procedures</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 7: List on OTA Platforms and Marketing</h3>
                  <p className="text-white/70 mb-4">
                    Register on Swiggy, Zomato, Google Business, and tourism platforms. Create business profiles with professional photos and detailed information. Build social
                    media presence on Instagram and Facebook. Develop launch marketing strategy and promotions.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Register on Swiggy and Zomato for delivery/dine-in</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Create Google Business profile with photos and details</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Build social media presence (Instagram, Facebook)</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Plan launch promotions and influencer partnerships</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 8: Soft Opening and Grand Launch</h3>
                  <p className="text-white/70 mb-4">
                    Conduct soft opening with friends and influencers to test operations and generate initial reviews. Plan grand launch with special offers, events, and media
                    coverage. Focus on building word-of-mouth marketing and establishing community presence.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Conduct soft opening with selected guests</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Invite influencers and media for coverage</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Offer opening specials and promotional pricing</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Host launch events to build community</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          {/* Legal Requirements */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Legal Requirements for Cafes in Goa</h2>
                <p className="body-md text-white/70 mb-6">
                  Operating a cafe in Goa requires compliance with multiple regulations:
                </p>
                <ul className="space-y-3 text-white/70">
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">FSSAI License:</strong> Mandatory for serving food and beverages. Obtain registration or license based on annual turnover.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Trade License:</strong> Register with municipal corporation for business operation.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Building Permission:</strong> Ensure space is approved for cafe operations.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Pollution Control:</strong> Obtain NOC from pollution control board if required.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">GST Registration:</strong> Mandatory for businesses with annual turnover above ₹20 lakhs (or ₹10 lakhs in Goa).</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Fire Safety:</strong> Install fire extinguishers and comply with safety standards.</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          {/* Investment Breakdown */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Investment Breakdown for Cafe Startup</h2>
                <p className="body-md text-white/70 mb-6">
                  For a 30-40 seat cafe in a good location:
                </p>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Rent deposit and renovation (3 months)</span>
                    <span className="text-accent font-semibold">₹4 - 10 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Kitchen equipment and furniture</span>
                    <span className="text-accent font-semibold">₹3 - 7 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Interior design and decor</span>
                    <span className="text-accent font-semibold">₹2 - 5 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">POS system and technology</span>
                    <span className="text-accent font-semibold">₹50,000 - 1 lakh</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Licenses and certifications</span>
                    <span className="text-accent font-semibold">₹50,000 - 1 lakh</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Initial inventory and supplies</span>
                    <span className="text-accent font-semibold">₹1 - 2 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Marketing and launch</span>
                    <span className="text-accent font-semibold">₹30,000 - 50,000</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-accent/10 border border-accent/20">
                    <span className="text-white font-semibold">Total Investment</span>
                    <span className="text-accent font-semibold">₹11.3 - 26.5 lakhs</span>
                  </div>
                </div>
                <p className="body-md text-white/70 mt-6">
                  Monthly operating costs: Staff (₹50,000-80,000), rent (₹20,000-50,000), utilities (₹5,000-10,000), supplies (₹20,000-30,000).
                </p>
              </div>
            </div>
          </section>

          {/* Revenue Potential */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Revenue Potential</h2>
                <p className="body-md text-white/70 mb-6">
                  For a 30-40 seat cafe with efficient operations:
                </p>
                <div className="space-y-4 mb-6">
                  <div className="p-5 rounded-lg bg-white/4 border border-white/8">
                    <h4 className="text-white font-semibold mb-2">Budget Cafe (Average ₹300-400/order)</h4>
                    <p className="text-white/70 text-sm">
                      At 80 orders/day: ₹72-96k/day, ₹2.16-2.88 lakhs/month. Annual: ₹26-35 lakhs (gross)
                    </p>
                  </div>
                  <div className="p-5 rounded-lg bg-white/4 border border-white/8">
                    <h4 className="text-white font-semibold mb-2">Mid-Range Cafe (Average ₹500-600/order)</h4>
                    <p className="text-white/70 text-sm">
                      At 60 orders/day: ₹90-108k/day, ₹2.7-3.24 lakhs/month. Annual: ₹32-39 lakhs (gross)
                    </p>
                  </div>
                  <div className="p-5 rounded-lg bg-white/4 border border-white/8">
                    <h4 className="text-white font-semibold mb-2">Premium Cafe (Average ₹700-900/order)</h4>
                    <p className="text-white/70 text-sm">
                      At 50 orders/day: ₹105-135k/day, ₹3.15-4.05 lakhs/month. Annual: ₹38-49 lakhs (gross)
                    </p>
                  </div>
                </div>
                <p className="body-md text-white/70">
                  Peak season (Oct-Mar) generates 55-65% of annual revenue. After operating costs (60-65%), net profit margin: 20-30%. OTA commissions (15-30%) reduce direct delivery revenue.
                </p>
              </div>
            </div>
          </section>

          {/* Mistakes to Avoid */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Common Mistakes to Avoid</h2>
                <div className="space-y-4">
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Poor Location Choice</h3>
                    <p className="text-white/70 text-sm">
                      Low-traffic locations struggle to generate volume. Location is most critical success factor. Don't compromise on this.
                    </p>
                  </div>
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Quality Inconsistency</h3>
                    <p className="text-white/70 text-sm">
                      Inconsistent coffee or food quality leads to bad reviews and customer loss. Maintain strict quality standards daily.
                    </p>
                  </div>
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Ignoring OTA Platforms</h3>
                    <p className="text-white/70 text-sm">
                      Many customers order via Swiggy/Zomato. Not being on these platforms limits reach significantly.
                    </p>
                  </div>
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Weak Social Media Presence</h3>
                    <p className="text-white/70 text-sm">
                      Instagram presence drives foot traffic and awareness. Post consistently with quality photos and engage followers.
                    </p>
                  </div>
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Poor Staff Management</h3>
                    <p className="text-white/70 text-sm">
                      Staff quality directly impacts customer experience. Invest in training and fair treatment for retention.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Expert Tips */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Expert Tips for Cafe Success</h2>
                <ul className="space-y-3 text-white/70">
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Unique Selling Proposition:</strong> Differentiate with specialty coffee, unique ambiance, or exclusive menu items.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Community Building:</strong> Host events, open mics, or workshops to create community and boost footfall.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Leverage Hospitality Activations:</strong> Participate in OTA Studio activations for exposure and bookings.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Seasonal Menus:</strong> Update offerings seasonally to keep regulars engaged and attract new customers.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Loyalty Programs:</strong> Offer rewards for repeat customers to build long-term revenue base.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Partner with Hotels:</strong> Build partnerships with nearby hotels for guest recommendations and catering.</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          {/* Related Services */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Related Services</h2>
              <div className="grid sm:grid-cols-3 gap-6 max-w-3xl mx-auto">
                <a href="/property-management-goa" className="p-6 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all text-center">
                  <h3 className="font-display font-bold text-lg text-white mb-2">Property Management</h3>
                  <p className="text-sm text-white/50">Professional management for your Goa properties</p>
                </a>
                <a href="/vision-mission" className="p-6 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all text-center">
                  <h3 className="font-display font-bold text-lg text-white mb-2">Our Vision</h3>
                  <p className="text-sm text-white/50">Learn about OTA Studio's hospitality mission</p>
                </a>
                <a href="/founders" className="p-6 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all text-center">
                  <h3 className="font-display font-bold text-lg text-white mb-2">Meet Our Team</h3>
                  <p className="text-sm text-white/50">Hospitality experts with 50+ years experience</p>
                </a>
              </div>
            </div>
          </section>

          {/* FAQs */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Frequently Asked Questions</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} itemScope itemType="https://schema.org/Question" className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span itemProp="name" className="font-display font-bold text-white pr-4">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div itemScope itemType="https://schema.org/Answer" className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div itemProp="text" className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* CTA Section */}
          <section className="bg-neutral-950 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ready to Launch Your Cafe?</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Get expert guidance on location, licensing, OTA integration, and hospitality marketing to build a thriving cafe business.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20start%20a%20cafe%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20need%20a%20free%20OTA%20audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
