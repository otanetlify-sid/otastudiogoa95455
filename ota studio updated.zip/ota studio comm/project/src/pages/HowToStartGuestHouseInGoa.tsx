import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What is the difference between a guest house and a hotel in Goa?', a: 'Guest houses are smaller, more intimate hospitality properties (typically 5-20 rooms) with limited amenities compared to hotels. They offer a homestay-like experience with personal touch, lower overhead costs, and flexible operations. Licensing is simpler than hotels, making them ideal for first-time hospitality entrepreneurs. Goa\'s tourism market values this authentic, personalized experience.' },
  { q: 'What licenses do I need to start a guest house in Goa?', a: 'Required licenses include: Shop and Establishment License from Municipal Corporation, FSSAI registration (if providing food), Fire Safety NOC, Health Trade License, Guest House/Homestay Registration with Goa Tourism Department, and GST registration. Total approval timeline: 4-6 weeks. Some areas may require additional local permissions depending on zoning.' },
  { q: 'How do I register my property as a homestay on OTA platforms?', a: 'Register on Airbnb, Booking.com Homestays, and Stayz. Requirements: professional photos (minimum 20-30), detailed property description highlighting unique features, accurate amenities list, competitive pricing, and responsive hosting. Complete profiles rank higher in searches. Focus on authenticity and guest experience to earn high ratings, which drives repeat bookings.' },
  { q: 'What investment is needed to start a guest house in Goa?', a: 'Budget approximately: Property purchase or lease (₹30-100 lakhs for 3-5 bedrooms), Renovation/Furnishing (₹10-30 lakhs), Licenses and Approvals (₹2-5 lakhs), Kitchen and common areas (₹3-8 lakhs), Initial inventory (₹50,000-1 lakh), and Working Capital (₹2-5 lakhs). Total: ₹50-150 lakhs for an entry-level guest house. Budget-friendly options available for homestay model.' },
  { q: 'How do OTA platforms affect guest house booking rates?', a: 'OTA platforms are crucial for guest house success, especially for properties targeting tourists. Airbnb and Booking.com provide instant global visibility to millions of potential guests. Professional listing optimization, competitive pricing strategy, and high guest ratings boost visibility in platform searches, driving higher occupancy rates and revenue.' },
  { q: 'What makes a guest house successful in Goa\'s competitive market?', a: 'Success factors include: authentic Goan hospitality and personal service, strategic location near tourist attractions or beaches, competitive pricing, high-quality guest accommodations and cleanliness, reliable WiFi and modern amenities, responsive guest communication, consistency in service quality, and strong presence on OTA platforms. Building local reputation and repeat customers is essential.' },
];

export default function HowToStartGuestHouseInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">How to Start a Guest House in Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Guest House Startup · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">How to Start a Guest House in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Complete guide to launching a guest house in Goa. Learn about guest house licensing, homestay registration, OTA listings, budget hospitality strategies, and proven methods to build a profitable guest house business.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20start%20a%20guest%20house%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Guest House Setup & Licensing</h2>
              <div className="grid md:grid-cols-2 gap-8">
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Initial Property Setup</h3>
                  <p className="text-white/70 mb-4">Select a property in tourist-friendly areas: coastal regions, near beaches, or central Panjim. The property can be your own home or leased. Ideal size: 3-8 bedrooms for manageable operations. Ensure adequate space for guest living, common areas, and kitchen facilities. Good location is critical for walk-in tourists and OTA visibility.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Tourist-friendly location selection
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Property documentation verification
                    </li>
                  </ul>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Licensing & Approvals</h3>
                  <p className="text-white/70 mb-4">Obtain Shop and Establishment License from Municipal Corporation. Register with Goa Tourism Department for homestay classification. File FSSAI registration if providing breakfast/meals. Get Health Trade License approval. Complete Fire Safety NOC. GST registration is mandatory for businesses. Timeline: 4-6 weeks combined.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Simplified guest house approval process
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Annual license renewal requirements
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Homestay Registration & OTA Strategy</h2>
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <h3 className="heading-md text-white mb-4">Airbnb Activation</h3>
                  <p className="text-white/70">Airbnb is the dominant platform for guest houses and homestays. Create a compelling listing with high-quality photos (20-30 minimum), detailed property descriptions, honest amenities list, and competitive pricing for your market segment. Respond quickly to inquiries and maintain 4.8+ rating. Regular availability and quick booking confirmations boost ranking visibility.</p>
                </div>
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <h3 className="heading-md text-white mb-4">Booking.com Homestays</h3>
                  <p className="text-white/70">List on Booking.com for direct traveler access. These platforms provide credibility and reach guests who prefer traditional booking platforms. Ensure accurate pricing, real-time availability syncing across platforms, professional communication, and consistent cleanliness standards. Higher ratings increase ranking and direct booking commissions.</p>
                </div>
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <h3 className="heading-md text-white mb-4">Google My Business & Social Media</h3>
                  <p className="text-white/70">Maintain active Google My Business profile for local search visibility. Post regularly on Instagram and Facebook showcasing common areas, guest testimonials, and unique features. This builds brand awareness and encourages direct bookings. Share guest reviews and user-generated content to build credibility and attract organic traffic.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Budget Hospitality Best Practices</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Cost Management</h3>
                  <p className="text-white/70 mb-4">Control operational costs to maximize margins. Use efficient cleaning systems, bulk purchasing for supplies, and automated processes (self-check-in, online communication). Manage staffing carefully - consider family operation or part-time help. Invest in durable, easy-to-maintain furnishings. Strategic cost control maintains profitability without compromising guest experience.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Guest Experience Excellence</h3>
                  <p className="text-white/70 mb-4">Personal touch differentiates guest houses. Welcome guests warmly, provide local recommendations, offer complimentary breakfast or tea, share Goa travel tips. High-quality WiFi, clean linens, and comfortable beds are non-negotiable. Responsive communication and willingness to help build loyalty and drive repeat bookings through positive OTA reviews.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Pricing Strategy</h3>
                  <p className="text-white/70 mb-4">Competitive pricing drives occupancy in guest house segment. Research local pricing, monitor seasonal demand, and adjust rates accordingly. Offer value through amenities and service rather than competing on lowest price. Long-stay discounts and early-booking offers improve occupancy rates. Monitor OTA algorithms and competitor pricing regularly.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Related Services</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <a href="/property-management-goa" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Property Management Goa</h3>
                  <p className="text-white/70 mb-4">Complete management services for guest houses and small hospitality properties.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/vision-mission" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Our Vision & Mission</h3>
                  <p className="text-white/70 mb-4">Learn about our commitment to guest house success and hospitality excellence.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/founders" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Meet Our Founders</h3>
                  <p className="text-white/70 mb-4">Discover the team behind successful guest house launches in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Guest House Startup FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-64' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer" itemScope itemType="https://schema.org/Answer"><span itemProp="text">{faq.a}</span></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ready to Launch Your Guest House in Goa?</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Let us help you set up your guest house with proper licensing, OTA activation, and strategies to build a successful, profitable homestay business in Goa.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20start%20a%20guest%20house%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="/" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
