import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What permits are needed to start a homestay in Goa?', a: 'Property registration, GST registration, municipal approval, and compliance with residential zoning. Goa has simplified homestay regulations compared to hotels. OTA Studio helps navigate regulatory requirements efficiently.' },
  { q: 'What is the investment for a homestay?', a: 'Budget ₹10-30 lakhs for property setup, furnishings, and marketing. Breaks even in 12-18 months with proper management. Premium homestays targeting tourists can achieve ₹15-25+ lakhs annual revenue.' },
  { q: 'Can I run a homestay from my personal residence?', a: 'Yes. Rent out spare rooms or entire property. Many successful homestays operate from residential properties. Ensure guest facilities don\'t impact personal living space or create zoning issues.' },
  { q: 'What amenities should I provide?', a: 'WiFi, comfortable bedding, clean bathrooms, air conditioning, basic kitchen, and welcome touches. Premium homestays add breakfast, tours, and personalized service, commanding 30-50% higher rates.' },
  { q: 'How do I attract guests to my homestay?', a: 'List on Airbnb, Booking.com, and OTA Studio. Collect reviews, optimize listings, and use professional photos. Homes with 4.8+ ratings book 3-5x more than average.' },
];

const steps = [
  'Prepare property for guests',
  'Set up basic safety and compliance',
  'Create compelling property listing',
  'Take professional photos',
  'Register on Airbnb, Booking.com, OTA Studio',
  'Set competitive pricing',
  'Prepare guest communication templates',
  'Execute flawless guest experiences',
];

export default function HowToStartHomestayInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li><span itemProp="name">How to Start a Homestay in Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Homestay Startup · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">How to Start a Homestay in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Launch a profitable homestay in Goa. Learn regulations, setup essentials, marketing strategies, and how to achieve high occupancy rates and guest satisfaction for sustainable revenue.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20start%20a%20homestay%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">Homestay Setup Steps</h2>
                  <ol className="space-y-4">
                    {steps.map((step, i) => (
                      <li key={i} className="flex items-start gap-4">
                        <span className="flex items-center justify-center w-8 h-8 rounded-full bg-accent/20 text-accent font-display font-bold shrink-0">{i + 1}</span>
                        <span className="text-white/70 pt-0.5">{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
                <div className="space-y-6">
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Legal Requirements</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Property registration</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Pan and GST registration</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Municipal approval</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Zoning compliance</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Safety certifications</span>
                      </li>
                    </ul>
                  </div>
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Revenue Potential</h3>
                    <div className="space-y-2 text-white/70 text-sm">
                      <p><span className="text-accent font-semibold">1-2 room homestay:</span> ₹5-12 lakhs/year</p>
                      <p><span className="text-accent font-semibold">3-4 room homestay:</span> ₹12-25 lakhs/year</p>
                      <p><span className="text-accent font-semibold">Occupancy target:</span> 60-75%</p>
                      <p><span className="text-accent font-semibold">Profit margin:</span> 60-70%</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Operations & Growth</h2>
              <div className="grid md:grid-cols-2 gap-8 mb-12">
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Property Preparation</h3>
                  <p className="text-white/70 mb-4">Invest in comfortable bedding, clean bathrooms, good WiFi, and welcoming ambiance. Small touches (welcome kits, local tips) increase guest satisfaction by 30-40% and improve reviews significantly.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Listing Optimization</h3>
                  <p className="text-white/70 mb-4">Professional photos, compelling descriptions, and competitive pricing drive bookings. Optimized listings achieve 2-3x more views. Professional photography costs ₹10,000-30,000 but increases bookings by 40%+.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Guest Experience</h3>
                  <p className="text-white/70 mb-4">Responsive communication, clean rooms, helpful local knowledge, and personalized service create 5-star reviews. Great reviews drive repeat bookings and word-of-mouth worth ₹10+ lakhs in marketing.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Multi-Platform Strategy</h3>
                  <p className="text-white/70 mb-4">List on Airbnb, Booking.com, and OTA Studio simultaneously. Diversified channels reduce dependency on single platform. Multiple listings increase total bookings by 60-100%.</p>
                </div>
              </div>
              <div className="p-8 rounded-2xl bg-neutral-900 border border-white/8">
                <h3 className="font-display font-bold text-xl text-white mb-4">Common Mistakes to Avoid</h3>
                <ul className="grid md:grid-cols-2 gap-4">
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Poor property presentation</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Pricing too high or too low</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Unresponsive to guest inquiries</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Not maintaining cleanliness</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Ignoring guest feedback</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Not using multiple booking platforms</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Expert Tips for Success</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Focus on Reviews</h3>
                  <p className="text-white/70">5-star reviews are your best marketing. Request reviews from happy guests. Properties with 4.8+ ratings book 3-5x more than average, supporting 50%+ higher rates.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Personal Touch</h3>
                  <p className="text-white/70">Memorable small gestures (welcome notes, local recommendations, check-in calls) differentiate you. Personal touches increase guest satisfaction by 40-50% and drive repeat bookings.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Dynamic Pricing</h3>
                  <p className="text-white/70">Adjust prices based on demand, season, and events. Dynamic pricing increases annual revenue by 20-30% versus fixed pricing without losing occupancy.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Frequently Asked Questions</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="text">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`} itemScope itemType="https://schema.org/Answer">
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="text">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-4">Related Services</h2>
              <p className="text-center text-white/50 mb-8">Explore more ways to grow your hospitality business</p>
              <div className="grid md:grid-cols-3 gap-6">
                <a href="/property-management-goa" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Property Management</h3>
                  <p className="text-white/50 text-sm">Comprehensive management for your Goa properties</p>
                </a>
                <a href="/vision-mission" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Our Vision & Mission</h3>
                  <p className="text-white/50 text-sm">Understand our commitment to Goa's hospitality</p>
                </a>
                <a href="/founders" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Meet Our Founders</h3>
                  <p className="text-white/50 text-sm">Learn from our hospitality industry experts</p>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Start Your Homestay Today</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">OTA Studio helps you setup, manage, and scale your Goa homestay for maximum occupancy and guest satisfaction.</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="https://wa.me/919270598602" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="#" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
