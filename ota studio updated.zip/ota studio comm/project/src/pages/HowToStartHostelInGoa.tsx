import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  {
    q: 'What is the ideal property type for a hostel in Goa?',
    a: 'Properties with 10-20+ rooms, large common areas, and good location near beaches or attractions work best. Look for residential buildings or small hotels that can be converted to hostel format.'
  },
  {
    q: 'How much revenue can a hostel generate?',
    a: 'A 20-bed hostel with ₹500-1,200/bed occupancy can generate ₹3-7 lakhs monthly at 70% occupancy. Annual revenue ranges from ₹36-84 lakhs with proper management.'
  },
  {
    q: 'Which platforms are essential for hostel listings?',
    a: 'Hostelworld is critical for backpackers. Also list on Booking.com, Agoda, and Airbnb. Multi-platform presence is essential to reach diverse guest segments.'
  },
  {
    q: 'What amenities do backpackers expect in hostels?',
    a: 'Free WiFi, common kitchen, lounge with games/entertainment, clean bathrooms, lockers, security, organized tours/activities, and social atmosphere are must-haves.'
  },
  {
    q: 'How do I create community in a hostel?',
    a: 'Organize daily group dinners, pub crawls, beach trips, and activities. Provide welcoming common spaces. Host social events to foster guest connections and build loyalty.'
  },
  {
    q: 'Is licensing different for hostels vs hotels?',
    a: 'Hostels follow similar licensing rules to hotels, including Hotel Classification, fire safety, and GST registration. Check with Goa Tourism Development Corporation for specific requirements.'
  }
];

export default function HowToStartHostelInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          {/* Hero Section */}
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white"><span itemProp="name">Home</span></a>
                    <meta itemProp="position" content="1" />
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white">
                    <span itemProp="name">How to Start Hostel in Goa</span>
                    <meta itemProp="position" content="2" />
                  </li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Hostel Startup · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">How to Start a Hostel in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Complete guide to launching a profitable hostel business in Goa. From property selection and community building to Hostelworld optimization and revenue scaling,
                learn how to create a thriving backpacker destination that generates consistent bookings and creates unforgettable guest experiences.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20start%20a%20hostel%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20a%20free%20OTA%20audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </div>

          {/* GrowthDashboard - Right after hero */}
          <GrowthDashboard />

          {/* Introduction Section */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Hostel Business Opportunity in Goa</h2>
                <p className="body-md text-white/70 mb-6">
                  Goa attracts millions of backpackers annually, making it an ideal market for hostel businesses. Budget-conscious travelers represent a significant, underserved segment
                  with consistent demand throughout the year. Hostels offer lower operational costs than hotels while serving high-volume markets, resulting in healthy profit margins
                  of 25-35% with professional management.
                </p>
                <p className="body-md text-white/70 mb-6">
                  The hostel market in Goa is growing, with backpackers seeking affordable, social accommodations with curated experiences. Modern hostels compete on community features,
                  organized activities, cleanliness, and social atmosphere. A well-positioned 20-bed hostel can generate ₹3-7 lakhs monthly revenue with 70-80% occupancy.
                </p>
              </div>
            </div>
          </section>

          {/* Step-by-Step Guide */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-12">Step-by-Step Guide to Starting a Hostel</h2>
              <div className="max-w-3xl mx-auto space-y-8">
                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 1: Select Strategic Location</h3>
                  <p className="text-white/70 mb-4">
                    Location is critical for hostel success. Choose areas with high backpacker foot traffic—beach towns like Baga, Calangute, or trendy neighborhoods with bars and
                    restaurants. Proximity to attractions, public transport, and social hubs directly impacts walk-in guests and repeat visits.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Identify high backpacker traffic areas (beaches, main roads)</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Evaluate proximity to bars, restaurants, and nightlife</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Check accessibility and public transport connectivity</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Analyze competitor hostels in the area</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 2: Acquire and Prepare Property</h3>
                  <p className="text-white/70 mb-4">
                    Secure a property suitable for hostel conversion. Look for properties with multiple rooms, space for common areas, and basic infrastructure. Deep clean,
                    fix maintenance issues, and plan room configuration (dorms vs private rooms).
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Identify property with 10-20+ room capacity</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Deep clean and address maintenance issues</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Design room layout: mix of dorms (4-6 bed) and private rooms</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Plan common areas (lounge, kitchen, rooftop)</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 3: Install Essential Amenities</h3>
                  <p className="text-white/70 mb-4">
                    Invest in quality beds, clean bathrooms, and essential amenities. Backpackers expect free WiFi, functional kitchens, lockers, and clean facilities. Create inviting
                    common spaces that encourage socializing and community building.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Install quality beds and fresh, durable linens</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Provide individual lockers and secure storage</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Set up functional, clean, shared kitchen facilities</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Install high-speed, reliable WiFi throughout property</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Create welcoming common areas with games, TV, seating</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 4: Establish Legal Compliance</h3>
                  <p className="text-white/70 mb-4">
                    Register with Hotel Classification Committee, obtain fire safety certificates, trade licenses, and GST registration. Hostels follow similar regulations as hotels
                    in Goa, so ensure all legal documentation is complete before opening.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Register with Hotel Classification Committee</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Obtain municipal trade license</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Get fire safety certificate and NOC</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Register for GST if annual turnover exceeds ₹20 lakhs</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 5: Professional Photography and Listing Creation</h3>
                  <p className="text-white/70 mb-4">
                    Create compelling listings with high-quality photos showing rooms, common areas, and social spaces. Highlight unique features like rooftop, free activities,
                    or organized events. Use compelling language emphasizing community and adventure.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Hire photographer to capture rooms and common areas</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Write engaging descriptions highlighting social atmosphere</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Emphasize free activities, events, and community features</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Include clear pricing for dorms and private rooms</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 6: List on Multiple Platforms</h3>
                  <p className="text-white/70 mb-4">
                    List on Hostelworld (essential), Booking.com, Airbnb, and Agoda. Hostelworld is the primary backpacker booking platform, so prioritize optimization there.
                    Multi-platform presence increases visibility and booking volume significantly.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Register and optimize listing on Hostelworld</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>List on Booking.com with competitive rates</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Add to Airbnb for private room bookings</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Create website with direct booking option</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 7: Set Competitive Pricing and Discounts</h3>
                  <p className="text-white/70 mb-4">
                    Price competitively while maintaining margins. Offer weekly/monthly discounts to encourage longer stays. Use dynamic pricing for seasonal demand fluctuations.
                    Provide group discounts for tour operators and travel agencies.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Research competitor pricing in your area</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Offer discounts for weekly/monthly stays (15-25%)</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Implement seasonal pricing adjustments</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Create partnerships with tour operators for bulk bookings</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 8: Build Community and Organize Activities</h3>
                  <p className="text-white/70 mb-4">
                    Create a vibrant community atmosphere. Organize daily social events, group dinners, pub crawls, beach trips, and adventures. These activities drive word-of-mouth
                    marketing, encourage return bookings, and generate higher per-guest spending through activity commissions.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Organize daily hostel dinners and cooking sessions</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Arrange weekly pub crawls and social outings</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Plan group beach trips and water sports activities</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Host game nights, movie screenings, and cultural events</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          {/* Legal Requirements */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Legal Requirements for Hostels in Goa</h2>
                <p className="body-md text-white/70 mb-6">
                  Hostels must comply with the same legal requirements as hotels in Goa:
                </p>
                <ul className="space-y-3 text-white/70">
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Hotel Classification:</strong> Register with Hotel Classification Committee for license and minimum standards compliance.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Trade License:</strong> Obtain municipal trade license from your local corporation.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Fire Safety:</strong> Get fire safety certificate and conduct regular fire drills. Maintain emergency exits and equipment.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">GST Registration:</strong> Required if annual turnover exceeds ₹20 lakhs. File returns quarterly or monthly.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Labor Compliance:</strong> Follow ESI and PF requirements for all staff. Maintain wage records and safety standards.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Guest Records:</strong> Maintain records of guest check-ins/check-outs for local authority compliance.</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          {/* Investment Breakdown */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Investment Breakdown for Hostel Startup</h2>
                <p className="body-md text-white/70 mb-6">
                  For a 20-bed hostel (assuming property is already owned):
                </p>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Beds, mattresses, linens, and furnishings</span>
                    <span className="text-accent font-semibold">₹2 - 5 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Kitchen setup and equipment</span>
                    <span className="text-accent font-semibold">₹1 - 2 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Lockers, storage, and common area furniture</span>
                    <span className="text-accent font-semibold">₹50,000 - 1 lakh</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">WiFi and electrical upgrades</span>
                    <span className="text-accent font-semibold">₹50,000 - 1 lakh</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Professional photography and listing creation</span>
                    <span className="text-accent font-semibold">₹30,000 - 50,000</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Licenses, registrations, and legal setup</span>
                    <span className="text-accent font-semibold">₹1 - 2 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Working capital (first 3 months)</span>
                    <span className="text-accent font-semibold">₹2 - 3 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-accent/10 border border-accent/20">
                    <span className="text-white font-semibold">Total Investment</span>
                    <span className="text-accent font-semibold">₹7.3 - 14.5 lakhs</span>
                  </div>
                </div>
                <p className="body-md text-white/70 mt-6">
                  Monthly operating costs: Staff (₹20,000-30,000), utilities (₹5,000-8,000), maintenance (₹2,000-3,000), cleaning supplies (₹2,000-3,000).
                </p>
              </div>
            </div>
          </section>

          {/* Revenue Potential */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Revenue Potential</h2>
                <p className="body-md text-white/70 mb-6">
                  For a 20-bed hostel with mix of dorms and private rooms:
                </p>
                <div className="space-y-4 mb-6">
                  <div className="p-5 rounded-lg bg-white/4 border border-white/8">
                    <h4 className="text-white font-semibold mb-2">Conservative Scenario (₹600-800/bed)</h4>
                    <p className="text-white/70 text-sm">
                      At 65% occupancy: ₹2.34-3.12 lakhs/month. Annual revenue: ₹28-37.5 lakhs (gross)
                    </p>
                  </div>
                  <div className="p-5 rounded-lg bg-white/4 border border-white/8">
                    <h4 className="text-white font-semibold mb-2">Mid-Range Scenario (₹800-1,000/bed)</h4>
                    <p className="text-white/70 text-sm">
                      At 70% occupancy: ₹3.36-4.2 lakhs/month. Annual revenue: ₹40-50 lakhs (gross)
                    </p>
                  </div>
                  <div className="p-5 rounded-lg bg-white/4 border border-white/8">
                    <h4 className="text-white font-semibold mb-2">Optimistic Scenario (₹1,000-1,200/bed)</h4>
                    <p className="text-white/70 text-sm">
                      At 75% occupancy: ₹4.5-5.4 lakhs/month. Annual revenue: ₹54-65 lakhs (gross)
                    </p>
                  </div>
                </div>
                <p className="body-md text-white/70">
                  Peak season (Oct-Mar) generates 55-65% of annual revenue. Additional revenue from food, tours, and activities adds 10-15% to total revenue.
                  Net profit margin: 25-35% after operating costs.
                </p>
              </div>
            </div>
          </section>

          {/* Mistakes to Avoid */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Common Mistakes to Avoid</h2>
                <div className="space-y-4">
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Poor Cleanliness Standards</h3>
                    <p className="text-white/70 text-sm">
                      Backpackers prioritize cleanliness. Even small issues like dirty bathrooms or unkempt common areas lead to bad reviews and reduced bookings.
                    </p>
                  </div>
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Ignoring Hostelworld Optimization</h3>
                    <p className="text-white/70 text-sm">
                      Hostelworld is primary backpacker platform. Poor optimization, low ratings, or limited visibility significantly impact booking volume.
                    </p>
                  </div>
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">No Community Building</h3>
                    <p className="text-white/70 text-sm">
                      Hostels thrive on community. Without organized activities and social atmosphere, properties struggle to compete and retain guests.
                    </p>
                  </div>
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Inadequate WiFi</h3>
                    <p className="text-white/70 text-sm">
                      Modern travelers demand high-speed, reliable WiFi. Poor internet is top complaint leading to negative reviews and lost bookings.
                    </p>
                  </div>
                  <li className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Single Platform Reliance</h3>
                    <p className="text-white/70 text-sm">
                      Multi-platform distribution is essential. Relying only on Hostelworld misses potential from Booking.com, Airbnb, and walk-in guests.
                    </p>
                  </li>
                </div>
              </div>
            </div>
          </section>

          {/* Expert Tips */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Expert Tips for Hostel Success</h2>
                <ul className="space-y-3 text-white/70">
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Hire Community Manager:</strong> Dedicate person to organize activities, engage guests, and build community atmosphere.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Leverage Reviews:</strong> Encourage reviews immediately after checkout. Maintain 8.5+ rating on Hostelworld through excellent service.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Diversify Revenue:</strong> Generate ancillary revenue from food, tours, activities, laundry, and merchandise sales.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Build Partnerships:</strong> Partner with tour operators, travel agencies, and nearby attractions for commissions and group bookings.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Seasonal Planning:</strong> Hire additional staff during peak season. Reduce rates during low season to maintain occupancy.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Social Media Presence:</strong> Build Instagram presence showcasing parties, activities, and guest reviews to attract travelers.</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          {/* Related Services */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Related Services</h2>
              <div className="grid sm:grid-cols-3 gap-6 max-w-3xl mx-auto">
                <a href="/property-management-goa" className="p-6 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all text-center">
                  <h3 className="font-display font-bold text-lg text-white mb-2">Property Management</h3>
                  <p className="text-sm text-white/50">Professional management for your Goa properties</p>
                </a>
                <a href="/vision-mission" className="p-6 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all text-center">
                  <h3 className="font-display font-bold text-lg text-white mb-2">Our Vision</h3>
                  <p className="text-sm text-white/50">Learn about OTA Studio's hospitality mission</p>
                </a>
                <a href="/founders" className="p-6 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all text-center">
                  <h3 className="font-display font-bold text-lg text-white mb-2">Meet Our Team</h3>
                  <p className="text-sm text-white/50">Hospitality experts with 50+ years experience</p>
                </a>
              </div>
            </div>
          </section>

          {/* FAQs */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Frequently Asked Questions</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} itemScope itemType="https://schema.org/Question" className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span itemProp="name" className="font-display font-bold text-white pr-4">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div itemScope itemType="https://schema.org/Answer" className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div itemProp="text" className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* CTA Section */}
          <section className="bg-neutral-950 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ready to Launch Your Hostel?</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Get expert guidance on community building, OTA optimization, and revenue maximization for successful hostel business in Goa.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20start%20a%20hostel%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20a%20free%20OTA%20audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
