import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  {
    q: 'What licenses do I need to start a hotel in Goa?',
    a: 'You need registration with the Hotel Classification Committee, trade license, FSSAI (if serving food), pollution control certificate, and fire safety compliance. GST registration is mandatory for hotels.'
  },
  {
    q: 'How much capital is required to start a hotel?',
    a: 'A 20-40 room hotel requires ₹30-80 lakhs depending on location, amenities, and star rating. Budget hotels are cheaper; luxury properties cost more. Include land, construction, furniture, and working capital.'
  },
  {
    q: 'What is the best location for a hotel in Goa?',
    a: 'Beachfront locations (Baga, Calangute, Arambol) command premium rates. Budget options: Panjim, Mapusa. Mid-range: Vagator, Dabolim areas. Consider proximity to airports, attractions, and target guests.'
  },
  {
    q: 'How do I maximize OTA bookings for my hotel?',
    a: 'List on major OTAs (Booking.com, Agoda, Expedia). Offer competitive rates, maintain high ratings, respond quickly, and use professional photos. Offer OTA-exclusive discounts to boost visibility.'
  },
  {
    q: 'What staff do I need to hire initially?',
    a: 'Start with: Manager (1), front desk staff (2-3), housekeeping (3-5), maintenance (1-2), and kitchen staff (2-3) for a 20-30 room hotel. Hire locals and invest in training.'
  },
  {
    q: 'How can I compete with established hotels?',
    a: 'Differentiate with unique design, excellent service, competitive pricing, OTA listings, and targeted marketing. Build brand presence, encourage reviews, and offer special packages for groups/events.'
  }
];

export default function HowToStartHotelInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          {/* Hero Section */}
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white"><span itemProp="name">Home</span></a>
                    <meta itemProp="position" content="1" />
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white">
                    <span itemProp="name">How to Start Hotel in Goa</span>
                    <meta itemProp="position" content="2" />
                  </li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Hotel Startup · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">How to Start a Hotel in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Comprehensive guide to launching a profitable hotel business in Goa. From licensing and property selection to OTA management and revenue optimization,
                learn the complete process to establish a successful hospitality venture in India's top tourism destination.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20start%20a%20hotel%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20a%20free%20OTA%20audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </div>

          {/* GrowthDashboard - Right after hero */}
          <GrowthDashboard />

          {/* Introduction Section */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Hotel Business Opportunity in Goa</h2>
                <p className="body-md text-white/70 mb-6">
                  Goa receives over 7 million tourists annually, making it one of India's most profitable hospitality markets. Hotels in strategic locations
                  achieve 60-80% occupancy rates year-round, with peak season rates reaching ₹5,000-15,000+ per night. The market supports properties at every
                  price point—from budget hotels (₹1,500-2,500) to luxury resorts (₹10,000-30,000+).
                </p>
                <p className="body-md text-white/70 mb-6">
                  Modern hotel businesses leverage OTA platforms (Booking.com, Agoda, Expedia), allowing efficient management without heavy offline marketing costs.
                  With professional operations, competitive positioning, and strong digital presence, a well-managed hotel can generate ₹15-50+ lakhs monthly revenue.
                </p>
              </div>
            </div>
          </section>

          {/* Step-by-Step Guide */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-12">Step-by-Step Guide to Starting a Hotel</h2>
              <div className="max-w-3xl mx-auto space-y-8">
                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 1: Feasibility Study and Market Research</h3>
                  <p className="text-white/70 mb-4">
                    Research market demand, competitor analysis, location viability, and target guest demographics. Identify demand patterns for your
                    location and property type. Review seasonal trends and competitive pricing in nearby hotels.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Analyze local hotel occupancy rates and pricing</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Identify target customer segments (tourists, business, backpackers)</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Evaluate location accessibility and proximity to attractions</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Create financial projections and ROI models</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 2: Secure Property and Finance</h3>
                  <p className="text-white/70 mb-4">
                    Identify suitable property with favorable terms. Secure financing through banks, investors, or personal capital. Ensure clear property
                    titles and legal documentation before commitment.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Identify property matching hotel requirements</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Verify legal ownership and clear titles</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Secure financing from banks or investors</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Complete property acquisition and registration</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 3: Obtain Licenses and Regulatory Approvals</h3>
                  <p className="text-white/70 mb-4">
                    Register with Hotel Classification Committee, obtain trade licenses, fire safety certificates, and pollution control clearance.
                    These are mandatory for legal operation in Goa.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Register with Hotel Classification Committee for star rating</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Obtain municipal trade license and building use approval</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Get fire safety and pollution control certificates</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Register for GST and obtain GST certificate</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 4: Design Hotel Concept and Layout</h3>
                  <p className="text-white/70 mb-4">
                    Design room layouts, amenities, and common areas optimized for guest comfort and operational efficiency. Plan for reception, restaurant,
                    fitness center, and other facilities based on property type and target market.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Plan optimal room mix (singles, doubles, suites)</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Design common areas (lobby, restaurant, bar, pool)</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Plan amenities (WiFi, AC, hot water, parking)</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Ensure ADA compliance and accessibility standards</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 5: Construction and Furniture Installation</h3>
                  <p className="text-white/70 mb-4">
                    Execute construction with quality oversight. Install premium furnishings, bedding, and amenities that support your star rating target.
                    Schedule phased completion if opening gradually.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Execute construction with quality control</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Install premium furniture, fixtures, and appliances</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Set up PMS (Property Management System) software</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Install WiFi, phone systems, and security infrastructure</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 6: Hire and Train Staff</h3>
                  <p className="text-white/70 mb-4">
                    Recruit experienced manager, front desk, housekeeping, and kitchen staff. Invest in training programs for service excellence and operational
                    efficiency. Establish clear SOPs for all departments.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Hire experienced hotel manager and department heads</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Recruit skilled front desk, housekeeping, and kitchen staff</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Conduct comprehensive training on service standards</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Create operational manuals and SOPs</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 7: Set Up Distribution and Marketing</h3>
                  <p className="text-white/70 mb-4">
                    List on major OTAs (Booking.com, Agoda, Expedia, MakeMyTrip). Create professional website with SEO optimization. Develop marketing strategy
                    targeting key segments. Build brand presence on social media.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>List on major OTA platforms</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Build professional hotel website with booking engine</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Create social media presence (Instagram, Facebook)</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Develop email marketing and loyalty programs</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 8: Soft Launch and Grand Opening</h3>
                  <p className="text-white/70 mb-4">
                    Conduct soft launch with selected guests to test operations and build initial reviews. Plan grand opening campaign with media coverage and
                    special promotions. Focus on generating positive reviews early.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Conduct soft launch with complimentary stays for reviewers</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Host media and influencer launch events</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Offer opening specials and promotional rates</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Monitor operations and address initial issues</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          {/* Legal Requirements */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Legal Requirements for Hotels in Goa</h2>
                <p className="body-md text-white/70 mb-6">
                  Operating a hotel in Goa requires compliance with multiple regulatory bodies:
                </p>
                <ul className="space-y-3 text-white/70">
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Hotel Classification Committee:</strong> Register for star rating (1-5 stars) based on facilities and services.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Municipal Corporation/Town Planning:</strong> Obtain building use certificate and trade license.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Fire Department:</strong> Get fire safety clearance and NOC. Conduct fire drills regularly.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Pollution Control Board:</strong> Obtain environmental clearance and pollution control certificate.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">GST Registration:</strong> Mandatory for all hotels. File returns quarterly or monthly.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">FSSAI Licensing:</strong> Required if serving food. Food handler certification mandatory.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Labor Compliance:</strong> Follow ESI, PF, and labor law requirements for all staff.</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          {/* Investment Breakdown */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Investment Breakdown for Hotel Startup</h2>
                <p className="body-md text-white/70 mb-6">
                  For a 25-30 room budget-to-mid-range hotel in Goa (excluding land):
                </p>
                <div className="space-y-4 mb-6">
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Construction (₹30-60 per sq ft)</span>
                    <span className="text-accent font-semibold">₹20 - 40 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Furniture & fixtures</span>
                    <span className="text-accent font-semibold">₹8 - 15 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Kitchen & equipment</span>
                    <span className="text-accent font-semibold">₹5 - 10 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">PMS & IT infrastructure</span>
                    <span className="text-accent font-semibold">₹2 - 4 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Licenses & approvals</span>
                    <span className="text-accent font-semibold">₹2 - 5 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Pre-opening marketing</span>
                    <span className="text-accent font-semibold">₹1 - 2 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Working capital (3 months)</span>
                    <span className="text-accent font-semibold">₹10 - 15 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-accent/10 border border-accent/20">
                    <span className="text-white font-semibold">Total (excluding land)</span>
                    <span className="text-accent font-semibold">₹48 - 91 lakhs</span>
                  </div>
                </div>
                <p className="body-md text-white/70">
                  Luxury properties cost 2-3x more. Including land acquisition, total investment can reach ₹1.5-5 crores depending on location and specifications.
                </p>
              </div>
            </div>
          </section>

          {/* Revenue Potential */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Revenue Potential</h2>
                <p className="body-md text-white/70 mb-6">
                  For a 25-30 room hotel with professional management:
                </p>
                <div className="space-y-4 mb-6">
                  <div className="p-5 rounded-lg bg-white/4 border border-white/8">
                    <h4 className="text-white font-semibold mb-2">Budget Hotel (₹2,000-3,500/night)</h4>
                    <p className="text-white/70 text-sm">
                      At 65% occupancy: ₹12-21 lakhs/month. Annual revenue: ₹1.44-2.52 crores (gross)
                    </p>
                  </div>
                  <div className="p-5 rounded-lg bg-white/4 border border-white/8">
                    <h4 className="text-white font-semibold mb-2">Mid-Range Hotel (₹4,000-7,000/night)</h4>
                    <p className="text-white/70 text-sm">
                      At 70% occupancy: ₹21-36.75 lakhs/month. Annual revenue: ₹2.52-4.41 crores (gross)
                    </p>
                  </div>
                  <div className="p-5 rounded-lg bg-white/4 border border-white/8">
                    <h4 className="text-white font-semibold mb-2">Upscale Hotel (₹8,000-12,000/night)</h4>
                    <p className="text-white/70 text-sm">
                      At 75% occupancy: ₹45-67.5 lakhs/month. Annual revenue: ₹5.4-8.1 crores (gross)
                    </p>
                  </div>
                </div>
                <p className="body-md text-white/70">
                  Peak season (Oct-Mar) generates 50-60% of annual revenue. After operational costs (staff, maintenance, utilities: ~40-50% of revenue),
                  net profit margin typically ranges from 15-25% for well-managed properties.
                </p>
              </div>
            </div>
          </section>

          {/* Mistakes to Avoid */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Common Mistakes to Avoid</h2>
                <div className="space-y-4">
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Underestimating Operating Costs</h3>
                    <p className="text-white/70 text-sm">
                      Hidden costs like utility bills, maintenance, and staff welfare can exceed projections by 30-40%. Build 20% buffer in financial planning.
                    </p>
                  </div>
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Ignoring OTA Distribution</h3>
                    <p className="text-white/70 text-sm">
                      Focusing only on direct bookings misses 60-70% of market. Multi-channel distribution through OTAs is essential for volume and stability.
                    </p>
                  </div>
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Poor Staff Training and Retention</h3>
                    <p className="text-white/70 text-sm">
                      Service quality directly impacts ratings and repeat bookings. Invest in training, fair wages, and work culture to minimize turnover.
                    </p>
                  </div>
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Inadequate Marketing</h3>
                    <p className="text-white/70 text-sm">
                      New hotels need 6-12 months to build awareness and achieve decent occupancy. Plan aggressive marketing budget in early years.
                    </p>
                  </div>
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Neglecting Online Reviews</h3>
                    <p className="text-white/70 text-sm">
                      First reviews are critical. Actively manage reviews, respond to feedback, and encourage satisfied guests to post reviews.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Expert Tips */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Expert Tips for Hotel Success</h2>
                <ul className="space-y-3 text-white/70">
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Implement PMS Software:</strong> Professional Property Management System automates bookings, staff coordination, and reporting.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Diversify Revenue Streams:</strong> Add restaurant, conferences, events, and activities to increase per-guest spending.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Build Loyalty Programs:</strong> Reward repeat guests with discounts and personalized experiences for long-term revenue.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Monitor Seasonality:</strong> Implement flexible pricing and dynamic revenue management for seasonal demand patterns.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Create Unique Experiences:</strong> Differentiate with local activities, unique dining, or wellness programs to justify premium pricing.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Professional Management:</strong> Consider hiring professional hotel management company for better operations and profitability.</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          {/* Related Services */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Related Services</h2>
              <div className="grid sm:grid-cols-3 gap-6 max-w-3xl mx-auto">
                <a href="/property-management-goa" className="p-6 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all text-center">
                  <h3 className="font-display font-bold text-lg text-white mb-2">Property Management</h3>
                  <p className="text-sm text-white/50">Professional management for your Goa properties</p>
                </a>
                <a href="/vision-mission" className="p-6 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all text-center">
                  <h3 className="font-display font-bold text-lg text-white mb-2">Our Vision</h3>
                  <p className="text-sm text-white/50">Learn about OTA Studio's hospitality mission</p>
                </a>
                <a href="/founders" className="p-6 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all text-center">
                  <h3 className="font-display font-bold text-lg text-white mb-2">Meet Our Team</h3>
                  <p className="text-sm text-white/50">Hospitality experts with 50+ years experience</p>
                </a>
              </div>
            </div>
          </section>

          {/* FAQs */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Frequently Asked Questions</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} itemScope itemType="https://schema.org/Question" className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span itemProp="name" className="font-display font-bold text-white pr-4">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div itemScope itemType="https://schema.org/Answer" className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div itemProp="text" className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* CTA Section */}
          <section className="bg-neutral-950 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ready to Start Your Hotel Business?</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Get expert guidance on every aspect of hotel startup and management in Goa. Our team has 50+ years combined hospitality experience.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20start%20a%20hotel%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20a%20free%20OTA%20audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
