import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What investment is needed to start a live music event business in Goa?', a: 'Budget ₹20-50 lakhs for venue, sound system, licensing, and initial marketing. Can start with ₹10+ lakhs if using existing venue. ROI is quick at 6-12 months with proper execution and marketing.' },
  { q: 'Where can I host live music events in Goa?', a: 'Beaches, restaurants, bars, property gardens, open-air venues, and dedicated event spaces work well. Goa\'s climate supports year-round outdoor music. Properties with green spaces can convert to music venues with minimal investment.' },
  { q: 'How do I book quality musicians?', a: 'Build relationships with local bands, DJs, and solo artists. Many Goa musicians perform regularly and are available for monthly bookings. Direct relationships provide better rates and reliable performers.' },
  { q: 'What revenue model works best?', a: 'Ticket sales (₹300-1000+ per person), beverage sales, food, VIP tables, and sponsorships. A 200-person event generates ₹1.5-3 lakhs revenue. Monthly events generate ₹5-10+ lakhs with 50-60% margins.' },
  { q: 'Can music events boost accommodation revenue?', a: 'Yes significantly. Music lovers book rooms for weekends with live music. Package events with rooms at premium rates. Music event weekends achieve 40-60% higher occupancy and 30-50% higher ADR.' },
];

const steps = [
  'Secure venue and obtain permits',
  'Invest in quality sound system',
  'Build musician relationships',
  'Plan monthly or weekly schedule',
  'Create compelling marketing strategy',
  'Set up ticketing system',
  'Coordinate logistics and operations',
  'Execute and optimize',
];

export default function HowToStartLiveMusicEventsInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li><span itemProp="name">How to Start Live Music Events in Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Live Music · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">How to Start Live Music Events in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Launch a profitable live music event business in Goa. Learn how to secure quality musicians, manage logistics, create compelling experiences, and generate sustainable revenue from music events.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20start%20live%20music%20events%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">Music Event Launch Steps</h2>
                  <ol className="space-y-4">
                    {steps.map((step, i) => (
                      <li key={i} className="flex items-start gap-4">
                        <span className="flex items-center justify-center w-8 h-8 rounded-full bg-accent/20 text-accent font-display font-bold shrink-0">{i + 1}</span>
                        <span className="text-white/70 pt-0.5">{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
                <div className="space-y-6">
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Music Event Infrastructure</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Professional sound system</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Lighting and stage setup</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Comfortable seating/standing areas</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Security and safety measures</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Bar and food service</span>
                      </li>
                    </ul>
                  </div>
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Revenue Model</h3>
                    <div className="space-y-2 text-white/70 text-sm">
                      <p><span className="text-accent font-semibold">100-person event:</span> ₹75,000-1.5 lakhs</p>
                      <p><span className="text-accent font-semibold">200-person event:</span> ₹1.5-3 lakhs</p>
                      <p><span className="text-accent font-semibold">Monthly events:</span> ₹5-10 lakhs/month</p>
                      <p><span className="text-accent font-semibold">Profit margin:</span> 50-60%</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Operations & Scale</h2>
              <div className="grid md:grid-cols-2 gap-8 mb-12">
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Sound Quality Priority</h3>
                  <p className="text-white/70 mb-4">Professional sound is non-negotiable. Poor sound kills events and generates negative reviews. Quality sound systems cost ₹5-15 lakhs but increase attendee satisfaction 40-50% and support premium pricing.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Musician Relationships</h3>
                  <p className="text-white/70 mb-4">Build strong relationships with local bands and DJs. Monthly performances create artist loyalty and fan bases. Predictable gigs allow musicians to promote to their followers, growing your audience organically.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Marketing & Promotion</h3>
                  <p className="text-white/70 mb-4">Promote 2-3 weeks ahead. Use social media, artist networks, partnerships, email lists. Artist promotion to their followers generates 30-40% of attendees at no cost to you. Multi-channel promotion drives 80%+ attendance.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Premium Packages</h3>
                  <p className="text-white/70 mb-4">Offer VIP tables, premium seating, backstage access. 20% of attendees spend 60% of revenue through premium packages. Premium packages increase margins 20-30% without increasing costs significantly.</p>
                </div>
              </div>
              <div className="p-8 rounded-2xl bg-neutral-900 border border-white/8">
                <h3 className="font-display font-bold text-xl text-white mb-4">Common Mistakes to Avoid</h3>
                <ul className="grid md:grid-cols-2 gap-4">
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Poor sound quality</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Unreliable musicians</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Inadequate crowd management</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Starting promotion too late</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Not building recurring audience</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Poor pricing strategy</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Expert Tips for Success</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Consistency Builds Audiences</h3>
                  <p className="text-white/70">Weekly or monthly predictable music events build loyal audiences who anticipate events. Consistent events are worth 3-5x marketing spend. Loyal attendees spend 4-6x more than casual visitors.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Create Community</h3>
                  <p className="text-white/70">Music events create social connections. Attendees meet, make friends, and return. Community-focused venues have 80%+ repeat customer rate and generate 5+ referrals per member.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Leverage OTA Channels</h3>
                  <p className="text-white/70">Promote events on OTA Studio, Booking.com, Airbnb. Tourists actively search for live music experiences. OTA promotion generates 30-50% of bookings for music venues in tourist areas.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Frequently Asked Questions</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="text">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`} itemScope itemType="https://schema.org/Answer">
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="text">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-4">Related Services</h2>
              <p className="text-center text-white/50 mb-8">Explore more ways to grow your hospitality business</p>
              <div className="grid md:grid-cols-3 gap-6">
                <a href="/property-management-goa" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Property Management</h3>
                  <p className="text-white/50 text-sm">Comprehensive management for your Goa properties</p>
                </a>
                <a href="/vision-mission" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Our Vision & Mission</h3>
                  <p className="text-white/50 text-sm">Understand our commitment to Goa's hospitality</p>
                </a>
                <a href="/founders" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Meet Our Founders</h3>
                  <p className="text-white/50 text-sm">Learn from our hospitality industry experts</p>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Start Your Music Event Business</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">OTA Studio helps you launch, market, and scale a profitable live music event business that builds community and generates sustainable revenue.</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="#" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
