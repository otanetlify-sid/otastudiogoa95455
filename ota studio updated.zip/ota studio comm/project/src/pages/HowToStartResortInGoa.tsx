import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What land requirements are needed to start a resort in Goa?', a: 'Minimum land requirement varies by classification: 5-star resorts typically need 2-5 acres, 3-4 star resorts need 1-3 acres, and heritage/boutique resorts can operate on 0.5-1 acre. Land must have clear title, environmental clearance, and be in zones permitting hospitality development. Avoid protected areas and mangrove regions which have strict regulations.' },
  { q: 'What licenses are required for a resort in Goa?', a: 'Essential licenses include: Hotel Registration from Goa Directorate of Tourism, FSSAI for food operations, Fire Safety NOC, Health Trade License, Liquor License (if serving alcohol), Environmental Clearance, Building Approval from Municipal Corporation, and GST registration. The entire approval process typically takes 2-4 months.' },
  { q: 'How important is luxury positioning for resort success?', a: 'Luxury positioning is critical for resort differentiation. Focus on: premium amenities (spa, fine dining, landscaping), personalized guest services, unique selling propositions (beachfront, heritage property, wellness focus), and professional housekeeping standards. Positioned correctly, luxury resorts command premium rates and attract high-value guests from global OTA platforms.' },
  { q: 'How should I manage OTA relationships for a resort?', a: 'Resort success depends on strong OTA partnerships. List on Booking.com, Agoda, Expedia, and niche platforms (Airbnb, Luxury Escapes). Optimize listings with professional photography, detailed amenities descriptions, competitive pricing, and fast response times. Manage reputation through consistent service excellence and proactive review responses. Consider revenue management tools to optimize pricing across channels.' },
  { q: 'What is the typical investment for starting a resort in Goa?', a: 'Budget significantly: Land (₹50-200 lakhs for 1-2 acres), Construction (₹100-400 lakhs depending on star rating and amenities), Licenses & Approvals (₹5-15 lakhs), Interior Design & Furnishing (₹30-100 lakhs), Kitchen Equipment (₹10-30 lakhs), Technology & Systems (₹5-10 lakhs), and Working Capital (₹20-50 lakhs). Total: ₹2.5-8 crores for a decent 3-4 star resort.' },
  { q: 'How does guest experience design impact resort success?', a: 'Guest experience is your competitive advantage. Design around: intuitive property layout for easy navigation, consistent high-quality service standards, memorable interactions with staff, attention to comfort details (temperature, lighting, noise), seamless technology integration (WiFi, online services), and personalized touches. Excellence here drives repeat bookings and positive reviews across OTA platforms.' },
];

export default function HowToStartResortInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">How to Start a Resort in Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Resort Business · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">How to Start a Resort in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Comprehensive guide to launching a successful resort in Goa. Learn about land requirements, licensing, luxury positioning, OTA management strategies, and guest experience design for premium resort success.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20start%20a%20resort%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Resort Licensing & Approvals</h2>
              <div className="grid md:grid-cols-2 gap-8">
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Government Approvals</h3>
                  <p className="text-white/70 mb-4">Goa Directorate of Tourism hotel registration is mandatory. Environmental Impact Assessment is required. Building plan approval from Municipal Corporation ensures structural compliance. Fire Department NOC confirms safety standards. These approvals take 6-8 weeks combined.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Tourism Ministry star classification
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Environmental clearance verification
                    </li>
                  </ul>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Operational Licenses</h3>
                  <p className="text-white/70 mb-4">FSSAI registration for food service operations. GST registration for taxation compliance. Health Trade License for food safety. Liquor License for bar operations. These licenses require specific documentation and compliance infrastructure in your resort.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Regular health inspections required
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Liquor license renewal annually
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Land Selection & Development Strategy</h2>
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <h3 className="heading-md text-white mb-4">Location Selection</h3>
                  <p className="text-white/70">Choose locations with strategic advantages: beach proximity for water sports and scenic views, accessibility to major tourist attractions, connection to airport and town centers, and protection from monsoon/flooding. Avoid protected zones, mangroves, and restricted tourism areas that face regulatory challenges.</p>
                </div>
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <h3 className="heading-md text-white mb-4">Architecture & Design Excellence</h3>
                  <p className="text-white/70">Invest in distinctive architecture that reflects Goan heritage or modern luxury. Well-designed resorts command premium rates. Incorporate open spaces, water features, landscaping, and functional indoor-outdoor flow. Professional design reduces operational costs and enhances guest satisfaction and OTA ratings.</p>
                </div>
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <h3 className="heading-md text-white mb-4">Amenity Development</h3>
                  <p className="text-white/70">Differentiate through premium amenities: spa and wellness center, multiple dining options, recreational facilities (pool, water sports, adventure activities), conference spaces, and unique experiences. These amenities justify premium pricing and are key OTA selling points.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Luxury Positioning & OTA Strategy</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Premium Positioning</h3>
                  <p className="text-white/70 mb-4">Define your unique value proposition. Luxury resorts succeed through differentiation: exclusive beachfront access, heritage architecture, wellness focus, adventure activities, or culinary excellence. Premium positioning allows higher rates and attracts quality guests willing to pay for exceptional experiences.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">OTA Management</h3>
                  <p className="text-white/70 mb-4">Strong OTA presence drives bookings. Optimize listings on Booking.com, Agoda, Expedia with professional photography, accurate descriptions, and real-time availability. Implement revenue management to optimize pricing across channels. Maintain high response times and review ratings to improve algorithmic visibility.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Guest Experience Design</h3>
                  <p className="text-white/70 mb-4">Superior service quality drives repeat bookings and positive reviews. Train staff extensively, implement service standards, personalize guest interactions, and address feedback immediately. Exceptional experiences translate to high OTA ratings and organic word-of-mouth marketing.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Related Services</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <a href="/property-management-goa" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Property Management Goa</h3>
                  <p className="text-white/70 mb-4">End-to-end property management for resorts and hospitality properties in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/vision-mission" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Our Vision & Mission</h3>
                  <p className="text-white/70 mb-4">Learn about our approach to luxury hospitality and resort excellence in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/founders" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Meet Our Founders</h3>
                  <p className="text-white/70 mb-4">Discover the expertise behind successful resort launches in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Resort Business FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-64' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer" itemScope itemType="https://schema.org/Answer"><span itemProp="text">{faq.a}</span></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ready to Build Your Dream Resort in Goa?</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Let us guide you through the complete resort development process, from land selection to OTA optimization and guest experience excellence.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20start%20a%20resort%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="/" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
