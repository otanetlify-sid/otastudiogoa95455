import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What are the main licenses required to start a restaurant in Goa?', a: 'The primary licenses include FSSAI registration (Food Safety and Standards Authority of India), Fire Safety NOC from the Fire Department, Health Trade License from the Municipal Corporation, Shop and Establishment License, and GST registration. Additionally, you may need a Liquor License if serving alcohol, and approval from the Goa Directorate of Tourism.' },
  { q: 'How long does FSSAI registration take in Goa?', a: 'FSSAI registration typically takes 1-2 weeks for basic registration. However, the entire process including documentation, inspection, and approval can take 3-4 weeks. We recommend starting this process early as it\'s mandatory before you can legally operate.' },
  { q: 'What is the cost of setting up a restaurant in Goa?', a: 'Initial costs vary significantly based on location and scale. Budget for: commercial space rental deposit (₹1-5 lakhs), license approvals (₹20,000-50,000), kitchen equipment (₹2-10 lakhs), furniture and decor (₹2-8 lakhs), initial inventory (₹1-3 lakhs), and working capital (₹3-5 lakhs). Total: ₹10-31 lakhs minimum for a modest restaurant.' },
  { q: 'How important is location strategy for a Goa restaurant?', a: 'Location is critical. High-traffic areas near hotels, beaches, and tourist hotspots generate better foot traffic. Consider proximity to your target market (tourists vs locals), accessibility, parking availability, and visibility. Beach shacks and tourist corridor restaurants benefit from passing traffic, while locals-focused restaurants work in residential areas.' },
  { q: 'Should I get OTA activated for my restaurant?', a: 'Yes, registering on platforms like Swiggy, Zomato, and Google Maps is essential for restaurant discovery. These platforms drive significant bookings and reservations, especially in Goa\'s tourism-heavy market. OTA registration also builds credibility and online presence immediately.' },
  { q: 'What makes a restaurant menu successful in Goa?', a: 'Goa\'s tourist market demands diverse menus. Consider offering: authentic local Goan cuisine, North/South Indian options, international favorites, and dietary options (vegan/vegetarian). Pricing should align with your location (beach shacks can charge premium; local eateries must be competitive). Keep seasonal specials and limit the menu to manage operations efficiently.' },
];

export default function HowToStartRestaurantInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">How to Start a Restaurant in Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Restaurant Startup · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">How to Start a Restaurant in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Complete guide to launching a restaurant in Goa. Learn about licensing requirements, location strategy, menu planning, OTA activations, and proven marketing strategies for restaurant success in Goa's competitive tourism market.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20start%20a%20restaurant%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Restaurant Licensing in Goa</h2>
              <div className="grid md:grid-cols-2 gap-8">
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">FSSAI Registration</h3>
                  <p className="text-white/70 mb-4">Food Safety and Standards Authority of India registration is mandatory. You'll need: NOC from local municipal authority, kitchen layout plan, details of food handlers, and compliance with food safety standards. Processing takes 2-4 weeks.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Basic or State License depending on turnover
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Periodic food safety inspections
                    </li>
                  </ul>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Fire Safety NOC</h3>
                  <p className="text-white/70 mb-4">Fire Department approval ensures your kitchen and dining area meet safety standards. Requirements include proper fire extinguishers, emergency exits, kitchen ventilation, and fire suppression systems. Inspection typically takes 1-2 weeks.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Kitchen equipment inspection
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Exit and safety infrastructure verification
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Location Strategy & Market Positioning</h2>
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <h3 className="heading-md text-white mb-4">Tourist-Focused Locations</h3>
                  <p className="text-white/70">Beach shacks, areas near Fort Aguada, Panjim riverfront, and major hotel clusters attract transient tourists. These locations command premium pricing and benefit from passing foot traffic. Higher rent but consistent seasonal bookings.</p>
                </div>
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <h3 className="heading-md text-white mb-4">Local Residential Markets</h3>
                  <p className="text-white/70">Areas in Panjim, Margao, and residential neighborhoods serve local communities. Lower rent, but requires local marketing and loyalty programs. Success depends on food quality, value pricing, and word-of-mouth reputation.</p>
                </div>
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <h3 className="heading-md text-white mb-4">Menu Planning Strategy</h3>
                  <p className="text-white/70">Success requires catering to diverse tastes. Offer authentic Goan specialties alongside Indian staples and international favorites. Analyze competitor menus, understand your target demographic's preferences, implement seasonal specials, and maintain competitive pricing aligned with your location's market positioning.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">OTA Activation & Digital Marketing</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Swiggy & Zomato</h3>
                  <p className="text-white/70 mb-4">Registration on major food delivery platforms is essential. These platforms provide visibility to thousands of potential customers and handle logistics. Optimize your menu listing with high-quality photos, accurate descriptions, and competitive pricing to maximize orders.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Google My Business</h3>
                  <p className="text-white/70 mb-4">Google Maps visibility drives walk-in traffic and online reservations. Maintain accurate business information, respond promptly to reviews, add quality food photos, and encourage customer reviews to improve ranking and credibility in local search results.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Social Media Marketing</h3>
                  <p className="text-white/70 mb-4">Instagram and Facebook engagement drives brand awareness and repeat customers. Share food photography, behind-the-scenes content, daily specials, and customer testimonials. Engage with followers, run targeted ads to tourists and locals, and build community presence.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Related Services</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <a href="/property-management-goa" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Property Management Goa</h3>
                  <p className="text-white/70 mb-4">Complete property management solutions for hospitality businesses in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/vision-mission" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Our Vision & Mission</h3>
                  <p className="text-white/70 mb-4">Learn about our approach to hospitality growth and business excellence in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/founders" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Meet Our Founders</h3>
                  <p className="text-white/70 mb-4">Discover the expertise behind successful restaurant launches in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Restaurant Startup FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-64' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer" itemScope itemType="https://schema.org/Answer"><span itemProp="text">{faq.a}</span></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ready to Launch Your Restaurant in Goa?</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Let us guide you through licensing, OTA activation, and digital marketing to establish your restaurant successfully in Goa's thriving hospitality market.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20start%20a%20restaurant%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="/" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
