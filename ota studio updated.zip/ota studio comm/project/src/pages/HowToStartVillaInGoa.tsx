import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  {
    q: 'What makes a property suitable for villa rental business?',
    a: 'Ideal properties have private amenities (pool, garden), unique design, 3-6 bedrooms, separate living areas, and parking. Proximity to beaches or attractions adds value significantly.'
  },
  {
    q: 'How much revenue can a villa generate in Goa?',
    a: 'Premium villas earn ₹3,000-10,000+ per night. At 70-80% occupancy: ₹63-2,40,000/month. Peak season (Oct-Mar) generates 50-60% of annual revenue.'
  },
  {
    q: 'Which OTA platforms are best for villa rentals?',
    a: 'Airbnb, Booking.com, and Vrbo (Vacation Rental by Owner) are top platforms. Also list on Agoda, Expedia, and local platforms for maximum reach and bookings.'
  },
  {
    q: 'Do I need property management for my villa?',
    a: 'Professional management increases revenue by 20-30% through optimized pricing, guest communication, and maintenance. Essential if you cannot manage daily operations yourself.'
  },
  {
    q: 'How do I maintain high guest satisfaction for villa rentals?',
    a: 'Provide pristine condition, quality amenities, responsive communication, local recommendations, and small welcome touches. Target 4.8+ rating through consistent excellence.'
  },
  {
    q: 'What legal documents do villa rental hosts need?',
    a: 'Property ownership, GST registration, property tax clearance, insurance covering short-term rentals, and sometimes NOC from society/municipal authority. Consult local authorities.'
  }
];

export default function HowToStartVillaInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          {/* Hero Section */}
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white"><span itemProp="name">Home</span></a>
                    <meta itemProp="position" content="1" />
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white">
                    <span itemProp="name">How to Start Villa in Goa</span>
                    <meta itemProp="position" content="2" />
                  </li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Villa Business · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">How to Start a Villa in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Complete guide to launching a luxury villa rental business in Goa. Learn property selection, premium positioning, multi-OTA distribution, guest experience optimization,
                and revenue maximization strategies for high-end vacation rentals.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20start%20villa%20rental%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20a%20free%20OTA%20audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </div>

          {/* GrowthDashboard - Right after hero */}
          <GrowthDashboard />

          {/* Introduction Section */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Premium Villa Rental Opportunity in Goa</h2>
                <p className="body-md text-white/70 mb-6">
                  Goa's luxury vacation rental market is rapidly expanding with increasing demand for premium, private accommodations. High-net-worth individuals, corporate groups,
                  and luxury-seeking tourists seek villas for their exclusive amenities, privacy, and personalized experiences. Premium villas command ₹5,000-20,000+ per night,
                  with occupancy rates of 70-80% year-round when properly positioned.
                </p>
                <p className="body-md text-white/70 mb-6">
                  Modern villa rental businesses leverage multi-channel distribution through Airbnb, Booking.com, Vrbo, and other platforms to maximize bookings. With strategic pricing,
                  professional photography, and excellent guest experiences, villa owners can generate ₹30-100+ lakhs annually from a single property.
                </p>
              </div>
            </div>
          </section>

          {/* Step-by-Step Guide */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-12">Step-by-Step Guide to Starting Villa Rental Business</h2>
              <div className="max-w-3xl mx-auto space-y-8">
                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 1: Select Premium Property</h3>
                  <p className="text-white/70 mb-4">
                    Choose a property with luxury appeal and strong income potential. Ideal villas have 3-6 bedrooms, private pool, garden, parking, and proximity to
                    beaches or tourist attractions. Unique architecture and modern amenities command premium rates.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Assess location: beach proximity, attraction access, road connectivity</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Evaluate amenities: pool, garden, BBQ, WiFi, modern kitchen, AC</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Verify property condition and maintenance requirements</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Confirm ownership documents and clear titles</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 2: Luxury Staging and Furnishing</h3>
                  <p className="text-white/70 mb-4">
                    Invest in premium furniture, decor, and amenities that justify high nightly rates. Quality matters—luxury guests expect excellence. Incorporate local design
                    elements while maintaining modern comfort standards.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Purchase high-quality beds, linens, and bathroom amenities</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Install designer furniture and contemporary decor</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Add premium kitchen equipment and appliances</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Install smart home features (lighting, temperature, security)</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 3: Professional Photography and Videography</h3>
                  <p className="text-white/70 mb-4">
                    Invest heavily in professional photography. High-quality images are critical for premium properties. Include aerial drone shots, interior detail shots,
                    and lifestyle photography. Consider professional video tour.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Hire luxury property photographer with hotel experience</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Capture 40-60 high-resolution photos from multiple angles</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Include aerial drone photography of property and surroundings</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Create professional video tour showcasing amenities and views</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 4: Create Compelling Listings on Multiple Platforms</h3>
                  <p className="text-white/70 mb-4">
                    Develop unique, platform-optimized listings highlighting premium features and unique selling points. Use compelling language and emphasize exclusivity,
                    privacy, and luxury amenities to justify premium pricing.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Write engaging titles emphasizing luxury and location benefits</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Create detailed descriptions highlighting unique features</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>List all amenities with emphasis on premium and exclusive features</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Include local guides and attraction recommendations</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 5: Implement Dynamic Pricing Strategy</h3>
                  <p className="text-white/70 mb-4">
                    Price strategically based on season, local events, and competition. Premium villas with excellent reviews can command 2-3x rates during peak season.
                    Use dynamic pricing tools to optimize revenue.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Set base rates reflecting location and amenities premium</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Implement seasonal pricing (peak: Oct-Mar, mid: Apr-Jun, low: Jul-Sep)</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Adjust weekly for events and competition</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Offer discounts for weekly/monthly bookings</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 6: List on Multiple OTA Channels</h3>
                  <p className="text-white/70 mb-4">
                    Multi-channel distribution is essential. List on Airbnb, Booking.com, Vrbo, Agoda, Expedia, and local platforms to maximize exposure and bookings.
                    Use channel managers to synchronize availability and pricing.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Register on Airbnb, Booking.com, Vrbo primary platforms</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Add to secondary platforms: Agoda, Expedia, Trip.com</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Use channel manager tool for synchronized availability</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Create dedicated website with direct booking option</span>
                    </li>
                  </ul>
                </div>

                <div className="border-l-2 border-accent/30 pl-6">
                  <h3 className="heading-md text-white mb-3">Step 7: Deliver Exceptional Guest Experience</h3>
                  <p className="text-white/70 mb-4">
                    Premium guests expect flawless service. Provide welcome packages, responsive communication, housekeeping attention to detail, and personalized recommendations.
                    Exceed expectations to earn 5-star reviews and premium positioning.
                  </p>
                  <ul className="space-y-2 text-white/70">
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Provide welcome amenities (wine, fruits, local snacks)</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Respond to inquiries within 1 hour</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Provide curated local recommendations and activity bookings</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                      <span>Ensure spotless cleanliness and maintenance standards</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          {/* Legal Requirements */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Legal Requirements for Villa Rentals in Goa</h2>
                <p className="body-md text-white/70 mb-6">
                  Villa rental hosts must comply with legal requirements:
                </p>
                <ul className="space-y-3 text-white/70">
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Property Ownership:</strong> Clear ownership documents and title deed proving legal ownership or rental authorization.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">GST Registration:</strong> Mandatory for properties with nightly rates above ₹2,500 or annual turnover above ₹20 lakhs.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Property Tax:</strong> Maintain current property tax payments to municipal corporation.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Insurance:</strong> Obtain comprehensive property insurance covering short-term rentals and guest liability.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Society Approval:</strong> If in gated community, obtain NOC from society/apartment association for rental business.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Guest Registration:</strong> Maintain guest records including passport/ID copies for compliance.</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          {/* Investment Breakdown */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Investment Breakdown for Villa Rental Business</h2>
                <p className="body-md text-white/70 mb-6">
                  Assuming property is already owned. Costs for converting to rental:
                </p>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Premium furnishing & decor</span>
                    <span className="text-accent font-semibold">₹5 - 15 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Pool/amenity upgrades</span>
                    <span className="text-accent font-semibold">₹3 - 10 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Professional photography/video</span>
                    <span className="text-accent font-semibold">₹1 - 3 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Smart home & security systems</span>
                    <span className="text-accent font-semibold">₹1 - 3 lakhs</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Insurance & legal setup</span>
                    <span className="text-accent font-semibold">₹50,000 - 1 lakh</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-white/4 border border-white/8">
                    <span className="text-white">Marketing & launch</span>
                    <span className="text-accent font-semibold">₹50,000 - 1 lakh</span>
                  </div>
                  <div className="flex justify-between items-center p-4 rounded-lg bg-accent/10 border border-accent/20">
                    <span className="text-white font-semibold">Total Conversion Cost</span>
                    <span className="text-accent font-semibold">₹11 - 33 lakhs</span>
                  </div>
                </div>
                <p className="body-md text-white/70 mt-6">
                  Monthly costs: Staff (₹15,000-30,000), utilities (₹5,000-10,000), maintenance (₹3,000-5,000), housekeeping supplies (₹2,000-3,000).
                </p>
              </div>
            </div>
          </section>

          {/* Revenue Potential */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Revenue Potential</h2>
                <p className="body-md text-white/70 mb-6">
                  Premium villa rental revenue projections:
                </p>
                <div className="space-y-4 mb-6">
                  <div className="p-5 rounded-lg bg-white/4 border border-white/8">
                    <h4 className="text-white font-semibold mb-2">4-Bedroom Beachfront Villa (₹6,000-8,000/night)</h4>
                    <p className="text-white/70 text-sm">
                      At 75% occupancy: ₹1,35,000 - ₹1,80,000/month. Annual revenue: ₹16.2 - 21.6 lakhs (gross)
                    </p>
                  </div>
                  <div className="p-5 rounded-lg bg-white/4 border border-white/8">
                    <h4 className="text-white font-semibold mb-2">Luxury Villa (₹10,000-15,000/night)</h4>
                    <p className="text-white/70 text-sm">
                      At 75% occupancy: ₹2,25,000 - ₹3,37,500/month. Annual revenue: ₹27 - 40.5 lakhs (gross)
                    </p>
                  </div>
                  <div className="p-5 rounded-lg bg-white/4 border border-white/8">
                    <h4 className="text-white font-semibold mb-2">Ultra-Luxury Villa (₹20,000+/night)</h4>
                    <p className="text-white/70 text-sm">
                      At 70% occupancy: ₹4,20,000+/month. Annual revenue: ₹50+ lakhs (gross)
                    </p>
                  </div>
                </div>
                <p className="body-md text-white/70">
                  Peak season (Oct-Mar) generates 50-60% of annual revenue. After operating costs (25-35% of revenue), net profit margin: 40-50% annually.
                </p>
              </div>
            </div>
          </section>

          {/* Mistakes to Avoid */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Common Mistakes to Avoid</h2>
                <div className="space-y-4">
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Poor Photography Quality</h3>
                    <p className="text-white/70 text-sm">
                      Premium properties need exceptional photography. Poor photos limit inquiries and prevent premium pricing even if quality is excellent.
                    </p>
                  </div>
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Insufficient Amenities</h3>
                    <p className="text-white/70 text-sm">
                      Premium guests expect high-end amenities. Cheap furnishings or missing amenities lead to poor reviews and lower repeat bookings.
                    </p>
                  </div>
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Single Platform Listing</h3>
                    <p className="text-white/70 text-sm">
                      Relying on one OTA limits booking potential. Multi-channel distribution is essential for volume and revenue optimization.
                    </p>
                  </div>
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Neglecting Maintenance</h3>
                    <p className="text-white/70 text-sm">
                      Between-guest maintenance is critical for premium properties. Worn amenities or cleanliness issues destroy reputation quickly.
                    </p>
                  </div>
                  <div className="border-l-4 border-accent pl-4 py-2">
                    <h3 className="text-white font-semibold mb-1">Static Pricing</h3>
                    <p className="text-white/70 text-sm">
                      Failing to adjust prices seasonally leaves money on table. Dynamic pricing is essential for revenue maximization.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Expert Tips */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-lg text-white mb-6">Expert Tips for Villa Success</h2>
                <ul className="space-y-3 text-white/70">
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Premium Positioning:</strong> Emphasize uniqueness, privacy, and luxury to justify high rates and attract affluent guests.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Personalized Service:</strong> Small touches (welcome gifts, local guides, activity bookings) create memorable experiences and 5-star reviews.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Leverage Reviews:</strong> Encourage reviews through excellent service and follow-up. 4.9+ rating enables premium positioning.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Professional Management:</strong> Consider hiring professional property management for higher revenue and reduced stress.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Unique Experiences:</strong> Offer curated experiences (yoga, cooking classes, tours) to command premium rates and enhance revenue.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                    <span><strong className="text-white">Regular Updates:</strong> Refresh furnishings and amenities annually to maintain luxury positioning and guest satisfaction.</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          {/* Related Services */}
          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Related Services</h2>
              <div className="grid sm:grid-cols-3 gap-6 max-w-3xl mx-auto">
                <a href="/property-management-goa" className="p-6 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all text-center">
                  <h3 className="font-display font-bold text-lg text-white mb-2">Property Management</h3>
                  <p className="text-sm text-white/50">Professional management for your Goa properties</p>
                </a>
                <a href="/vision-mission" className="p-6 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all text-center">
                  <h3 className="font-display font-bold text-lg text-white mb-2">Our Vision</h3>
                  <p className="text-sm text-white/50">Learn about OTA Studio's hospitality mission</p>
                </a>
                <a href="/founders" className="p-6 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all text-center">
                  <h3 className="font-display font-bold text-lg text-white mb-2">Meet Our Team</h3>
                  <p className="text-sm text-white/50">Hospitality experts with 50+ years experience</p>
                </a>
              </div>
            </div>
          </section>

          {/* FAQs */}
          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Frequently Asked Questions</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} itemScope itemType="https://schema.org/Question" className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span itemProp="name" className="font-display font-bold text-white pr-4">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div itemScope itemType="https://schema.org/Answer" className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div itemProp="text" className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* CTA Section */}
          <section className="bg-neutral-950 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ready to Launch Your Luxury Villa Rental?</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Get expert guidance on positioning, pricing, and multi-channel distribution for maximum bookings and revenue.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20start%20villa%20rental%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20a%20free%20OTA%20audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
