import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What is the difference between a wellness retreat and a yoga retreat?', a: 'Yoga retreats focus on yoga practice and teacher instruction. Wellness retreats encompass yoga, meditation, spa, nutrition, fitness, and holistic wellness. Both formats are profitable in Goa with strong demand from wellness tourists.' },
  { q: 'What investment is needed for a wellness retreat center?', a: 'Budget ₹20-50 lakhs for property, studio setup, equipment, and permits. Premium retreat centers with spa services run ₹50+ lakhs. 12-18 month ROI with proper marketing and operations.' },
  { q: 'How do I find and manage wellness practitioners?', a: 'Partner with certified yoga instructors, massage therapists, nutritionists, and wellness coaches. Build relationships with local practitioners. Quality instructors are essential for reputation and word-of-mouth growth.' },
  { q: 'What pricing can wellness retreats command?', a: 'Budget retreats: ₹20,000-30,000 per person. Mid-range: ₹30,000-75,000. Premium: ₹75,000-2,00,000+. International tourists spend 3-5x more than domestic guests on wellness experiences.' },
  { q: 'Can a wellness retreat generate year-round revenue?', a: 'Yes. Peak season (Oct-March) runs at 80%+ occupancy. Off-season can maintain 50%+ through workshops, local classes, and corporate wellness programs. Diversified revenue streams ensure consistency.' },
];

const steps = [
  'Secure suitable property with peaceful ambiance',
  'Design retreat studios and therapy spaces',
  'Build accommodations for guests',
  'Partner with wellness practitioners',
  'Obtain necessary licenses and insurance',
  'Create compelling retreat packages',
  'Build marketing and booking system',
  'Launch and scale operations',
];

export default function HowToStartWellnessRetreatInGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li><span itemProp="name">How to Start a Wellness Retreat in Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Wellness Retreat · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">How to Start a Wellness Retreat in Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Establish a thriving wellness retreat center in Goa. Learn how to design transformative programs, partner with practitioners, market to wellness tourists, and build a sustainable business around health and wellbeing.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20start%20a%20wellness%20retreat%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Consultation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">Wellness Retreat Setup Steps</h2>
                  <ol className="space-y-4">
                    {steps.map((step, i) => (
                      <li key={i} className="flex items-start gap-4">
                        <span className="flex items-center justify-center w-8 h-8 rounded-full bg-accent/20 text-accent font-display font-bold shrink-0">{i + 1}</span>
                        <span className="text-white/70 pt-0.5">{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
                <div className="space-y-6">
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Essential Services</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Yoga and meditation classes</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Massage and spa therapies</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Nutritional counseling</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Healthy meal service</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">Comfortable accommodations</span>
                      </li>
                    </ul>
                  </div>
                  <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                    <h3 className="font-display font-bold text-xl text-white mb-4">Revenue Potential</h3>
                    <div className="space-y-2 text-white/70 text-sm">
                      <p><span className="text-accent font-semibold">5-room center (25 capacity):</span> ₹15-30 lakhs/year</p>
                      <p><span className="text-accent font-semibold">10-room center (50 capacity):</span> ₹30-75 lakhs/year</p>
                      <p><span className="text-accent font-semibold">Full occupancy at premium rates:</span> ₹75+ lakhs/year</p>
                      <p><span className="text-accent font-semibold">Profit margin:</span> 50-65%</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-6">Program Design & Operations</h2>
              <div className="grid md:grid-cols-2 gap-8 mb-12">
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Retreat Program Design</h3>
                  <p className="text-white/70 mb-4">Curate programs addressing specific wellness goals: stress relief, weight loss, fitness, nutrition, spiritual growth. Specialized programs attract target audiences and justify premium pricing. Customized programs increase satisfaction 40-50%.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Practitioner Network</h3>
                  <p className="text-white/70 mb-4">Build quality network of certified instructors, therapists, and coaches. Relationships with quality practitioners are your key differentiator. Word-of-mouth from practitioners generates 30-50% of new bookings.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Guest Experience</h3>
                  <p className="text-white/70 mb-4">Peaceful ambiance, healthy organic meals, expert instruction, and personal attention create transformation. Guests experiencing transformation book again (repeat rate 40%+) and refer friends (average 5+ referrals).</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white mb-4">Marketing Strategy</h3>
                  <p className="text-white/70 mb-4">Target wellness communities, health-conscious travelers, corporate wellness programs. Instagram, wellness blogs, and OTA channels reach ideal customers. Influencer partnerships amplify reach 5-10x.</p>
                </div>
              </div>
              <div className="p-8 rounded-2xl bg-neutral-900 border border-white/8">
                <h3 className="font-display font-bold text-xl text-white mb-4">Common Mistakes to Avoid</h3>
                <ul className="grid md:grid-cols-2 gap-4">
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Poor practitioner quality</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Inadequate meal quality</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Uncomfortable accommodations</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Overbooked retreats</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Poor marketing and customer acquisition</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent font-bold">•</span>
                    <span className="text-white/70">Not building alumni community</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Expert Tips for Success</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Transformation Focus</h3>
                  <p className="text-white/70">Design programs showing measurable transformation. Guests seeking transformation spend 3-5x more than casual tourists. Transformation stories are your best marketing.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Community Building</h3>
                  <p className="text-white/70">Keep alumni engaged through communities, events, and exclusive content. Engaged alumni generate 50%+ repeat bookings and 5+ referrals each. Lifetime value increases 10x with community.</p>
                </div>
                <div className="p-6 rounded-xl border border-white/8 bg-neutral-950">
                  <h3 className="font-display font-bold text-accent mb-3">Premium Quality</h3>
                  <p className="text-white/70">Quality never compromises. Wellness tourists pay premium rates for quality experiences. Invest in best practitioners, healthiest food, and most comfortable accommodations.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Frequently Asked Questions</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="text">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`} itemScope itemType="https://schema.org/Answer">
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="text">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-4">Related Services</h2>
              <p className="text-center text-white/50 mb-8">Explore more ways to grow your hospitality business</p>
              <div className="grid md:grid-cols-3 gap-6">
                <a href="/property-management-goa" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Property Management</h3>
                  <p className="text-white/50 text-sm">Comprehensive management for your Goa properties</p>
                </a>
                <a href="/vision-mission" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Our Vision & Mission</h3>
                  <p className="text-white/50 text-sm">Understand our commitment to Goa's hospitality</p>
                </a>
                <a href="/founders" className="p-6 rounded-xl border border-white/8 bg-white/4 hover:bg-white/6 transition-colors">
                  <h3 className="font-display font-bold text-white mb-2">Meet Our Founders</h3>
                  <p className="text-white/50 text-sm">Learn from our hospitality industry experts</p>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Start Your Wellness Retreat</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">OTA Studio helps you launch and scale a profitable wellness retreat center that transforms lives and generates sustainable revenue.</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Consultation</a>
                <a href="#" className="btn-secondary">Get Free OTA Audit</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
