import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Music } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'How do you organize live music events at venues?', a: 'We handle complete event coordination: artist booking, technical setup, sound/lighting, promotion, and execution. You focus on hospitality while we manage the event logistics.' },
  { q: 'What types of live music draw crowds in Goa?', a: 'Acoustic performances, jazz, blues, indie rock, folk, and contemporary Indian music resonate well. Genre selection depends on your venue vibe and target audience.' },
  { q: 'How do you find quality musicians in Goa?', a: 'Our artist network includes verified musicians across genres. We audition and curate talent to match your venue aesthetic and ensure professional events.' },
  { q: 'Can live music events increase venue revenue?', a: 'Yes. Live music nights typically increase covers by 30-50%, average bill by 25-40%, and create repeat customer loyalty. Regular live music is an investment that pays itself.' },
  { q: 'How do you promote live music events?', a: 'Social media teasers featuring the artist, Google Business and Zomato optimization, WhatsApp communities, email marketing, and influencer outreach drive attendance.' },
  { q: 'What is involved in technical setup for live music?', a: 'Sound systems, lighting design, microphones, monitors, and acoustics. We manage all technical requirements so artists perform professionally and guests enjoy the experience.' },
];

const services = [
  'Live musician and artist booking',
  'Event planning and coordination',
  'Sound and lighting technical setup',
  'Venue acoustics consultation',
  'Artist roster management',
  'Event promotion and marketing',
  'Guest experience coordination',
  'Post-event analysis and reporting',
];

const musicGenres = [
  'Acoustic performances',
  'Jazz and blues',
  'Indie and alternative rock',
  'Folk and world music',
  'Contemporary Indian',
  'Electronic live sets',
  'Soul and funk',
  'Collaborative jam sessions',
];

export default function LiveMusicEventsGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Live Music Events Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Live Music · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Live Music Events Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Live music event organization at Goa hospitality venues. Artist booking, technical coordination, and promotion for memorable events that drive crowds and revenue.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20host%20live%20music%20events" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Book Live Music <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20to%20plan%20an%20event" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Plan An Event
                </a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What We Deliver</h2>
                  <p className="body-md mb-8">Complete live music event service from artist booking to execution.</p>
                  <ul className="space-y-3">
                    {services.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Music size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Music Genres</h3>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {musicGenres.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-white/70">
                        <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                        {item}
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '40%', label: 'Guest Increase' },
                      { metric: '35%', label: 'Revenue Boost' },
                      { metric: '50+', label: 'Artists Booked' },
                      { metric: '95%', label: 'Satisfaction' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-8">Live Music Event Process</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Artist Curation</h3>
                  <p className="text-white/70 text-sm">We match musicians with your venue vibe and audience. Each artist is vetted for professionalism and crowd appeal.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Technical Excellence</h3>
                  <p className="text-white/70 text-sm">Professional sound systems, lighting design, and acoustics optimization ensure memorable performances for every guest.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Promotion & Execution</h3>
                  <p className="text-white/70 text-sm">We promote events across social media, email, and WhatsApp, and coordinate all logistics for seamless execution.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Live Music Events FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Create Memorable Live Music Experiences</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Professional artist booking and event coordination for consistent crowds and happy guests.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Book Live Music</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
