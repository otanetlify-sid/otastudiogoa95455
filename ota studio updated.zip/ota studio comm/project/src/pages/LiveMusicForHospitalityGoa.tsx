import { useState } from 'react';
import { ChevronDown, Music, Headphones, Volume2, Radio } from 'lucide-react';
import PageLayout from '../components/PageLayout';
import Breadcrumbs from '../components/Breadcrumbs';

const faqs = [
  {
    q: 'How does live music increase hospitality bookings?',
    a: 'Live music creates destination experiences that attract guests seeking memorable dining and entertainment. Hotels and restaurants with regular live music see higher occupancy rates, longer guest stays, higher check averages, and strong word-of-mouth marketing. Guests return specifically for the music experience.',
  },
  {
    q: 'What types of live music work best for hospitality venues in Goa?',
    a: 'The best genres depend on your venue and target audience. Acoustic sets, jazz, world music, reggae, Bollywood, electronic/DJ nights, and cultural performances all thrive in Goa. We recommend starting with genres that align with your guest profile.',
  },
  {
    q: 'How often should hospitality venues host live music?',
    a: 'Weekly performances build audience loyalty and anticipation. Many venues start with 1-2 nights per week and expand based on demand. Some run daily performances during peak seasons. Consistency matters more than frequency.',
  },
  {
    q: 'Can we host live music with limited space or budget?',
    a: 'Absolutely. Solo musicians and acoustic duos work beautifully in smaller venues and cost significantly less than full bands. We help optimize the experience within your budget and space constraints.',
  },
  {
    q: 'What technical setup does live music require?',
    a: 'Depending on the artist and venue, you may need sound systems, microphones, instruments, stage lighting, and technical support. We manage all technical requirements and coordinate with audio professionals.',
  },
  {
    q: 'How do you find and book quality musicians in Goa?',
    a: 'We have established relationships with top musicians, artists, and bands across genres in Goa. We audition, negotiate rates, handle contracts, and manage all logistics so your venue hosts consistent, high-quality performances.',
  },
];

const services = [
  {
    icon: Music,
    title: 'Artist Booking & Curation',
    desc: 'We connect you with talented musicians across genres—from solo acoustics to full bands. Every artist is curated for quality and fit with your venue brand and guest profile.',
    features: [
      'Extensive artist network',
      'Quality vetting process',
      'Genre variety',
      'Contract management',
    ],
  },
  {
    icon: Volume2,
    title: 'Technical Setup & Sound Engineering',
    desc: 'Professional sound systems, microphones, instruments, staging, and technical support. We handle all logistics so your venue sounds incredible every night.',
    features: [
      'Sound system setup',
      'Audio engineering',
      'Stage lighting design',
      'Technical support',
    ],
  },
  {
    icon: Headphones,
    title: 'Event Programming & Scheduling',
    desc: 'Designing recurring music programming that builds audience loyalty. We manage artist rotation, scheduling, and promotion for consistent, packed performances.',
    features: [
      'Event calendar design',
      'Artist rotation planning',
      'Genre programming strategy',
      'Seasonal scheduling',
    ],
  },
  {
    icon: Radio,
    title: 'Promotion & Audience Building',
    desc: 'Strategic marketing to build a regular music audience. Social media, email, partnerships, and word-of-mouth drive attendance and create buzz around your music programming.',
    features: [
      'Social media promotion',
      'Email campaigns',
      'Partnership outreach',
      'Community building',
    ],
  },
];

export default function LiveMusicForHospitalityGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <PageLayout
      title="Live Music for Hospitality Businesses in Goa | Venue Music Programming | The OTA Studio"
      description="Live music programming for hospitality businesses in Goa. Artist booking, genre curation, technical setup and recurring event strategies for hotels, cafes and restaurants."
      canonical="https://otastudio.in/live-music-for-hospitality-goa"
      schemaType="community"
    >
      <article>
        <div className="bg-neutral-950 pt-16 pb-20 sm:pt-20 sm:pb-28 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <div className="text-white/50 pb-2">
              <Breadcrumbs crumbs={[{ label: 'Community' }, { label: 'Live Music for Hospitality' }]} />
            </div>
            <div className="max-w-3xl">
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Community Events · Goa</span>
              <h1 className="heading-xl text-white mb-6">
                Live Music for <br className="hidden sm:block" />
                <span className="text-accent">Hospitality in Goa</span>
              </h1>
              <p className="text-base sm:text-xl text-white/70 leading-relaxed mb-8">
                Turn your hotel, restaurant, or cafe into a music destination. The OTA Studio books,
                manages, and promotes live music programming that fills seats, creates memorable
                experiences, and drives repeat bookings through the power of great live performances.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20live%20music%20for%20my%20venue"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary"
                >
                  Start Your Music Programming
                </a>
                <a
                  href="https://wa.me/919309706263?text=Tell%20me%20about%20live%20music%20strategy"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-secondary"
                >
                  Get Music Strategy Consult
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="section-max section-padding py-16 sm:py-20 bg-neutral-900">
          <h2 className="heading-lg text-center text-white mb-12">
            Live Music Services for Hospitality Venues
          </h2>
          <div className="grid sm:grid-cols-2 gap-6">
            {services.map((service, i) => (
              <div
                key={i}
                className="p-7 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/7 hover:shadow-[0_0_20px_rgba(255,208,0,0.05)] hover:-translate-y-1 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-5">
                  <service.icon size={22} className="text-accent" />
                </div>
                <h3 className="font-display font-bold text-xl text-white mb-3">{service.title}</h3>
                <p className="text-sm text-white/50 leading-relaxed mb-5">{service.desc}</p>
                <div className="flex flex-wrap gap-2">
                  {service.features.map((feature, j) => (
                    <span
                      key={j}
                      className="px-3 py-1 rounded-full bg-white/8 border border-white/8 text-xs font-medium text-white/60"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-neutral-950 py-16 sm:py-20 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="heading-lg text-white mb-6">
                  How We Build Your Music Program
                </h2>
                <div className="space-y-4">
                  {[
                    { num: '1', title: 'Venue Assessment', desc: 'We evaluate your space, acoustics, capacity, and target audience to design optimal music programming.' },
                    { num: '2', title: 'Genre & Artist Selection', desc: 'Curating artists and genres that align with your brand, guest profile, and business goals.' },
                    { num: '3', title: 'Artist Booking & Contracts', desc: 'Managing all artist recruitment, negotiations, contracts, and rate agreements.' },
                    { num: '4', title: 'Technical Setup', desc: 'Installing and optimizing sound systems, staging, and technical infrastructure for great sound.' },
                    { num: '5', title: 'Promotion & Marketing', desc: 'Building audience awareness through social media, email, partnerships, and word-of-mouth.' },
                    { num: '6', title: 'Ongoing Management', desc: 'Monitoring performance, gathering feedback, rotating artists, and optimizing your music schedule.' },
                  ].map((step, i) => (
                    <div key={i} className="flex items-start gap-4">
                      <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center shrink-0">
                        <span className="font-display font-bold text-sm text-accent">{step.num}</span>
                      </div>
                      <div>
                        <div className="font-display font-bold text-white text-sm">{step.title}</div>
                        <div className="text-xs text-white/40 mt-0.5">{step.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div className="p-7 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white text-xl mb-6">
                    Music Genres We Offer
                  </h3>
                  <ul className="space-y-3">
                    {[
                      'Acoustic and folk music',
                      'Jazz and blues',
                      'World and reggae',
                      'Bollywood and Indian classical',
                      'Electronic and DJ sets',
                      'Rock and alternative',
                      'Soul and R&B',
                      'Indie and indie-folk',
                      'Latin and bossa nova',
                      'Cultural and traditional performances',
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 shrink-0" />
                        <span className="text-sm text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-neutral-900 py-16 sm:py-20 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-30" />
          <div className="section-max section-padding relative">
            <h2 className="heading-lg text-center text-white mb-12">
              Live Music FAQs — Goa Hospitality
            </h2>
            <div className="max-w-3xl mx-auto space-y-3">
              {faqs.map((faq, i) => (
                <div
                  key={i}
                  className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden"
                >
                  <button
                    onClick={() => setOpenIdx(openIdx === i ? null : i)}
                    className="w-full flex items-center justify-between p-5 sm:p-6 text-left"
                    aria-expanded={openIdx === i}
                  >
                    <span className="font-display font-bold text-base sm:text-lg text-white pr-4">
                      {faq.q}
                    </span>
                    <ChevronDown
                      size={20}
                      className={`shrink-0 text-white/40 transition-transform duration-300 ${
                        openIdx === i ? 'rotate-180 text-accent' : ''
                      }`}
                    />
                  </button>
                  <div
                    className={`overflow-hidden transition-all duration-300 ${
                      openIdx === i ? 'max-h-48' : 'max-h-0'
                    }`}
                  >
                    <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-sm sm:text-base text-white/50 leading-relaxed">
                      {faq.a}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-neutral-950 py-16 sm:py-20 text-center relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <h2 className="heading-lg text-white mb-4">
              Make Your Venue a Music Destination
            </h2>
            <p className="text-white/50 mb-8 max-w-xl mx-auto">
              Let The OTA Studio bring live music to your hotel, restaurant, or cafe. Build audience
              loyalty, increase bookings, and create unforgettable experiences through quality music programming.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <a
                href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20live%20music%20for%20my%20venue"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
              >
                Start Your Music Programming
              </a>
              <a href="/" className="btn-secondary">
                Back to Home
              </a>
            </div>
          </div>
        </div>
      </article>
    </PageLayout>
  );
}
