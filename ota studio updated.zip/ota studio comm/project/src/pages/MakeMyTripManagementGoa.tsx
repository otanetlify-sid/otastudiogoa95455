import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, TrendingUp, BarChart3, Compass } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'Why should Goa properties focus on MakeMyTrip?', a: 'MakeMyTrip is India\'s largest OTA and controls 30%+ of domestic online bookings. For Goa properties targeting Indian travelers, a strong MakeMyTrip presence is essential for capturing high-volume domestic bookings.' },
  { q: 'How do you optimize MakeMyTrip listings for Indian travelers?', a: 'We tailor listings specifically for Indian guest preferences, including payment methods, pricing displays, local language descriptions, and highlighting features that appeal to domestic travelers like multi-family accommodations and Indian cuisine availability.' },
  { q: 'What is rate parity and why does it matter?', a: 'Rate parity means maintaining consistent pricing across all OTAs. MakeMyTrip closely monitors competitor rates, and maintaining fair pricing prevents commission issues while maximizing bookings without conflicting with other channels.' },
  { q: 'How long before I see domestic booking growth?', a: 'Most properties see increased MakeMyTrip bookings within 2-4 weeks of optimization. Domestic travelers book more frequently than international guests, so improvement timelines are typically faster than other OTAs.' },
  { q: 'Does MakeMyTrip handle corporate bookings?', a: 'Yes, MakeMyTrip has a strong corporate travel segment. We optimize for both leisure and corporate bookings, helping you capture this lucrative business segment for higher average room rates.' },
  { q: 'Can you improve my cancellation and refund policies?', a: 'We review and optimize your cancellation policies to be competitive while protecting your revenue. Flexible policies attract more Indian travelers who prefer last-minute booking options.' },
];

const includes = [
  'MakeMyTrip listing optimization for domestic market',
  'Rate parity management across OTAs',
  'Professional photography and content optimization',
  'Indian guest preference-focused descriptions',
  'Corporate travel and bulk booking management',
  'Payment method optimization',
  'Cancellation policy review and optimization',
  'Weekly performance monitoring and reporting',
];

export default function MakeMyTripManagementGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">MakeMyTrip Management Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">MakeMyTrip Management · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">MakeMyTrip Management Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Specialized MakeMyTrip management for Goa properties targeting domestic Indian travelers. We optimize listings, manage rates strategically,
                and capture the high-volume Indian travel market to maximize bookings and revenue.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20MakeMyTrip%20management%20for%20my%20Goa%20property" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Grow Domestic Bookings <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">MakeMyTrip Management Includes</h2>
                  <p className="body-md text-white/70 mb-8">Complete MakeMyTrip optimization tailored for the Indian domestic travel market.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <h3 className="font-display font-bold text-xl text-white mb-6">Results We Deliver</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '320%', label: 'Domestic Booking Growth' },
                      { metric: '40%+', label: 'Revenue from Domestic' },
                      { metric: '4.6+', label: 'Average Rating Score' },
                      { metric: '80+', label: 'Properties Optimized' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid md:grid-cols-3 gap-8 mb-16">
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <BarChart3 size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Revenue Optimization</h3>
                  <p className="text-white/70 mb-4">Indian travelers are price-sensitive but willing to pay for quality. We set optimal pricing that captures high-volume bookings from domestic guests while maximizing average daily rates during peak seasons.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Domestic price optimization
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Festival season rate management
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Corporate rate packages
                    </li>
                  </ul>
                </div>

                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <Compass size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Listing Optimization</h3>
                  <p className="text-white/70 mb-4">We optimize listings specifically for Indian travelers, highlighting features they value most: family-friendly amenities, Indian cuisine, payment flexibility, and domestic travel preferences.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Indian preference localization
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Multi-room family packages
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Payment method highlighting
                    </li>
                  </ul>
                </div>

                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <TrendingUp size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Ranking Improvement</h3>
                  <p className="text-white/70 mb-4">MakeMyTrip's algorithm prioritizes booking volume and guest ratings. We boost both by ensuring high visibility, fast response times, and exceptional guest experiences that lead to positive reviews and repeat bookings.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Guest rating optimization
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Booking conversion enhancement
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Top position search placement
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Benefits for Goa Hotels</h2>
              <div className="grid md:grid-cols-2 gap-8">
                {[
                  'Access to 500+ million Indian travelers searching on MakeMyTrip',
                  'Capture high-volume domestic bookings that typically have higher frequency',
                  'Understand and serve Indian guest preferences for higher satisfaction',
                  'Leverage corporate travel packages for consistent business bookings',
                  'Festival season optimization to capture peak domestic travel periods',
                  'Quick booking turnaround with domestic travelers (often same/next week)',
                  'Build reputation through domestic guest reviews and repeat bookings',
                  'Rate optimization that captures volume while protecting margins',
                ].map((benefit, i) => (
                  <div key={i} className="flex items-start gap-4 p-6 rounded-xl border border-white/8 bg-white/4">
                    <CheckCircle2 size={24} className="text-accent mt-1 shrink-0" />
                    <p className="text-white/70">{benefit}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Why Choose Us for MakeMyTrip?</h2>
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Domestic Market Expertise</h3>
                  <p className="text-white/70">We specialize in the Indian domestic travel market, understanding guest preferences, seasonality patterns, and cultural nuances that drive bookings from Indian travelers.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">MakeMyTrip Platform Excellence</h3>
                  <p className="text-white/70">Our team has deep expertise in MakeMyTrip's algorithm, ranking factors, and optimization techniques specific to this platform. We know exactly how to get properties to the top positions.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Proven Domestic Booking Growth</h3>
                  <p className="text-white/70">80+ Goa properties have increased their domestic bookings by 300%+ through our MakeMyTrip optimization strategies. Our methods are proven and effective.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Related Services</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <a href="/property-management-goa" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Property Management Goa</h3>
                  <p className="text-white/70 mb-4">Complete property management including OTA management, operations, and revenue optimization.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/vision-mission" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Our Vision & Mission</h3>
                  <p className="text-white/70 mb-4">Learn about our approach to hospitality growth and property management excellence in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/founders" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Meet Our Founders</h3>
                  <p className="text-white/70 mb-4">Discover the team behind successful MakeMyTrip management strategies for Goa properties.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">MakeMyTrip Management FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-64' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ready to Capture More Domestic Bookings?</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Let's optimize your MakeMyTrip presence and tap into India's largest OTA platform for consistent domestic bookings.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20MakeMyTrip%20management%20for%20my%20property" target="_blank" rel="noopener noreferrer" className="btn-primary">Start Growing Domestic Bookings</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
