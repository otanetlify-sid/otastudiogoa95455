import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Music } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What is nightlife growth service?', a: 'We help bars and clubs build thriving nightlife businesses through music programming, event curation, and community activations. We drive consistent crowds through digital visibility and experiential events.' },
  { q: 'How do you program nightlife events?', a: 'We curate DJ lineups, live music performances, themed parties, and special events that appeal to your target audience. Programming is data-driven and venue-specific.' },
  { q: 'What role does music play in nightlife growth?', a: 'Music is central to nightlife. Quality DJ sets and live music performances create reasons for people to visit regularly and become predictable revenue drivers.' },
  { q: 'How do you build nightlife audience loyalty?', a: 'Through consistent, quality events that people anticipate. Recurring DJ nights, themed parties, and member perks create loyalty and word-of-mouth promotion.' },
  { q: 'Can nightlife businesses be profitable year-round?', a: 'Yes. Strategic programming, community focus, and digital visibility create consistent customer flow even during off-seasons.' },
  { q: 'How do you promote nightlife events effectively?', a: 'Social media campaigns, WhatsApp communities, influencer partnerships, Google Business optimization, and Zomato visibility drive event attendance.' },
];

const services = [
  'Nightlife business strategy and positioning',
  'Music programming and DJ curation',
  'Live performance booking and coordination',
  'Event design and themed party creation',
  'Digital marketing and social promotion',
  'Community building for nightlife audiences',
  'Venue optimization for events',
  'Revenue and attendance tracking',
];

const eventTypes = [
  'Electronic DJ nights',
  'Live band performances',
  'Themed dance parties',
  'Open-format DJ nights',
  'Music festival activations',
  'Artist collaborations',
  'Seasonal parties',
  'Member-exclusive nights',
];

export default function NightlifeGrowthGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Nightlife Growth Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Nightlife Growth · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Nightlife Growth Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Build thriving nightlife businesses through music programming, DJ curation, and community activations. Consistent crowds, event-driven revenue, and loyal audiences.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20grow%20my%20nightlife%20business" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Grow Nightlife <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20a%20Venue%20Audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Get A Venue Audit
                </a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What We Deliver</h2>
                  <p className="body-md mb-8">Complete nightlife growth service for consistent crowds and revenue.</p>
                  <ul className="space-y-3">
                    {services.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Music size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Event Types</h3>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {eventTypes.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-white/70">
                        <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                        {item}
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '2.5x', label: 'Revenue Increase' },
                      { metric: '75%', label: 'Weekend Growth' },
                      { metric: '30+', label: 'DJs Booked' },
                      { metric: '85%', label: 'Repeat Audience' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-8">Nightlife Growth Strategy</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Music Curation</h3>
                  <p className="text-white/70 text-sm">Strategic DJ and live music programming that creates signature events and builds anticipation among your audience.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Artist Network</h3>
                  <p className="text-white/70 text-sm">Access to verified DJs, musicians, and performers across Goa. We handle all bookings and coordination for quality events.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Audience Building</h3>
                  <p className="text-white/70 text-sm">Create loyal audiences through consistent programming, community engagement, and memorable experiences.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Nightlife Growth FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Build A Thriving Nightlife Business</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Strategic music programming and community activations drive consistent crowds and revenue growth.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Grow Nightlife</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
