import { Hop as Home, MessageCircle, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20 flex items-center justify-center">
        <div className="section-max section-padding py-20 sm:py-32 text-center relative">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="max-w-xl mx-auto relative">
            <div className="font-display font-extrabold text-8xl sm:text-9xl text-accent/20 mb-6 leading-none">404</div>
            <h1 className="font-display font-bold text-2xl sm:text-3xl md:text-4xl text-white mb-4">This Page Doesn't Exist</h1>
            <p className="text-base sm:text-lg text-white/50 leading-relaxed mb-10 max-w-md mx-auto">
              The page you're looking for has moved, been removed, or never existed.
            </p>

            <div className="flex flex-col sm:flex-row gap-3 justify-center mb-12">
              <a href="/" className="btn-primary"><Home size={18} /> Return Home</a>
              <a href="https://wa.me/919270598602" target="_blank" rel="noopener noreferrer" className="btn-secondary"><MessageCircle size={18} /> Contact Us</a>
            </div>

            <div className="border-t border-white/8 pt-10">
              <p className="text-sm text-white/40 mb-5">Looking for one of these?</p>
              <div className="grid sm:grid-cols-2 gap-3 max-w-sm mx-auto">
                {[
                  { label: 'OTA Management Goa', href: '/ota-management-goa' },
                  { label: 'OTA Onboarding Goa', href: '/ota-onboarding-goa' },
                  { label: 'Airbnb Management Goa', href: '/airbnb-management-goa' },
                  { label: 'Hotel Distribution Goa', href: '/hotel-distribution-goa' },
                ].map((link, i) => (
                  <a key={i} href={link.href} className="flex items-center justify-between p-4 rounded-xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-accent/5 transition-all group">
                    <span className="text-sm font-medium text-white/70 group-hover:text-white">{link.label}</span>
                    <ArrowRight size={14} className="text-white/30 group-hover:text-accent transition-colors" />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
