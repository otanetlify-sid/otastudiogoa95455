import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'What does OTA management include?', a: 'OTA management includes listing optimization, rate management, content updates, photo strategy, review responses, distribution across platforms, and performance reporting.' },
  { q: 'Which OTAs do you manage?', a: 'We manage all major OTAs including Booking.com, Airbnb, Agoda, Expedia, MakeMyTrip, Goibibo, Hostelworld, and Trip.com.' },
  { q: 'How long before I see results?', a: 'Most properties see improved search rankings within 2-4 weeks. Booking improvements typically follow within 30-60 days.' },
  { q: 'What types of properties do you manage?', a: 'We manage hotels, resorts, hostels, villas, Airbnb properties, boutique hotels, homestays, and vacation rentals.' },
];

const includes = [
  'Complete OTA profile audit and optimization', 'Listing content rewrite and SEO enhancement',
  'Professional photo sequencing strategy', 'Dynamic pricing and rate management',
  'Channel manager setup and sync', 'Distribution across 8+ OTA platforms',
  'Review response and reputation management', 'Monthly performance reports',
];

export default function OtaManagementGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white" itemProp="name">OTA Management Goa</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">OTA Management · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">OTA Management Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Professional OTA management service for hotels, hostels, villas, homestays, and resorts across Goa.
                We optimize, manage, and grow your presence on every major booking platform.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20OTA%20management%20for%20my%20Goa%20property" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Start Growing Your Bookings <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%27d%20like%20a%20Property%20Growth%20Audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Get A Property Growth Audit
                </a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What OTA Management Includes</h2>
                  <p className="body-md mb-8">Complete OTA management for maximum visibility and bookings.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <h3 className="font-display font-bold text-xl text-white mb-6">Results We Deliver</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '3x', label: 'Average Booking Increase' },
                      { metric: '340%', label: 'Visibility Improvement' },
                      { metric: '2.8x', label: 'Revenue Growth' },
                      { metric: '8+', label: 'OTA Platforms Managed' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">OTA Management FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Let's Grow Your Goa Property</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Start with a free Property Growth Audit today.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602" target="_blank" rel="noopener noreferrer" className="btn-primary">Start Growing Your Bookings</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
