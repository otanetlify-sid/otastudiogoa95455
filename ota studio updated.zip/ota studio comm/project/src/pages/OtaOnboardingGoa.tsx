import { useState } from 'react';
import { ChevronDown, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'How long does OTA onboarding take?', a: 'Most properties go live on major OTAs within 7 to 14 days depending on platforms and property complexity.' },
  { q: 'What documents do I need?', a: 'Typically you need FSSAI or hotel license, bank account details, property photos, ID proof, and registration documents.' },
  { q: 'Which OTAs do you onboard on?', a: 'We onboard on Booking.com, Airbnb, Agoda, Expedia, MakeMyTrip, Goibibo, Hostelworld, and Trip.com.' },
  { q: 'Is onboarding a one-time service?', a: 'We offer both one-time onboarding and monthly management packages.' },
];

const steps = [
  { num: '01', title: 'Discovery Call', desc: 'Understanding your property, goals, and target guests.' },
  { num: '02', title: 'Property Review', desc: 'Full audit of current setup and competitive positioning.' },
  { num: '03', title: 'Content Creation', desc: 'We write compelling titles, descriptions, and room details.' },
  { num: '04', title: 'Platform Setup', desc: 'Account creation and configuration on all OTAs.' },
  { num: '05', title: 'Optimization', desc: 'Pricing strategy, photo sequencing, listing enhancement.' },
  { num: '06', title: 'Go Live', desc: 'Your property goes live with full optimization.' },
];

export default function OtaOnboardingGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white">OTA Onboarding Goa</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">OTA Onboarding · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">OTA Onboarding Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Complete OTA onboarding service for hotels, hostels, villas, homestays, and resorts in Goa.
                Get listed on all major booking platforms in 7-14 days.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20need%20OTA%20onboarding%20for%20my%20Goa%20property" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Start Growing Your Bookings <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Our OTA Onboarding Process</h2>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mb-12">
                {steps.map((step, i) => (
                  <div key={i} className="p-6 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 transition-all">
                    <div className="font-display font-extrabold text-3xl text-accent/40 mb-4">{step.num}</div>
                    <h3 className="font-display font-bold text-lg text-white mb-2">{step.title}</h3>
                    <p className="text-sm text-white/50">{step.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">OTA Onboarding FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Get Your Property Listed on OTAs</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Go live on all major OTAs in 7-14 days.</p>
              <a href="https://wa.me/919270598602" target="_blank" rel="noopener noreferrer" className="btn-primary">Start Growing Your Bookings</a>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
