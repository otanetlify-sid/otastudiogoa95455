import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Rocket, TrendingUp, Building2 } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  {
    q: 'Why should I care about OTA strategy instead of just focusing on commissions?',
    a: 'OTAs are not just a cost — they are your primary distribution channel, visibility driver, and trust builder. Smart hoteliers understand that OTA commissions are an investment in visibility, not a loss. The properties that focus on reducing OTA presence often lose bookings. The properties that optimize it thrive.',
  },
  {
    q: 'How do OTAs help beyond just bringing bookings?',
    a: 'OTAs bring trust through verified reviews, global exposure to millions of travelers, professional photography standards, competitive pricing intelligence, and seamless payment processing. They also handle customer service and refunds, reducing your operational burden.',
  },
  {
    q: 'Can I really build direct bookings while using OTAs?',
    a: 'Yes. Strategic OTA management gives you data on traveler preferences, peak seasons, and pricing trends. You use this intelligence to build your direct booking channel (email lists, loyalty programs, website) without losing OTA revenue. Both channels feed each other.',
  },
  {
    q: 'What is strategic OTA management, exactly?',
    a: 'Strategic OTA management means: optimizing every listing, managing rates across platforms, responding to reviews professionally, monitoring performance, diversifying across 6-8+ platforms, and using OTA data to improve your property and direct booking strategy.',
  },
  {
    q: 'Why is Goa relevant to OTA strategy?',
    a: 'Goa is one of India\'s top tourist destinations attracting international and domestic travelers. OTA platforms are where travelers discover and book. Properties that master OTA presence in Goa can attract global visitors and maximize occupancy year-round.',
  },
  {
    q: 'What should my next step be?',
    a: 'Start with an OTA audit to understand your current listings, gaps, and opportunities. Then prioritize optimization and rate management. Finally, implement ongoing monitoring and scaling. We can help you with every step.',
  },
];

const insights = [
  { icon: Rocket, title: 'More Visibility', desc: 'Reach millions of travelers on major booking platforms' },
  { icon: TrendingUp, title: 'More Occupancy', desc: 'Optimize listings and pricing to increase booking conversion' },
  { icon: Building2, title: 'More Revenue', desc: 'Strategic pricing and multi-platform presence drive revenue growth' },
];

const commissionMyth = [
  'OTA commissions are not overhead — they are marketing spend',
  'Reducing OTA presence doesn\'t reduce commissions; it reduces bookings',
  'The properties avoiding OTAs struggle with occupancy',
  'Smart properties diversify across multiple OTA platforms to reduce dependency on any single one',
];

const strategicManagement = [
  'Professional listing optimization with SEO and keyword strategy',
  'Dynamic pricing that responds to demand, seasonality, and competitor rates',
  'Professional photography and content that converts browsers to bookers',
  'Review management and reputation building on every platform',
  'Rate synchronization across 8+ platforms to avoid overbooking',
  'Performance tracking and monthly optimization cycles',
];

const directBookings = [
  'Use OTA data to understand guest preferences and seasonal patterns',
  'Build your email list through every OTA booking',
  'Create loyalty programs for repeat guests',
  'Develop a professional website with direct booking capability',
  'Run targeted marketing to past guests',
  'Offer small incentives for direct bookings (5-10% discount)',
];

const goaStrategy = [
  'Goa attracts diverse travelers: backpackers, families, couples, adventure seekers, digital nomads',
  'Different traveler segments use different OTAs (Airbnb vs. Booking.com vs. Hostelworld)',
  'Seasonal patterns: peak (Oct-Mar), shoulder (Apr-May, Aug-Sep), off-season (Jun-Jul)',
  'Competition is high — OTA optimization is essential to stand out',
  'International tourists rely on OTA reviews and ratings more than locals',
  'Strategic OTA presence in Goa compounds with word-of-mouth and local partnerships',
];

export default function OtaStrategyInsights() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white" itemProp="name">OTA Strategy Insights</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">OTA Strategy · Insights</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">OTA Strategy Insights</h1>
              <p className="body-lg text-lg max-w-3xl mb-8">
                Understanding how to use OTA platforms strategically to maximize visibility, occupancy, and revenue.
              </p>
            </div>
          </div>

          <section className="bg-accent/10 border-y border-accent/20 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto p-8 rounded-2xl bg-white/4 border border-accent/20">
                <p className="text-lg text-white leading-relaxed">
                  Many hoteliers focus on OTA commissions. Smart hoteliers focus on visibility. OTAs don't just bring bookings — they bring trust, exposure, reviews, and global reach. The goal isn't to avoid OTAs. The goal is to use them strategically while building direct bookings alongside them.
                </p>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Three Pillars of OTA Success</h2>
              <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
                {insights.map((insight, i) => {
                  const Icon = insight.icon;
                  return (
                    <div key={i} className="p-8 rounded-2xl bg-white/4 border border-white/8 text-center">
                      <div className="w-12 h-12 rounded-lg bg-accent/15 flex items-center justify-center mx-auto mb-4">
                        <Icon size={24} className="text-accent" />
                      </div>
                      <h3 className="font-display font-bold text-xl text-white mb-2">{insight.title}</h3>
                      <p className="text-white/60 text-sm">{insight.desc}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">The OTA Commission Myth</h2>
              <div className="max-w-3xl mx-auto space-y-4">
                {commissionMyth.map((item, i) => (
                  <div key={i} className="flex items-start gap-4 p-5 rounded-xl bg-white/4 border border-white/8">
                    <CheckCircle2 size={20} className="text-accent mt-0.5 shrink-0" />
                    <span className="text-white/70">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Strategic OTA Management</h2>
              <p className="text-white/60 text-center mb-8 max-w-2xl mx-auto">What professional OTA management actually includes:</p>
              <div className="max-w-3xl mx-auto space-y-4">
                {strategicManagement.map((item, i) => (
                  <div key={i} className="flex items-start gap-4 p-5 rounded-xl bg-white/4 border border-white/8">
                    <CheckCircle2 size={20} className="text-accent mt-0.5 shrink-0" />
                    <span className="text-white/70">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Building Direct Bookings Alongside OTAs</h2>
              <p className="text-white/60 text-center mb-8 max-w-2xl mx-auto">Use OTA success to fuel your direct booking strategy:</p>
              <div className="max-w-3xl mx-auto space-y-4">
                {directBookings.map((item, i) => (
                  <div key={i} className="flex items-start gap-4 p-5 rounded-xl bg-white/4 border border-white/8">
                    <CheckCircle2 size={20} className="text-accent mt-0.5 shrink-0" />
                    <span className="text-white/70">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Why Goa Properties Need OTA Strategy</h2>
              <div className="max-w-3xl mx-auto space-y-4">
                {goaStrategy.map((item, i) => (
                  <div key={i} className="flex items-start gap-4 p-5 rounded-xl bg-white/4 border border-white/8">
                    <CheckCircle2 size={20} className="text-accent mt-0.5 shrink-0" />
                    <span className="text-white/70">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Your OTA Strategy Questions Answered</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-64' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Explore More</h2>
              <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
                <a href="/property-management-goa" className="p-6 rounded-xl bg-white/4 border border-white/8 hover:border-accent/40 transition">
                  <h3 className="font-display font-bold text-white mb-2">Property Management Goa</h3>
                  <p className="text-white/60 text-sm mb-4">Comprehensive property management services for Goa properties.</p>
                  <span className="text-accent text-sm flex items-center gap-2">Learn more <ArrowRight size={14} /></span>
                </a>
                <a href="/vision-mission" className="p-6 rounded-xl bg-white/4 border border-white/8 hover:border-accent/40 transition">
                  <h3 className="font-display font-bold text-white mb-2">Our Vision & Mission</h3>
                  <p className="text-white/60 text-sm mb-4">Understand what drives OTA Studio and our commitment to hospitality.</p>
                  <span className="text-accent text-sm flex items-center gap-2">Learn more <ArrowRight size={14} /></span>
                </a>
                <a href="/founders" className="p-6 rounded-xl bg-white/4 border border-white/8 hover:border-accent/40 transition">
                  <h3 className="font-display font-bold text-white mb-2">Meet Our Founders</h3>
                  <p className="text-white/60 text-sm mb-4">Learn about the team building OTA Studio's systems.</p>
                  <span className="text-accent text-sm flex items-center gap-2">Learn more <ArrowRight size={14} /></span>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Grow Smarter With OTA Studio</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Transform your OTA presence into sustainable revenue growth.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%27d%20like%20to%20discuss%20OTA%20strategy%20for%20my%20property" target="_blank" rel="noopener noreferrer" className="btn-primary">
                  Start Your OTA Strategy
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
