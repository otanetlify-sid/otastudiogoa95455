import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Network } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'What is the OTA Studio Partner Network?', a: 'A hospitality growth ecosystem connecting properties, technology providers, and activation partners. Together, we create a unified approach to growing hospitality businesses in Goa.' },
  { q: 'Who can join the partner network?', a: 'Hospitality properties, technology providers (PMS, channel managers, revenue platforms), and activation partners (musicians, DJs, yoga instructors, artists, event organizers).' },
  { q: 'What are the benefits of joining?', a: 'Property partners get OTA growth and activations. Technology partners get referral opportunities and network access. Activation partners get venue opportunities and event collaborations.' },
  { q: 'Is there a cost to join?', a: 'Reach out via WhatsApp to discuss partnership terms. We tailor partnerships based on category and engagement level.' },
  { q: 'How do I apply?', a: 'Simply message us on WhatsApp with your details. We\'ll assess the fit and get back to you within 24 hours.' },
];

const benefits = [
  'Properties gain OTA growth and real-world activations',
  'Technology partners access referral opportunities and hospitality network',
  'Activation partners get venue opportunities and event collaborations',
  'Unified ecosystem connecting all three categories',
  'Strategic co-marketing and collaboration opportunities',
  'Growing network across Goa\'s hospitality industry',
];

export default function PartnerNetworkPage() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white" itemProp="name">Partner Network</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Partner Network · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">OTA Studio Partner Network</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Join OTA Studio's hospitality growth network. We connect properties, technology providers, and activation partners to create a unified ecosystem for hospitality growth in Goa.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%27d%20like%20to%20join%20the%20OTA%20Studio%20Partner%20Network" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Join the Network <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="#" className="btn-secondary">
                  Explore Activations
                </a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">The Hospitality Growth Network</h2>
                  <ul className="space-y-3">
                    {benefits.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Network size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Network Categories</h3>
                  </div>
                  <div className="space-y-4 mb-8">
                    <div>
                      <div className="font-semibold text-white mb-1">Property Partners</div>
                      <p className="text-sm text-white/50">Hotels, cafes, restaurants, bars, beach clubs</p>
                    </div>
                    <div>
                      <div className="font-semibold text-white mb-1">Technology Partners</div>
                      <p className="text-sm text-white/50">PMS, channel managers, SaaS, consultants</p>
                    </div>
                    <div>
                      <div className="font-semibold text-white mb-1">Activation Partners</div>
                      <p className="text-sm text-white/50">Musicians, DJs, yoga instructors, artists</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '3', label: 'Partner Categories' },
                      { metric: '30+', label: 'Network Partners' },
                      { metric: '50+', label: 'Activations Delivered' },
                      { metric: '8+', label: 'OTA Platforms' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Partner Network FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Join OTA Studio Network</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Connect with Goa's hospitality growth ecosystem.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%27d%20like%20to%20join%20the%20OTA%20Studio%20Partner%20Network" target="_blank" rel="noopener noreferrer" className="btn-primary">Join the Network</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
