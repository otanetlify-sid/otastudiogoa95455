import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <div className="section-max section-padding py-12 sm:py-16">
          <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
            <ol className="flex items-center gap-2">
              <li><a href="/" className="hover:text-white">Home</a></li>
              <li>/</li>
              <li className="text-white">Privacy Policy</li>
            </ol>
          </nav>
          <h1 className="heading-lg text-white mb-4">Privacy Policy</h1>
          <p className="text-sm text-white/40 mb-10">Last updated: June 11, 2026</p>

          <div className="max-w-3xl space-y-8 text-white/60">
            <section>
              <h2 className="font-display font-bold text-xl text-white mb-3">1. Introduction</h2>
              <p>The OTA Studio is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or contact us about our hospitality growth services.</p>
            </section>

            <section>
              <h2 className="font-display font-bold text-xl text-white mb-3">2. Information We Collect</h2>
              <ul className="list-disc pl-5 space-y-2">
                <li><strong>Contact Information:</strong> Name, phone number, email address, and property details.</li>
                <li><strong>Usage Data:</strong> Information about how you interact with our website.</li>
                <li><strong>Communication Data:</strong> Messages sent via WhatsApp, email, or contact forms.</li>
              </ul>
            </section>

            <section>
              <h2 className="font-display font-bold text-xl text-white mb-3">3. Contact Us</h2>
              <div className="p-5 rounded-xl bg-white/4 border border-white/8">
                <p className="text-white"><strong>The OTA Studio</strong></p>
                <p>Goa, India</p>
                <p>Email: theotastudios@gmail.com</p>
                <p>Phone: +91 85519 52391</p>
              </div>
            </section>
          </div>

          <div className="mt-10 pt-8 border-t border-white/8 flex flex-wrap gap-4 text-sm">
            <a href="/terms-and-conditions" className="text-accent hover:underline">Terms &amp; Conditions</a>
            <a href="/" className="text-white/50 hover:underline">Back to Home</a>
          </div>
        </div>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
