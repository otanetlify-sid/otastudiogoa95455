import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Briefcase, BarChart3, Zap } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'What is full-service property management?', a: 'Full-service property management includes everything: OTA optimization across all platforms, day-to-day guest communications, housekeeping coordination, maintenance, revenue management, and strategic growth planning. We handle your property as if it were our own.' },
  { q: 'How do you manage multiple OTAs efficiently?', a: 'We use advanced channel management tools to synchronize your inventory, rates, and availability across Booking.com, Airbnb, Agoda, Expedia, MakeMyTrip, Goibibo, Hostelworld, and other OTAs in real-time, preventing overbookings and ensuring consistent pricing.' },
  { q: 'What operations do you handle?', a: 'We manage housekeeping scheduling, guest check-ins/check-outs, maintenance coordination, damage management, complaint resolution, and all guest-facing operations. Our team ensures every guest has an exceptional experience.' },
  { q: 'How do you optimize revenue?', a: 'We implement dynamic pricing across OTAs, manage seasonal rate adjustments, optimize for high-demand periods, negotiate with OTA partners, and implement ancillary revenue strategies to maximize your income from your property.' },
  { q: 'Can you handle properties remotely?', a: 'Absolutely. We manage properties remotely using cloud-based systems, trusted housekeeping partners, and on-ground coordinators. Many of our clients own properties in Goa while living elsewhere.' },
  { q: 'What reporting do you provide?', a: 'We provide detailed monthly reports including occupancy rates, average daily rates, revenue by OTA, guest feedback summaries, maintenance logs, and strategic recommendations for continued growth and optimization.' },
];

const includes = [
  'Multi-OTA management across 8+ platforms',
  'Dynamic pricing and revenue optimization',
  'Guest communication and support',
  'Housekeeping coordination and scheduling',
  'Maintenance and issue management',
  'Listing optimization across all platforms',
  'Review management and reputation building',
  'Strategic growth planning and consulting',
];

export default function PropertyManagementGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Property Management Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Property Management · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Property Management Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Complete property management services for hotels, resorts, villas, and vacation rentals in Goa. From OTA optimization to operations,
                we handle everything so you can focus on growth. Professional, transparent, results-driven property management.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20complete%20property%20management%20for%20my%20Goa%20property" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Grow Your Property Revenue <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">Complete Management Services</h2>
                  <p className="body-md text-white/70 mb-8">Everything you need to operate successfully and grow revenue from your Goa property.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <h3 className="font-display font-bold text-xl text-white mb-6">Results We Deliver</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '3.5x', label: 'Average Revenue Growth' },
                      { metric: '85%+', label: 'Average Occupancy' },
                      { metric: '4.8+', label: 'Average Guest Rating' },
                      { metric: '150+', label: 'Properties Managed' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid md:grid-cols-3 gap-8 mb-16">
                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <BarChart3 size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Revenue Optimization</h3>
                  <p className="text-white/70 mb-4">Our revenue management experts optimize pricing across all OTAs, implement dynamic rate strategies based on demand, and identify ancillary revenue opportunities. Average clients see 3.5x revenue growth.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Multi-OTA rate optimization
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Dynamic pricing implementation
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Revenue maximization strategies
                    </li>
                  </ul>
                </div>

                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <Briefcase size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Operations Management</h3>
                  <p className="text-white/70 mb-4">We handle all operational aspects: housekeeping coordination, guest communications, check-in/check-out, maintenance scheduling, and problem resolution. Your property runs smoothly while you focus on growth.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Full guest services management
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Housekeeping coordination
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Maintenance and repairs oversight
                    </li>
                  </ul>
                </div>

                <div className="p-8 rounded-2xl border border-accent/20 bg-accent/5">
                  <Zap size={32} className="text-accent mb-4" />
                  <h3 className="heading-md text-white mb-4">Growth Strategy</h3>
                  <p className="text-white/70 mb-4">Beyond day-to-day management, we implement strategic growth initiatives: market expansion to new OTAs, enhanced guest experiences, reputation building, and positioning your property for maximum market reach and profitability.</p>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Strategic market expansion
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Reputation management
                    </li>
                    <li className="flex items-center gap-2 text-sm text-white/70">
                      <CheckCircle2 size={16} className="text-accent" />
                      Long-term growth planning
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Why Full-Service Management?</h2>
              <div className="grid md:grid-cols-2 gap-8">
                {[
                  'Eliminate the stress of daily property operations and guest management',
                  'Increase revenue through professional pricing optimization and OTA management',
                  'Maintain consistent high occupancy rates and guest satisfaction scores',
                  'Access expert knowledge of Goa market, seasonality, and traveler preferences',
                  'Benefit from our relationships with 8+ OTA platforms for better visibility',
                  'Reduce operational costs through efficient housekeeping and maintenance coordination',
                  'Receive detailed monthly reporting and transparent financial statements',
                  'Focus on business growth while we handle day-to-day operations',
                ].map((benefit, i) => (
                  <div key={i} className="flex items-start gap-4 p-6 rounded-xl border border-white/8 bg-white/4">
                    <CheckCircle2 size={24} className="text-accent mt-1 shrink-0" />
                    <p className="text-white/70">{benefit}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Our Approach</h2>
              <div className="max-w-3xl mx-auto space-y-6">
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Transparent Partnership</h3>
                  <p className="text-white/70">We treat your property as if it's our own. You get full transparency with detailed monthly reports, real-time booking visibility, and direct access to our team whenever needed. No hidden fees, no surprises.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Local Expertise</h3>
                  <p className="text-white/70">Our team knows Goa intimately. We understand seasonal patterns, local events, traveler preferences, and competitive dynamics. This expertise translates directly to better pricing decisions and higher revenue for your property.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Technology-Driven</h3>
                  <p className="text-white/70">We leverage cloud-based systems, AI-powered pricing, real-time analytics, and integrated OTA management tools. Your property benefits from cutting-edge technology without you having to manage it yourself.</p>
                </div>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-4">Results-Focused</h3>
                  <p className="text-white/70">Our success is measured by your growth. We focus on increasing occupancy, revenue per booking, guest satisfaction, and long-term property value. Your growth is our growth.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Related Services</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <a href="/vision-mission" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Our Vision & Mission</h3>
                  <p className="text-white/70 mb-4">Learn about our commitment to hospitality excellence and property management in Goa.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <a href="/founders" className="p-8 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/10 transition-all group">
                  <h3 className="heading-md text-white mb-3 group-hover:text-accent transition-colors">Meet Our Founders</h3>
                  <p className="text-white/70 mb-4">Discover the team of experienced hospitality professionals leading our management services.</p>
                  <span className="text-accent flex items-center gap-2">Learn More <ArrowRight size={16} /></span>
                </a>
                <div className="p-8 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Specialized OTA Services</h3>
                  <p className="text-white/70 mb-4">Need management for specific OTAs? We offer dedicated management for Booking.com, Airbnb, Agoda, Expedia, MakeMyTrip, Goibibo, and Hostelworld.</p>
                  <span className="text-accent flex items-center gap-2">View OTA Services <ArrowRight size={16} /></span>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Property Management FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-64' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ready to Maximize Your Property's Potential?</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Let's discuss how our complete property management services can transform your Goa property into a revenue-generating asset.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20complete%20property%20management%20for%20my%20Goa%20property" target="_blank" rel="noopener noreferrer" className="btn-primary">Start Growing Your Revenue</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
