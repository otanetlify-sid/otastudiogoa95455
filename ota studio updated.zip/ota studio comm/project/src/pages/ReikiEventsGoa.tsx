import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Heart } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What is Reiki and why host it at hospitality venues?', a: 'Reiki is energy healing that promotes relaxation, healing, and wellness. Venues host Reiki events to attract wellness guests, create unique experiences, and position themselves as wellness destinations.' },
  { q: 'What happens in a Reiki session?', a: 'Sessions typically last 60-90 minutes. Clients lie relaxed while certified Reiki practitioners channel healing energy through gentle hand placement, promoting deep relaxation and holistic wellness.' },
  { q: 'Who attends Reiki events?', a: 'Wellness enthusiasts, yoga practitioners, stress management seekers, tourists wanting healing experiences, and spiritually curious guests. These are high-value guests who often spend significantly.' },
  { q: 'Can Reiki create recurring revenue?', a: 'Absolutely. Monthly or weekly Reiki sessions build a dedicated wellness community, create predictable recurring revenue, and attract guests who visit regularly for healing.' },
  { q: 'How do you book certified Reiki practitioners?', a: 'Our network includes certified Reiki masters. We handle all booking, scheduling, and coordination for professional, consistent Reiki programming.' },
  { q: 'What atmosphere is needed for Reiki sessions?', a: 'Peaceful, calm spaces with comfortable furniture for clients to recline. We coordinate proper ambiance with soft lighting, calming music, and healing energy to support transformative sessions.' },
];

const services = [
  'Certified Reiki practitioner network',
  'Session planning and scheduling',
  'Venue space optimization',
  'Comfort and ambiance coordination',
  'Wellness community building',
  'Event promotion and marketing',
  'Guest experience curation',
  'Monthly wellness program reporting',
];

const eventTypes = [
  'One-on-one Reiki sessions',
  'Group Reiki circles',
  'Reiki healing days',
  'Chakra balancing sessions',
  'Distance Reiki programs',
  'Reiki and yoga combinations',
  'Wellness retreat components',
  'Corporate wellness programs',
];

export default function ReikiEventsGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Reiki Events Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Reiki Events · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Reiki Events Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Energy healing Reiki events at Goa hospitality venues. Professional Reiki masters, healing sessions, and wellness community programming for transformative guest experiences.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20host%20Reiki%20events" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Host Reiki Events <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20to%20plan%20wellness%20programming" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Plan Wellness Program
                </a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What We Deliver</h2>
                  <p className="body-md mb-8">Complete Reiki event and wellness programming service.</p>
                  <ul className="space-y-3">
                    {services.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Heart size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Event Types</h3>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {eventTypes.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-white/70">
                        <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                        {item}
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '150+', label: 'Sessions Hosted' },
                      { metric: '28%', label: 'Revenue Growth' },
                      { metric: '10+', label: 'Practitioners' },
                      { metric: '97%', label: 'Satisfaction Rate' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-8">Reiki Wellness Strategy</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Certified Practitioners</h3>
                  <p className="text-white/70 text-sm">Experienced, certified Reiki masters deliver authentic healing sessions that guests find transformative and deeply meaningful.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Healing Destination</h3>
                  <p className="text-white/70 text-sm">Position your venue as a healing sanctuary where guests come for transformative wellness experiences and energy healing.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Wellness Loyalty</h3>
                  <p className="text-white/70 text-sm">Build a devoted wellness community that returns regularly and creates strong advocacy and word-of-mouth promotion.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Reiki Events FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Offer Transformative Reiki Healing</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Professional Reiki sessions that create wellness communities and loyal, returning guests.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Host Reiki Events</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
