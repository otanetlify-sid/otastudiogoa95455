import { useState } from 'react';
import { ChevronDown, UtensilsCrossed, Music, Users, Flame } from 'lucide-react';
import PageLayout from '../components/PageLayout';
import Breadcrumbs from '../components/Breadcrumbs';

const faqs = [
  {
    q: 'How do restaurant events drive repeat visits?',
    a: 'Themed dining events, chef collaborations, and special experiences create reasons for guests to return. Events generate word-of-mouth marketing, social media buzz, and premium pricing opportunities. Regular event attendees become loyal customers who visit more frequently.',
  },
  {
    q: 'What restaurant event ideas work best in Goa?',
    a: 'Chef table experiences, wine pairing dinners, live music nights, cultural cuisine themes, seafood festivals, craft beverage tastings, and seasonal celebrations all perform exceptionally well. The key is authentic curation aligned with your restaurant concept.',
  },
  {
    q: 'How often should restaurants host events?',
    a: 'We recommend 1-2 events per month for most restaurants. Some host weekly or bi-weekly. Consistency builds anticipation and community. Frequency depends on your team capacity, guest demand, and revenue goals.',
  },
  {
    q: 'Can smaller restaurants run successful events?',
    a: 'Absolutely. Intimate restaurant spaces often create more memorable experiences than large venues. Small restaurants can host tasting menus, limited chef tables, or exclusive wine evenings that feel premium and exclusive.',
  },
  {
    q: 'How do you ensure good attendance at restaurant events?',
    a: 'We promote through email lists, social media, Google Business Profile, WhatsApp groups, and local partnerships. Building an event subscriber base and leveraging past attendees is key to consistent, strong attendance.',
  },
  {
    q: 'What\'s the financial impact of restaurant events?',
    a: 'Event evenings typically generate 30-50% higher revenue per seat than regular service. Guests spend more on premium menu items and beverages. Events also drive off-peak bookings during slow periods.',
  },
];

const services = [
  {
    icon: UtensilsCrossed,
    title: 'Themed Dining Experiences',
    desc: 'From chef collaboration dinners to cultural cuisine nights, we design unique dining themes that showcase your restaurant\'s strengths and attract food enthusiasts.',
    features: [
      'Chef table experiences',
      'Themed cuisine events',
      'Menu curation support',
      'Culinary storytelling',
    ],
  },
  {
    icon: Music,
    title: 'Live Entertainment & Ambiance',
    desc: 'Curating live musicians, performers, and ambient experiences that enhance dining atmosphere and create memorable moments worth sharing on social media.',
    features: [
      'Live music booking',
      'Artist coordination',
      'Ambiance design',
      'Sound system management',
    ],
  },
  {
    icon: Users,
    title: 'Event Promotion & Community Building',
    desc: 'Strategic marketing to build event awareness, create subscriber lists, and develop a community of food enthusiasts who return for every event.',
    features: [
      'Email marketing campaigns',
      'Social media promotion',
      'Community building',
      'Local partnerships',
    ],
  },
  {
    icon: Flame,
    title: 'Premium Experience Management',
    desc: 'End-to-end event execution ensuring flawless service, memorable experiences, and seamless conversion of event attendees into regular customers.',
    features: [
      'Event coordination',
      'Service training',
      'Guest experience design',
      'Repeat booking conversion',
    ],
  },
];

export default function RestaurantEventIdeasGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <PageLayout
      title="Restaurant Event Ideas in Goa | Curated Dining Experiences | The OTA Studio"
      description="Creative restaurant event ideas in Goa. Chef tables, tasting menus, themed nights, live music dinners and community events that drive repeat visits."
      canonical="https://otastudio.in/restaurant-event-ideas-goa"
      schemaType="community"
    >
      <article>
        <div className="bg-neutral-950 pt-16 pb-20 sm:pt-20 sm:pb-28 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <div className="text-white/50 pb-2">
              <Breadcrumbs crumbs={[{ label: 'Community' }, { label: 'Restaurant Event Ideas' }]} />
            </div>
            <div className="max-w-3xl">
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Community Events · Goa</span>
              <h1 className="heading-xl text-white mb-6">
                Restaurant Event Ideas <br className="hidden sm:block" />
                <span className="text-accent">in Goa</span>
              </h1>
              <p className="text-base sm:text-xl text-white/70 leading-relaxed mb-8">
                Create unforgettable dining experiences that drive repeat visits and premium revenue.
                The OTA Studio designs and executes restaurant events—from chef collaborations to live
                music dinners—that build community and boost your bottom line.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20event%20ideas%20for%20my%20restaurant"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary"
                >
                  Plan Your First Event
                </a>
                <a
                  href="https://wa.me/919309706263?text=Tell%20me%20about%20restaurant%20event%20strategies"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-secondary"
                >
                  Get Event Strategy
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="section-max section-padding py-16 sm:py-20 bg-neutral-900">
          <h2 className="heading-lg text-center text-white mb-12">
            Restaurant Event Services in Goa
          </h2>
          <div className="grid sm:grid-cols-2 gap-6">
            {services.map((service, i) => (
              <div
                key={i}
                className="p-7 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/7 hover:shadow-[0_0_20px_rgba(255,208,0,0.05)] hover:-translate-y-1 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-5">
                  <service.icon size={22} className="text-accent" />
                </div>
                <h3 className="font-display font-bold text-xl text-white mb-3">{service.title}</h3>
                <p className="text-sm text-white/50 leading-relaxed mb-5">{service.desc}</p>
                <div className="flex flex-wrap gap-2">
                  {service.features.map((feature, j) => (
                    <span
                      key={j}
                      className="px-3 py-1 rounded-full bg-white/8 border border-white/8 text-xs font-medium text-white/60"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-neutral-950 py-16 sm:py-20 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="heading-lg text-white mb-6">
                  How We Design Restaurant Events
                </h2>
                <div className="space-y-4">
                  {[
                    { num: '1', title: 'Concept Development', desc: 'Creating themed event concepts aligned with your restaurant brand and target audience.' },
                    { num: '2', title: 'Menu & Experience Design', desc: 'Curating special menus, wine pairings, and experiences that justify premium pricing.' },
                    { num: '3', title: 'Entertainment Booking', desc: 'Sourcing and coordinating live musicians, performers, or guest chefs to enhance the experience.' },
                    { num: '4', title: 'Promotion & Ticketing', desc: 'Strategic marketing campaigns and ticket sales to ensure strong attendance and buzz.' },
                    { num: '5', title: 'Flawless Execution', desc: 'Day-of coordination ensuring seamless service, timing, and guest satisfaction.' },
                    { num: '6', title: 'Community Building', desc: 'Converting event attendees into regular customers and tracking repeat visit impact.' },
                  ].map((step, i) => (
                    <div key={i} className="flex items-start gap-4">
                      <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center shrink-0">
                        <span className="font-display font-bold text-sm text-accent">{step.num}</span>
                      </div>
                      <div>
                        <div className="font-display font-bold text-white text-sm">{step.title}</div>
                        <div className="text-xs text-white/40 mt-0.5">{step.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div className="p-7 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white text-xl mb-6">
                    Event Ideas That Work in Goa
                  </h3>
                  <ul className="space-y-3">
                    {[
                      'Chef table experiences with kitchen view',
                      'Wine pairing and tasting dinners',
                      'Live music dinner nights',
                      'Themed cuisine events (Italian, Asian, etc.)',
                      'Seafood festival and seasonal celebrations',
                      'Craft beverage and cocktail tastings',
                      'Guest chef collaboration dinners',
                      'Cultural cuisine and heritage menus',
                      'Progressive dining experiences',
                      'Brewery or winery partnership events',
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 shrink-0" />
                        <span className="text-sm text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-neutral-900 py-16 sm:py-20 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-30" />
          <div className="section-max section-padding relative">
            <h2 className="heading-lg text-center text-white mb-12">
              Restaurant Event FAQs — Goa
            </h2>
            <div className="max-w-3xl mx-auto space-y-3">
              {faqs.map((faq, i) => (
                <div
                  key={i}
                  className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden"
                >
                  <button
                    onClick={() => setOpenIdx(openIdx === i ? null : i)}
                    className="w-full flex items-center justify-between p-5 sm:p-6 text-left"
                    aria-expanded={openIdx === i}
                  >
                    <span className="font-display font-bold text-base sm:text-lg text-white pr-4">
                      {faq.q}
                    </span>
                    <ChevronDown
                      size={20}
                      className={`shrink-0 text-white/40 transition-transform duration-300 ${
                        openIdx === i ? 'rotate-180 text-accent' : ''
                      }`}
                    />
                  </button>
                  <div
                    className={`overflow-hidden transition-all duration-300 ${
                      openIdx === i ? 'max-h-48' : 'max-h-0'
                    }`}
                  >
                    <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-sm sm:text-base text-white/50 leading-relaxed">
                      {faq.a}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-neutral-950 py-16 sm:py-20 text-center relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <h2 className="heading-lg text-white mb-4">
              Turn Your Restaurant Into an Event Destination
            </h2>
            <p className="text-white/50 mb-8 max-w-xl mx-auto">
              Let The OTA Studio design and execute events that drive repeat visits, build community,
              and generate premium revenue for your restaurant.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <a
                href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20event%20ideas%20for%20my%20restaurant"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
              >
                Plan Your First Event
              </a>
              <a href="/" className="btn-secondary">
                Back to Home
              </a>
            </div>
          </div>
        </div>
      </article>
    </PageLayout>
  );
}
