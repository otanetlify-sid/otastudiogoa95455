import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, UtensilsCrossed } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'How do you market restaurants in Goa?', a: 'We combine OTA optimization (Zomato, Swiggy, EazyDiner) with real-world activations like live music nights, food + music pairings, and themed dining experiences to drive both online orders and dine-in footfall.' },
  { q: 'Which platforms do you optimize for restaurants?', a: 'We optimize for Zomato, Swiggy, EazyDiner, Dineout, and Google Business Profile — plus social media amplification for every activation.' },
  { q: 'What kind of activations work for restaurants?', a: 'The most effective activations include live music dinners, food + music pairing events, art pop-ups, cultural Goa nights, and community engagement events that create shareable moments.' },
  { q: 'How quickly will I see results?', a: 'Online optimization improvements are visible within 2-4 weeks. Activation-driven footfall increases are typically seen from the very first event, with compounding growth over recurring schedules.' },
  { q: 'Do you handle social media for restaurants?', a: 'We create social media content around activations and amplify events. For full social media management, we can include it as part of a broader engagement.' },
];

const includes = [
  'Zomato, Swiggy & EazyDiner profile optimization', 'Google Business Profile management',
  'Photo and content strategy for listings', 'Review response and reputation management',
  'Live music and entertainment curation', 'Food + music pairing event design',
  'Social media amplification for activations', 'Monthly performance and footfall reports',
];

export default function RestaurantMarketingGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white" itemProp="name">Restaurant Marketing Goa</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Restaurant Marketing · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Restaurant Marketing Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Digital growth and real-world activations for restaurants in Goa. We optimize your online presence
                and curate experiences that fill tables and build loyal diners.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20need%20marketing%20for%20my%20restaurant%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Market My Restaurant <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20a%20restaurant%20growth%20audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Get A Growth Audit
                </a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What Restaurant Marketing Includes</h2>
                  <p className="body-md mb-8">Digital optimization and activation marketing for Goa restaurants.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 rounded-lg bg-accent/15 flex items-center justify-center">
                      <UtensilsCrossed size={20} className="text-accent" />
                    </div>
                    <h3 className="font-display font-bold text-xl text-white">Restaurant Activations</h3>
                  </div>
                  <div className="space-y-3 mb-6">
                    {['Live music dinner nights', 'Food + music pairing events', 'Art and culture pop-ups', 'Cultural Goa dining experiences', 'Community engagement events'].map((item, i) => (
                      <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-white/4 border border-white/8">
                        <CheckCircle2 size={16} className="text-accent shrink-0" />
                        <span className="text-sm text-white/70">{item}</span>
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '3x', label: 'Online Visibility' },
                      { metric: '2.5x', label: 'Dine-in Footfall' },
                      { metric: '4.5', label: 'Avg Rating Improvement' },
                      { metric: '5+', label: 'Platforms Optimized' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Restaurant Marketing FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Grow Your Goa Restaurant</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Digital optimization + real-world activations for consistent footfall.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20need%20marketing%20for%20my%20restaurant%20in%20Goa" target="_blank" rel="noopener noreferrer" className="btn-primary">Market My Restaurant</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
