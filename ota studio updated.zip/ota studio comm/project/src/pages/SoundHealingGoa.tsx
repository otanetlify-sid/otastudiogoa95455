import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Volume2 } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What are sound healing events?', a: 'Sound healing uses vibrations, instruments, and frequencies to promote relaxation, healing, and wellness. Events include singing bowl sessions, gong baths, and sound meditations.' },
  { q: 'Why do venues host sound healing events?', a: 'Sound healing attracts wellness seekers, creates unique experiences, positions venues as wellness destinations, and generate additional revenue from event-goers who often stay for dining and drinks.' },
  { q: 'What is a typical sound healing session?', a: 'Sessions typically last 45-90 minutes. Participants relax while experienced practitioners create therapeutic soundscapes using singing bowls, gongs, tuning forks, and other sound instruments.' },
  { q: 'Who attends sound healing events?', a: 'Wellness seekers, yoga practitioners, tourists looking for transformative experiences, stress management seekers, and spiritually curious guests. High-value audience that spends well.' },
  { q: 'Can venues do monthly sound healing programs?', a: 'Yes. Monthly or weekly sound healing sessions build a wellness community, create recurring revenue, and attract loyal guests who visit for the healing experience.' },
  { q: 'How do you promote sound healing events?', a: 'Wellness communities, Instagram storytelling, email to wellness seekers, local yoga studio partnerships, and word-of-mouth from satisfied attendees.' },
];

const services = [
  'Sound healing practitioner network',
  'Session planning and coordination',
  'Venue acoustics assessment',
  'Audio-visual setup and equipment',
  'Community building for wellness',
  'Event promotion and marketing',
  'Guest experience coordination',
  'Monthly wellness community reporting',
];

const sessionTypes = [
  'Singing bowl baths',
  'Gong sound healing',
  'Sound meditation',
  'Tuning fork therapy',
  'Crystal bowl sessions',
  'Binaural beat sessions',
  'Group healing circles',
  'Private sound sessions',
];

export default function SoundHealingGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Sound Healing Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Sound Healing · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Sound Healing Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Sound healing events and wellness programs at Goa hospitality venues. Professional practitioners, therapeutic sessions, and wellness community building for transformative guest experiences.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20host%20sound%20healing%20events" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Host Sound Healing <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20wellness%20programming" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Plan Wellness Program
                </a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What We Deliver</h2>
                  <p className="body-md mb-8">Complete sound healing event and wellness program service.</p>
                  <ul className="space-y-3">
                    {services.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Volume2 size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Session Types</h3>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {sessionTypes.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-white/70">
                        <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                        {item}
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '100+', label: 'Sessions Hosted' },
                      { metric: '25%', label: 'Revenue Increase' },
                      { metric: '12+', label: 'Practitioners' },
                      { metric: '96%', label: 'Guest Satisfaction' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-8">Sound Healing Wellness Strategy</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Expert Practitioners</h3>
                  <p className="text-white/70 text-sm">Experienced sound healing practitioners deliver authentic, therapeutic sessions that leave guests transformed and wanting to return.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Wellness Destination</h3>
                  <p className="text-white/70 text-sm">Position your venue as a healing destination, attracting wellness-focused guests and creating unique differentiation in the market.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Loyal Community</h3>
                  <p className="text-white/70 text-sm">Build a wellness community that returns regularly for healing sessions and creates strong word-of-mouth loyalty.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Sound Healing FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Create Healing Experiences at Your Venue</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Sound healing sessions that transform guests and build loyal wellness communities.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Host Sound Healing</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
