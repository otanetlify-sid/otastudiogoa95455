import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Send, Server } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import FormField, { FormSelect } from '../components/FormField';

const faqs = [
  { q: 'What is a technology partnership?', a: 'A strategic collaboration where hospitality technology providers gain access to our property network, referral opportunities, and co-marketing initiatives across Goa.' },
  { q: 'Who qualifies as a technology partner?', a: 'PMS providers, channel manager companies, revenue management platforms, booking engine providers, hospitality SaaS companies, hotel consultants, hotel photographers, and hospitality website developers.' },
  { q: 'What are the benefits?', a: 'Referral opportunities, hospitality network access, co-marketing opportunities, strategic collaborations, and integration partnerships with our growing property base.' },
  { q: 'Is there a partnership fee?', a: 'We structure partnerships based on mutual value. Reach out via WhatsApp to discuss terms tailored to your product and business model.' },
  { q: 'How quickly can I start?', a: 'After application review (typically 24-48 hours), we onboard partners and begin collaborative initiatives immediately.' },
];

const includes = [
  'Referral opportunities from our property network',
  'Hospitality industry network access across Goa',
  'Co-marketing and promotional opportunities',
  'Strategic collaboration on hospitality solutions',
  'Integration partnership opportunities',
  'Featured listing in our partner directory',
];

const partnerCategories = [
  'PMS Providers', 'Channel Manager Providers', 'Revenue Management Platforms',
  'Booking Engine Providers', 'Hospitality SaaS Companies', 'Hotel Consultants',
];

function validateEmail(email: string) {
  if (!email) return 'Email is required';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return 'Enter a valid email address';
  return '';
}

function validatePhone(phone: string) {
  if (!phone) return 'WhatsApp number is required';
  if (!/^[+]?[\d\s-]{7,15}$/.test(phone)) return 'Enter a valid phone number';
  return '';
}

function validateRequired(value: string, field: string) {
  if (!value.trim()) return `${field} is required`;
  return '';
}

export default function TechnologyPartners() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    company: '', contact: '', website: '', productType: '', whatsapp: '', email: '', proposal: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: Record<string, string> = {};
    newErrors.company = validateRequired(formData.company, 'Company name');
    newErrors.contact = validateRequired(formData.contact, 'Contact name');
    newErrors.website = validateRequired(formData.website, 'Website');
    newErrors.productType = validateRequired(formData.productType, 'Product type');
    newErrors.whatsapp = validatePhone(formData.whatsapp);
    newErrors.email = validateEmail(formData.email);
    setErrors(newErrors);

    if (Object.values(newErrors).some(e => e)) return;

    const text = `Hi, I'd like to become a Technology Partner.\n\nCompany: ${formData.company}\nContact: ${formData.contact}\nWebsite: ${formData.website}\nProduct Type: ${formData.productType}\nWhatsApp: ${formData.whatsapp}\nEmail: ${formData.email}\nProposal: ${formData.proposal}`;
    window.open(`https://wa.me/919270598602?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white" itemProp="name">Technology Partners</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Technology Partners · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">OTA Technology Partners Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Become an OTA Studio technology partner. PMS providers, channel managers, revenue platforms,
                and hospitality SaaS companies — join our network and access referral opportunities across Goa's hospitality industry.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20become%20a%20Technology%20Partner" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Become a Technology Partner <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="/partner-network" className="btn-secondary">View All Partnerships</a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">Technology Partnership Includes</h2>
                  <p className="body-md mb-8">Strategic benefits for hospitality technology providers.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center">
                      <Server size={20} className="text-white" />
                    </div>
                    <h3 className="font-display font-bold text-xl text-white">Partner Categories</h3>
                  </div>
                  <div className="space-y-3 mb-6">
                    {partnerCategories.map((cat, i) => (
                      <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-white/4 border border-white/8">
                        <CheckCircle2 size={16} className="text-accent shrink-0" />
                        <span className="text-sm text-white/70">{cat}</span>
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '30+', label: 'Properties in Network' },
                      { metric: '8+', label: 'OTA Platforms' },
                      { metric: '5+', label: 'Active Tech Partners' },
                      { metric: '100+', label: 'Referral Opportunities' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-2xl mx-auto p-6 sm:p-8 rounded-2xl border border-white/8 bg-white/4">
                <h3 className="font-display font-bold text-lg text-white mb-6 text-center">Apply as Technology Partner</h3>
                <form onSubmit={handleSubmit} noValidate className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <FormField label="Company Name" name="tp-company" required placeholder="Your company name" value={formData.company} onChange={(e) => setFormData({ ...formData, company: e.target.value })} error={errors.company} />
                    <FormField label="Contact Name" name="tp-contact" required placeholder="Your full name" value={formData.contact} onChange={(e) => setFormData({ ...formData, contact: e.target.value })} error={errors.contact} />
                  </div>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <FormField label="Website" name="tp-website" type="url" required placeholder="https://yourcompany.com" value={formData.website} onChange={(e) => setFormData({ ...formData, website: e.target.value })} error={errors.website} />
                    <FormSelect label="Product Type" name="tp-productType" required value={formData.productType} onChange={(e) => setFormData({ ...formData, productType: e.target.value })}>
                      <option value="">Select product type</option>
                      <option value="PMS">PMS Provider</option>
                      <option value="Channel Manager">Channel Manager</option>
                      <option value="Revenue Management">Revenue Management Platform</option>
                      <option value="Booking Engine">Booking Engine Provider</option>
                      <option value="Hospitality SaaS">Hospitality SaaS</option>
                      <option value="Consultant">Hotel Consultant</option>
                      <option value="Photographer">Hotel Photographer</option>
                      <option value="Developer">Website Developer</option>
                    </FormSelect>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <FormField label="WhatsApp Number" name="tp-whatsapp" type="tel" required placeholder="+91 XXXXXXXXXX" value={formData.whatsapp} onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })} error={errors.whatsapp} />
                    <FormField label="Email Address" name="tp-email" type="email" required placeholder="you@company.com" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} error={errors.email} />
                  </div>
                  <FormField label="Partnership Proposal" name="tp-proposal" placeholder="Brief description of the partnership you're proposing..." value={formData.proposal} onChange={(e) => setFormData({ ...formData, proposal: e.target.value })} rows={3} />
                  <button type="submit" className="btn-primary w-full"><Send size={16} />Become a Technology Partner</button>
                </form>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Technology Partner FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Become a Technology Partner</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Access Goa's growing hospitality network.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919270598602?text=Hi%2C%20I%20want%20to%20become%20a%20Technology%20Partner" target="_blank" rel="noopener noreferrer" className="btn-primary">Become a Technology Partner</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
