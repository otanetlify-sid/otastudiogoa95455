import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

export default function TermsConditions() {
  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <div className="section-max section-padding py-12 sm:py-16">
          <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
            <ol className="flex items-center gap-2">
              <li><a href="/" className="hover:text-white">Home</a></li>
              <li>/</li>
              <li className="text-white">Terms &amp; Conditions</li>
            </ol>
          </nav>
          <h1 className="heading-lg text-white mb-4">Terms &amp; Conditions</h1>
          <p className="text-sm text-white/40 mb-10">Last updated: June 11, 2026</p>

          <div className="max-w-3xl space-y-8 text-white/60">
            <section>
              <h2 className="font-display font-bold text-xl text-white mb-3">1. Agreement to Terms</h2>
              <p>By accessing our website at otastudio.in or engaging our services, you agree to be bound by these Terms &amp; Conditions.</p>
            </section>

            <section>
              <h2 className="font-display font-bold text-xl text-white mb-3">2. Services</h2>
              <p className="mb-3">The OTA Studio provides hospitality growth services including:</p>
              <ul className="list-disc pl-5 space-y-2">
                <li>OTA onboarding and management</li>
                <li>Listing optimization and content creation</li>
                <li>Distribution management and channel manager setup</li>
                <li>Revenue optimization and pricing strategy</li>
              </ul>
            </section>

            <section>
              <h2 className="font-display font-bold text-xl text-white mb-3">3. Contact</h2>
              <div className="p-5 rounded-xl bg-white/4 border border-white/8">
                <p className="text-white"><strong>The OTA Studio</strong></p>
                <p>Goa, India</p>
                <p>Email: theotastudios@gmail.com</p>
                <p>Phone: +91 85519 52391</p>
              </div>
            </section>
          </div>

          <div className="mt-10 pt-8 border-t border-white/8 flex flex-wrap gap-4 text-sm">
            <a href="/privacy-policy" className="text-accent hover:underline">Privacy Policy</a>
            <a href="/" className="text-white/50 hover:underline">Back to Home</a>
          </div>
        </div>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
