import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Sparkles } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'What is venue activation?', a: 'Venue activation uses events, experiences, and programming to energize a space and drive guest engagement. It transforms venues from passive spaces into vibrant destinations.' },
  { q: 'How does activation increase revenue?', a: 'Activations drive foot traffic, increase average bill through extended stays, generate event ticket revenue, create word-of-mouth marketing, and build loyal communities that visit frequently.' },
  { q: 'What are examples of venue activations?', a: 'Live music events, DJ nights, wellness experiences, cultural programming, creative workshops, themed parties, networking events, and community gatherings all activate venues.' },
  { q: 'How often should venues activate?', a: 'Weekly or bi-weekly is ideal for consistent visibility and audience building. Consistent programming creates anticipation and repeat attendance better than sporadic events.' },
  { q: 'Can activation work for all venue types?', a: 'Yes. Restaurants, bars, cafes, hotels, resorts, and clubs all benefit from strategic activation. Programming is customized to venue type and audience.' },
  { q: 'What is the ROI on venue activation?', a: 'Well-executed activations typically generate 30-50% revenue increase and 2-3x traffic growth. ROI is usually positive within 2-3 months.' },
];

const services = [
  'Venue activation strategy and planning',
  'Event programming and curation',
  'Artist and organizer network',
  'Complete event execution',
  'Promotion and marketing',
  'Guest experience optimization',
  'Venue space optimization',
  'Revenue and attendance tracking',
];

const activationTypes = [
  'Live music and performances',
  'DJ and nightlife events',
  'Wellness and healing experiences',
  'Cultural and local experiences',
  'Creative workshops',
  'Themed community events',
  'Seasonal celebrations',
  'Collaborative activations',
];

export default function VenueActivationGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Venue Activation Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Venue Activation · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Venue Activation Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Strategic venue activation through events, experiences, and community programming. Transform your hospitality space into a vibrant destination that drives engagement, loyalty, and revenue growth.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20activate%20my%20venue" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Activate My Venue <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20an%20Activation%20Plan" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Get Activation Plan
                </a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What We Deliver</h2>
                  <p className="body-md mb-8">Complete venue activation service for consistent growth.</p>
                  <ul className="space-y-3">
                    {services.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Sparkles size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Activation Types</h3>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {activationTypes.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-white/70">
                        <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                        {item}
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '3x', label: 'Traffic Growth' },
                      { metric: '45%', label: 'Revenue Increase' },
                      { metric: '100+', label: 'Events Executed' },
                      { metric: '89%', label: 'Satisfaction Rate' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-8">Venue Activation Strategy</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Strategic Planning</h3>
                  <p className="text-white/70 text-sm">Custom activation plans aligned with your venue, audience, and business goals. Data-driven strategies that maximize engagement and revenue.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Expert Execution</h3>
                  <p className="text-white/70 text-sm">Professional event coordination, artist bookings, technical setup, and promotion. We handle all details while you focus on service.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Community Building</h3>
                  <p className="text-white/70 text-sm">Create loyal communities around your activated venue. Regular events build anticipation, repeat attendance, and organic word-of-mouth promotion.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Venue Activation FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Transform Your Venue Into A Destination</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Strategic activation with events and programming that drive consistent engagement, loyalty, and revenue growth.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Activate My Venue</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
