import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Umbrella } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'What is a venue activation?', a: 'A venue activation is a curated experience designed for your hospitality space — live music, wellness sessions, art pop-ups, themed events — that drives footfall, social engagement, and revenue.' },
  { q: 'Which venues do you activate?', a: 'Cafes, restaurants, bars, beach clubs, hotels, resorts, and homestays across Goa. Any hospitality venue looking to increase engagement and footfall.' },
  { q: 'Does OTA Studio have its own venue?', a: 'No. We are not a physical space. All activations happen at your venue. We bring the talent, concept, and audience.' },
  { q: 'How long does an activation take to plan?', a: 'Simple activations can be planned in 1-2 weeks. Larger or recurring programs typically take 2-4 weeks for concept, talent booking, and marketing setup.' },
  { q: 'Can activations be recurring?', a: 'Yes. Recurring activations (weekly music, monthly themed nights) are the most effective for building loyal audiences and sustained footfall growth.' },
];

const includes = [
  'Venue assessment and audience profiling', 'Experience concept and theme design',
  'Talent curation from partner network', 'Pre-activation marketing and audience building',
  'On-site execution and coordination', 'Post-activation performance reporting',
  'OTA listing integration and cross-promotion', 'Recurring activation scheduling',
];

const activationTypes = [
  'Cafe activations',
  'Restaurant activations',
  'Beach club activations',
  'Bar and nightlife activations',
  'Hotel experience programming',
  'Community engagement events',
];

export default function VenueActivationsGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white" itemProp="name">Venue Activations Goa</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Venue Activations · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Venue Activations Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                End-to-end venue activation services for hospitality businesses in Goa. We curate and execute experiences at cafes, restaurants, bars, beach clubs, hotels, and resorts that drive footfall and build community.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20activate%20my%20venue" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Activate My Venue <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Tell%20me%20about%20activation%20categories" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  View Activation Categories
                </a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What Venue Activations Include</h2>
                  <p className="body-md mb-8">Complete venue activation management for maximum footfall and engagement.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Umbrella size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Venue Activations</h3>
                  </div>
                  <ul className="space-y-2 mb-8">
                    {activationTypes.map((type, i) => (
                      <li key={i} className="text-white/70 flex items-start gap-2">
                        <span className="text-accent mt-1">•</span>
                        <span>{type}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '50+', label: 'Activations Delivered' },
                      { metric: '30+', label: 'Partner Venues' },
                      { metric: '2x', label: 'Average Footfall Increase' },
                      { metric: '4', label: 'Activation Categories' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Venue Activation FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Activate Your Goa Venue</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Curated experiences that drive footfall and build community.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20activate%20my%20venue" target="_blank" rel="noopener noreferrer" className="btn-primary">Activate Your Venue</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
