import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Building2 } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'What is a venue partnership?', a: 'A comprehensive growth partnership where OTA Studio manages your OTA presence and curates activations at your venue to drive both online bookings and real-world footfall.' },
  { q: 'Which venues qualify?', a: 'Hotels, hostels, villas, homestays, resorts, cafes, restaurants, bars, and beach clubs across Goa.' },
  { q: 'Do I get both OTA services and activations?', a: 'Yes. Venue partners can access OTA Growth services (onboarding, management, distribution) and Hospitality Activations (music, wellness, creative, community events) — or choose either independently.' },
  { q: 'How quickly will I see results?', a: 'OTA optimization improvements show within 2-4 weeks. Activation-driven footfall increases are visible from the first event.' },
  { q: 'What does it cost?', a: 'We structure partnerships based on your property type, goals, and scope of services. Reach out via WhatsApp for a tailored proposal.' },
];

const includes = [
  'OTA onboarding, management, and optimization',
  'Distribution across 8+ OTA platforms',
  'Revenue management and dynamic pricing',
  'Channel manager setup and sync',
  'Curated activations at your venue',
  'Marketing and audience building for events',
  'Monthly performance and footfall reports',
  'Strategic growth planning and consultation',
];

const venueTypes = [
  'Hotels',
  'Hostels',
  'Villas and Homestays',
  'Resorts',
  'Cafes',
  'Restaurants',
  'Bars',
  'Beach Clubs',
];

export default function VenuePartners() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white" itemProp="name">Venue Partners Goa</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Venue Partners · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Venue Partners Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Partner with OTA Studio to grow your hospitality business. OTA optimization, distribution management, and curated activations — all designed to increase your visibility, bookings, and footfall.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20grow%20my%20property%20with%20OTA%20Studio" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Grow My Property <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20a%20Growth%20Audit" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Get A Growth Audit
                </a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What Venue Partnership Includes</h2>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Building2 size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Venue Types</h3>
                  </div>
                  <div className="grid grid-cols-2 gap-3 mb-8">
                    {venueTypes.map((type, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <CheckCircle2 size={16} className="text-accent shrink-0" />
                        <span className="text-white/70 text-sm">{type}</span>
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '100+', label: 'Properties Served' },
                      { metric: '8+', label: 'OTA Platforms' },
                      { metric: '3x', label: 'Average Booking Growth' },
                      { metric: '50+', label: 'Activations Delivered' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Venue Partnership FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Grow Your Goa Property</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">OTA growth + hospitality activations for modern hospitality brands.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Start Growing Your Bookings</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
