import { CircleCheck as CheckCircle2, ArrowRight } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const missionItems = [
  'Increase hospitality visibility globally',
  'Optimize OTA listings for conversions',
  'Reduce manual hotel management dependency',
  'Improve revenue using data-driven systems',
];

const executionSteps = [
  { step: '1', title: 'Audit & Analyze', desc: 'Understand your current OTA presence and growth opportunities' },
  { step: '2', title: 'Optimize & List', desc: 'Improve every OTA listing with strategic content and positioning' },
  { step: '3', title: 'Manage & Grow', desc: 'Ongoing optimization, rate management, and performance tracking' },
  { step: '4', title: 'Scale & Expand', desc: 'Add new platforms, channels, and activation opportunities' },
];

const whatDrivesUs = [
  'Every property deserves professional OTA management',
  'Technology should simplify hospitality, not complicate it',
  'Data beats intuition in revenue optimization',
  'Community-driven hospitality creates lasting value',
];

export default function VisionMission() {
  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Organization">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white" itemProp="name">Vision & Mission</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Our Purpose · OTA Studio</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">OTA Studio Vision & Mission</h1>
              <p className="body-lg text-lg max-w-3xl mb-8">
                We're building the systems and strategies that empower hospitality businesses worldwide.
              </p>
            </div>
          </div>

          <section className="bg-accent/5 border-t border-accent/20 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="max-w-3xl mx-auto">
                <h2 className="heading-md text-accent mb-6 text-center">Our Vision</h2>
                <p className="text-xl text-white text-center leading-relaxed">
                  Build a world where every hotel, resort, and hostel maximizes global visibility and revenue using intelligent OTA systems and direct booking strategies.
                </p>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Our Mission</h2>
              <div className="max-w-3xl mx-auto space-y-4">
                {missionItems.map((item, i) => (
                  <div key={i} className="flex items-start gap-4 p-5 rounded-xl bg-white/4 border border-white/8">
                    <CheckCircle2 size={20} className="text-accent mt-0.5 shrink-0" />
                    <span className="text-white/70 text-lg">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">How We Execute Our Vision</h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
                {executionSteps.map((item, i) => (
                  <div key={i} className="p-6 rounded-xl bg-white/4 border border-white/8">
                    <div className="font-display font-extrabold text-3xl text-accent mb-3">{item.step}</div>
                    <h3 className="font-display font-bold text-white mb-2">{item.title}</h3>
                    <p className="text-white/60 text-sm">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">What Drives Us</h2>
              <div className="max-w-3xl mx-auto space-y-4">
                {whatDrivesUs.map((item, i) => (
                  <div key={i} className="flex items-start gap-4 p-5 rounded-xl bg-white/4 border border-white/8">
                    <CheckCircle2 size={20} className="text-accent mt-0.5 shrink-0" />
                    <span className="text-white/70">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Learn More About Us</h2>
              <div className="grid md:grid-cols-2 gap-6 max-w-2xl mx-auto">
                <a href="/founders" className="p-6 rounded-xl bg-white/4 border border-white/8 hover:border-accent/40 transition">
                  <h3 className="font-display font-bold text-white mb-2">Meet Our Founders</h3>
                  <p className="text-white/60 text-sm mb-4">Learn about Siddharth and Suchit's journey in hospitality and OTA growth.</p>
                  <span className="text-accent text-sm flex items-center gap-2">
                    Learn more <ArrowRight size={14} />
                  </span>
                </a>
                <a href="/ota-strategy-insights" className="p-6 rounded-xl bg-white/4 border border-white/8 hover:border-accent/40 transition">
                  <h3 className="font-display font-bold text-white mb-2">OTA Strategy Insights</h3>
                  <p className="text-white/60 text-sm mb-4">Discover how strategic OTA management drives visibility and revenue.</p>
                  <span className="text-accent text-sm flex items-center gap-2">
                    Learn more <ArrowRight size={14} />
                  </span>
                </a>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Ready to Transform Your OTA Growth?</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Let's build a sustainable growth strategy together.</p>
              <a href="https://wa.me/919270598602?text=Hi%2C%20I%27d%20like%20to%20discuss%20OTA%20growth%20strategy" target="_blank" rel="noopener noreferrer" className="btn-primary inline-block">
                Start Your Journey
              </a>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
