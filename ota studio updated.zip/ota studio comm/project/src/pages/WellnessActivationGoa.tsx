import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Flower2 } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'What wellness activations do you offer?', a: 'We offer yoga sessions at partner properties, meditation and breathwork, fitness bootcamps, wellness retreat coordination, and sound healing experiences — all curated for hospitality venues in Goa.' },
  { q: 'Can wellness activations work for hotels and resorts?', a: 'Yes. Wellness activations are especially effective for hotels, resorts, and beach clubs. They attract wellness-conscious travelers, fill off-peak hours, and create premium experiences that justify higher rates.' },
  { q: 'Do you provide yoga instructors and wellness professionals?', a: 'Yes. Our Partner Network includes certified yoga instructors, meditation guides, fitness trainers, and sound healing practitioners across Goa.' },
  { q: 'How do wellness activations drive revenue?', a: 'Wellness activations create premium add-on experiences (paid sessions, retreat packages), attract a high-spending wellness audience, and differentiate your property from competitors on OTA platforms.' },
  { q: 'Can you coordinate multi-day wellness retreats?', a: 'Yes. We handle the entire retreat — from instructor booking and schedule design to guest registration, marketing, and on-site coordination across your property.' },
];

const includes = [
  'Yoga session curation and instructor booking', 'Meditation and breathwork experience design',
  'Fitness bootcamp programming', 'Wellness retreat coordination and management',
  'Sound healing experience curation', 'Wellness audience marketing and acquisition',
  'OTA listing integration for wellness packages', 'Post-session feedback and reporting',
];

export default function WellnessActivationGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white" itemProp="name">Wellness Activation Goa</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Wellness Activation · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Wellness Activation Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Curated wellness activations for hotels, resorts, and beach clubs in Goa. Yoga, meditation,
                sound healing, and wellness retreats — designed to attract premium guests and drive revenue.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20wellness%20activations%20at%20my%20Goa%20property" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Start Wellness Activation <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27m%20a%20wellness%20professional%20and%20want%20to%20join%20the%20network" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Join as Wellness Pro
                </a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What Wellness Activation Includes</h2>
                  <p className="body-md mb-8">Full-service wellness experience curation for Goa hospitality venues.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 rounded-lg bg-accent/15 flex items-center justify-center">
                      <Flower2 size={20} className="text-accent" />
                    </div>
                    <h3 className="font-display font-bold text-xl text-white">Wellness Experiences</h3>
                  </div>
                  <div className="space-y-3 mb-6">
                    {['Yoga sessions at your property', 'Meditation and breathwork', 'Fitness bootcamps', 'Wellness retreats', 'Sound healing experiences'].map((item, i) => (
                      <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-white/4 border border-white/8">
                        <CheckCircle2 size={16} className="text-accent shrink-0" />
                        <span className="text-sm text-white/70">{item}</span>
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '10+', label: 'Wellness Partners' },
                      { metric: '2x', label: 'Guest Spend Increase' },
                      { metric: '30%', label: 'Off-peak Fill Rate' },
                      { metric: '4.8', label: 'Avg Guest Rating' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Wellness Activation FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Activate Wellness at Your Goa Property</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Premium wellness experiences that attract guests and drive revenue.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20wellness%20activations%20at%20my%20Goa%20property" target="_blank" rel="noopener noreferrer" className="btn-primary">Start Wellness Activation</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
