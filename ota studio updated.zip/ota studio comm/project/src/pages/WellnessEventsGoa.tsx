import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Flower2 } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';

const faqs = [
  { q: 'What wellness events do you organize?', a: 'We curate yoga sessions, beach yoga, meditation, breathwork, wellness retreats, sound healing, and fitness bootcamps at partner properties across Goa.' },
  { q: 'Are wellness events effective for hotels?', a: 'Yes. Wellness events attract premium wellness-conscious travelers, fill off-peak hours, create premium add-on experiences, and differentiate your property on OTA platforms.' },
  { q: 'Do you provide wellness instructors?', a: 'Yes. Our Partner Network includes certified yoga instructors, meditation guides, fitness trainers, and sound healing practitioners across Goa.' },
  { q: 'How do wellness events drive revenue?', a: 'They create premium add-on experiences, attract high-spending wellness audiences, fill low-occupancy periods, and generate social media content that enhances your digital presence.' },
  { q: 'Can you coordinate multi-day wellness retreats?', a: 'Yes. We handle the entire retreat — instructor booking, schedule design, guest registration, marketing, and on-site coordination.' },
];

const includes = [
  'Yoga session curation and instructor booking',
  'Beach yoga and outdoor wellness programming',
  'Meditation and breathwork experience design',
  'Wellness retreat coordination and management',
  'Sound healing experience curation',
  'Wellness audience marketing and acquisition',
  'OTA listing integration for wellness packages',
  'Post-session feedback and reporting',
];

const cardItems = [
  'Yoga sessions at your property',
  'Beach yoga experiences',
  'Meditation and breathwork',
  'Wellness retreats',
  'Sound healing experiences',
  'Fitness bootcamps',
];

export default function WellnessEventsGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li><a href="/" className="hover:text-white">Home</a></li>
                  <li>/</li>
                  <li className="text-white" itemProp="name">Wellness Events Goa</li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Wellness Events · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Wellness Events Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Curated wellness events for hotels, resorts, and beach clubs in Goa. Yoga sessions, meditation, sound healing, and wellness retreats — designed to attract premium guests and drive revenue.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20to%20start%20wellness%20events%20at%20my%20property" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Start Wellness Events <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20to%20join%20as%20a%20Wellness%20Pro" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Join as Wellness Pro
                </a>
              </div>
            </div>
          </div>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What We Offer</h2>
                  <p className="body-md mb-8">Complete wellness event solutions for your Goa property.</p>
                  <ul className="space-y-3">
                    {includes.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Flower2 size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Wellness Events</h3>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {cardItems.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={16} className="text-accent mt-1 shrink-0" />
                        <span className="text-white/70 text-sm">{item}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '10+', label: 'Wellness Partners' },
                      { metric: '2x', label: 'Guest Spend Increase' },
                      { metric: '30%', label: 'Off-peak Fill Rate' },
                      { metric: '4.8', label: 'Avg Guest Rating' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Wellness Events FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Activate Wellness at Your Goa Property</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Premium wellness events that attract guests and drive revenue.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Start Wellness Events</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
