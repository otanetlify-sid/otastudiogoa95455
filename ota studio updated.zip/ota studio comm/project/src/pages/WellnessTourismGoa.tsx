import { useState } from 'react';
import { ChevronDown, Flower2, Heart, Wind, Sparkles } from 'lucide-react';
import PageLayout from '../components/PageLayout';
import Breadcrumbs from '../components/Breadcrumbs';

const faqs = [
  {
    q: 'What is wellness tourism and why is it booming in Goa?',
    a: 'Wellness tourism includes yoga retreats, meditation centers, healing practices, and holistic experiences. Goa is ideal for wellness tourism—the tropical climate, beaches, and spiritual culture attract wellness seekers worldwide. Wellness travelers spend more, stay longer, and book premium experiences.',
  },
  {
    q: 'What wellness services can hotels and resorts offer?',
    a: 'Hotels can offer yoga sessions, meditation classes, spa treatments, sound healing, Reiki, nutritional coaching, ayurvedic therapies, breathing workshops, and wellness retreats. Many combine accommodation with comprehensive wellness programming for multi-day stays.',
  },
  {
    q: 'How do wellness experiences increase hotel bookings and revenue?',
    a: 'Wellness-focused experiences attract a specific, affluent guest demographic seeking health and transformation. These guests book longer stays, pay premium rates, and have high satisfaction and repeat rates. Wellness programming differentiates your property in a competitive market.',
  },
  {
    q: 'Can we start small with wellness offerings?',
    a: 'Absolutely. Start with daily yoga classes and basic meditation. Add wellness instructors, expand offerings based on demand, and build toward comprehensive retreat programming. Many successful wellness properties started with just morning yoga.',
  },
  {
    q: 'What wellness trends are hot in Goa right now?',
    a: 'Sound healing, breathwork, holistic nutrition, Reiki, advanced yoga (yin, restorative), plant-medicine experiences, and digital detox retreats are all trending. Guests seek authentic, transformative wellness experiences beyond basic spa treatments.',
  },
  {
    q: 'How do you market wellness tourism offerings?',
    a: 'We market through wellness travel platforms, yoga and meditation communities, social media targeting wellness interests, email lists, partnerships with yoga studios, and content marketing around wellness topics and instructor expertise.',
  },
];

const services = [
  {
    icon: Flower2,
    title: 'Wellness Programming & Instruction',
    desc: 'Curating and managing daily wellness classes—yoga, meditation, breathwork—and specialized workshops that create transformative guest experiences.',
    features: [
      'Yoga & meditation instruction',
      'Breathwork workshops',
      'Sound healing sessions',
      'Wellness class scheduling',
    ],
  },
  {
    icon: Heart,
    title: 'Healing & Holistic Services',
    desc: 'Bringing practitioners of diverse healing modalities—Reiki, massage therapy, ayurvedic treatments, energy work—to your property for authentic wellness experiences.',
    features: [
      'Practitioner recruitment',
      'Service coordination',
      'Space optimization',
      'Guest experience design',
    ],
  },
  {
    icon: Wind,
    title: 'Wellness Retreat Design',
    desc: 'Creating complete multi-day or week-long wellness retreats with integrated accommodation, meals, classes, and healing experiences tailored to specific wellness goals.',
    features: [
      'Retreat curriculum design',
      'Meal planning integration',
      'Schedule coordination',
      'Instructor management',
    ],
  },
  {
    icon: Sparkles,
    title: 'Wellness Marketing & Positioning',
    desc: 'Strategic positioning of your property as a wellness destination. Marketing through wellness communities, platforms, and channels to attract guests seeking transformation.',
    features: [
      'Wellness positioning strategy',
      'Content marketing',
      'Community partnerships',
      'Guest testimonials',
    ],
  },
];

export default function WellnessTourismGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <PageLayout
      title="Wellness Tourism in Goa | Yoga, Meditation & Healing Retreats | The OTA Studio"
      description="Wellness tourism in Goa. Yoga retreats, meditation centers, sound healing, Reiki and holistic wellness experiences for travelers and hospitality venues."
      canonical="https://otastudio.in/wellness-tourism-goa"
      schemaType="community"
    >
      <article>
        <div className="bg-neutral-950 pt-16 pb-20 sm:pt-20 sm:pb-28 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <div className="text-white/50 pb-2">
              <Breadcrumbs crumbs={[{ label: 'Community' }, { label: 'Wellness Tourism' }]} />
            </div>
            <div className="max-w-3xl">
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Community Events · Goa</span>
              <h1 className="heading-xl text-white mb-6">
                Wellness Tourism <br className="hidden sm:block" />
                <span className="text-accent">in Goa</span>
              </h1>
              <p className="text-base sm:text-xl text-white/70 leading-relaxed mb-8">
                Attract wellness-focused travelers seeking transformation. The OTA Studio helps hotels,
                resorts, and wellness centers create authentic yoga retreats, meditation programs, and
                holistic healing experiences that generate premium revenue and guest loyalty.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20offer%20wellness%20experiences%20at%20my%20property"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary"
                >
                  Launch Wellness Programming
                </a>
                <a
                  href="https://wa.me/919309706263?text=Tell%20me%20about%20wellness%20retreat%20design"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-secondary"
                >
                  Design a Wellness Retreat
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="section-max section-padding py-16 sm:py-20 bg-neutral-900">
          <h2 className="heading-lg text-center text-white mb-12">
            Wellness Tourism Services in Goa
          </h2>
          <div className="grid sm:grid-cols-2 gap-6">
            {services.map((service, i) => (
              <div
                key={i}
                className="p-7 rounded-2xl border border-white/8 bg-white/4 hover:border-accent/30 hover:bg-white/7 hover:shadow-[0_0_20px_rgba(255,208,0,0.05)] hover:-translate-y-1 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-5">
                  <service.icon size={22} className="text-accent" />
                </div>
                <h3 className="font-display font-bold text-xl text-white mb-3">{service.title}</h3>
                <p className="text-sm text-white/50 leading-relaxed mb-5">{service.desc}</p>
                <div className="flex flex-wrap gap-2">
                  {service.features.map((feature, j) => (
                    <span
                      key={j}
                      className="px-3 py-1 rounded-full bg-white/8 border border-white/8 text-xs font-medium text-white/60"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-neutral-950 py-16 sm:py-20 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="heading-lg text-white mb-6">
                  How We Build Wellness Programs
                </h2>
                <div className="space-y-4">
                  {[
                    { num: '1', title: 'Wellness Assessment', desc: 'Understanding your property, guest profile, and goals to design aligned wellness offerings.' },
                    { num: '2', title: 'Instructor & Practitioner Sourcing', desc: 'Recruiting experienced yoga teachers, meditation instructors, and healing practitioners for your property.' },
                    { num: '3', title: 'Programming Design', desc: 'Creating daily schedules of yoga, meditation, breathwork, and specialized healing sessions.' },
                    { num: '4', title: 'Space & Logistics', desc: 'Optimizing your property for wellness—yoga studio setup, meditation spaces, treatment areas.' },
                    { num: '5', title: 'Retreat Development', desc: 'Designing complete multi-day wellness retreat packages with integrated meals and experiences.' },
                    { num: '6', title: 'Marketing & Guest Acquisition', desc: 'Positioning your property as a wellness destination and attracting wellness travelers.' },
                  ].map((step, i) => (
                    <div key={i} className="flex items-start gap-4">
                      <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center shrink-0">
                        <span className="font-display font-bold text-sm text-accent">{step.num}</span>
                      </div>
                      <div>
                        <div className="font-display font-bold text-white text-sm">{step.title}</div>
                        <div className="text-xs text-white/40 mt-0.5">{step.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div className="p-7 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="font-display font-bold text-white text-xl mb-6">
                    Wellness Offerings & Experiences
                  </h3>
                  <ul className="space-y-3">
                    {[
                      'Daily yoga classes (various styles)',
                      'Meditation and mindfulness sessions',
                      'Breathwork and pranayama workshops',
                      'Sound healing and gong baths',
                      'Reiki and energy healing',
                      'Ayurvedic therapies and consultations',
                      'Massage and holistic bodywork',
                      'Nutrition and wellness coaching',
                      'Digital detox and silent retreats',
                      'Nature-based wellness walks and experiences',
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 shrink-0" />
                        <span className="text-sm text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-neutral-900 py-16 sm:py-20 relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-30" />
          <div className="section-max section-padding relative">
            <h2 className="heading-lg text-center text-white mb-12">
              Wellness Tourism FAQs — Goa
            </h2>
            <div className="max-w-3xl mx-auto space-y-3">
              {faqs.map((faq, i) => (
                <div
                  key={i}
                  className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden"
                >
                  <button
                    onClick={() => setOpenIdx(openIdx === i ? null : i)}
                    className="w-full flex items-center justify-between p-5 sm:p-6 text-left"
                    aria-expanded={openIdx === i}
                  >
                    <span className="font-display font-bold text-base sm:text-lg text-white pr-4">
                      {faq.q}
                    </span>
                    <ChevronDown
                      size={20}
                      className={`shrink-0 text-white/40 transition-transform duration-300 ${
                        openIdx === i ? 'rotate-180 text-accent' : ''
                      }`}
                    />
                  </button>
                  <div
                    className={`overflow-hidden transition-all duration-300 ${
                      openIdx === i ? 'max-h-48' : 'max-h-0'
                    }`}
                  >
                    <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-sm sm:text-base text-white/50 leading-relaxed">
                      {faq.a}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-neutral-950 py-16 sm:py-20 text-center relative overflow-hidden">
          <div className="absolute inset-0 section-grid opacity-40" />
          <div className="section-max section-padding relative">
            <h2 className="heading-lg text-white mb-4">
              Become a Wellness Destination in Goa
            </h2>
            <p className="text-white/50 mb-8 max-w-xl mx-auto">
              Let The OTA Studio help you attract wellness travelers seeking transformation.
              Create authentic experiences that generate premium revenue and loyal guests.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <a
                href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20offer%20wellness%20experiences%20at%20my%20property"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
              >
                Launch Wellness Programming
              </a>
              <a href="/" className="btn-secondary">
                Back to Home
              </a>
            </div>
          </div>
        </div>
      </article>
    </PageLayout>
  );
}
