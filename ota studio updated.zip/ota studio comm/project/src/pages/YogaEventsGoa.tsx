import { useState } from 'react';
import { ChevronDown, CircleCheck as CheckCircle2, ArrowRight, Wind } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FloatingContact from '../components/FloatingContact';
import GrowthDashboard from '../components/GrowthDashboard';

const faqs = [
  { q: 'How do yoga events benefit hospitality venues?', a: 'Yoga events attract wellness-focused guests, create unique experiences, and drive consistent attendance. They position your venue as a wellness destination and generate additional revenue.' },
  { q: 'What types of yoga events work best?', a: 'Morning sunrise yoga on beaches, hatha and vinyasa classes, yoga retreats, partner yoga experiences, and meditation sessions all work well at hospitality venues in Goa.' },
  { q: 'Who are the guests at yoga events?', a: 'Tourists seeking wellness experiences, local yoga practitioners, wellness enthusiasts, and corporate team builders. These guests typically spend well and return frequently.' },
  { q: 'Can yoga events create recurring revenue?', a: 'Yes. Weekly yoga classes, monthly retreats, and seasonal wellness events create predictable recurring revenue and build a wellness community.' },
  { q: 'How do you coordinate yoga instructors?', a: 'Our network includes certified yoga instructors across Goa. We handle booking, scheduling, and coordination for professional, consistent classes.' },
  { q: 'What is the atmosphere like for yoga events?', a: 'Peaceful, professional, and welcoming. We ensure proper space, equipment, sound, and ambiance to support meaningful yoga experiences that guests love.' },
];

const services = [
  'Yoga instructor and instructor network',
  'Class scheduling and coordination',
  'Retreat planning and execution',
  'Studio space design consultation',
  'Equipment provision and setup',
  'Member community building',
  'Event promotion and marketing',
  'Monthly wellness reporting',
];

const eventTypes = [
  'Morning yoga classes',
  'Sunset beach yoga',
  'Yoga retreats',
  'Partner and couples yoga',
  'Meditation sessions',
  'Hatha and vinyasa classes',
  'Breathwork workshops',
  'Wellness weekends',
];

export default function YogaEventsGoa() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main className="pt-16 sm:pt-20">
        <article itemScope itemType="https://schema.org/Service">
          <div className="relative overflow-hidden bg-neutral-950 py-20">
            <div className="absolute inset-0 section-grid opacity-40" />
            <div className="section-max section-padding relative">
              <nav className="text-sm text-white/50 mb-6" aria-label="Breadcrumb">
                <ol className="flex items-center gap-2" itemScope itemType="https://schema.org/BreadcrumbList">
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem">
                    <a href="/" itemProp="item" className="hover:text-white">
                      <span itemProp="name">Home</span>
                    </a>
                  </li>
                  <li>/</li>
                  <li itemProp="itemListElement" itemScope itemType="https://schema.org/ListItem" className="text-white"><span itemProp="name">Yoga Events Goa</span></li>
                </ol>
              </nav>
              <span className="badge bg-accent/10 text-accent border border-accent/20 mb-5">Yoga Events · Goa</span>
              <h1 className="heading-xl text-white mb-4" itemProp="name">Yoga Events Goa</h1>
              <p className="body-lg text-lg max-w-3xl mb-8" itemProp="description">
                Wellness-focused yoga events at hotels, resorts, and hospitality venues in Goa. Professional instruction, retreat programming, and community building for venues seeking wellness experiences.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%20want%20to%20host%20yoga%20events" target="_blank" rel="noopener noreferrer" className="btn-primary group">
                  Host Yoga Events <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </a>
                <a href="https://wa.me/919309706263?text=Hi%2C%20I%27d%20like%20to%20plan%20a%20wellness%20program" target="_blank" rel="noopener noreferrer" className="btn-secondary">
                  Plan Wellness Program
                </a>
              </div>
            </div>
          </div>

          <GrowthDashboard />

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <div className="grid lg:grid-cols-2 gap-12">
                <div>
                  <h2 className="heading-lg text-white mb-6">What We Deliver</h2>
                  <p className="body-md mb-8">Complete yoga event and wellness program service.</p>
                  <ul className="space-y-3">
                    {services.map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 size={18} className="text-accent mt-0.5 shrink-0" />
                        <span className="text-white/70">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-8 rounded-2xl bg-neutral-950 border border-white/8">
                  <div className="flex items-center gap-3 mb-6">
                    <Wind size={24} className="text-accent" />
                    <h3 className="font-display font-bold text-xl text-white">Event Types</h3>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {eventTypes.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-white/70">
                        <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                        {item}
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { metric: '200+', label: 'Classes Taught' },
                      { metric: '30%', label: 'Revenue Increase' },
                      { metric: '15+', label: 'Instructors' },
                      { metric: '92%', label: 'Guest Satisfaction' },
                    ].map((r, i) => (
                      <div key={i} className="p-4 rounded-xl bg-white/4 text-center">
                        <div className="font-display font-extrabold text-2xl text-accent">{r.metric}</div>
                        <div className="text-xs text-white/50 mt-1">{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-950 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-8">Yoga & Wellness Program Strategy</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Professional Instruction</h3>
                  <p className="text-white/70 text-sm">Certified yoga instructors deliver authentic, meaningful classes. Quality instruction builds loyal wellness communities.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Wellness Positioning</h3>
                  <p className="text-white/70 text-sm">Position your venue as a wellness destination, attracting guests seeking holistic experiences and healthy lifestyles.</p>
                </div>
                <div className="p-6 rounded-2xl border border-white/8 bg-white/4">
                  <h3 className="heading-md text-white mb-3">Community Wellness</h3>
                  <p className="text-white/70 text-sm">Build wellness communities through consistent classes, retreats, and member programs that create loyalty and recurring revenue.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-center text-white mb-12">Yoga Events FAQs</h2>
              <div className="max-w-3xl mx-auto space-y-3" itemScope itemType="https://schema.org/FAQPage">
                {faqs.map((faq, i) => (
                  <div key={i} className="rounded-2xl border border-white/8 bg-white/4 overflow-hidden" itemScope itemType="https://schema.org/Question">
                    <button onClick={() => setOpenIdx(openIdx === i ? null : i)} className="w-full flex items-center justify-between p-5 sm:p-6 text-left">
                      <span className="font-display font-bold text-white pr-4" itemProp="name">{faq.q}</span>
                      <ChevronDown size={20} className={`shrink-0 text-white/40 transition-transform ${openIdx === i ? 'rotate-180 text-accent' : ''}`} />
                    </button>
                    <div className={`overflow-hidden transition-all ${openIdx === i ? 'max-h-48' : 'max-h-0'}`}>
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 text-white/50" itemProp="acceptedAnswer">{faq.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="bg-neutral-900 py-16 sm:py-20 text-center">
            <div className="section-max section-padding">
              <h2 className="heading-lg text-white mb-4">Build Wellness Experiences at Your Venue</h2>
              <p className="text-white/50 mb-8 max-w-xl mx-auto">Professional yoga programming and wellness events that attract guests and create community.</p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="https://wa.me/919309706263" target="_blank" rel="noopener noreferrer" className="btn-primary">Host Yoga Events</a>
                <a href="/" className="btn-secondary">Back to Home</a>
              </div>
            </div>
          </section>
        </article>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
