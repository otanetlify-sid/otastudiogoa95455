/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          black: '#0B0B0B',
          white: '#FFFFFF',
          yellow: '#FFD000',
        },
        accent: {
          DEFAULT: '#FFD000',
          50: '#FFFBE6',
          100: '#FFF5CC',
          200: '#FFE999',
          300: '#FFE366',
          400: '#FFDD33',
          500: '#FFD000',
          600: '#CCA700',
          700: '#997D00',
          800: '#665400',
          900: '#332A00',
        },
        neutral: {
          950: '#0B0B0B',
          900: '#111111',
          800: '#1A1A1A',
          700: '#2A2A2A',
          600: '#3A3A3A',
          500: '#4A4A4A',
          400: '#5A5A5A',
          300: '#7A7A7A',
          200: '#9A9A9A',
          100: '#BABABA',
          50: '#EAEAEA',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
        display: ['Inter', 'system-ui', 'sans-serif'],
      },
      animation: {
        'fade-up': 'fadeUp 0.6s ease-out forwards',
        'fade-in': 'fadeIn 0.4s ease-out forwards',
        'pulse-glow': 'pulseGlow 3s ease-in-out infinite',
        'float': 'float 6s ease-in-out infinite',
        'marquee': 'marquee 35s linear infinite',
        'ping-slow': 'ping 2s cubic-bezier(0, 0, 0.2, 1) infinite',
      },
      keyframes: {
        fadeUp: {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        pulseGlow: {
          '0%, 100%': { boxShadow: '0 0 20px rgba(255,208,0,0.3), 0 0 40px rgba(255,208,0,0.1)' },
          '50%': { boxShadow: '0 0 30px rgba(255,208,0,0.5), 0 0 60px rgba(255,208,0,0.2)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        marquee: {
          '0%': { transform: 'translateX(0)' },
          '100%': { transform: 'translateX(-50%)' },
        },
      },
    },
  },
  plugins: [],
};
