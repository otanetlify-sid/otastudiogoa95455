#!/bin/bash
# Update community-related phone numbers across all community pages

COMMUNITY_FILES=(
  "src/pages/CommunityActivationGoa.tsx"
  "src/pages/CommunityEventsForHotelsGoa.tsx"
  "src/pages/CommunityEventsGoa.tsx"
  "src/pages/CommunityGrowthForCafes.tsx"
  "src/pages/CommunityGrowthForRestaurants.tsx"
  "src/pages/CommunityManagementGoa.tsx"
  "src/pages/CommunityManagersNetwork.tsx"
  "src/pages/CafeCommunityBuildingGoa.tsx"
  "src/pages/HospitalityCommunityBuildingGoa.tsx"
  "src/pages/CulturalExperiencesGoa.tsx"
  "src/pages/CreativeWorkshopsGoa.tsx"
  "src/pages/HowToBuildACommunityInGoa.tsx"
  "src/pages/HowToRunCommunityEventsForBars.tsx"
  "src/pages/HowToRunCommunityEventsForCafes.tsx"
  "src/pages/HowToRunCommunityEventsForRestaurants.tsx"
  "src/pages/HowToStartCommunityEventsInGoa.tsx"
  "src/pages/BarGrowthGoa.tsx"
  "src/pages/BarMarketingGoa.tsx"
  "src/pages/BarNightlifeMarketingGoa.tsx"
  "src/pages/NightlifeGrowthGoa.tsx"
  "src/pages/LiveMusicEventsGoa.tsx"
  "src/pages/LiveMusicForHospitalityGoa.tsx"
  "src/pages/HowToOrganizeLiveMusicEventsInGoa.tsx"
  "src/pages/HowToStartLiveMusicEventsInGoa.tsx"
  "src/pages/RestaurantEventIdeasGoa.tsx"
  "src/pages/RestaurantMarketingGoa.tsx"
  "src/pages/SoundHealingGoa.tsx"
  "src/pages/ReikiEventsGoa.tsx"
  "src/pages/YogaEventsGoa.tsx"
  "src/pages/HowToHostYogaRetreatsInGoa.tsx"
  "src/pages/HowToStartAYogaSchoolInGoa.tsx"
  "src/pages/WellnessEventsGoa.tsx"
  "src/pages/WellnessTourismGoa.tsx"
  "src/pages/WellnessActivationGoa.tsx"
  "src/pages/HowToOrganizeWellnessEventsInGoa.tsx"
  "src/pages/HowToStartWellnessRetreatInGoa.tsx"
  "src/pages/EventOrganizersNetwork.tsx"
  "src/pages/HospitalityNetworkingEventsGoa.tsx"
  "src/pages/VenueActivationGoa.tsx"
  "src/pages/VenueActivationsGoa.tsx"
  "src/pages/VenuePartners.tsx"
  "src/pages/ActivationPartners.tsx"
  "src/pages/HospitalityActivationGoa.tsx"
  "src/pages/HospitalityActivationsGoa.tsx"
  "src/pages/HospitalityGrowthGoa.tsx"
  "src/pages/HowToCreateHospitalityExperiencesInGoa.tsx"
)

for f in "${COMMUNITY_FILES[@]}"; do
  if [ -f "$f" ]; then
    sed -i \
      -e 's/9270598602/9309706263/g' \
      -e 's/wa\.me\/919270598602/wa.me\/919309706263/g' \
      -e 's/tel:+919270598602/tel:+919309706263/g' \
      "$f"
    echo "Updated: $f"
  else
    echo "Missing: $f"
  fi
done

echo "Done updating community files."
